# eq-document-manager

#When you change on any entity
1. Active com.mysema.maven plugin
2. Generate query dsl entity and paste into com.equabli.common.entity.dsl package.
