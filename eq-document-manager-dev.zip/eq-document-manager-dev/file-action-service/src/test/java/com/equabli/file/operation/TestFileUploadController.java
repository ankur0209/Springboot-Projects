package com.equabli.file.operation;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;
import org.springframework.mock.web.MockMultipartFile;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.configs.BaseConfigService;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.DocType;
import com.equabli.common.entity.Document;
import com.equabli.common.entity.Lookup;
import com.equabli.common.entity.LookupGroup;
import com.equabli.common.entity.RecordStatus;
import com.equabli.common.entity.SendReceiveDocument;
import com.equabli.common.entity.Usage;
import com.equabli.common.enums.RecordStatusCode;
import com.equabli.common.feignclients.CommonConfigService;
import com.equabli.common.repository.DocTypeRepository;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.repository.LookupRepository;
import com.equabli.common.repository.RequireDocRepository;
import com.equabli.common.repository.SentReceiveDocumentRepository;
import com.equabli.common.repository.UsageRepository;
import com.equabli.common.request.FileUploadConfigRequest;
import com.equabli.common.request.RequestNewDocumentRequest;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.FileOperationResponse;
import com.equabli.common.response.RequireDocResponse;
import com.equabli.common.response.UserDetailResponse;
import com.equabli.common.response.UserDetails;
import com.equabli.common.response.UserMailResponse;
import com.equabli.common.response.config.ConfigResponse;
import com.equabli.common.utils.DurationDateUtils;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.file.operation.constants.FileOperationMessageConstants;
import com.equabli.file.operation.feignclient.SentMail;
import com.equabli.file.operation.feignclient.UserService;
import com.equabli.file.operation.integration.accounts.AccountsJson;
import com.equabli.file.operation.response.integrationaccount.AccountsResponse;
import com.equabli.file.operation.response.integrationaccount.ClientResponse;
import com.fasterxml.jackson.core.JsonProcessingException;

@TestInstance(Lifecycle.PER_CLASS)
@TestMethodOrder(OrderAnnotation.class)
class TestFileUploadController extends TestAppConfig{
	
	@Value("${files.upload.baseDir}")
	private String basePath;
	
	public static final String URI = "http://localhost:8082/file/upload";
	private static final String CLIENT = "CT", INVALID_USER_TYPE = "Abc", ORG_TYPE = "orgType", FAILURES = "Failures",
			ACCOUNT_NUMBER = "accountNumber", OTHER = "Other", DOCUMENT_TYPE="docType",APPLICATION_CODE = "AP",
					PROD_CODE = "CC";

	@MockBean(reset = MockReset.BEFORE) 
	FetchTokenData fetchTokenData;
	
	@MockBean
	RequireDocRepository requireDocRepository;
	
	@MockBean
	DocumentRepository documentRepository;
	
	@Autowired
	MessageSupplier messageSupplier;
	
	@MockBean
	SentReceiveDocumentRepository sentReceiveDocumentRepository;
	
	@Autowired
	DocTypeRepository docTypeRepository;
	
	@MockBean 
	private UserService userService;
	
	@MockBean
	private SentMail sentMail;

	@MockBean
	private UsageRepository usageRepository;
	
	@MockBean
	LookupRepository lookupRepository;
	
	@MockBean(reset = MockReset.BEFORE)
	CommonConfigService commonConfigService;
	
	@MockBean
	AccountsJson accountsJson;
	
	@MockBean 
	BaseConfigService baseConfigService;

	@BeforeEach
	public void setTokenData() throws JsonProcessingException {
		Mockito.when(userService.emailExists(any(), any()))
				.thenReturn(convertJsonToString(getListUserDetailResponse()));
		Mockito.when(sentMail.sendEmails(any(), anyList())).thenReturn("Mail Sent");
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
		
		when(commonConfigService.getMappedClientDetail(anyString(), eq("web"), eq(2)))
				.thenReturn(getJsonStringUsingObjectMapper(getConfigResponse()));
		when(accountsJson.getAccounts()).thenReturn(getAccountsList());
		when(baseConfigService.getRecordStatusByShortCode(RecordStatusCode.REJECT)).thenReturn(new RecordStatus());
		Mockito.when(commonConfigService.getToken(any(), any(), any())).thenReturn(getFcmToken());
		Mockito.when(sentMail.sendNotification(any(), any())).thenReturn("send Successfully");
	}
	
	@Test
	void uploadDocument() throws Exception {
		when(documentRepository.findByReceiveFileNameAndIsDeleteFalse("73122-CC-BRA-434-02122023-a.txt"))
				.thenReturn(Arrays.asList(saveDocument()));
		setUsageResult(21l);
		
		String uri = URI;
		MockMultipartFile file = getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("73122-CC-BRA-434-02122023-a.txt").getFile(), true);
		CommonResponse<FileOperationResponse> baseresponse = uploadFileResponseForPost(uri, file, CLIENT);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	@Test
	void uploadSingleDocumentForAccountNo() throws Exception {
		when(documentRepository.findByClientAccountNoAndReceiveFileNameAndIsDeleteFalse("73122",
				"73122-CC-BRA-434-02122023-a.txt")).thenReturn(Arrays.asList(saveDocument()));
		setUsageResult(21l);
		
		String uri = URI + "/account";
		MockMultipartFile file = getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("73122-CC-BRA-434-02122023-a.txt").getFile(), true);
		String data = convertJsonToString(getSingleFileUploadParams("BRA"));
		CommonResponse<FileOperationResponse> baseresponse = uploadFileForAccountNoResponseForPost(uri, file, data);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	@Test
	void uploadMultipleFile() throws Exception {
		when(documentRepository.findByReceiveFileNameAndIsDeleteFalse("73122-CC-BRA-434-02122023-a.txt"))
				.thenReturn(Arrays.asList(saveDocument()));
		setUsageResult(21l);
		
		String uri = URI + "/multiple";
		List<MockMultipartFile> files = new ArrayList<>();
		files.add(getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("hello-ML-AP-434-01052022-Application.txt").getFile(), false));
		files.add(getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("hello1-CC-AP-check-01052022-Application.txt").getFile(), false));
		CommonResponse<FileOperationResponse> baseresponse = uploadMultipleFileResponseForPost(uri, files, CLIENT,
				true);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	@Test
	void uploadMultipleFile_1() throws Exception {
		when(documentRepository.findByReceiveFileNameAndIsDeleteFalse("73122-CC-BRA-434-02122023-a.txt"))
		.thenReturn(Arrays.asList(saveDocument()));
		setUsageResult(21l);
		
		String uri = URI + "/multiple";
		List<MockMultipartFile> files = new ArrayList<>();
		files.add(getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("hello-ML-AP-434-01052022-Application.txt").getFile(),false));
		files.add(getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("hello-ML-AP-434-01052022-Application.txt").getFile(),false));
		files.add(getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("hello-ML-AP-434-01052022-Application.txt").getFile(),false));
		files.add(getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("hello-ML-AP-434-01052022-Application.txt").getFile(),false));
		files.add(getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("hello-ML-AP-434-01052022-Application.txt").getFile(),false));
		files.add(getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("hello-ML-AP-434-01052022-Application.txt").getFile(),false));
		files.add(getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("hello-ML-AP-434-01052022-Application.txt").getFile(),false));
		files.add(getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("hello-ML-AP-434-01052022-Application.txt").getFile(),false));
		files.add(getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("hello-ML-AP-434-01052022-Application.txt").getFile(),false));
		files.add(getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("hello-ML-AP-434-01052022-Application.txt").getFile(),false));
		files.add(getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("hello-ML-AP-434-01052022-Application.txt").getFile(),false));
		CommonResponse<FileOperationResponse> baseresponse = uploadMultipleFileResponseForPost(uri, files,CLIENT,false);
		Assert.assertEquals(CommonResponse.OperationStatus.FAILURE, baseresponse.getStatus());
	}
	
	@Test
	void uploadBulkFile() throws Exception {
		String uri = URI + "/bulk";
		String fileUploadVan = convertJsonToString(getFileUploadParams1("upload"));
		List<MockMultipartFile> bulkFiles = new ArrayList<>();
		bulkFiles.add(getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("matrix.xlsx").getFile(),false));
		bulkFiles.add(getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("matrix.zip").getFile(),false));
		CommonResponse<FileOperationResponse> baseresponse = uploadBulkFileResponseForPost(uri, bulkFiles, fileUploadVan);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	@Test
	void uploadBulkFile_1() throws Exception {
		String uri = URI + "/bulk";
		String fileUploadVan = convertJsonToString(getFileUploadParams1("SendRequestDocument"));
		List<MockMultipartFile> bulkFiles = new ArrayList<>();
		bulkFiles.add(getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("TestSendRequestDoc2.xlsx").getFile(),false));
		CommonResponse<FileOperationResponse> baseresponse = uploadSendRequestResponseForPost(uri, bulkFiles, fileUploadVan);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
//	@Test
//	void handleBulkFile() throws Exception {
//		String uri = URI + "/bulk/read";
//		when(documentRepository.findByReceiveFileNameAndIsDeleteFalse("73122-CC-BRA-434-02122023-a.txt"))
//		.thenReturn(Arrays.asList(saveDocument()));
//		setUsageResult(21l);
//		String excelPath = loadMatrixWithClassPathResource("matrix.xlsx").getFile().getAbsolutePath();
//		String json = convertJsonToString(getFileUploadParams2(excelPath));
//		CommonResponse<FileOperationResponse> baseresponse = getBaseResponseForPOST(uri,json);
//		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
//	}
	
	@Test
	void handleBulkFileInvalid_1() throws Exception {
		when(documentRepository.findByReceiveFileNameAndIsDeleteFalse("73122-CC-BRA-434-02122023-a.txt"))
		.thenReturn(Arrays.asList(saveDocument()));
		setUsageResult(21l);
		String uri = URI + "/bulk/read";
		String excelPath = loadMatrixWithClassPathResource("73122-CC-BRA-434-02122023-a.txt").getFile().getAbsolutePath();
		String json = convertJsonToString(getFileUploadParams2(excelPath));
		CommonResponse<FileOperationResponse> baseresponse = getBaseResponseForPOST(uri,json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	@Test
	void handleBulkFileInvalidHeader() throws Exception {
		when(documentRepository.findByReceiveFileNameAndIsDeleteFalse("73122-CC-BRA-434-02122023-a.txt"))
		.thenReturn(Arrays.asList(saveDocument()));
		setUsageResult(21l);
		String uri = URI + "/bulk/read";
		String excelPath = loadMatrixWithClassPathResource("matrixInvlidHeader.xlsx").getFile().getAbsolutePath();
		String json = convertJsonToString(getFileUploadParams2(excelPath));
		CommonResponse<FileOperationResponse> baseresponse = getBaseResponseForPOST(uri,json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	
	@Test
	void uploadFileForSpecificDocument() throws Exception {

		DurationDateUtils tenture = new DurationDateUtils(null, LocalDateTime.now());
		MockMultipartFile file = getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("matrix2.xlsx").getFile());

		when(requireDocRepository.getByOrgTypeCodeAndDocTypeCodeAndIsDeleteFalse(anyString(), anyString(), any()))
				.thenReturn(getListRequireDocResponse("AP"));
		when(documentRepository.getTotalDocumentSummary("MRLT", "CC", tenture.getFirstDay(),
				tenture.getLastDay(), null, null, Arrays.asList("CC"))).thenReturn(Arrays.asList("CC"));
		
		Document document = new Document();
		document.saveDocument(document, getTokenData(), getTokenData(), "AP", "CC",
				null, file.getName(), file.getSize(), "123456", null, null);
		when(documentRepository.save(document)).thenReturn(document);
		
		when(sentReceiveDocumentRepository.getBySendReceiveDocument(null, null, 1L)).thenReturn(getSendReceiveDocument());
		setUsageResult(21l);
		
		String uri = URI + "/specific/accounts";
		String fileUploadVan = convertJsonToString(getFileUploadParams("AP"));

		CommonResponse<String> commonResponse = uploadSingleFile(uri, file, fileUploadVan);
		Assert.assertEquals(messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.CREATE_SUCCESS),
				commonResponse.getMessage());
	}

	@Test
	void uploadFileForSpecificDocument_1() throws Exception {

		String uri = URI + "/specific/accounts";
		String fileUploadVan = convertJsonToString(getFileUploadParams("invalid"));
		MockMultipartFile file = getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("matrix2.xlsx").getFile());
		setUsageResult(21l);
		
		CommonResponse<String> commonResponse = uploadSingleFile(uri, file, fileUploadVan);
		Assert.assertEquals(messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, " invalid"),
				commonResponse.getErrors().get(0));
	}

	@Test
	void uploadFileForSpecificDocument_2() throws Exception {

		String uri = URI + "/specific/accounts";
		String data = "{invalide data json";
		MockMultipartFile file = getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("matrix2.xlsx").getFile());
		setUsageResult(21l);
		
		CommonResponse<String> commonResponse = uploadSingleFile(uri, file, data);
		Assert.assertEquals("Provide a valid data", commonResponse.getMessage());
	}

	@Test
	void uploadFileForSpecificDocument_3() throws Exception {

		String uri = URI + "/specific/accounts";
		String data = convertJsonToString(getFileUploadParams("AP"));
		setUsageResult(21l);
		
		CommonResponse<String> commonResponse = uploadSingleFile(uri, getMockMultipartFileBlankFile(), data);
		Assert.assertEquals(messageSupplier.get(FileOperationMessageConstants.FILE_NOT_VALID),
				commonResponse.getMessage());
	}
	
	private Map<String, String> getFileUploadParams1(String bulkType){
		Map<String, String> map = new LinkedHashMap<>();
		map.put(ORG_TYPE, CLIENT);
		map.put("bulkType", bulkType);
		return map;
	}
	
	private Map<String, String> getFileUploadParams2(String excelPath) throws IOException{
		String zipPath = loadMatrixWithClassPathResource("matrix.zip").getFile().getAbsolutePath();
		Map<String, String> map = new LinkedHashMap<>();
		map.put("excelUrl", excelPath);
		map.put("zipUrl", zipPath);
		map.put(ORG_TYPE, CLIENT);
		map.put("bulkType", "upload");
		return map;
	}
	
	private Map<String, String> getFileUploadParams(String docTypeCode){
		Map<String, String> map = new LinkedHashMap<>();
		map.put("docTypeCode", docTypeCode);
		return map;
	}
	
	private Map<String, String> getSingleFileUploadParams(String docTypeCode){
		Map<String, String> map = new LinkedHashMap<>();
		map.put("accountNumber", "1122");
		map.put("docType", docTypeCode);
		return map;
	}
	
	private List<RequireDocResponse> getListRequireDocResponse(String docTypecode){
		return Arrays.asList(getRequireDocResponse(docTypecode, "CC"));
	}
	
	private RequireDocResponse getRequireDocResponse(String docTypeCode, String productCode) {
		RequireDocResponse requireDocResponse = new RequireDocResponse();
		requireDocResponse.setDocTypeCode(docTypeCode);
		requireDocResponse.setProductCode(productCode);
		return requireDocResponse;
	}
	
	private Optional<SendReceiveDocument> getSendReceiveDocument(){
		return Optional.of(new SendReceiveDocument());
	}
	
	private Document saveDocument() {
		Document document = new Document();

		FileUploadConfigRequest fileUploadConfigRequest = new FileUploadConfigRequest();
		fileUploadConfigRequest.setClientAccountNo("73122");
		fileUploadConfigRequest.setDocumentGenerationDate(LocalDateTime.now());
		fileUploadConfigRequest.setDocType(APPLICATION_CODE);
		fileUploadConfigRequest.setProductCode(PROD_CODE);
		fileUploadConfigRequest.setFileName("73122-CC-BRA-434-02122023-a.txt");

		DocType docType = docTypeRepository.findByShortCode("AP").orElseThrow();

		document.saveDocument(document, fileUploadConfigRequest, false, null, docType.getName(),  getTokenData(), getTokenData());
		return document;
	}
	
	public RequestNewDocumentRequest getDocumentRequest() {
		RequestNewDocumentRequest requestNewDocumentRequest  = new RequestNewDocumentRequest();
		requestNewDocumentRequest.setClientAccountNumber("1122");
		requestNewDocumentRequest.setOriginalAccountNumber("3344");
		requestNewDocumentRequest.setDocTypeCode("AP");
		requestNewDocumentRequest.setDocumentType("Application");
		return requestNewDocumentRequest;
	}
	
	public UserDetails getUserDetail() {
		UserDetails userDetails = new UserDetails();
		userDetails.setFirstName("Sachin");
		userDetails.setPrincipleId(21L);
		userDetails.setOrgType("CL");
		userDetails.setOrgCode("MRLT");
		return userDetails;
	}
	
	private UserMailResponse getListUserDetailResponse() {
		UserDetailResponse userDetailResponse = new UserDetailResponse();
		userDetailResponse.setIsExists(true);
		userDetailResponse.setMailId("ssingh2@q3tech.com");
		
		UserDetails userDetails = new UserDetails();
		userDetails.setFirstName("Sachin");
		userDetails.setPrincipleId(21L);
		userDetails.setOrgType("CL");
		userDetails.setOrgCode("MRLT");
		userDetailResponse.setUserDetails(userDetails);
		
		UserDetailResponse userDetailResponse2 = new UserDetailResponse();
		userDetailResponse2.setIsExists(true);
		userDetailResponse2.setMailId("abehal@equabli.com");
		UserDetails userDetails2 = new UserDetails();
		userDetails2.setFirstName("Aakash");
		userDetails2.setPrincipleId(9L);
		userDetails2.setOrgType("PT");
		userDetails2.setOrgCode("TRAKA");
		userDetailResponse2.setUserDetails(userDetails2);
		
		UserMailResponse userMailResponse = new UserMailResponse();
		userMailResponse.setError(null);
		userMailResponse.setValidation(true);
		userMailResponse.setMessage("success");
		userMailResponse.setResponse(Arrays.asList(userDetailResponse, userDetailResponse2));
		
		return userMailResponse;
	}
	
	private Usage getusage() {
		Usage usage = new Usage();
		usage.saveUsage(usage, null, null, getTokenData());
		return usage;
	}
	
	private void setUsageResult(Long userId) {
		
		when(usageRepository.findByOrgCode(any())).thenReturn(Optional.of(getusage()));
		when(usageRepository.save(any(Usage.class))).thenReturn(getusage());
		when(lookupRepository.findByLookupGroup_keyvalueAndKeycode(any(), any()))
				.thenReturn(Optional.of(getLookup(MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE)));
		when(lookupRepository.findByUid(any())).thenReturn(Optional.of(getLookup(MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE)));
	}
	
	private Lookup getLookup(String keycode) {
		Lookup lookup = new Lookup();
		lookup.saveLookup(lookup, keycode, "15 GB", new LookupGroup(), getTokenData());
		return lookup;
	}
	
	private static ConfigResponse<ClientResponse> getConfigResponse(){
		return new ConfigResponse<>("Success", ConfigResponse.OperationStatus.SUCCESS,
				new ClientResponse(), true, null);
	}
	
	private static List<AccountsResponse> getAccountsList() {
		AccountsResponse accountsResponse = new AccountsResponse();
		accountsResponse.setClientAccountNumber("1122");
		accountsResponse.setClientName("ABC-ABC ABC");
		accountsResponse.setAccountStatus("NEW");
		AccountsResponse accountsResponse1 = new AccountsResponse();
		accountsResponse1.setClientAccountNumber("73122");
		accountsResponse1.setClientName("ABC-ABC ABC");
		accountsResponse1.setAccountStatus("RCL");
		AccountsResponse accountsResponse2 = new AccountsResponse();
		accountsResponse2.setClientAccountNumber("123456");
		accountsResponse2.setClientName("XYZ-XYZ XYZ");
		accountsResponse2.setAccountStatus("RCL");
		return Arrays.asList(accountsResponse, accountsResponse1, accountsResponse2);
	}
}
