package com.equabli.file.operation;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;

import com.equabli.common.auth.TokenData;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.FileOperationResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.utils.LocalDateDeserializer;
import com.equabli.file.operation.request.UserDocConfigRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.gson.Gson;

@SpringBootTest
@AutoConfigureMockMvc
@ExtendWith(SpringExtension.class)
@ActiveProfiles("test")
public class TestAppConfig {

	public static final String TOKEN = "Bearer eyJhbGciOiJIUzUxMiJ9.eyJhdWQiOiJjaHJvbWUtZXh0ZW5zaW9uOi8vYWljbWtncGdha2RkZ25hcGhoaHBsaWlmcGNmaGljZm8iLCJyZW1vdGUtaXAiOiIwOjA6MDowOjA6MDowOjEiLCJqdGkiOiI4YjcxMmFhMGZiMDhmZjcxMjAxZWJmNWEzMWU1YjY0NDY5MmEyYTQ4ZmM0MWIzMTBiOTkxNmIxODMxMTg4YTA0IiwiYXV0aG9yaXRpZXMiOlsiQ09MT1JfUiIsIkNPTE9SX1ciXSwidXNlci1hZ2VudCI6Ik1vemlsbGEvNS4wIChXaW5kb3dzIE5UIDEwLjA7IFdpbjY0OyB4NjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xMDguMC4wLjAgU2FmYXJpLzUzNy4zNiJ9.gjzYhB6bg4_rtSoiVrsr9uGP9juk53WnJwitStEabtOdlcVaJuJixULUOSghYtB4RjW59K3BpsBcfPa-EQicwQ";
	public static final String AUTHORIZATION = "Authorization";

	@Autowired
	private MockMvc mockMvc;
	
	public static CommonResponse getErrorMessageFromTest(MockHttpServletResponse baseResponseForPOST) throws Exception {
		return new Gson().fromJson(baseResponseForPOST.getContentAsString(), 
				CommonResponse.class);
	}
	 
	public static <T> String convertJsonToString(T element) {
		return new Gson().toJson(element);
	}
	
	public static CommonResponse<?> getBaseResponseFromMockResponse(MockHttpServletResponse baseResponseForPOST) throws Exception {
		return new Gson().fromJson(baseResponseForPOST.getContentAsString(), 
				CommonResponse.class);
	}
	
	public static PagedResponse<?> getPagedResponse(MockHttpServletResponse baseResponseForPOST) throws Exception {
		return new Gson().fromJson(baseResponseForPOST.getContentAsString(), 
				PagedResponse.class);
	}
	
	/**
	 * For POST API
	 * 
	 * @param matcher
	 * @param uri
	 * @param json
	 * @return
	 * @throws Exception
	 */
	public CommonResponse getBaseResponseForPOST(String uri, String json)
			throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(uri).header(AUTHORIZATION, TOKEN)
				.contentType(MediaType.APPLICATION_JSON).content(json);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}
	
	/**
	 * 
	 * @param matcher
	 * @param uri
	 * @param json
	 * @return
	 * @throws Exception
	 */
	public MockHttpServletResponse getBaseResponseForPOST(ResultMatcher matcher, String uri, MultiValueMap<String, String> params)
			throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(uri).header(AUTHORIZATION, TOKEN)
				.params(params);
		MvcResult result = mockMvc.perform(requestBuilder).andExpect(matcher).andReturn();
		return result.getResponse();
	}
	
	public CommonResponse getBaseResponseForPOST(String uri, MultiValueMap<String, String> params)
			throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(uri).header(AUTHORIZATION, TOKEN)
				.contentType(MediaType.APPLICATION_JSON).params(params);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}

	/**
	 * For GET API with parameters
	 * 
	 * @param matcher
	 * @param uri
	 * @param json
	 * @return
	 * @throws Exception
	 */
	public CommonResponse getBaseResponseForGET(String uri,
			MultiValueMap<String, String> params) throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(uri).header(AUTHORIZATION, TOKEN).params(params);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}
	
	/**
	 * For GET API without parameters
	 * 
	 * @param matcher
	 * @param uri
	 * @param json
	 * @return
	 * @throws Exception
	 */
	public CommonResponse getBaseResponseForGET(String uri) throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(uri).header(AUTHORIZATION, TOKEN);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}
	
	public PagedResponse getPagedResponseForGET(String uri,
			MultiValueMap<String, String> params, String json) throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(uri).header(AUTHORIZATION, TOKEN).params(params)
				.contentType(MediaType.APPLICATION_JSON).content(json);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getPagedResponse(result.getResponse());
	}
	
	public CommonResponse<FileOperationResponse> uploadFileResponseForPost(String uri, MockMultipartFile file,
			String client) throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.multipart(uri).file(file).header(AUTHORIZATION, TOKEN)
				.param("orgType", client).contentType(MediaType.MULTIPART_FORM_DATA);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}
	
	public CommonResponse<FileOperationResponse> uploadFileForAccountNoResponseForPost(String uri, MockMultipartFile file,
			String data) throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.multipart(uri).file(file).header(AUTHORIZATION, TOKEN)
				.param("data", data).contentType(MediaType.MULTIPART_FORM_DATA);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}

	public CommonResponse<FileOperationResponse> uploadMultipleFileResponseForPost(String uri,
			List<MockMultipartFile> file, String client, boolean checkForLargeNoOfFile) throws Exception {
		MockHttpServletRequestBuilder builder = null;
		if(checkForLargeNoOfFile)
			builder = MockMvcRequestBuilders.multipart(uri).file(file.get(0))
				.file(file.get(1));
		else
			builder = MockMvcRequestBuilders.multipart(uri).file(file.get(0))
			.file(file.get(1)).file(file.get(2)).file(file.get(3)).file(file.get(4)).file(file.get(5)).file(file.get(6))
			.file(file.get(7)).file(file.get(8)).file(file.get(9)).file(file.get(10));
		MvcResult result = mockMvc.perform(builder.header(AUTHORIZATION, TOKEN).param("orgType", client)).andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}

	
	public CommonResponse<FileOperationResponse> uploadBulkFileResponseForPost(String uri, List<MockMultipartFile> file,
			String json) throws Exception {
		MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.multipart(uri).file(file.get(0))
				.file(file.get(1));
		MvcResult result = mockMvc.perform(builder.header(AUTHORIZATION, TOKEN).param("fileUploadVan", json))
				.andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}

	public Resource loadMatrixWithClassPathResource(String fileName) {
	    return new ClassPathResource("data/" + fileName);
	}
	
	public MultipartFile getMultipartFileFromFile(File file) throws FileNotFoundException, IOException {
	    return new MockMultipartFile(file.getName(), new FileInputStream(file));
	}
	
	public MockMultipartFile getMockMultipartFileFromFile(File file, Boolean isSingleFile) throws FileNotFoundException, IOException {
		String fileVal =  isSingleFile ? "file" : "files";
		return new MockMultipartFile(fileVal, file.getName(),null, new FileInputStream(file));
	}
	
	public CommonResponse<String> uploadSingleFile(String uri, MockMultipartFile file,
			String json) throws Exception {
		MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.multipart(uri).file(file);
		MvcResult result = mockMvc.perform(builder.header(AUTHORIZATION, TOKEN).param("data", json))
				.andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}
	
	public MockMultipartFile getMockMultipartFileFromFile(File file) throws FileNotFoundException, IOException {
		return new MockMultipartFile("file", file.getName(),null, new FileInputStream(file));
	}
	
	public MockMultipartFile getMockMultipartFileBlankFile() throws FileNotFoundException, IOException {
		return new MockMultipartFile("file", "".getBytes());
	}
	
	public static UserDocConfigRequest getUserDocConfigRequest(String docMrgConfig, String docMrgConfigVal, String orgType) {
		UserDocConfigRequest userDocConfigRequest = new UserDocConfigRequest();
		userDocConfigRequest.setConfigShortCode(docMrgConfig);
		userDocConfigRequest.setConfigValShortCode(docMrgConfigVal);
		userDocConfigRequest.setOrgTypeCode(orgType);
		return userDocConfigRequest;
	}
	
	public static TokenData getTokenData() {
		TokenData tokenData = new TokenData();
		tokenData.setPrincipleId(21L);
		tokenData.setLoginKey("ssingh2@q3tech.com");
		tokenData.setFirstName("Sachin");
		tokenData.setEmailAddress("ssingh2@q3tech.com");
		tokenData.setOrgType("CL");
		tokenData.setUserOrgCode("MRLT");
		tokenData.setUserOrgId(2);
		tokenData.setUserOrgName("XYZ Bank");
		tokenData.setToken("eyJhbGciOiJSUzI1NiJ9.eyJwcmluY2lwbGUiOnsicHJpbmNpcGxlSWQiOjIxLCJ1aWQiOiIwNmEyZGExOS02N2NiLTQ5ODYtODRiMC1hODE4Y2U5NWJkZTEiLCJsb2dpbktleSI6InNzaW5naDJAcTN0ZWNoLmNvbSIsImxvZ2luU2VjcmV0IjoiJDJhJDEwJE9SZzNJM2NucW9CRjN6a1NUeUtlNU9KSUdjYy9PMkJ1SHZwanRhSXRVRnpnazdYTUp6OE0yIiwibmV3TG9naW5TZWNyZXQiOm51bGwsImZpcnN0TmFtZSI6IlNhY2hpbiIsIm1pZGRsZU5hbWUiOiIiLCJsYXN0TmFtZSI6IiIsImVtYWlsQWRkcmVzcyI6InNzaW5naDJAcTN0ZWNoLmNvbSIsImVtYWlsQ29uc2VudCI6bnVsbCwiZW1haWxDb25zZW50RGF0ZSI6bnVsbCwicGhvbmUiOiI3ODI3MzU0OTY4IiwicGhvbmVDb25zZW50IjpudWxsLCJwaG9uZUNvbnNlbnREYXRlIjpudWxsLCJhZGRyZXNzMSI6bnVsbCwiYWRkcmVzczIiOm51bGwsImNpdHkiOm51bGwsInN0YXRlIjpudWxsLCJzdGF0ZU5hbWUiOm51bGwsImNvdW50cnkiOm51bGwsInppcCI6bnVsbCwib3JnVHlwZSI6IkNMIiwicmVjb3JkU291cmNlIjoiQ2xpZW50IiwiY2xpZW50SWQiOjE5LCJwYXJ0bmVySWQiOm51bGwsImNvdW50TG9naW5BdHRlbXB0IjozODQ4LCJjb3VudEZhaWxlZEF0dGVtcHQiOjAsImNsaWVudE5hbWUiOiJNYXJsZXR0IiwicGFydG5lck5hbWUiOm51bGwsImR0bUxvY2siOm51bGwsInJlY29yZFN0YXR1c0lkIjpudWxsLCJyZWNvcmRTdGF0dXMiOiJFbmFibGVkIiwicmVjb3JkU291cmNlSWQiOm51bGwsImFwcElkIjpudWxsLCJzZWNyZXRBbnN3ZXJzIjpudWxsLCJpc1Jlc2V0UmVxdWlyZWQiOm51bGwsInRva2VuIjpudWxsLCJhY2Nlc3NLZXkiOm51bGwsImNyZWF0ZWRCeSI6bnVsbCwidXBkYXRlZEJ5IjpudWxsLCJhdXRoVHlwZSI6bnVsbCwidXNlck9yZ0NvZGUiOiJNUkxUIiwidXNlck9yZ0lkIjoxOSwidXNlck9yZ05hbWUiOiJNYXJsZXR0IiwicHJvZmlsZVBpY3R1cmUiOiJodHRwczovL2VxLWRldi1kbS5zMy5hbWF6b25hd3MuY29tL1Byb2ZpbGUlMjBQaWN0dXJlLzIxL25pY29sYXMtaG9ybi1BUkJRQ2UyR3JqUS11bnNwbGFzaC5qcGc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotRGF0ZT0yMDIzMDYxNVQwNDIzNDBaJlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCZYLUFtei1FeHBpcmVzPTg2Mzk5JlgtQW16LUNyZWRlbnRpYWw9QUtJQVYyVUNWTzc0SUdPTFEyNTQlMkYyMDIzMDYxNSUyRnVzLWVhc3QtMSUyRnMzJTJGYXdzNF9yZXF1ZXN0JlgtQW16LVNpZ25hdHVyZT02YTBkYTE2ZjBkYWE3ZjFjMjFjZjM4NDFkZjRmNmM0OWJjYTI1YTQ1NzE0YmEyZjQzMDE5N2NiMDA4ZTg3MTRlIn0sImtleSI6InNzaW5naDJAcTN0ZWNoLmNvbSIsInN1YiI6InNzaW5naDJAcTN0ZWNoLmNvbSIsImlhdCI6MTY4NjgwMzAyMCwiYXVkIjoiMzFiNDQyOGMtMjc1ZS0xMWVjLTk2MjEtMDI0MmFjMTMwMDAyIiwiZXhwIjoxNjg2ODg5NDIwLCJuYmYiOjE2ODY4MDMwMjB9.S5YHzbZmpKOfK93k_1sJkzkSX5lAR_6Zj9WD3whpau5VgwbnxjAYNjJiSyNk4n6GpjGL0t00xIh9T0NBJOzEJ5xECviNLOtctT9EULffmke0DzxGg19aQP4wvA_LEhQ-6n77MxMIY4GWf9T_CtB_BSl-Hvu7YxcLhv5XdwMib9kjZseBPEPr66kMqtYehmiv34EyLK2CNchw_H1f6-FdqhSxTLUyHc6VYQ7HOgozzfxteKRQA5Q34CRH6BFOT-efQL4OOUVbxuserYWRjh3NbZYINLDP2xgtVk2WkPkiBSP3Mj0Xy8EuRmFhJ7cCAKYsRBcQuY7a3QBPRIol1KaTYg");
		return tokenData;
	}
	
	public CommonResponse<FileOperationResponse> uploadFullfillResponseForPost(String uri, MockMultipartFile file,
			String id) throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.multipart(uri).file(file).header(AUTHORIZATION, TOKEN)
				.param("id", id).contentType(MediaType.MULTIPART_FORM_DATA);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}
	
	public CommonResponse<FileOperationResponse> uploadSendRequestResponseForPost(String uri, List<MockMultipartFile> file,
			String json) throws Exception {
		MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.multipart(uri).file(file.get(0));
		MvcResult result = mockMvc.perform(builder.header(AUTHORIZATION, TOKEN).param("fileUploadVan", json))
				.andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}
	
	public static String getJsonStringUsingObjectMapper(Object value) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		JavaTimeModule javaTimeModule = new JavaTimeModule();
		javaTimeModule.addDeserializer(LocalDate.class, new LocalDateDeserializer());
		objectMapper.registerModule(javaTimeModule);
		return objectMapper.writeValueAsString(value);
	}
	
	public static String getFcmToken() {
		return "{\"message\":\"Web Token fetch successfully\",\"status\":\"SUCCESS\",\"response\":[{\"userId\":21,\"token\":\"d_Ee3a-9Fn_TpuEIjqtCAM:APA91bFW82G9YGNNylBOhv4PS2rSoL6iGiS_614H-WUqmPa1YM3VNlRe1qVvv9DObQ2SHCldDko8cxzxHRmHanAXusHgHABDTBiJVFjz3gtOdfco0lzzxE0WGHzYTPNyXE0SKNeG0Qvm\"}],\"validation\":true} ";
	}
}
