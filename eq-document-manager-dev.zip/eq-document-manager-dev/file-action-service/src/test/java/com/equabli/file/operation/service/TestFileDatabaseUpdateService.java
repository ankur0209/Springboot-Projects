package com.equabli.file.operation.service;

import static org.junit.Assert.assertNotNull;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.entity.DocMgrConfig;
import com.equabli.common.entity.DocMgrConfigVal;
import com.equabli.common.entity.SendReceiveDocument;
import com.equabli.common.entity.UserDocConfig;
import com.equabli.common.enums.FileNameConfigEnum;
import com.equabli.common.repository.DocMgrConfigRepository;
import com.equabli.common.repository.DocMgrConfigValRepository;
import com.equabli.common.repository.UserDocConfigRepository;
import com.equabli.common.request.FileUploadConfigRequest;
import com.equabli.common.utils.ZipUtils;
import com.equabli.file.operation.TestAppConfig;
import com.equabli.file.operation.request.UserDocConfigRequest;
import com.equabli.file.operation.response.FileUploadConfigResponse;

class TestFileDatabaseUpdateService extends TestAppConfig {

	@Autowired private FileUploadDatabaseOperation databaseOperation;
	@Autowired private FileReadOperationService fileReadOperationService;
	@Autowired private DocMgrConfigRepository docMgrConfigRepository;
	@Autowired private DocMgrConfigValRepository docMgrConfigValRepository;
	@Autowired private UserDocConfigRepository userDocConfigRepository;
	@Autowired private AsyncService asyncService;
	
	@Value("${files.upload.baseDir}")
	private String basePath;
	
	private static final String CLIENT = "CT", INVALID_USER_TYPE = "Abc", ORG_TYPE = "orgTypeCode", MATRIX_FILE_NAME = "matrix.xlsx",
			DOC_TYPE = "AP", PARTNER = "PT";
	
	@MockBean(reset = MockReset.BEFORE) 
	FetchTokenData fetchTokenData;

	@BeforeEach
	public void setTokenData() {
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
	}
	
//	@Test
//	void testReadExcelFile() throws Exception {
//		saveUserFileConfig(getUserDocConfigRequest("CT", true));
//		File excelFile = loadMatrixWithClassPathResource("matrix2.xlsx").getFile();
//		File zipFile = loadMatrixWithClassPathResource("matrix.zip").getFile();
//		String path = ZipUtils.extractZip(zipFile);
//		File[] listFile = asyncService.getListOfFile(new File(path).listFiles());
//		List<String> errorMessage = fileReadOperationService.readExcelFile(excelFile, getRequestParams(null, CLIENT),
//				listFile, fetchTokenData.getTokenData());
//		Assert.assertEquals(3, errorMessage.size());
//		listFile[0].delete();
//	}
//	
//	@Test
//	void testReadExcelFile_1() throws Exception {
//		saveUserFileConfig(getUserDocConfigRequest("CT", true));
//		File excelFile = loadMatrixWithClassPathResource("hello1-CC-check-AP-01052022-Application.txt").getFile();
//		File zipFile = loadMatrixWithClassPathResource("matrix.zip").getFile();
//		String path = ZipUtils.extractZip(zipFile);
//		File[] listFile = asyncService.getListOfFile(new File(path).listFiles());
//		List<String> errorMessage = fileReadOperationService.readExcelFile(excelFile, getRequestParams(null, CLIENT),
//				listFile, fetchTokenData.getTokenData());
//		Assert.assertEquals(0, errorMessage.size());
//		listFile[0].delete();
//	}
//	
//	@Test
//	void tesUploadFilePath() {
//		saveUserFileConfig(getUserDocConfigRequest("CT",true));
//		FileUploadConfigRequest fileUploadConfigRequest = getRequestParams(null,CLIENT);
//		String message = databaseOperation.updateFilePath(fileUploadConfigRequest,fetchTokenData.getTokenData());
//		Assert.assertEquals("Data update successfully", message);
//	}
//	
//	@Test
//	void testHandleFileNamingValidation() {
//		saveUserFileConfig(getUserDocConfigRequest("CT", true));
//		String filename = "hello1-CC-check-AP-01052022-Application-1.txt";
//		FileUploadConfigRequest fileUploadConfigRequest = getRequestParams(filename, CLIENT);
//		FileUploadConfigResponse response = databaseOperation.handleFileNamingValidation(fileUploadConfigRequest,
//				fetchTokenData.getTokenData());
//		assertNotNull(response.getDocumentPolicy());
//	}
//	
//	@Test
//	void testHandleFileNamingValidationInvalid() {
//		saveUserFileConfig(getUserDocConfigRequest("CT", true));
//		String filename = "hello1-CC-check-AP-01052022.txt";
//		FileUploadConfigRequest fileUploadConfigRequest = getRequestParams(filename, CLIENT);
//		FileUploadConfigResponse response = databaseOperation.handleFileNamingValidation(fileUploadConfigRequest,
//				fetchTokenData.getTokenData());
//		assertNotNull(response);
//	}
//	
//	@Test
//	void testSetFieldValueFromFileName() {
//		String filename = "hello1-CC-check-AP-01052022-Application-1.txt";
//		List<UserDocConfig> fileNameConfigs = userDocConfigRepository
//				.findByOrgCodeAndDocMgrConfig_ShortCodeStartsWithAndIsDeleteFalseOrderByDocMgrConfig_ShortCode(
//						fetchTokenData.getTokenData().getUserOrgCode(), FileNameConfigEnum.FIELD.getShortCode());
//		FileUploadConfigRequest fileUploadConfigRequest = getRequestParams(filename,CLIENT);
//		databaseOperation.setFieldValueFromFileName(filename.split("-"), fileNameConfigs, fileUploadConfigRequest);
//		assertNotNull(fileUploadConfigRequest.getClientAccountNo());
//	}
////
////	@Test
////	void testSetFieldValueFromFileName_1() {
////		String filename = "hello1-434243-check-01052022-Application.txt-NA";
////		List<UserDocConfig> fileNameConfigs = userDocConfigRepository
////				.findByOrgCodeAndDocMgrConfig_ShortCodeStartsWithAndIsDeleteFalseOrderByDocMgrConfig_ShortCode(PARTNER, FileNameConfigEnum.FIELD.getShortCode());
////		FileUploadConfigRequest fileUploadConfigRequest = getRequestParams(filename,PARTNER);
////		boolean stat = databaseOperation.getValidateFile(fileUploadConfigRequest, fileNameConfigs, "-");
////		assertNotNull(stat);
////	}
//	
//	private FileUploadConfigRequest getRequestParams(String filename, String orgType) {
//		FileUploadConfigRequest fileUploadConfigRequest = new FileUploadConfigRequest();
//		fileUploadConfigRequest.setOrgType(orgType);
//		fileUploadConfigRequest.setDocType(DOC_TYPE);
//		fileUploadConfigRequest.setFileName(filename);
//		fileUploadConfigRequest.setFilePath("home/Document/abd.txt");
//		fileUploadConfigRequest.setObjKey("home/Document/abd.txt");
//		fileUploadConfigRequest.setDocumentId(1l);
//		return fileUploadConfigRequest;
//	}
	
	private List<UserDocConfigRequest> getUserDocConfigRequest(String orgType,boolean wrongDocumentPolicyp) {

		List<UserDocConfigRequest> userDocConfigRequests = new ArrayList<>();
		if(!orgType.equals("CT")) {
			userDocConfigRequests.add(getUserDocConfigRequest("field1", "CIDSC", orgType));
			userDocConfigRequests.add(getUserDocConfigRequest("field2", "PC", orgType));
			userDocConfigRequests.add(getUserDocConfigRequest("field3", "DT", orgType));
			userDocConfigRequests.add(getUserDocConfigRequest("field4", "CAN", orgType));
			userDocConfigRequests.add(getUserDocConfigRequest("field5", "OAN", orgType));
			userDocConfigRequests.add(getUserDocConfigRequest("field6", "DGD", orgType));
			userDocConfigRequests.add(getUserDocConfigRequest("field7", "DN", orgType));
		}else {
			userDocConfigRequests.add(getUserDocConfigRequest("field1", "CAN", orgType));
			userDocConfigRequests.add(getUserDocConfigRequest("field2", "PC", orgType));
			userDocConfigRequests.add(getUserDocConfigRequest("field3", "OAN", orgType));
			userDocConfigRequests.add(getUserDocConfigRequest("field4", "DT", orgType));
			userDocConfigRequests.add(getUserDocConfigRequest("field5", "DGD", orgType));
			userDocConfigRequests.add(getUserDocConfigRequest("field6", "DN", orgType));
			userDocConfigRequests.add(getUserDocConfigRequest("DP", "RE", orgType));
			userDocConfigRequests.add(getUserDocConfigRequest("RP", "60", orgType));
		}
		userDocConfigRequests.add(getUserDocConfigRequest("SEPARATOR", "-", orgType));
		return userDocConfigRequests;
	}
	
	private void saveUserFileConfig(List<UserDocConfigRequest> userDocConfigRequestList) {
		for (UserDocConfigRequest userDocConfigRequest : userDocConfigRequestList) {

			Optional<DocMgrConfig> docMgrConfig = docMgrConfigRepository.findByShortCodeAndOrgTypeCode(userDocConfigRequest.getConfigShortCode(),
					userDocConfigRequest.getOrgTypeCode());
			Optional<DocMgrConfigVal> docMgrConfigVal = docMgrConfigValRepository.findByShortCodeAndDocMgrConfig_Id(
					userDocConfigRequest.getConfigValShortCode(), docMgrConfig.get().getId());

			UserDocConfig userDocConfig = userDocConfigRepository
					.findByOrgCodeAndDocMgrConfig(userDocConfigRequest.getOrgTypeCode(), docMgrConfig.get())
					.orElse(new UserDocConfig());

			userDocConfig.saveUserDocConfig(userDocConfig, docMgrConfig.get(), docMgrConfigVal.get(),
					fetchTokenData.getTokenData());
			userDocConfig = userDocConfigRepository.save(userDocConfig);
		}
	}
	
	private void saveSendReceiveRequest() {
		SendReceiveDocument sendReceiveDocument = new SendReceiveDocument();
	}
	
}
