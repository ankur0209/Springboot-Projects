package com.equabli.file.operation.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.equabli.file.operation.TestAppConfig;
import com.equabli.file.operation.integration.accounts.AccountsJson;

class AccountJsonTest extends TestAppConfig {

	@Autowired
	private AccountsJson accountsJson;

//	@Test
//	void getAccountList() throws FileNotFoundException, IOException {
//
//		assertEquals(5, accountsJson.getAccounts().size());
//	}
}
