//package com.equabli.file.operation.controller;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//
//import java.time.LocalDateTime;
//import java.util.Arrays;
//import java.util.Collections;
//import java.util.List;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mockito;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.boot.test.mock.mockito.MockReset;
//import org.springframework.util.LinkedMultiValueMap;
//import org.springframework.util.MultiValueMap;
//
//import com.equabli.common.auth.FetchTokenData;
//import com.equabli.common.constants.MessageConstants;
//import com.equabli.common.entity.DocType;
//import com.equabli.common.entity.Document;
//import com.equabli.common.repository.DocTypeRepository;
//import com.equabli.common.repository.DocumentRepository;
//import com.equabli.common.request.FileUploadConfigRequest;
//import com.equabli.common.request.ShiftDocumentRequest;
//import com.equabli.common.response.CommonResponse;
//import com.equabli.common.utils.MessageSupplier;
//import com.equabli.file.operation.TestAppConfig;
//import com.equabli.file.operation.constants.FileOperationMessageConstants;
//
//class TestShiftDocumentController extends TestAppConfig {
//
//	private static final String URI = "http://localhost:8081/file/document";
//
//	@Autowired
//	private MessageSupplier messageSupplier;
//
//	@MockBean(reset = MockReset.BEFORE)
//	FetchTokenData fetchTokenData;
//
//	@MockBean
//	DocumentRepository documentRepository;
//	
//	@Autowired
//	DocTypeRepository docTypeRepository;
//
//	@BeforeEach
//	public void setTokenData() {
//		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
//	}
//	
//	@Test
//	void shiftAccount() throws Exception {
//
//		Mockito.when(documentRepository.findByUserIdAndOrgTypeCodeAndOrgCodeAndClientAccountNoAndIsDeleteFalse(21L,
//				"CL", "MRLT", "123456")).thenReturn(getDocumentList());
//		
//		String json = convertJsonToString(getShiftDocumentRequest("PT"));
//
//		@SuppressWarnings("unchecked")
//		CommonResponse<String> commonResponse = getBaseResponseForPOST(URI + "/shift", json);
//		assertEquals(messageSupplier.get(FileOperationMessageConstants.ShiftDocument.DOCUMENT_SHIFT_SUCCESS),
//				commonResponse.getMessage());
//	}
//	
//	@Test
//	void recallAccount() throws Exception {
//		String uri = URI + "/recallAccount";
//		Mockito.when(documentRepository.getDocumentList("123456","TRAKA")).thenReturn(getDocumentList());
//		MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
//		params.add("accountNumber", "123456");
//		params.add("orgCode", "TRAKA");
//		@SuppressWarnings("unchecked")
//		CommonResponse<String> commonResponse = getBaseResponseForPOST(uri, params);
//		assertEquals(messageSupplier.get(FileOperationMessageConstants.ShiftDocument.DOCUMENT_REVOKE_SUCCESS),
//				commonResponse.getMessage());
//	}
//	
//	@Test
//	void recallAccount_1() throws Exception {
//		String uri = URI + "/recallAccount";
//		Mockito.when(documentRepository.getDocumentList("123456","TRAKA")).thenReturn(Collections.EMPTY_LIST);
//		MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
//		params.add("accountNumber", "123456");
//		params.add("orgCode", "TRAKA");
//		@SuppressWarnings("unchecked")
//		CommonResponse<String> commonResponse = getBaseResponseForPOST(uri, params);
//		assertEquals(messageSupplier.get(MessageConstants.NOT_VALID_ACCOUNT_NUMBER, "123456"),
//				commonResponse.getMessage());
//	}
//	
//	private ShiftDocumentRequest getShiftDocumentRequest(String toOrgTypeCode) {
//		ShiftDocumentRequest shiftDocumentRequest = new ShiftDocumentRequest();
//		shiftDocumentRequest.setFromOrgTypeCode("CL");
//		shiftDocumentRequest.setFromOrgCode("MRLT");
//		shiftDocumentRequest.setFromUserId(21L);
//		shiftDocumentRequest.setToOrgTypeCode(toOrgTypeCode);
//		shiftDocumentRequest.setToOrgCode("TRAKA");
//		shiftDocumentRequest.setToUserId(9L);
//		shiftDocumentRequest.setAccountNumber(Arrays.asList("123456"));
//		return shiftDocumentRequest;
//	}
//	
//	private ShiftDocumentRequest getRevokeDocumentRequest(String toOrgTypeCode) {
//		ShiftDocumentRequest shiftDocumentRequest = new ShiftDocumentRequest();
//		shiftDocumentRequest.setFromOrgTypeCode(toOrgTypeCode);
//		shiftDocumentRequest.setFromOrgCode("TRAKA");
//		shiftDocumentRequest.setFromUserId(9L);
//		shiftDocumentRequest.setToOrgTypeCode("CL");
//		shiftDocumentRequest.setToOrgCode("MRLT");
//		shiftDocumentRequest.setToUserId(21L);
//		shiftDocumentRequest.setAccountNumber(Arrays.asList("123456"));
//		return shiftDocumentRequest;
//	}
//
//	private List<Document> getDocumentList() {
//		ShiftDocumentRequest shiftDocumentRequest = getShiftDocumentRequest("PT");
//		String objectKey = "Client/MRLT/Media/Document/123456/CC/456789/AP/one.png";
//		Document document = new Document();
//		Document toDocument = new Document();
//		
//		document.saveObjectKey(document, objectKey, objectKey);
//		toDocument.saveDocument(document, toDocument, shiftDocumentRequest.getToUserId(),
//				shiftDocumentRequest.getToOrgTypeCode(), shiftDocumentRequest.getToOrgCode(), getTokenData());
//
//		return Arrays.asList(toDocument);
//	}
//	
//	private Document saveDocument(boolean isDelete) {
//		Document document = new Document();
//
//		FileUploadConfigRequest fileUploadConfigRequest = new FileUploadConfigRequest();
//		fileUploadConfigRequest.setClientAccountNo("1122");
//		fileUploadConfigRequest.setDocumentGenerationDate(LocalDateTime.now());
//		fileUploadConfigRequest.setDocType("AP");
//		fileUploadConfigRequest.setProductCode("CC");
//		fileUploadConfigRequest.setFileName("73122-CC-BRA-434-02122023-a.txt");
//
//		DocType docType = docTypeRepository.findByShortCode("AP").orElseThrow();
//
//		document.saveDocument(document, fileUploadConfigRequest, false, null, docType.getName(),  getTokenData(), getTokenData());
//		if(isDelete)
//			document.deleteDocument(document, getTokenData());
//		return document;
//	}
//}
