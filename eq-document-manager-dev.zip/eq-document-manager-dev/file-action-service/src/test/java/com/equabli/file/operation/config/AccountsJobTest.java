package com.equabli.file.operation.config;

import java.time.LocalDateTime;
import java.time.ZoneId;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.scheduling.support.CronExpression;

import com.equabli.file.operation.TestAppConfig;
import com.equabli.file.operation.integration.accounts.AccountIntegration;

import lombok.extern.slf4j.Slf4j;

@Slf4j
class AccountsJobTest extends TestAppConfig {

	private final ZoneId timezone = ZoneId.of("UTC");

	@MockBean
	AccountIntegration accountIntegration;

	@Test
	void testAccountCronJob() {

		int MAX_RUNS = 5;
		CronExpression generator = CronExpression.parse(AccountsJob.ACCOUNTS_CRON);
		LocalDateTime now = LocalDateTime.now(timezone);

		for (int i = 0; i < MAX_RUNS; i++) {
			LocalDateTime nextRun = generator.next(now);
			log.info(nextRun.toString());
			now = nextRun;
		}
	}
}
