package com.equabli.file.operation.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Optional;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;
import org.springframework.mock.web.MockMultipartFile;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.DocType;
import com.equabli.common.entity.Document;
import com.equabli.common.entity.Lookup;
import com.equabli.common.entity.LookupGroup;
import com.equabli.common.entity.SendReceiveDocument;
import com.equabli.common.entity.Usage;
import com.equabli.common.enums.DocumentRequestStatusEnum;
import com.equabli.common.feignclients.CommonConfigService;
import com.equabli.common.repository.DocTypeRepository;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.repository.LookupRepository;
import com.equabli.common.repository.SentReceiveDocumentRepository;
import com.equabli.common.repository.UsageRepository;
import com.equabli.common.request.FileUploadConfigRequest;
import com.equabli.common.request.RequestNewDocumentRequest;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.FileOperationResponse;
import com.equabli.common.response.UserDetailResponse;
import com.equabli.common.response.UserDetails;
import com.equabli.common.response.UserMailResponse;
import com.equabli.common.response.config.ConfigResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.file.operation.TestAppConfig;
import com.equabli.file.operation.feignclient.SentMail;
import com.equabli.file.operation.feignclient.UserService;
import com.equabli.file.operation.response.integrationaccount.ClientResponse;
import com.fasterxml.jackson.core.JsonProcessingException;

@TestInstance(Lifecycle.PER_CLASS)
@TestMethodOrder(OrderAnnotation.class)
class TestFullfillmentDocument extends TestAppConfig{

	@Value("${files.upload.baseDir}")
	private String basePath;
	
	public static final String URI = "http://localhost:8082/file/upload";
	@Autowired
	MessageSupplier messageSupplier;
	
	@MockBean
	SentReceiveDocumentRepository sentReceiveDocumentRepository;
	
	@MockBean
	DocumentRepository documentRepository;
	
	@MockBean(reset = MockReset.BEFORE) 
	FetchTokenData fetchTokenData;
	
	@MockBean
	private UsageRepository usageRepository;
	
	@MockBean
	LookupRepository lookupRepository;
	
	@MockBean(reset = MockReset.BEFORE)
	CommonConfigService commonConfigService;
	
	@Autowired
	DocTypeRepository docTypeRepository;
	
	@MockBean 
	private UserService userService;
	
	@MockBean
	private SentMail sentMail;
	
	@BeforeEach
	public void setTokenData() throws JsonProcessingException {
		Mockito.when(userService.emailExists(any(), any()))
				.thenReturn(convertJsonToString(getListUserDetailResponse()));
		Mockito.when(sentMail.sendEmails(any(), anyList())).thenReturn("Mail Sent");
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
		
		when(commonConfigService.getMappedClientDetail(anyString(), eq("web"), eq(2)))
				.thenReturn(getJsonStringUsingObjectMapper(getConfigResponse()));
	}
	@Test
	void testFullfillDocument() throws Exception {
		when(sentReceiveDocumentRepository.findById(1l)).thenReturn(Optional.of(sentReceiveDocument()));
		when(documentRepository.findProductCodeDistinctByClientAccountNo("1122")).thenReturn(Arrays.asList("CC"));
		when(documentRepository.findByClientAccountNoAndReceiveFileNameAndIsDeleteFalse("1122",
				"73122-CC-BRA-434-02122023-a.txt")).thenReturn(Arrays.asList(saveDocument()));
		setUsageResult(21l);
		String uri = URI + "/fullfill";
		MockMultipartFile file = getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("73122-CC-BRA-434-02122023-a.txt").getFile(),true);
		CommonResponse<FileOperationResponse> baseresponse = uploadFullfillResponseForPost(uri, file, "1");
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	@Test
	void testFullfillDocumentInvalidData() throws Exception {
		when(sentReceiveDocumentRepository.findById(1l)).thenReturn(Optional.of(sentReceiveDocument()));
		when(documentRepository.findProductCodeDistinctByClientAccountNo("1122")).thenReturn(Arrays.asList("CC"));
		when(documentRepository.findByClientAccountNoAndReceiveFileNameAndIsDeleteFalse("1122",
				"73122-CC-BRA-434-02122023-a.txt")).thenReturn(Arrays.asList(saveDocument()));
		setUsageResult(21l);
		
		when(sentReceiveDocumentRepository.findById(1l)).thenReturn(Optional.of(sentReceiveDocument()));
		
		String uri = URI + "/fullfill";
		MockMultipartFile file = getMockMultipartFileFromFile(
				loadMatrixWithClassPathResource("hello1-CC-AP-check-01052022-Application.txt").getFile(),true);
		CommonResponse<FileOperationResponse> baseresponse = uploadFullfillResponseForPost(uri, file, "15");
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	private void setUsageResult(Long userId) {
		
		when(usageRepository.findByOrgCode(any())).thenReturn(Optional.of(getusage()));
		when(usageRepository.save(any(Usage.class))).thenReturn(getusage());
		when(lookupRepository.findByLookupGroup_keyvalueAndKeycode(any(), any()))
				.thenReturn(Optional.of(getLookup(MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE)));
		when(lookupRepository.findByUid(any())).thenReturn(Optional.of(getLookup(MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE)));
	}
	
	private Lookup getLookup(String keycode) {
		Lookup lookup = new Lookup();
		lookup.saveLookup(lookup, keycode, "15 GB", new LookupGroup(), getTokenData());
		return lookup;
	}
	
	private SendReceiveDocument sentReceiveDocument() {
		SendReceiveDocument sendReceiveDocument = new SendReceiveDocument();
		sendReceiveDocument.saveSendReceiveDocument(sendReceiveDocument, getDocumentRequest(),
				DocumentRequestStatusEnum.OPEN, getTokenData(), getTokenData(), getUserDetail(), 5);
		return sendReceiveDocument;
	}

	public RequestNewDocumentRequest getDocumentRequest() {
		RequestNewDocumentRequest requestNewDocumentRequest  = new RequestNewDocumentRequest();
		requestNewDocumentRequest.setClientAccountNumber("1122");
		requestNewDocumentRequest.setOriginalAccountNumber("3344");
		requestNewDocumentRequest.setDocTypeCode("AP");
		requestNewDocumentRequest.setDocumentType("Application");
		return requestNewDocumentRequest;
	}
	
	public UserDetails getUserDetail() {
		UserDetails userDetails = new UserDetails();
		userDetails.setFirstName("Sachin");
		userDetails.setPrincipleId(21L);
		userDetails.setOrgType("CL");
		userDetails.setOrgCode("MRLT");
		return userDetails;
	}
	
	private Usage getusage() {
		Usage usage = new Usage();
		usage.saveUsage(usage, null, null, getTokenData());
		return usage;
	}
	
	private Document saveDocument() {
		Document document = new Document();

		FileUploadConfigRequest fileUploadConfigRequest = new FileUploadConfigRequest();
		fileUploadConfigRequest.setClientAccountNo("73122");
		fileUploadConfigRequest.setDocumentGenerationDate(LocalDateTime.now());
		fileUploadConfigRequest.setDocType("AP");
		fileUploadConfigRequest.setProductCode("CC");
		fileUploadConfigRequest.setFileName("73122-CC-BRA-434-02122023-a.txt");

		DocType docType = docTypeRepository.findByShortCode("AP").orElseThrow();

		document.saveDocument(document, fileUploadConfigRequest, false, null, docType.getName(),  getTokenData(), getTokenData());
		return document;
	}
	
	private UserMailResponse getListUserDetailResponse() {
		UserDetailResponse userDetailResponse = new UserDetailResponse();
		userDetailResponse.setIsExists(true);
		userDetailResponse.setMailId("ssingh2@q3tech.com");
		
		UserDetails userDetails = new UserDetails();
		userDetails.setFirstName("Sachin");
		userDetails.setPrincipleId(21L);
		userDetails.setOrgType("CL");
		userDetails.setOrgCode("MRLT");
		userDetailResponse.setUserDetails(userDetails);
		
		UserDetailResponse userDetailResponse2 = new UserDetailResponse();
		userDetailResponse2.setIsExists(true);
		userDetailResponse2.setMailId("abehal@equabli.com");
		UserDetails userDetails2 = new UserDetails();
		userDetails2.setFirstName("Aakash");
		userDetails2.setPrincipleId(9L);
		userDetails2.setOrgType("PT");
		userDetails2.setOrgCode("TRAKA");
		userDetailResponse2.setUserDetails(userDetails2);
		
		UserMailResponse userMailResponse = new UserMailResponse();
		userMailResponse.setError(null);
		userMailResponse.setValidation(true);
		userMailResponse.setMessage("success");
		userMailResponse.setResponse(Arrays.asList(userDetailResponse, userDetailResponse2));
		
		return userMailResponse;
	}
	
	private static ConfigResponse<ClientResponse> getConfigResponse(){
		return new ConfigResponse<>("Success", ConfigResponse.OperationStatus.SUCCESS,
				new ClientResponse(), true, null);
	}
}

