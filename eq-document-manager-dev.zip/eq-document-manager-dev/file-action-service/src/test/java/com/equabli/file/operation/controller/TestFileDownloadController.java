package com.equabli.file.operation.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.entity.Document;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.response.CommonResponse;
import com.equabli.file.operation.TestAppConfig;
import com.equabli.file.operation.request.FileDownloadRequest;
import com.equabli.file.operation.request.FolderDownloadRequest;

class TestFileDownloadController extends TestAppConfig {

	public static final String URI = "http://localhost:8082/file/download";
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	DocumentRepository documentRepository;

	@MockBean(reset = MockReset.BEFORE) 
	FetchTokenData fetchTokenData;

	@BeforeEach
	public void setTokenData() {
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
	}
	
	@Test
	void downloadSendRequestDocFile() throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(URI).header(AUTHORIZATION, TOKEN);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		assertNotNull(result.getResponse().getContentAsString());
		assertEquals("application/vnd.ms-excel", result.getResponse().getContentType());
	}
	
	@Test
	void generatePresignUrl() throws Exception{
		String uri = URI+"/presignUrl";
		MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>(2);
		multiValueMap.add("objectKey", "/asd/ads/a.txt");
		multiValueMap.add("fileSize", "2154");
		@SuppressWarnings("unchecked")
		CommonResponse<String> pagedResponse = getBaseResponseForGET(uri, multiValueMap);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}
	
	@Test
	void testDownloadFile() throws Exception {
		String uri = URI+"/file";
		String data = convertJsonToString(getDocumentId());
		
		when(documentRepository.findById(1L)).thenReturn(Optional.of(new Document()));
		@SuppressWarnings("unchecked")
		CommonResponse<String> pagedResponse = getBaseResponseForPOST(uri, data);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}
	
	@Test
	void testDownloadFolder() throws Exception {
		String uri = URI+"/folder";
		String data = convertJsonToString(getAccountNumbers());
		
		when(documentRepository.findById(1L)).thenReturn(Optional.of(new Document()));
		@SuppressWarnings("unchecked")
		CommonResponse<String> pagedResponse = getBaseResponseForPOST(uri, data);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}
	
	private FileDownloadRequest getDocumentId() {
		FileDownloadRequest fileDownloadRequest = new FileDownloadRequest();
		List<Long> documentIds = new ArrayList<>();
		documentIds.add(1l);
		documentIds.add(2l);
		fileDownloadRequest.setDocumentIds(documentIds);
		return fileDownloadRequest;
	}
	
	private FolderDownloadRequest getAccountNumbers() {
		FolderDownloadRequest folderDownloadRequest = new FolderDownloadRequest();
		List<String> accountNumbers = new ArrayList<>();
		accountNumbers.add("123456");
		accountNumbers.add("40050");
		folderDownloadRequest.setAccountNumbers(accountNumbers);
		return folderDownloadRequest;
	}
}
