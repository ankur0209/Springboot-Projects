package com.equabli.file.operation.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.when;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;
import org.springframework.web.multipart.MultipartFile;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.entity.Document;
import com.equabli.common.exception.ExcelReaderException;
import com.equabli.common.feignclients.CommonConfigService;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.repository.SentReceiveDocumentRepository;
import com.equabli.common.request.EmailRequest;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.UserDetailResponse;
import com.equabli.common.response.UserDetails;
import com.equabli.common.response.UserMailResponse;
import com.equabli.common.response.config.ConfigResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.file.operation.TestAppConfig;
import com.equabli.file.operation.constants.FileOperationMessageConstants;
import com.equabli.file.operation.feignclient.SentMail;
import com.equabli.file.operation.feignclient.UserService;
import com.equabli.file.operation.integration.accounts.AccountsJson;
import com.equabli.file.operation.response.RequestDocumentExcelResponse;
import com.equabli.file.operation.response.integrationaccount.AccountsResponse;
import com.equabli.file.operation.response.integrationaccount.ClientResponse;
import com.equabli.file.operation.service.impl.BulkRequestDocumentServiceImpl;

class TestBulkRequestDocumentService extends TestAppConfig {

	@Autowired
	BulkRequestDocumentServiceImpl bulkRequestDocumentService;

	@Autowired
	MessageSupplier messageSupplier;

	@MockBean
	private SentMail sentMail;

	@MockBean
	private UserService userService;

	@MockBean(reset = MockReset.BEFORE)
	FetchTokenData fetchTokenData;

	@MockBean
	CommonConfigService commonConfigService;

	@MockBean
	AccountsJson accountsJson;

	@MockBean
	SentReceiveDocumentRepository sentReceiveDocumentRepository;
	
	@MockBean
	DocumentRepository documentRepository;

	@BeforeEach
	public void setTokenData() {
		Mockito.when(userService.emailExists(any(), any()))
				.thenReturn(convertJsonToString(getListUserDetailResponse()));
		Mockito.when(sentMail.sendEmails(any(), anyList())).thenReturn("Mail Sent");
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());

		Mockito.when(sentReceiveDocumentRepository.saveAll(null)).thenReturn(null);
		Mockito.when(documentRepository.save(new Document())).thenReturn(null);
		when(commonConfigService.getMappedClientDetail(TOKEN, "web", getTokenData().getUserOrgId()))
				.thenReturn(convertJsonToString(getConfigResponse()));
		when(accountsJson.getAccounts()).thenReturn(getAccountsList());
	}

	@ParameterizedTest
	@MethodSource("getSentRequestData")
	void sendRequestDoc_1(String fileName, String expectedMessage, TokenData tokenData)
			throws FileNotFoundException, IOException {

		Mockito.when(fetchTokenData.getTokenData()).thenReturn(tokenData);

		MultipartFile multipartFile = getMultipartFileFromFile(loadMatrixWithClassPathResource(fileName).getFile());

		CommonResponse<List<RequestDocumentExcelResponse>> reponse = bulkRequestDocumentService
				.saveBulkRequestDocument(multipartFile);
		assertEquals(messageSupplier.get(expectedMessage), reponse.getMessage());
	}

	@Test
	void sendRequestDoc_4() {
		assertThrows(ExcelReaderException.class, () -> bulkRequestDocumentService.saveBulkRequestDocument(null),
				messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.EXCEL_FILE_UPLOAD_ERROR));
	}

	static List<Object[]> getSentRequestData() {
		return Arrays.asList(
				new Object[] { "SentRequestValideFile.xlsx",
						FileOperationMessageConstants.FileOperationConfigs.EXCEL_FILE_UPLOAD_SUCCESS, getTokenData() },
				new Object[] { "SentRequestParnter.xlsx",
						FileOperationMessageConstants.FileOperationConfigs.EXCEL_FILE_UPLOAD_SUCCESS,
						getPartnerTokenData() },
				new Object[] { "TestSendRequestDoc3.xlsx",
						FileOperationMessageConstants.FileOperationConfigs.EXCEL_FILE_INVALID_VALUES, getPartnerTokenData() },
				new Object[] { "TestSendRequestDoc2.xlsx",
						FileOperationMessageConstants.FileOperationConfigs.EXCEL_HEADER_NAME_INVALID,
						getPartnerTokenData() });
	}

	public static TokenData getPartnerTokenData() {
		TokenData tokenData = new TokenData();
		tokenData.setPrincipleId(21L);
		tokenData.setLoginKey("ssingh2@q3tech.com");
		tokenData.setFirstName("Sachin");
		tokenData.setEmailAddress("ssingh2@q3tech.com");
		tokenData.setOrgType("PT");
		tokenData.setUserOrgCode("TRAKA");
		tokenData.setUserOrgId(2);
		tokenData.setUserOrgName("XYZ Bank");
		return tokenData;
	}

	private UserMailResponse getListUserDetailResponse() {
		UserDetailResponse userDetailResponse = new UserDetailResponse();
		userDetailResponse.setIsExists(true);
		userDetailResponse.setMailId("ssingh2@q3tech.com");

		UserDetails userDetails = new UserDetails();
		userDetails.setFirstName("Sachin");
		userDetails.setPrincipleId(21L);
		userDetails.setOrgType("CL");
		userDetails.setOrgCode("MRLT");
		userDetailResponse.setUserDetails(userDetails);

		UserDetailResponse userDetailResponse2 = new UserDetailResponse();
		userDetailResponse2.setIsExists(true);
		userDetailResponse2.setMailId("abehal@equabli.com");
		UserDetails userDetails2 = new UserDetails();
		userDetails2.setFirstName("Aakash");
		userDetails2.setPrincipleId(9L);
		userDetails2.setOrgType("PT");
		userDetails2.setOrgCode("TRAKA");
		userDetailResponse2.setUserDetails(userDetails2);

		List<UserDetailResponse> userDetailResponselist = new ArrayList<>();
		userDetailResponselist.addAll(Arrays.asList(userDetailResponse, userDetailResponse2));
		userDetailResponselist.add(getUserDetailResponse("abc@gmail.com", false));
		userDetailResponselist.add(getUserDetailResponse("xyz@gmail.com", false));

		UserMailResponse userMailResponse = new UserMailResponse();
		userMailResponse.setError(null);
		userMailResponse.setValidation(true);
		userMailResponse.setMessage("success");
		userMailResponse.setResponse(userDetailResponselist);

		return userMailResponse;
	}

	private List<EmailRequest> getEmailRequest(String email) {
		return Arrays.asList(EmailRequest.builder().recipients(Arrays.asList(email)).subject("Testing mail")
				.parameters(null).templateName("sample.html").build());
	}

	private UserDetailResponse getUserDetailResponse(String mail, boolean isExists) {
		UserDetailResponse userDetailResponse = new UserDetailResponse();
		userDetailResponse.setIsExists(false);
		userDetailResponse.setMailId(mail);
		return userDetailResponse;
	}

	private static ConfigResponse<ClientResponse> getConfigResponse() {
		return new ConfigResponse<>("Success", ConfigResponse.OperationStatus.SUCCESS, new ClientResponse(), true,
				null);
	}

	private static List<AccountsResponse> getAccountsList() {
		AccountsResponse accountsResponse = new AccountsResponse();
		accountsResponse.setClientAccountNumber("40001");
		accountsResponse.setClientName("ABC-ABC ABC");
		accountsResponse.setAccountStatus("NEW");
		AccountsResponse accountsResponse1 = new AccountsResponse();
		accountsResponse1.setClientAccountNumber("40002");
		accountsResponse1.setClientName("ABC-ABC ABC");
		accountsResponse1.setAccountStatus("RCL");
		AccountsResponse accountsResponse2 = new AccountsResponse();
		accountsResponse2.setClientAccountNumber("123456");
		accountsResponse2.setClientName("XYZ-XYZ XYZ");
		accountsResponse2.setAccountStatus("RCL");
		return Arrays.asList(accountsResponse, accountsResponse1, accountsResponse2);
	}
}
