package com.equabli.file.operation.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.equabli.common.entity.DocType;
import com.equabli.common.entity.DocTypeIdentification;
import com.equabli.common.repository.DocTypeIdentificationRepository;
import com.equabli.file.operation.TestAppConfig;
import com.equabli.file.operation.service.impl.ReadDocumentServiceImpl;

class TestReadDocumentService extends TestAppConfig {

	
	@MockBean
	DocTypeIdentificationRepository docTypeIdentificationRepository;

	@Autowired
	ReadDocumentServiceImpl readDocumentService;

	@Test
	void readDocument() throws FileNotFoundException, IOException {

		File file = loadMatrixWithClassPathResource("ReadFile.pdf").getFile();
		when(docTypeIdentificationRepository.findByIsDeleteFalseOrderByUpdatedAtDesc())
				.thenReturn(Arrays.asList(getDocTypeIdentificationForPdf()));

		Optional<DocType> docTypeOpt = readDocumentService.readDocument(file);
		assertEquals(true, docTypeOpt.isPresent());

	}

	@Test
	void readDocument_1() throws FileNotFoundException, IOException {

		File file = loadMatrixWithClassPathResource("ReadFile.xlsx").getFile();
		when(docTypeIdentificationRepository.findByIsDeleteFalseOrderByUpdatedAtDesc())
				.thenReturn(Arrays.asList(getDocTypeIdentificationForExcel()));

		Optional<DocType> docTypeOpt = readDocumentService.readDocument(file);
		assertEquals(true, docTypeOpt.isPresent());

	}

	@ParameterizedTest
	@ValueSource(strings = {"ReadFile.xlsx", "ReadFile.pdf", "matrix.zip"})
	void readDocument_2(String fileName) throws FileNotFoundException, IOException {
		
		File file = loadMatrixWithClassPathResource(fileName).getFile();
		when(docTypeIdentificationRepository.findByIsDeleteFalseOrderByUpdatedAtDesc())
				.thenReturn(Arrays.asList(getDocTypeIdentification_1()));
		Optional<DocType> docTypeOpt = readDocumentService.readDocument(file);
		assertEquals(true, docTypeOpt.isEmpty());
	}

	private DocTypeIdentification getDocTypeIdentificationForPdf() {
		DocTypeIdentification docTypeIdentification = new DocTypeIdentification();
		docTypeIdentification.saveDocTypeIdentification(docTypeIdentification, new DocType(), getTokenData());
		docTypeIdentification.setIdentificationJson(Arrays.asList("Client Account Number", "Invoice Number"));
		return docTypeIdentification;
	}

	private DocTypeIdentification getDocTypeIdentification_1() {
		DocTypeIdentification docTypeIdentification = new DocTypeIdentification();
		docTypeIdentification.saveDocTypeIdentification(docTypeIdentification, new DocType(), getTokenData());
		docTypeIdentification.setIdentificationJson(Arrays.asList("Test 1", "Test2"));
		return docTypeIdentification;
	}

	private DocTypeIdentification getDocTypeIdentificationForExcel() {
		DocTypeIdentification docTypeIdentification = new DocTypeIdentification();
		docTypeIdentification.saveDocTypeIdentification(docTypeIdentification, new DocType(), getTokenData());
		docTypeIdentification.setIdentificationJson(Arrays.asList("Client Account Number", "Original Account Number"));
		return docTypeIdentification;
	}
}
