//package com.equabli.file.operation.integration;
//
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.when;
//
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.LinkedHashMap;
//import java.util.List;
//import java.util.Map;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.mock.mockito.MockBean;
//
//import com.equabli.common.auth.TokenData;
//import com.equabli.common.configs.BaseConfigService;
//import com.equabli.common.entity.DocType;
//import com.equabli.common.entity.Document;
//import com.equabli.common.feignclients.CommonConfigService;
//import com.equabli.common.repository.DocTypeRepository;
//import com.equabli.common.repository.DocumentRepository;
//import com.equabli.common.request.FileUploadConfigRequest;
//import com.equabli.common.response.ClientSubscription;
//import com.equabli.common.response.PartnerResponse;
//import com.equabli.common.response.config.ConfigResponse;
//import com.equabli.file.operation.TestAppConfig;
//import com.equabli.file.operation.feignclient.UserService;
//import com.equabli.file.operation.integration.accounts.AccountIntegration;
//import com.equabli.file.operation.integration.accounts.AccountsJson;
//import com.equabli.file.operation.response.integrationaccount.ClientAccountsResponse;
//import com.equabli.file.operation.response.integrationaccount.ClientResponse;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//class AccountIntegrationTest extends TestAppConfig {
//
//	@MockBean
//	UserService userService;
//
//	@MockBean
//	CommonConfigService commonConfigService;
//
//	@Autowired
//	AccountIntegration accountIntegration;
//
//	@MockBean
//	AccountsJson accountsJson;
//	
//	@MockBean
//	BaseConfigService baseConfigService;
//	
//	@MockBean
//	DocumentRepository documentRepository;
//	
//	@Autowired
//	DocTypeRepository docTypeRepository;
//	
//	@BeforeEach
//	void commonData() {
//		when(userService.login(any(), any())).thenReturn(convertJsonToString(getConfigResponse()));
//		when(documentRepository.groupByOrgcode()).thenReturn(Arrays.asList("MRLT"));
//		when(commonConfigService.getClientsByShortCode(any(),any(),any())).
//			thenReturn(convertJsonToString(getClientResponse()));
//		when(baseConfigService.getClientSubscriptionResponse(any()))
//				.thenReturn(getSubscribedClientResponseList());
//		when(documentRepository
//				.groupByClientAccountNoByOrgCode("MRLT")).thenReturn(Arrays.asList("40050"));
//	}
//	
//	@Test
//	void testAssignDocument() {
//		List<ClientAccountsResponse> accounts = Arrays.asList(getStaticData());
//		accounts.forEach(account -> {
//			account.setAccountStatus("NEW");
//		});
//		testIntegrationDocument(accounts);
//	}
//	
//	@Test
//	void testReAssignDocument() {
//		List<ClientAccountsResponse> accounts = Arrays.asList(getStaticData());
//		accounts.forEach(account -> {
//			account.setAccountStatus("OPN");
//		});
//		testIntegrationDocument(accounts);
//	}
//	
//	@Test
//	void testRecallDocument() {
//		List<ClientAccountsResponse> accounts = Arrays.asList(getStaticData());
//		accounts.forEach(account -> {
//			account.setAccountStatus("RTR");
//		});
//		
//		when(documentRepository.findByClientAccountNoAndClientOrgCodeAndOrgCodeAndIsDeleteFalse(any(), any(), any()))
//		.thenReturn(Arrays.asList(savePartnersDocument()));
//		testIntegrationDocument(accounts);
//	}
//	
//	@Test
//	void testinvalidAccount() {
//		List<ClientAccountsResponse> accounts = Arrays.asList(getStaticData());
//		accounts.forEach(account -> {
//			account.setAccountStatus("WT");
//		});
//		
//		when(documentRepository.findByClientAccountNoAndClientOrgCodeAndOrgCodeAndIsDeleteFalse(any(), any(), any()))
//		.thenReturn(Arrays.asList(savePartnersDocument()));
//		testIntegrationDocument(accounts);
//	}
//	
//	private void testIntegrationDocument(List<ClientAccountsResponse> accounts) {
//		when(accountsJson.getAccountDetail(19, "40050")).thenReturn(accounts);
//		when(commonConfigService.getPartnersByFullNames(any(), any(), any()))
//				.thenReturn(convertJsonToString(getPartnerResponse()));
//		when(documentRepository.findByClientAccountNoAndOrgCodeAndIsDeleteFalse(any(), any()))
//				.thenReturn(Arrays.asList(saveDocument()));
//			 
//		accountIntegration.integrateAccount();
//		//verify(accountsJson, times(1)).getAccounts();
//	}
//	
//	private static ConfigResponse<TokenData> getConfigResponse() {
//		return new ConfigResponse<>("Success", ConfigResponse.OperationStatus.SUCCESS, getTokenData(), true, null);
//	}
//	
//	private static Map<String, ClientSubscription> getSubscribedClientResponseList() {
//		ClientSubscription subscribedClientResponse = new ClientSubscription();
//		subscribedClientResponse.setClientId(19);
//		subscribedClientResponse.setShortName("MRLT");
//		subscribedClientResponse.setFullName("Marlett");
//		subscribedClientResponse.setAppCodes("ED");
//		
//		Map<String, ClientSubscription> map = new LinkedHashMap<>();
//		map.put("MRLT", subscribedClientResponse);
//		return map;
//	}
//	
//	private static ConfigResponse<List<ClientResponse>> getClientResponse() {
//		return new ConfigResponse<>("Success", ConfigResponse.OperationStatus.SUCCESS, getClient(), true, null);
//	}
//	
//	private static List<ClientResponse> getClient(){
//		List<ClientResponse> clientDetail = new ArrayList<>();
//		ClientResponse clientResponse = new ClientResponse();
//		clientResponse.setClientId(19);
//		clientResponse.setShortName("MRLT");
//		clientResponse.setFullName("Marlett");
//		clientDetail.add(clientResponse);
//		return clientDetail;
//	}
//	
//	private static ConfigResponse<List<PartnerResponse>> getPartnerResponse() {
//		return new ConfigResponse<>("Success", ConfigResponse.OperationStatus.SUCCESS, getPartner(), true, null);
//	}
//	
//	private static List<PartnerResponse> getPartner() {
//		PartnerResponse partnerResponse = new PartnerResponse();
//		partnerResponse.setPartnerId(19);
//		partnerResponse.setShortName("TRAKA");
//		partnerResponse.setFullName("TRAKAmerica");
//		
//		List<PartnerResponse> list = new ArrayList<>();
//		list.add(partnerResponse);
//		return list;
//	}
//
//	private Document saveDocument() {
//		String objKey = "Client/MRLT/Media/Document/40050/CC/50400/AP/05032023/Application.pdf";
//		Document document = new Document();
//
//		FileUploadConfigRequest fileUploadConfigRequest = new FileUploadConfigRequest();
//		fileUploadConfigRequest.setClientAccountNo("40050");
//		fileUploadConfigRequest.setDocumentGenerationDate(LocalDateTime.now());
//		fileUploadConfigRequest.setDocType("AP");
//		fileUploadConfigRequest.setProductCode("CC");
//		fileUploadConfigRequest.setFileName("40050-CC-BRA-50400-02122023-a.txt");
//		fileUploadConfigRequest.setGeneratedFileName("MRLT-Application-20230305-40050-Application.pdf");
//
//		DocType docType = docTypeRepository.findByShortCode("AP").orElseThrow();
//
//		document.saveDocument(document, fileUploadConfigRequest, false, null, docType.getName(),  getTokenData(), getTokenData());
//		document.saveObjectKey(document, objKey, objKey);
//		return document;
//	}
//	
//	private Document savePartnersDocument() {
//		Document document = saveDocument();
//		document.assignDocument(document, getTokenData(), 31l, "PT", "TRAKA");
//		return document;
//	}
//	
//	private ClientAccountsResponse getStaticData() {
//		String data = "{\n"
//				+ " \"accountId\": 13724,\n"
//				+ " \"clientName\": \"Preferred Bank\",\n"
//				+ " \"clientId\": 3,\n"
//				+ " \"consumerName\": \"James Kumar Gupta\",\n"
//				+ " \"consumerId\": 20399,\n"
//				+ " \"equabliAccountNumber\": 13724,\n"
//				+ " \"originalAccountNumber\": \"50400\",\n"
//				+ " \"accountQueue\": \"NEW-Request to Recall\",\n"
//				+ " \"accountStatus\": \"NEW-Request to Recall\",\n"
//				+ " \"productType\": \"CC-Credit Card\",\n"
//				+ " \"chargeOffDate\": \"06-03-2020\",\n"
//				+ " \"chargeOffBalance\": \"$118.13\",\n"
//				+ " \"currentBalance\": \"$248.91\",\n"
//				+ " \"placementId\": 2605,\n"
//				+ " \"originalLender\": \"123 MAIN BANK\",\n"
//				+ " \"delinquencyDate\": \"02-02-2020\",\n"
//				+ " \"compliance\": \"Yes\",\n"
//				+ " \"partnerName\": \"TRAKAmerica\",\n"
//				+ " \"consumerNumber\": 333\n"
//				+ "}";
//		try {
//			return new ObjectMapper().readValue(data, ClientAccountsResponse.class);
//		} catch (JsonProcessingException e) {
//			e.printStackTrace();
//		}
//		return null;
//	}
//	
//}
