INSERT INTO conf.doc_type(
    doc_type_id, dtm_utc_create, name, description, short_code)
    VALUES (1, NOW(), 'Application', 'Application', 'AP'),
    (2, NOW(), 'Bill of Sale', 'Bill of Sale', 'BS'),
    (3, NOW(), 'Business Record Affidavit', 'Business Record Affidavit', 'BRA'),
    (4, NOW(), 'Military Affidavit', 'Military Affidavit', 'MA'),
    (5, NOW(), 'Transaction History', 'Transaction History', 'TH');
    
INSERT INTO conf.doc_mgr_config(
    doc_mgr_config_id, short_code, description, org_type_code, default_value, dtm_utc_create)
    VALUES (1, 'field1', '', 'CL', 'Client Account Number', NOW()),
    (2, 'field2', '', 'CL', 'Product Code', NOW()),
    (3, 'field3', '', 'CL', 'Document Type ID', NOW()),
    (4, 'field4', '', 'CL', 'Original Account Number', NOW()),
    (5, 'field5', '', 'CL', 'Document Generation Date', NOW()),
    (6, 'field6', '', 'CL', 'Document Name', NOW());
    
    
INSERT INTO conf.doc_mgr_config(
    doc_mgr_config_id, short_code, description, org_type_code, default_value, dtm_utc_create)
    VALUES (7, 'SEPARATOR', 'file seperator', 'CL', 'Underscore[_]', NOW()),
    (8, 'RP', 'retention policy in day', 'CL', '60', NOW()),
    (9, 'DP', 'Specify document policy like allow create new document or replace', 'CL', 'Keep Both File', NOW());

-- For Partner
INSERT INTO conf.doc_mgr_config(
    doc_mgr_config_id, short_code, description, org_type_code, default_value, dtm_utc_create)
    VALUES (10, 'field1', '', 'PT', 'Client ID or Client Short Code', NOW()),
    (11, 'field2', '', 'PT', 'Product Code', NOW()),
    (12, 'field3', '', 'PT', 'Document Type ID', NOW()),
    (13, 'field4', '', 'PT', 'Client Account Number', NOW()),
    (14, 'field5', '', 'PT', 'Original Account Number', NOW()),
    (15, 'field6', '', 'PT', 'Document Generation Date', NOW()),
    (16, 'field7', '', 'PT', 'Document Name', NOW());

INSERT INTO conf.doc_mgr_config(
    doc_mgr_config_id, short_code, description, org_type_code, default_value, dtm_utc_create)
    VALUES (17, 'SEPARATOR', 'file seperator', 'PT', 'Underscore[_]', NOW());


--- For 3rd Party


INSERT INTO conf.doc_mgr_config(
    doc_mgr_config_id, short_code, description, org_type_code, default_value, dtm_utc_create)
    VALUES (18, 'field1', '', 'TP', 'Client ID or Client Short Code', NOW()),
    (19, 'field2', '', 'TP', 'Product Code', NOW()),
    (20, 'field3', '', 'TP', 'Document Type ID', NOW()),
    (21, 'field4', '', 'TP', 'Client Account Number', NOW()),
    (22, 'field5', '', 'TP', 'Original Account Number', NOW()),
    (23, 'field6', '', 'TP', 'Document Generation Date', NOW()),
    (24, 'field7', '', 'TP', 'Document Name', NOW());

INSERT INTO conf.doc_mgr_config(
    doc_mgr_config_id, short_code, description, org_type_code, default_value, dtm_utc_create)
    VALUES (25, 'SEPARATOR', 'file seperator', 'TP', 'Underscore[_]', NOW());


--=============== Client =================
INSERT INTO conf.doc_mgr_config_val(doc_mgr_config_val_id, doc_mgr_config_id, short_code, description, dtm_utc_create, field_value)
 VALUES (1, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'CL'),'CAN', 'client account number', NOW(), 'Client Account Number'),
(2, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'CL'),'PC', 'Product Code', NOW(), 'Product Code'),
(3, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'CL'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(4, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'CL'),'OAN', 'Original account number', NOW(), 'Orignal Account Number'),
(5, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'CL'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(6, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'CL'),'DN', 'Document Name', NOW(), 'Document Name'),

(7, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'CL'),'CAN', 'client account number', NOW(), 'Client Account Number'),
(8, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'CL'),'PC', 'Product Code', NOW(), 'Product Code'),
(9, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'CL'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(10, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'CL'),'OAN', 'Original account number', NOW(), 'Orignal Account Number'),
(11, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'CL'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(12, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'CL'),'DN', 'Document Name', NOW(), 'Document Name'),


(13, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'CL'),'CAN', 'client account number', NOW(), 'Client Account Number'),
(14, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'CL'),'PC', 'Product Code', NOW(), 'Product Code'),
(15, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'CL'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(16, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'CL'),'OAN', 'Original account number', NOW(), 'Orignal Account Number'),
(17, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'CL'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(18, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'CL'),'DN', 'Document Name', NOW(), 'Document Name'),


(19, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'CL'),'CAN', 'client account number', NOW(), 'Client Account Number'),
(20, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'CL'),'PC', 'Product Code', NOW(), 'Product Code'),
(21, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'CL'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(22, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'CL'),'OAN', 'Original account number', NOW(), 'Orignal Account Number'),
(23, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'CL'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(24, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'CL'),'DN', 'Document Name', NOW(), 'Document Name'),


(25, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'CL'),'CAN', 'client account number', NOW(), 'Client Account Number'),
(26, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'CL'),'PC', 'Product Code', NOW(), 'Product Code'),
(27, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'CL'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(28, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'CL'),'OAN', 'Original account number', NOW(), 'Orignal Account Number'),
(29, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'CL'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(30, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'CL'),'DN', 'Document Name', NOW(), 'Document Name'),


(31, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'CL'),'CAN', 'client account number', NOW(), 'Client Account Number'),
(32, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'CL'),'PC', 'Product Code', NOW(), 'Product Code'),
(33, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'CL'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(34, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'CL'),'OAN', 'Original account number', NOW(), 'Orignal Account Number'),
(35, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'CL'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(36, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'CL'),'DN', 'Document Name', NOW(), 'Document Name');


INSERT INTO conf.doc_mgr_config_val(doc_mgr_config_val_id, doc_mgr_config_id, short_code, description, dtm_utc_create, field_value)
 VALUES (38, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'SEPARATOR' and dm.org_type_code = 
         'CL'),'-', 'Hyphne[-]', NOW(), 'Hyphne[-]'),
(39, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'SEPARATOR' and dm.org_type_code = 
         'CL'),'_', 'Underscore[_]', NOW(), 'Underscore[_]'),      
(40, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'RP' and dm.org_type_code = 
         'CL'),'60', 'retention policy in 60 days', NOW(), '60'),
(41, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'RP' and dm.org_type_code = 
         'CL'),'90', 'retention policy in 90 days', NOW(), '90'),         
(42, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'DP' and dm.org_type_code = 
         'CL'),'KBF', 'Keep Both File', NOW(), 'Keep Both File'),
(43, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'DP' and dm.org_type_code = 
         'CL'),'RE', 'Replace  Existing', NOW(), 'Replace Existing');
         
         
-- For Partner
INSERT INTO conf.doc_mgr_config_val(doc_mgr_config_val_id, doc_mgr_config_id, short_code, description, dtm_utc_create, field_value)
 VALUES (44, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'PT'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
 (45, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'PT'),'PC', 'Product Code', NOW(), 'Product Code'),
(46, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'PT'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(47, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'PT'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
(48, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'PT'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
(49, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'PT'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(50, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'PT'),'DN', 'Document Name', NOW(), 'Document Name'),

(51, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'PT'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
(52, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'PT'),'PC', 'Product Code', NOW(), 'Product Code'),
(53, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'PT'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(54, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'PT'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
(55, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'PT'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
(56, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'PT'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(57, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'PT'),'DN', 'Document Name', NOW(), 'Document Name'),


(58, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'PT'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
(59, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'PT'),'PC', 'Product Code', NOW(), 'Product Code'),
(60, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'PT'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(61, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'PT'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
(62, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'PT'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
(63, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'PT'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(64, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'PT'),'DN', 'Document Name', NOW(), 'Document Name'),


(65, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'PT'),'CIDSC', 'Client ID or Client Short Code',NOW(), 'Client ID or Client Short Code'),
(66, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'PT'),'PC', 'Product Code', NOW(), 'Product Code'),
(67, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'PT'),'DT', 'Document Type Id',NOW(), 'Document Type Id'),
(68, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'PT'),'CAN', 'Client Account Number',NOW(), 'Client Account Number'),
(69, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'PT'),'OAN', 'Original Account Number',NOW(), 'Original Account Number'),
(70, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'PT'),'DGD', 'Document Generation Date',NOW(), 'Document Generation Date'),
(71, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'PT'),'DN', 'Document Name',NOW(), 'Document Name'),


(72, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'PT'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
(73, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'PT'),'PC', 'Product Code', NOW(), 'Product Code'),
(74, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'PT'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(75, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'PT'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
(76, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'PT'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
(77, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'PT'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(78, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'PT'),'DN', 'Document Name', NOW(), 'Document Name'),


(79, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'PT'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
(80, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'PT'),'PC', 'Product Code', NOW(), 'Product Code'),
(81, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'PT'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(82, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'PT'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
(83, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'PT'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
(84, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'PT'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(85, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'PT'),'DN', 'Document Name', NOW(), 'Document Name'),

(86, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field7' and dm.org_type_code = 
         'PT'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
(87, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field7' and dm.org_type_code = 
         'PT'),'PC', 'Product Code', NOW(), 'Product Code'),
(88, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field7' and dm.org_type_code = 
         'PT'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(89, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field7' and dm.org_type_code = 
         'PT'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
(90, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field7' and dm.org_type_code = 
         'PT'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
(91, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field7' and dm.org_type_code = 
         'PT'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(92, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field7' and dm.org_type_code = 
         'PT'),'DN', 'Document Name', NOW(), 'Document Name');
         
INSERT INTO conf.doc_mgr_config_val(doc_mgr_config_val_id, doc_mgr_config_id, short_code, description, dtm_utc_create, field_value)
 VALUES (93, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'SEPARATOR' and dm.org_type_code = 
         'PT'),'-', 'Hyphne[-]', NOW(), 'Hyphne[-]'),
(94, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'SEPARATOR' and dm.org_type_code = 
         'PT'),'_', 'Underscore[_]', NOW(), 'Underscore[_]');    
         


--Third Party

INSERT INTO conf.doc_mgr_config_val(doc_mgr_config_val_id, doc_mgr_config_id, short_code, description, dtm_utc_create, field_value)
 VALUES (95, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'TP'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
 (96, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'TP'),'PC', 'Product Code', NOW(), 'Product Code'),
(97, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'TP'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(98, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'TP'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
(99, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'TP'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
(100, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'TP'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(101, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'TP'),'DN', 'Document Name', NOW(), 'Document Name'),

(102, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'TP'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
(103, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'TP'),'PC', 'Product Code', NOW(), 'Product Code'),
(104, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'TP'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(105, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'TP'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
(106, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'TP'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
(107, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'TP'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(108, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'TP'),'DN', 'Document Name', NOW(), 'Document Name'),


(109, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'TP'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
(110, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'TP'),'PC', 'Product Code', NOW(), 'Product Code'),
(111, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'TP'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(112, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'TP'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
(113, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'TP'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
(114, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'TP'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(115, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'TP'),'DN', 'Document Name', NOW(), 'Document Name'),


(116, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'TP'),'CIDSC', 'Client ID or Client Short Code',NOW(), 'Client ID or Client Short Code'),
(117, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'TP'),'PC', 'Product Code', NOW(), 'Product Code'),
(118, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'TP'),'DT', 'Document Type Id',NOW(), 'Document Type Id'),
(119, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'TP'),'CAN', 'Client Account Number',NOW(), 'Client Account Number'),
(120, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'TP'),'OAN', 'Original Account Number',NOW(), 'Original Account Number'),
(121, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'TP'),'DGD', 'Document Generation Date',NOW(), 'Document Generation Date'),
(122, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'TP'),'DN', 'Document Name',NOW(), 'Document Name'),


(123, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'TP'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
(124, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'TP'),'PC', 'Product Code', NOW(), 'Product Code'),
(126, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'TP'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(127, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'TP'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
(128, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'TP'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
(129, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'TP'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(130, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'TP'),'DN', 'Document Name', NOW(), 'Document Name'),


(131, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'TP'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
(132, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'TP'),'PC', 'Product Code', NOW(), 'Product Code'),
(133, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'TP'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
(134, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'TP'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
(135, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'TP'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
(136, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'TP'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
(137, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'TP'),'DN', 'Document Name', NOW(), 'Document Name');

INSERT INTO conf.doc_mgr_config_val(doc_mgr_config_val_id, doc_mgr_config_id, short_code, description, dtm_utc_create, field_value)
 VALUES (138, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'SEPARATOR' and dm.org_type_code = 
         'TP'),'-', 'Hyphne[-]', NOW(), 'Hyphne[-]'),
(139, (select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'SEPARATOR' and dm.org_type_code = 
         'TP'),'_', 'Underscore[_]', NOW(), 'Underscore[_]');


INSERT INTO data.user_doc_config(
	user_doc_config_id,doc_mgr_config_val_id, doc_mgr_config_id, user_id, org_type_code, org_code, 
	doc_mgr_config_selected_code, doc_mgr_config_val_selected_code, dtm_utc_create,is_delete)
	VALUES (1,1, 1, 21, 'CL', 'MRLT', 'field1', 'CAN', NOW(),false),
	(2,8, 2, 21, 'CL', 'MRLT', 'field2', 'PC', NOW(),false),
	(3,15, 3, 21, 'CL', 'MRLT', 'field3', 'DT', NOW(),false),
	(4,22, 4, 21, 'CL', 'MRLT', 'field4', 'OAN', NOW(),false),
	(5,29, 5, 21, 'CL', 'MRLT', 'field5', 'DGD', NOW(),false),
	(6,36, 6, 21, 'CL', 'MRLT', 'field6', 'DN', NOW(),false),
	(7,38, 7, 21, 'CL', 'MRLT', 'SEPARATOR', '-', NOW(),false),
	(8,40, 8, 21, 'CL', 'MRLT', 'RP', '30', NOW(),false),
	(9,43, 9, 21, 'CL', 'MRLT', 'DP', 'RE', NOW(),false);


INSERT INTO data.send_receive_document(
	send_receive_document_id, doc_type_code, original_account_no, client_account_no, action_by_user_id,
	action_by_org_type_code, action_by_org_code, sent_request_user_id, sent_request_org_type_code, sent_request_org_code,dtm_utc_requested,dtm_utc_create, document_type)
	VALUES (1, 'AP', '3344', '1122', 21, 'CL', 'MRLT', 21, 'CL', 'MRLT', NOW(), NOW(), 'Application');
