package com.equabli.file.operation.config;



import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.converter.MessageConverter;
import org.springframework.messaging.handler.annotation.support.PayloadMethodArgumentResolver;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.sqs.AmazonSQSAsync;
import com.amazonaws.services.sqs.AmazonSQSAsyncClientBuilder;
import com.equabli.common.configs.SecretConfig;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.awspring.cloud.messaging.config.QueueMessageHandlerFactory;
import io.awspring.cloud.messaging.core.QueueMessagingTemplate;

@Configuration
@Profile("!test")
public class SQSConfig {

	@Autowired
	SecretConfig secretConfig;

	@Bean
	public AmazonSQSAsync amazonSQS(Environment environment) {
		final AmazonSQSAsync sqs = AmazonSQSAsyncClientBuilder .standard().withCredentials(new AWSStaticCredentialsProvider(
				new BasicAWSCredentials(secretConfig.getAwsAccessKey(),secretConfig.getAwsSecretKey())))
				.withRegion(secretConfig.getRegion()).build();
		return sqs;
	}
	
	
	 @Bean
	  public QueueMessagingTemplate queueMessagingTemplate(
	    AmazonSQSAsync amazonSQSAsync) {
	      return new QueueMessagingTemplate(amazonSQSAsync);
	  }
	  
	  @Bean
	  public QueueMessageHandlerFactory queueMessageHandlerFactory(
	    final ObjectMapper mapper, final AmazonSQSAsync amazonSQSAsync){

	        final QueueMessageHandlerFactory queueHandlerFactory = 
	                                   new QueueMessageHandlerFactory();
	        queueHandlerFactory.setAmazonSqs(amazonSQSAsync);
	        queueHandlerFactory.setArgumentResolvers(Collections.singletonList(
	          new PayloadMethodArgumentResolver(jackson2MessageConverter(mapper))
	        ));
	        return queueHandlerFactory;
	  }

	  private MessageConverter jackson2MessageConverter(final ObjectMapper mapper){
	  
	        final MappingJackson2MessageConverter 
	            converter = new MappingJackson2MessageConverter();
	        converter.setObjectMapper(mapper);
	        return converter;
	  }
}
