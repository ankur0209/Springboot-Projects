package com.equabli.file.operation.response.integrationaccount;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "PageMetaData response from EQ Collection CommonAcctSearch API ")
public class PageMetaData {
	private Integer pageSize;
	private Integer pageNumber;
	private Integer recordCount;
	private Integer pageCount;
}
