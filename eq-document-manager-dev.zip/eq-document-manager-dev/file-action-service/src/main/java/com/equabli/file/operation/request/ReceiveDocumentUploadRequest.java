package com.equabli.file.operation.request;

import javax.validation.constraints.NotBlank;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(description = "Received Document upload data configuration")
public class ReceiveDocumentUploadRequest {

	Long id;

//	@NotBlank
//	@Schema(description = "Give orgTypeCode means which user is client, partner or any other need to specify here", example = "CL")
//	private String orgType;

	@NotBlank
	@Schema(description = "Document type code means, which type of document is it", example = "AP")
	private String docType;

	@Schema(description = "Document type code means, which type of document is it", example = "AP")
	private String clientAccountNo;

}
