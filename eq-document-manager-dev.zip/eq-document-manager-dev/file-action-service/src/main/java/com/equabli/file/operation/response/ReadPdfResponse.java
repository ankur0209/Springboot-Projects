package com.equabli.file.operation.response;

import com.equabli.common.entity.DocType;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Schema(description = "Response of after reading the pdf file")
public class ReadPdfResponse {
	private DocType docType;
	private String clientAccountNumber;
	private String originalAccountNumber;
	private Long equabliAccountNumber;
	private String productCode;
}
