package com.equabli.file.operation.service;

import java.util.List;

import com.equabli.common.auth.TokenData;
import com.equabli.common.entity.Document;
import com.equabli.file.operation.response.integrationaccount.AccountsResponse;

public interface ValidateAccountsService {

	/**
	 * Validate the document client account number if account number is not valid
	 * then change the status of document and set IsDelete true
	 * 
	 * @param eqCollectAccounts, sent empty list if not available
	 * @param tokenData
	 * @param document
	 * @return
	 */
	void validateClientAccountNumbers(List<AccountsResponse> eqCollectAccounts, TokenData tokenData,
			Document document);

}