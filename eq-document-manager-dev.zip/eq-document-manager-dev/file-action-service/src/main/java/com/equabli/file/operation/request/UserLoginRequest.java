package com.equabli.file.operation.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@Schema(description = "user login request for user service")
public class UserLoginRequest {

	private String loginKey;
	private String loginSecret;
}
