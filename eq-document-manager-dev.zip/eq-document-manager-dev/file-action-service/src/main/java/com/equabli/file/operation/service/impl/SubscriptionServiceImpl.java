package com.equabli.file.operation.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.Lookup;
import com.equabli.common.entity.Usage;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.repository.LookupRepository;
import com.equabli.common.repository.UsageRepository;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.file.operation.response.integrationaccount.ClientResponse;
import com.equabli.file.operation.service.SubscriptionService;

@Service
public class SubscriptionServiceImpl implements SubscriptionService {

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	LookupRepository lookupRepository;

	@Autowired
	UsageRepository usageRepository;

	@Override
	public Usage getUsage(TokenData tokenData) {
		return getUsage(tokenData, tokenData.getUserOrgCode());
	}

	@Override
	public Usage getUsage(TokenData tokenData, ClientResponse clientDetail) {
		return getUsage(tokenData, clientDetail.getShortName());
	}

	private Usage getUsage(TokenData tokenData, String orgCode) {
		Usage usage = usageRepository.findByOrgCode(orgCode).orElse(new Usage());
		if (usage.getLookupUid() == null) {
			usage.saveUsage(usage,
					getLookupBySubscriptionCode(MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE).getUid(),
					tokenData);
			usage = usageRepository.save(usage);
		}

		return usage;
	}

	private Lookup getLookupBySubscriptionCode(String subscriptionCode) {
		return lookupRepository
				.findByLookupGroup_keyvalueAndKeycode(MessageConstants.Subscription.SUBSCRIPTION_TYPE, subscriptionCode)
				.orElseThrow(() -> new InvalidArgumentException(
						messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, subscriptionCode)));
	}

}
