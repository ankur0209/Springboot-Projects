package com.equabli.file.operation.service;

import static com.equabli.common.constants.NotificationConstant.BODY;
import static com.equabli.common.constants.NotificationConstant.DOCUMENT_TYPE;
import static com.equabli.common.constants.NotificationConstant.FULLFILL_DOCUMENT;
import static com.equabli.common.constants.NotificationConstant.FULLFILL_NOTIFICATIO_BODY_MESSAGE;
import static com.equabli.common.constants.NotificationConstant.TYPE;

import java.io.File;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.TokenData;
import com.equabli.common.entity.DocType;
import com.equabli.common.entity.Document;
import com.equabli.common.entity.SendReceiveDocument;
import com.equabli.common.enums.DocumentRequestStatusEnum;
import com.equabli.common.exception.IOException;
import com.equabli.common.repository.DocTypeRepository;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.repository.RequireDocRepository;
import com.equabli.common.repository.SentReceiveDocumentRepository;
import com.equabli.common.request.EmailRequest;
import com.equabli.common.request.FileUploadConfigRequest;
import com.equabli.common.request.NotificationRequest;
import com.equabli.common.request.RequestNewDocumentRequest;
import com.equabli.common.response.DocumentSummaryResponse;
import com.equabli.common.response.RequireDocResponse;
import com.equabli.common.response.UserDetailResponse;
import com.equabli.common.response.UserDetails;
import com.equabli.common.utils.DurationDateUtils;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.common.utils.ZipUtils;
import com.equabli.file.operation.feignclient.SentMail;
import com.equabli.file.operation.integration.FileOperation;
import com.equabli.file.operation.integration.accounts.AccountsJson;
import com.equabli.file.operation.request.AccountDocumentsRequest;
import com.equabli.file.operation.request.FileUploadRequest;
import com.equabli.file.operation.response.FileUploadConfigResponse;
import com.equabli.file.operation.response.integrationaccount.AccountsResponse;
import com.equabli.file.operation.response.integrationaccount.ClientResponse;
import com.equabli.file.operation.service.impl.FullfillDocumentServiceImpl;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AsyncService {
	
	private static final String SUBJECT = "Document Requested for Client Account Number : ";
	private static final String SUBJECT_UPLOAD = "Upload Document for Client Account Number : ";
	private static final String ACCOUNT = "account";
	private static final String FULLFILL_DOCUMENT_TITLE = "send notification for document fullfill";
	
	@Value("${user.not.exists.mail-template.name}")
	private String userNotExistTemplate;
	
	@Value("${user.exists.mail-template.name}")
	private String userExistTemplate;
	
	@Value("${document.over-due.in-days}")
	private Integer documentOverDue;
	
	@Value("${upload.document.mail-template.name}")
	private String userUploadDocumentTemplate;
	
	@Value("${upload.bulk.mail-template.name}")
	private String userUploadBulkDocumentTemplate;
	
	private FileReadOperationService fileReadOperationService;

	@Autowired
	public AsyncService(@Lazy FileReadOperationService fileReadOperationService) {
		this.fileReadOperationService = fileReadOperationService;
	}
	
	@Autowired
	private FileUploadDatabaseOperation databaseOperation;
	
	@Qualifier(value = "s3FileOperation")
	@Autowired
	private FileOperation fileOperation;
	
	@Autowired
	FullfillDocumentServiceImpl fullfillDocumentServiceImpl;

	@Autowired
	private SentReceiveDocumentRepository sentReceiveDocumentRepository;
	
	@Autowired
	private DocTypeRepository docTypeRepository;
	
	@Autowired
	private DocumentRepository documentRepository;
	
	@Autowired
	private SentMail sentMail;
	
	@Autowired
	private RequireDocRepository requireDocRepository;
	
	@Autowired
	private AccountsJson accountsJson;
	
	@Autowired
	private ValidateAccountsService validateAccountsService;

	@Autowired
	MessageSupplier messageSupplier;
	
	@Async
	public void manageSingleFileUpload(FileUploadConfigRequest fileUploadVo, File convertFile, TokenData tokenData,
			String authorization) {

		fileUploadVo.setFileName(convertFile.getName());
		fileUploadVo.setFileSize(convertFile.length());
		// validate File, add to database and then upload file.
		FileUploadConfigResponse response = databaseOperation.handleFileNamingValidation(fileUploadVo, tokenData,
				authorization, convertFile);
		log.info("We are getting response from the database after file validate {}", response);
		fileOperation.uploadFile(fileUploadVo, response, convertFile, "", tokenData);
		fileUploadVo.setDocumentId(response.getDocumentId());
		databaseOperation.updateFilePath(fileUploadVo, tokenData);
		Util.deleteTempFile(convertFile.toPath());
		if(Boolean.FALSE.equals(response.getIsFileValid())) {
			uploadFileEmailToUser(tokenData, databaseOperation.getDocType(fileUploadVo.getDocType()),
					fileUploadVo.getClientAccountNo(), authorization, convertFile.getName(), 1);
		}
	}
	
	@Async
	public void manageSingleFileUploadForAccountNo(File convertFile, FileUploadRequest fileUploadRequest,
			String authorization, TokenData tokenData) {

		FileUploadConfigRequest fileUploadVo = new FileUploadConfigRequest();
		fileUploadVo.setFileName(convertFile.getName());
		fileUploadVo.setFileSize(convertFile.length());
		fileUploadVo.setClientAccountNo(fileUploadRequest.getAccountNumber());
		fileUploadVo.setDocType(fileUploadRequest.getDocType());
		fileUploadVo.setDocumentName(fileUploadVo.getFileName());
		fileUploadVo.setClientShortCode(fileUploadRequest.getClientShortCode());
		// validate File, add to database and then upload file.
		FileUploadConfigResponse response = databaseOperation.handleFileNameOfAccountNumber(fileUploadVo, tokenData,
				authorization);
		fileOperation.uploadFile(fileUploadVo, response, convertFile, "", tokenData);
		fileUploadVo.setDocumentId(response.getDocumentId());
		databaseOperation.updateFilePath(fileUploadVo, tokenData);
		Util.deleteTempFile(convertFile.toPath());
		if(Boolean.FALSE.equals(response.getIsFileValid())) {
			uploadFileEmailToUser(tokenData, databaseOperation.getDocType(fileUploadVo.getDocType()),
				fileUploadVo.getClientAccountNo(), authorization, convertFile.getName(), 1);
		}
	}
	
	@Async
	public void manageBulkFile(String zipUrl, FileUploadConfigRequest fileUploadVo, String excelUrl,
			TokenData tokenData, String authorization) {
		tokenData.setToken(authorization);
		List<String> mailContent = handleBulkFile(zipUrl, fileUploadVo, excelUrl, tokenData);
		if (!mailContent.isEmpty()) {
			uploadBulkEmailToUser(tokenData, "", "", authorization, mailContent);
		}
	}

	private void uploadBulkEmailToUser(TokenData tokenData, String docType, String clientAccountNumber,
			String authorization, List<String> mailContent) {
		List<EmailRequest> emailRequests = new ArrayList<>();
		HashMap<String, Object> parameters = setMailDataOfBulk(tokenData, docType, clientAccountNumber, mailContent);
		emailRequests.add(EmailRequest.builder().recipients(Arrays.asList(tokenData.getEmailAddress()))
				.subject(SUBJECT_UPLOAD + clientAccountNumber).parameters(parameters)
				.templateName(userUploadBulkDocumentTemplate).build());

		String mailResponse = sentMail.sendEmails(authorization, emailRequests);
		log.info("mailResponse -> {}", mailResponse);
	}

	private HashMap<String, Object> setMailDataOfBulk(TokenData tokenData, String docType, String clientAccountNumber,
			List<String> mailContent) {
		HashMap<String, Object> parameters = new HashMap<>();
		parameters.put("name", tokenData.getFirstName());
		parameters.put("docTypeCode", docType);
		parameters.put("documentType", "");
		parameters.put("clientAccountNumber", clientAccountNumber);
		parameters.put("userOrgName", tokenData.getUserOrgName());
		parameters.put("reason", mailContent);
		return parameters;
	}

	@Async
	public void manageFullFillDocument(TokenData tokenData, Long id, File convertFile, String authorization, String clientShortCode) {
		SendReceiveDocument sendReceiveDocument = fullfillDocumentServiceImpl.handleFullfillDocument(tokenData, id,
				convertFile, authorization, clientShortCode);
		Util.deleteTempFile(convertFile.toPath());
		uploadFileEmailToUser(tokenData, databaseOperation.getDocType(sendReceiveDocument.getDocTypeCode()),
				sendReceiveDocument.getClientAccountNo(), authorization, convertFile.getName(), 1);
		fullfillDocumentNotification(tokenData, sendReceiveDocument, authorization);
	}
	
	private List<String> handleBulkFile(String uploadFileUrl, FileUploadConfigRequest fileUploadVo, String excelFileUrl,
			TokenData tokenData) {
		List<String> listOfMailContent = null;

		List<AccountsResponse> eqCollectAccount = accountsJson.getAccounts();
		log.info("eqCollectAccount {}", eqCollectAccount);
		try {
			File excelFile = getFile(excelFileUrl);
			File zipFile = getFile(uploadFileUrl);
			String files = ZipUtils.extractZip(zipFile);
			File[] listFile = getListOfFile(new File(files).listFiles());
			listOfMailContent = fileReadOperationService.readExcelFile(excelFile, fileUploadVo, listFile, tokenData,
					eqCollectAccount);
			log.info("LIST OF FILE'S WHICH READ SUCCESSFULL {} ", listOfMailContent);
			boolean status = Util.deleteDirectory(new File(files).listFiles()[0]);
			Files.delete(excelFile.toPath());
			Files.delete(zipFile.toPath());
			log.info("Temp File Delete :: " + status);
			fileOperation.deleteBulkAfterRead(excelFileUrl, uploadFileUrl);
		} catch (Exception e) {
			fileOperation.deleteBulkAfterRead(excelFileUrl, uploadFileUrl);
			throw new IOException("EXCEPTION OCCURED WHEN FILE DELETE {} " + e.getMessage());
		}
		return listOfMailContent;
	}
	
	public File[] getListOfFile(File[] files) {
		File[] listOfFile = files;
		if(listOfFile[0].isDirectory()) {
			listOfFile = files[0].listFiles();
			getListOfFile(listOfFile);
		}
		return listOfFile;
	}

	public File downloadFile(String fileUrl, String fileName, File tempFile) {
		return fileOperation.downloadFile(fileUrl, fileName, tempFile);
	}

	private File getFile(String uploadFileUrl) {
		String fileName = Util.getFileNameFromUrl(uploadFileUrl);
		File tempFile = new File(System.getProperty("java.io.tmpdir") + File.separator + fileName);
		return downloadFile(uploadFileUrl, fileName, tempFile);
	}

	public void uploadFile(FileUploadConfigResponse response, FileUploadConfigRequest fileRequest, File checkFile, TokenData tokenData) {
		fileOperation.uploadFile(fileRequest, response, checkFile, "", tokenData);
		fileRequest.setDocumentId(response.getDocumentId());
		log.info("go to update file path and fullfill detail..");
		databaseOperation.updateFilePath(fileRequest, tokenData);
	}
	
	@Async
	public void saveBulkSendReceiveDocumentFromExcel(String authorization, List<RequestNewDocumentRequest> requestDocuments,
			TokenData tokenData, List<UserDetailResponse> userDetailResponse) {

		log.info("Bulk document request is started");

		List<EmailRequest> emailRequests = new ArrayList<>();
		Map<String, UserDetailResponse> existUserList = userDetailResponse.stream()
				.filter(UserDetailResponse::getIsExists)
				.collect(Collectors.toMap(UserDetailResponse::getMailId, Function.identity()));

		Map<String, UserDetailResponse> nonExistUserList = userDetailResponse.stream()
				.filter(l -> l.getIsExists().equals(false))
				.collect(Collectors.toMap(UserDetailResponse::getMailId, Function.identity()));

		log.info("existUserList --> {}", existUserList);
		log.info("nonExistUserList --> {}", nonExistUserList);

		List<SendReceiveDocument> sentReceiveDocuments = new ArrayList<>();
		requestDocuments = requestDocuments.stream().filter(rd -> rd.getDocumentType() != null).toList();

		for (RequestNewDocumentRequest requestDocument : requestDocuments) {

			DocType docType = getDocType(requestDocument.getDocTypeCode()); 
			
			if (existUserList.containsKey(requestDocument.getSendRequest())) {

				UserDetails userDetail = existUserList.get(requestDocument.getSendRequest()).getUserDetails();
				log.info("EXISTS USER DETAIL -> {}", existUserList.get(requestDocument.getSendRequest()));

				HashMap<String, Object> parameters = setMailData(tokenData, docType,
						requestDocument.getClientAccountNumber());

				emailRequests.add(EmailRequest.builder().recipients(Arrays.asList(userDetail.getEmailAddress()))
						.subject(SUBJECT + requestDocument.getClientAccountNumber()).parameters(parameters).templateName(userExistTemplate).build());

				SendReceiveDocument sendReceiveDocument = saveRequestNewDocument(requestDocument, tokenData,
						existUserList.get(requestDocument.getSendRequest()), docType);
				if (sendReceiveDocument != null)
					sentReceiveDocuments.add(sendReceiveDocument);

			} else if(nonExistUserList.containsKey(requestDocument.getSendRequest())){
				UserDetailResponse userDetail = nonExistUserList.get(requestDocument.getSendRequest());
				log.info("NOT EXISTS USER DETAIL -> {}", userDetail);

				HashMap<String, Object> parameters = setMailData(tokenData, docType,
						requestDocument.getClientAccountNumber());

				emailRequests.add(EmailRequest.builder().recipients(Arrays.asList(userDetail.getMailId()))
						.subject(SUBJECT + requestDocument.getClientAccountNumber()).parameters(parameters).templateName(userNotExistTemplate).build());
			}
		}

		sentReceiveDocumentRepository.saveAll(sentReceiveDocuments);
		String mailResponse = sentMail.sendEmails(authorization, emailRequests);
		log.info("mailResponse -> {}", mailResponse);
		log.info("Bulk document request is completed");
	}
	
	private HashMap<String, Object> setMailData(TokenData tokenData, DocType docType, String clientAccountNumber) {
		HashMap<String, Object> parameters = new HashMap<>();
		parameters.put("name", tokenData.getFirstName());
		parameters.put("docTypeCode", docType.getShortCode());
		parameters.put("documentType", docType.getName());
		parameters.put("clientAccountNumber", clientAccountNumber);
		parameters.put("userOrgName", tokenData.getUserOrgName());
		return parameters;
	}
	
	private HashMap<String, Object> setMailData(TokenData tokenData, DocType docType, String clientAccountNumber,
			String fileName, int fileNo) {
		HashMap<String, Object> parameters = new HashMap<>();
		parameters.put("name", tokenData.getFirstName());
		parameters.put("docTypeCode", docType.getShortCode());
		parameters.put("documentType", docType.getName());
		parameters.put("clientAccountNumber", clientAccountNumber);
		parameters.put("userOrgName", tokenData.getUserOrgName());
		parameters.put("rejectedFileName", fileName);
		parameters.put("rejectedFileNo", fileNo);
		return parameters;
	}
	
	private SendReceiveDocument saveRequestNewDocument(RequestNewDocumentRequest requestNewDocumentRequest,
			TokenData tokenData, UserDetailResponse userDetailResponse, DocType docType) {

		requestNewDocumentRequest.setDocumentType(docType.getName());

//		If document already uploaded do nothing
		Long documentCount = documentRepository.findDocumentByAccountNumber(tokenData.getOrgType(),
				requestNewDocumentRequest.getOriginalAccountNumber(),
				requestNewDocumentRequest.getClientAccountNumber(), requestNewDocumentRequest.getEquabliAccountNumber(),
				requestNewDocumentRequest.getDocTypeCode());

		if (documentCount > 0) {
			return null;
		}

//		If document request already generate than update data else create new 
		SendReceiveDocument sendReceiveDocument = sentReceiveDocumentRepository
				.getBySendReceiveDocument(requestNewDocumentRequest.getOriginalAccountNumber(),
						requestNewDocumentRequest.getClientAccountNumber(), docType.getShortCode(),
						userDetailResponse.getUserDetails().getPrincipleId())
				.orElse(new SendReceiveDocument());

		sendReceiveDocument.saveSendReceiveDocument(sendReceiveDocument, requestNewDocumentRequest,
				DocumentRequestStatusEnum.OPEN, tokenData, tokenData, userDetailResponse.getUserDetails(),documentOverDue);
		return sendReceiveDocument;
	}
	
	private DocType getDocType(String docTypeCode) {
		return docTypeRepository.findByShortCode(docTypeCode).orElse(new DocType());
	}

	@Async
	public void uploadFileForAccounts(File file, TokenData tokenData, DocType docType,
			AccountDocumentsRequest accountDocumentsRequest, Optional<ClientResponse> clientDetail) {

		List<String> accountsHasDoc = getAccountNumberForSpecificDocument(docType.getShortCode(), tokenData,
				accountDocumentsRequest);
		List<String> allAccounts = this.getAllAccountNumberForSpecificDocument(docType.getShortCode(), tokenData,
				accountDocumentsRequest);
		List<String> productCodes = this.getProductCodeForSpecificDocument(docType.getShortCode(), tokenData,
				accountDocumentsRequest.getProductCode());

		List<String> finalAccountList = new ArrayList<>();
		finalAccountList.addAll(accountsHasDoc);
		finalAccountList.addAll(allAccounts);
		finalAccountList.removeAll(accountsHasDoc);

		log.info("accountsHasDoc --> {} ", accountsHasDoc);
		log.info("All Accounts --> {} ", allAccounts);
		log.info("After Remove finalAccountList --> {} ", finalAccountList);
		log.info("productCodes --> {} ", productCodes);
		
		List<AccountsResponse> eqCollectAccount = accountsJson.getAccounts();
		log.info("eqCollectAccount {}", eqCollectAccount);
		
		for (String account : finalAccountList) {
			for (String prodctCode : productCodes) {
				String objectKey = fileOperation.uploadFileForAccounts(file, tokenData,
						new DocumentSummaryResponse(account, prodctCode, docType.getShortCode()));
				Document document = new Document();
				
				String generatedFileName = generatedFileName(docType.getName(), account, tokenData.getUserOrgCode(),
						file.getName());
				
				document.saveDocument(document, tokenData, tokenData, docType.getShortCode(), prodctCode,
						docType.getName(), file.getName(), file.length(), account, objectKey, generatedFileName);
				documentRepository.save(document);
				
				databaseOperation.updateUsage(file.length(), 1l, tokenData, clientDetail);
				validateAccountsService.validateClientAccountNumbers(eqCollectAccount, tokenData, document);
				updateSendReceiveRequest(document, tokenData);
			}
		}

		try {
			Files.delete(file.toPath());
		} catch (java.io.IOException e) {
			log.error("ERROR WHILE DELETE FILE -> {} ", e.getMessage(), e);
		}
	}
	
	private String generatedFileName(String documentType, String clientAccountNumber, String userOrgCode,
			String fileName) {

		String seperatorForGeneratedFile = "-";
		StringBuilder generatedFileName = new StringBuilder();
		generatedFileName.append(seperatorForGeneratedFile + userOrgCode);
		generatedFileName.append(seperatorForGeneratedFile + documentType);
		generatedFileName.append(seperatorForGeneratedFile + clientAccountNumber);
		generatedFileName.append(seperatorForGeneratedFile + fileName);

		return generatedFileName.substring(seperatorForGeneratedFile.length());
	}
	
	private void updateSendReceiveRequest(Document document, TokenData tokenData) {
		// If document request already generate than fulfilled 
		Optional<SendReceiveDocument> sendReceiveDocumentData = sentReceiveDocumentRepository.getBySendReceiveDocument(
				document.getClientAccountNo(), document.getDocTypeCode(), tokenData.getPrincipleId());
		if (sendReceiveDocumentData.isPresent()) {
			SendReceiveDocument sendReceiveDocument = sendReceiveDocumentData.get();
			sendReceiveDocument.updateSendReceiveDocument(sendReceiveDocument, document,
					DocumentRequestStatusEnum.FULFILLED, tokenData, tokenData);
			sentReceiveDocumentRepository.save(sendReceiveDocument);
		}

	}

	/**
	 * Fetch the those client account number that have document
	 * 
	 * @param docTypeCode
	 * @param tokenData
	 * @param documentsSearchParam
	 * @param tenure
	 * @return
	 */
	private List<String> getAllAccountNumberForSpecificDocument(String docTypeCode, TokenData tokenData,
			AccountDocumentsRequest accountDocumentsRequest) {

		DurationDateUtils tenture = new DurationDateUtils(accountDocumentsRequest.getTenure(), LocalDateTime.now());

		List<String> requireDocs = requireDocRepository
				.getByOrgTypeCodeAndDocTypeCodeAndIsDeleteFalse(tokenData.getUserOrgCode(), docTypeCode,
						accountDocumentsRequest.getProductCode())
				.stream().map(RequireDocResponse::getProductCode).toList();

		log.info("tokendata {}, doctype {}, productcode {}", tokenData.getUserOrgCode(), docTypeCode,
				accountDocumentsRequest.getProductCode());
		log.info("requireDocs {}", requireDocs);
		
		if(requireDocs.isEmpty())
			return Collections.emptyList();

		List<String> accounts = documentRepository.getTotalDocumentSummary(tokenData.getUserOrgCode(),
				accountDocumentsRequest.getProductCode(), tenture.getFirstDay(), tenture.getLastDay(),
				accountDocumentsRequest.getUserId(), accountDocumentsRequest.getPortfolio(), requireDocs);

		log.info("tenture {}, Document All Accounts {}", tenture, accounts);

		return accounts;
	}

	private List<String> getProductCodeForSpecificDocument(String docTypeCode, TokenData tokenData,
			String productCode) {
		return requireDocRepository
				.getByOrgTypeCodeAndDocTypeCodeAndIsDeleteFalse(tokenData.getUserOrgCode(), docTypeCode, productCode)
				.stream().map(RequireDocResponse::getProductCode).distinct().toList();
	}

	/**
	 * Fetch the those client account number that have specific document
	 * 
	 * @param docTypeCode
	 * @param tokenData
	 * @param documentsSearchParam
	 * @param tenure
	 * @return
	 */
	private List<String> getAccountNumberForSpecificDocument(String docTypeCode, TokenData tokenData,
			AccountDocumentsRequest accountDocumentsRequest) {

		DurationDateUtils tenture = new DurationDateUtils(accountDocumentsRequest.getTenure(), LocalDateTime.now());

		List<String> requireDocs = requireDocRepository
				.getByOrgTypeCodeAndDocTypeCodeAndIsDeleteFalse(tokenData.getUserOrgCode(), docTypeCode,
						accountDocumentsRequest.getProductCode())
				.stream().map(RequireDocResponse::getProductCode).toList();
		log.info("requireDocs {}", requireDocs);
		
		if(requireDocs.isEmpty())
			return Collections.emptyList();

		List<String> accounts = documentRepository.getCompletedDocumentSummary(tokenData.getUserOrgCode(), requireDocs,
				docTypeCode, tenture.getFirstDay(), tenture.getLastDay(), accountDocumentsRequest.getUserId(),
				accountDocumentsRequest.getPortfolio(), accountDocumentsRequest.getProductCode());

		log.info("tenture {}, Document Has Accounts {}", tenture, accounts);
		
		return accounts;
	}
	
	public void uploadFileEmailToUser(TokenData tokenData, DocType docType, String clientAccountNumber,
			String authorization, String fileName, int fileNo) {
		List<EmailRequest> emailRequests = new ArrayList<>();
		HashMap<String, Object> parameters = setMailData(tokenData, docType, clientAccountNumber,fileName,fileNo);
		emailRequests.add(EmailRequest.builder().recipients(Arrays.asList(tokenData.getEmailAddress()))
				.subject(SUBJECT_UPLOAD + clientAccountNumber).parameters(parameters).templateName(userUploadDocumentTemplate)
				.build());
		
		String mailResponse = sentMail.sendEmails(authorization, emailRequests);
		log.info("mailResponse -> {}", mailResponse);
	}
	
	public void manageBulkFileSQS(String zipUrl, FileUploadConfigRequest fileUploadVo, String excelUrl,
			TokenData tokenData) {
		handleBulkFile(zipUrl, fileUploadVo, excelUrl, tokenData);
	}

	/*******
	 * 
	 * Notification Part Start
	 * 
	 *******/

	/**
	 * Send notification for Full fill document.
	 * 
	 * @param tokenData
	 * @param sendReceiveDocument
	 * @param fullfillDocumentTitle
	 * @param authorization
	 */
	private void fullfillDocumentNotification(TokenData tokenData, SendReceiveDocument sendReceiveDocument,
			String authorization) {

		String message = messageSupplier.get(FULLFILL_NOTIFICATIO_BODY_MESSAGE, tokenData.getFirstName(),
				tokenData.getUserOrgCode(), sendReceiveDocument.getDocumentType(),
				sendReceiveDocument.getClientAccountNo());
		Map<String, Object> notificationData = fulfillDocumentNotificationData(sendReceiveDocument, FULLFILL_DOCUMENT,
				message);
		sendNotification(sendReceiveDocument.getSentRequestUserId(), sendReceiveDocument.getSentRequestOrgCode(),sendReceiveDocument.getSentRequestOrgTypeCode(), 
				notificationData, message, authorization);
	}

	private Map<String, Object> fulfillDocumentNotificationData(SendReceiveDocument sendReceiveDocument, String type,
			String bodyMessage) {
		Map<String, Object> parameters = new LinkedHashMap<>();
		parameters.put("requestBy", sendReceiveDocument.getRequestedBy());
		parameters.put("fullfillBy", sendReceiveDocument.getRequestedTo());
		parameters.put(TYPE, type);
		parameters.put(ACCOUNT, sendReceiveDocument.getClientAccountNo());
		parameters.put(BODY, bodyMessage);
		parameters.put(DOCUMENT_TYPE, sendReceiveDocument.getDocumentType());

		return parameters;
	}
	
	private void sendNotification(Long userId,String orgCode,String orgType, Map<String, Object> notificationData,
			String message, String authorization) {
		NotificationRequest notificationRequests = NotificationRequest.builder()
				.userId(userId).orgCode(orgCode)
				.orgTypeCode(orgType).title(FULLFILL_DOCUMENT_TITLE).message(message)
				.dataMap(notificationData).build();
		String response = sentMail.sendNotification(authorization, notificationRequests);
		log.info("", response);
	}
	
}
