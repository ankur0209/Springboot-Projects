package com.equabli.file.operation.service;

import com.equabli.common.auth.TokenData;
import com.equabli.common.entity.Usage;
import com.equabli.file.operation.response.integrationaccount.ClientResponse;

public interface SubscriptionService {

	Usage getUsage(TokenData tokenData);

	Usage getUsage(TokenData tokenData, ClientResponse clientDetail);

}