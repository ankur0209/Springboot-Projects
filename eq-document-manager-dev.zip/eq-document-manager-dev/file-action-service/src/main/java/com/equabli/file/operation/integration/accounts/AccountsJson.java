package com.equabli.file.operation.integration.accounts;

import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import com.equabli.common.response.config.ConfigResponse;
import com.equabli.file.operation.feignclient.EQCollectService;
import com.equabli.file.operation.response.integrationaccount.AccountsResponse;
import com.equabli.file.operation.response.integrationaccount.ClientAccountsResponse;
import com.equabli.file.operation.response.integrationaccount.CommonAcctSearchResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AccountsJson {

	private static final String FILE_SEPARATOR = File.separator;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	EQCollectService eqCollectService;

	public Optional<ClientAccountsResponse> getAccountDetail(Integer clientId, String clientAccountNumber) {
		String rqsOrigin = "equabliProcess";
		try {
			String accountDetailJson = eqCollectService.getAccountDetails(rqsOrigin, clientId, clientAccountNumber);
			ConfigResponse<ClientAccountsResponse> clientsAccountResponse = objectMapper.readValue(accountDetailJson,
					new TypeReference<ConfigResponse<ClientAccountsResponse>>() {
					});

			log.info("clientsAccountResponse {}", clientsAccountResponse);
			return Optional.ofNullable(clientsAccountResponse.getResponse());
		} catch (Exception e) {
			log.error("ERROR WHILE FETCHING getPartnersByPartnerIds ->{}", e.getMessage(), e);
		}
		return Optional.empty();
	}

	public List<AccountsResponse> getAccounts() {

		try {
			var resource = new ClassPathResource("AccountsJson" + FILE_SEPARATOR + "ListOfAccount.json");
			log.info("File data {}", resource.getFile().getName());

			ConfigResponse<CommonAcctSearchResponse> commonResponse = objectMapper.readValue(resource.getFile(),
					new TypeReference<ConfigResponse<CommonAcctSearchResponse>>() {
					});

			log.info("Common Accounts Search Response ->{}", commonResponse);
			return commonResponse.getResponse().getAccounts();
		} catch (JsonProcessingException e) {
			log.error("ERROR JSON PROCESSING getToken ->{}", e.getMessage(), e);
			return Collections.emptyList();
		} catch (Exception e) {
			log.error("ERROR WHILE FETCHING Login Detail ->{}", e.getMessage(), e);
			return Collections.emptyList();
		}
	}

}
