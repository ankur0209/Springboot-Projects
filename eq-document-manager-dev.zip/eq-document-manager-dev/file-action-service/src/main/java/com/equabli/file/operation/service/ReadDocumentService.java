package com.equabli.file.operation.service;

import java.io.File;
import java.util.Optional;

import com.equabli.common.entity.DocType;

public interface ReadDocumentService {

	Optional<DocType> readDocument(File file);

}
