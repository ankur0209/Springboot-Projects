package com.equabli.file.operation.response;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Schema(description = "Request document excel response if any error in excel sheet ")
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
public class RequestDocumentExcelResponse {

	@Schema(description = "Row number of excel sheet", example = "1")
	private Integer rowNumber;
	
	@Schema(description = "Column number of excel sheet",  example = "1")
	private Integer columnNumber;
	
	@Schema(description = "Error message of excel sheet value", example = "Document Type is required")
	private String message;
}
