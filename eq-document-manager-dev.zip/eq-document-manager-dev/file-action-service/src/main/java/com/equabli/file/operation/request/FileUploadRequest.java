package com.equabli.file.operation.request;

import javax.validation.constraints.NotBlank;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(description = "Add File upload data configuration")
public class FileUploadRequest {

	@Schema(description = "Document type code means, which type of document is it", example = "AP")
	@NotBlank
	private String accountNumber;
	
	@Schema(description = "Document type code means, which type of document is it", example = "AP")
	@NotBlank
	private String docType;
	
	@Schema(description = "client short code", example = "MRLT")
	private String clientShortCode;
}
