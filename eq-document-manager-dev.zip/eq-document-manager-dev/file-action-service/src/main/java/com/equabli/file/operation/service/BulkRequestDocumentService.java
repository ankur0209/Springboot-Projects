package com.equabli.file.operation.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.equabli.common.response.CommonResponse;
import com.equabli.file.operation.response.RequestDocumentExcelResponse;

public interface BulkRequestDocumentService {

	CommonResponse<List<RequestDocumentExcelResponse>> saveBulkRequestDocument(MultipartFile file);
}
