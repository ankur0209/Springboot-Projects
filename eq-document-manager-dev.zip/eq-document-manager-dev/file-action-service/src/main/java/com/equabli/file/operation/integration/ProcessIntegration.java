package com.equabli.file.operation.integration;

import java.util.List;

import com.equabli.common.auth.TokenData;
import com.equabli.common.entity.Document;
import com.equabli.common.response.PartnerResponse;
import com.equabli.common.response.ProcessIntegrationResponse;

public interface ProcessIntegration {

	List<ProcessIntegrationResponse> executeIntegration(List<Document> documents, PartnerResponse partner,
			TokenData tokenData, String clientShortCode);

}
