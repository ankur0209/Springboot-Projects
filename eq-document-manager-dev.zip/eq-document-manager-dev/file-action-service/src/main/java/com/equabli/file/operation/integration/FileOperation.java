package com.equabli.file.operation.integration;

import java.io.File;
import java.util.List;
import java.util.Optional;

import com.equabli.common.auth.TokenData;
import com.equabli.common.entity.Document;
import com.equabli.common.request.FileUploadConfigRequest;
import com.equabli.common.response.DocumentSummaryResponse;
import com.equabli.file.operation.response.FileUploadConfigResponse;

public interface FileOperation {

	// Upload File API
	FileUploadConfigRequest uploadFile(FileUploadConfigRequest fileUploadVo, FileUploadConfigResponse response,
			File file, String bulkType, TokenData tokenData);

	// DownLoad File API
	File downloadFile(String fileUrl, String fileName, File tempFile);

	// Delete object after successfully read
	void deleteBulkAfterRead(String excelFileUrl, String uploadFileUrl);

	String uploadFileForAccounts(File file, TokenData tokenData, DocumentSummaryResponse documentSummaryResponse);

	String copyAccountFolder(String fromAccountPath, String toAccountPath);

	void deleteAccountNumberData(List<String> obejectKey);

	Boolean checkForExistance(String obejectKey);

	List<String> getObjectKeyIfExists(String objectKey);

	String uploadDownloadedFile(TokenData tokenData, File zipFilePath, String fileName);

	/**
	 * For upload file in AWS
	 * @param document
	 * @param file
	 * @return
	 */
	Optional<String> uploadFile(Document document, File file);
}
