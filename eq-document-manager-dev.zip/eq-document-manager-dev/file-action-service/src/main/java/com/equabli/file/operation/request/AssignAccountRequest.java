package com.equabli.file.operation.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(description = "Request have a detail of client and partner.")
public class AssignAccountRequest {

	private String accountNumber;
	
	private String clientOrgCode;
	private String clientOrgTypeCode;
	
	private String partnerOrgCode;
	private String partnerOrgTypeCode;
}
