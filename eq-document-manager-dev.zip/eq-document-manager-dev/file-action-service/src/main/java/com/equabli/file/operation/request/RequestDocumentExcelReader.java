package com.equabli.file.operation.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(description = "Request a new document from excel")
public class RequestDocumentExcelReader {

	@Override
	public String toString() {
		return "RequestDocumentExcelReader [documentType=" + documentType + ", requestedFrom=" + requestedFrom
				+ ", originalAccountNumber=" + originalAccountNumber + ", clientAccountNumber=" + clientAccountNumber
				+ ", equabliAccountNumber=" + equabliAccountNumber + "]";
	}

	@Schema(description = "Type of document", example = "Transation History")
	private String documentType;

	@Schema(description = "users mail", example = "abc@gmail.com")
	private String requestedFrom;

//	private String portFolioId;

	@Schema(description = "Original Account Number", example = "456789")
	private String originalAccountNumber;

	@Schema(description = "Client Account Number", example = "123456")
	private String clientAccountNumber;

	@Schema(description = "Equabli Account Number", example = "123456")
	private Long equabliAccountNumber;

}
