package com.equabli.file.operation.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.DocType;
import com.equabli.common.exception.IOException;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.repository.DocCostRepository;
import com.equabli.common.repository.DocTypeRepository;
import com.equabli.common.repository.UserDocConfigRepository;
import com.equabli.common.request.FileUploadConfigRequest;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.FileOperationResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.file.operation.constants.FileOperationMessageConstants;
import com.equabli.file.operation.integration.FileOperation;
import com.equabli.file.operation.request.AccountDocumentsRequest;
import com.equabli.file.operation.request.FileUploadDataRequest;
import com.equabli.file.operation.request.FileUploadRequest;
import com.equabli.file.operation.response.FileUploadConfigResponse;
import com.equabli.file.operation.response.integrationaccount.ClientResponse;
import com.equabli.file.operation.service.AsyncService;
import com.equabli.file.operation.service.FileUploadDatabaseOperation;
import com.equabli.file.operation.service.FileUploadService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FileUploadServiceImplementation implements FileUploadService {

	private static final String SEND_REQUEST_DOC_EXCEL_BULK_TYPE = "SendRequestDocument";

	@Qualifier(value = "s3FileOperation")
	@Autowired
	FileOperation fileOperation;

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	FileUploadDatabaseOperation databaseOperation;

	@Autowired
	BulkRequestDocumentServiceImpl bulkRequestDocumentServiceImpl;

	@Autowired
	UserDocConfigRepository docConfigRepository;

	@Autowired
	DocCostRepository docCostRepository;
	
	@Autowired
	private FetchTokenData fetchTokenData;
	
	@Autowired
	private AsyncService asyncService;
	
	@Autowired
	private DocTypeRepository docTypeRepository;
	@Autowired private HttpServletRequest request;
	
	@Override
	public CommonResponse<String> uploadFile(MultipartFile file) {

		FileUploadConfigRequest fileUploadVo = new FileUploadConfigRequest();
		TokenData tokenData = fetchTokenData.getTokenData();
		File convertFile = Util.convertMultipartToFile(file);
		log.info("We are Converted File Path is {} name is {} ", convertFile.getAbsolutePath(), convertFile.getName());
		String authorization = request.getHeader(Constants.AUTHORIZATION);
		asyncService.manageSingleFileUpload(fileUploadVo, convertFile, tokenData, authorization);
		return CommonResponse.success(
				messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.CREATE_SUCCESS, ""),
				file.getOriginalFilename());
	}
	
	@Override
	public CommonResponse<FileOperationResponse> uploadFile(File file, TokenData tokenData) {

		log.info(" UPLOAD FILE Path is {} name is {} ", file.getAbsolutePath(), file.getName());
		
		FileUploadConfigRequest fileUploadVo = new FileUploadConfigRequest();
		
		// Check for file name and get details from the file name
		String fileUrl = handleFileNamingConvention(fileUploadVo, file, tokenData);
		log.info("We are getting file URL as {} ", fileUrl);
		
		List<String> res = new ArrayList<>();
		res.add(String.join(",", String.valueOf("1"),file.getName(),fileUrl,"0",null));
		FileOperationResponse response = generateResponse(res);
		
		log.info("Response {} ", response);
		return CommonResponse.success(
				messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.CREATE_SUCCESS,""), response);
	}

	@Override
	public CommonResponse<FileOperationResponse> uploadMultipleFile(List<MultipartFile> multipartFiles) {
		
		TokenData tokenData = fetchTokenData.getTokenData();
		List<String> readFileList = new ArrayList<>();
		if (multipartFiles.size() > FileOperationMessageConstants.FileOperationConfigs.MULTIPLE_FILE_LENGTH) {
			return CommonResponse.failure(
					messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.MULTIPLE_FILE_LENGTH_INVALID,
							FileOperationMessageConstants.FileOperationConfigs.MULTIPLE_FILE_LENGTH));
		}
		
		handleMultipleFile(multipartFiles,readFileList,tokenData);
		FileOperationResponse response = generateResponse(readFileList);
		log.info("Response1 {} ", response);
		return CommonResponse.success(
				messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.CREATE_SUCCESS,""), response);
	}
	
	private void handleMultipleFile(List<MultipartFile> multipartFiles, List<String> readFileList,
			TokenData tokenData) {
		int rejectFileNo = 0;
		FileUploadConfigRequest fileUploadVo = new FileUploadConfigRequest();
		for (MultipartFile file : multipartFiles) {
			rejectFileNo++;
			String rejectedFile = file.getOriginalFilename();
			File convertFile = Util.convertMultipartToFile(file);
			// Check for file name and get details from the file name
			String fileUrl = handleFileNamingConvention(fileUploadVo, convertFile, tokenData);
			String listOfFileUrl = String.join(",", String.valueOf(rejectFileNo), rejectedFile, fileUrl, "0", null);
			readFileList.add(listOfFileUrl);
			Util.deleteTempFile(convertFile.toPath());
		}
	}

	@Override
	public CommonResponse<?> uploadBulkFile(List<MultipartFile> files, String fileUploadJson) {
		
		TokenData tokenData = fetchTokenData.getTokenData();
		FileOperationResponse response = null;
		String listOfFileUrl = null;
		String rejectedFile = null;
		int rejectFileNo = 0;
		List<String> readFileList = new ArrayList<>();
		FileUploadDataRequest fileUploadDataRequest = new FileUploadDataRequest();
		try {
			fileUploadDataRequest = new ObjectMapper().readValue(fileUploadJson, FileUploadDataRequest.class);
		} catch (JsonProcessingException e) {
			return CommonResponse.success(messageSupplier.get(MessageConstants.NOT_VALID, fileUploadJson),"fail");
		}
		if (SEND_REQUEST_DOC_EXCEL_BULK_TYPE.equals(fileUploadDataRequest.getBulkType())) {
			return bulkRequestDocumentServiceImpl.saveBulkRequestDocument(files.get(0));
		}

		FileUploadConfigRequest fileUploadVo = new FileUploadConfigRequest();
		for (MultipartFile file : files) {
			String bulkUploadUrl = uploadBulkFileAndUpdateOperation(file, fileUploadDataRequest.getBulkType(),
					fileUploadVo, tokenData);
			rejectFileNo++;
			rejectedFile = file.getOriginalFilename();
			listOfFileUrl = String.join(",", String.valueOf(rejectFileNo), rejectedFile, bulkUploadUrl, "0", null);
			readFileList.add(listOfFileUrl);
		}
		response = generateResponse(readFileList);
		log.info("Response2 {} ", response);
		return CommonResponse.success(
				messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.CREATE_SUCCESS,""), response);
	}

	@Override
	public CommonResponse<FileOperationResponse> handleBulkFile(FileUploadDataRequest fileUploadDataRequest) {
		FileUploadConfigRequest fileUploadVo = new FileUploadConfigRequest();
		TokenData tokenData = fetchTokenData.getTokenData();
		String authorization = request.getHeader(Constants.AUTHORIZATION);
		asyncService.manageBulkFile(fileUploadDataRequest.getZipUrl(), fileUploadVo,
				fileUploadDataRequest.getExcelUrl(), tokenData, authorization);
		return CommonResponse.success(
				messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.CREATE_SUCCESS,""));
	}

	private String uploadBulkFileAndUpdateOperation(MultipartFile file, String bulkType,
			FileUploadConfigRequest fileUploadVo, TokenData tokenData) {
		
		FileUploadConfigResponse response = new FileUploadConfigResponse();
		response.setIsFileValid(true);
		File convertFile = Util.convertMultipartToFile(file);
		fileUploadVo.setFileName(file.getOriginalFilename());
		fileUploadVo.setFileSize(file.getSize());
		fileOperation.uploadFile(fileUploadVo, response, convertFile, bulkType, tokenData);
		if (Util.isEndWith(file.getOriginalFilename()))
			databaseOperation.saveBulkOperation(fileUploadVo, bulkType, false, tokenData);
		Util.deleteTempFile(convertFile.toPath());
		return fileUploadVo.getFilePath();
	}

	/**
	 * Handle single and multiple file only
	 * 
	 * @param fileUploadVo
	 * @param multipartFile
	 * @return
	 * @throws IOException
	 */
	public String handleFileNamingConvention(FileUploadConfigRequest fileUploadVo, File file, TokenData tokenData) {

		FileUploadConfigResponse response = fileDetailsUpdateOnDatabase(fileUploadVo, file.getName(), file.length(), tokenData, file);
		log.info("We are getting response from the database after file validate {}", response);
		return handleFileOperation(fileUploadVo, response, file, tokenData);

	}

	/**
	 * Handle any of File like single, multiple or bulk.
	 * 
	 * @param fileUploadVo
	 * @param response
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public String handleFileOperation(FileUploadConfigRequest fileUploadVo, FileUploadConfigResponse response,
			File file, TokenData tokenData) {

		fileOperation.uploadFile(fileUploadVo, response, file, "", tokenData);
		updateDocumentDetails(fileUploadVo, fileUploadVo.getFilePath(), fileUploadVo.getObjKey(),
				response.getDocumentId(), tokenData);
		return fileUploadVo.getFilePath();
	}

	/**
	 * Check of file validation and update data in database
	 * 
	 * @param fileUploadVo
	 * @param filename
	 * @param fileSize
	 * @return
	 * @throws IOException
	 */
	public FileUploadConfigResponse fileDetailsUpdateOnDatabase(FileUploadConfigRequest fileUploadVo, String filename,
			Long fileSize, TokenData tokenData, File file) {

		// Get File name
		fileUploadVo.setFileName(filename);
		fileUploadVo.setFileSize(fileSize);

		// check file name is proper or not
		// if proper then add to database and then upload file.
		FileUploadConfigResponse databaseResponse = databaseOperation.handleFileNamingValidation(fileUploadVo, tokenData, null, file);
		log.info("Wait for DB :: " + databaseResponse);
		return databaseResponse;
	}

	// Generate response of API upload or reject.
	private FileOperationResponse generateResponse(List<String> respo) {
		log.info("No OF FIle {} " + respo);
		List<String> fileName = new ArrayList<>();
		List<String> fileUrl = new ArrayList<>();
		List<String> rejectFileName = new ArrayList<>();
		int fileNo = 0;
		int docRejectNo = 0;
		for(String url : respo) {
			String[] str = url.split(",");
			fileNo = fileNo + Integer.parseInt(str[0]);
			fileName.add(str[1]);
			fileUrl.add(str[2]);
			docRejectNo = docRejectNo + Integer.parseInt(str[3]);
			rejectFileName.add(str[4]);
		}
		FileOperationResponse response = new FileOperationResponse();
		response.setFileUrl(fileUrl);
		response.setFileNo(String.valueOf(fileNo));
		response.setFileNames(fileName);
		response.setDocumentRejectNo(String.valueOf(docRejectNo));
		response.setDocumentRejectFile(rejectFileName);
		return response;
	}
	
	/**
	 * Get file upload path and key then update it on database
	 * 
	 * @param fileUploadVo
	 * @param filePath
	 * @param fileUrl
	 * @param documentId
	 */
	private void updateDocumentDetails(FileUploadConfigRequest fileUploadVo, String filePath, String fileUrl,
			Long documentId, TokenData tokenData) {
		fileUploadVo.setFilePath(filePath);
		fileUploadVo.setObjKey(fileUrl);
		fileUploadVo.setDocumentId(documentId);
		String filePathResponse = databaseOperation.updateFilePath(fileUploadVo, tokenData);
		log.info("Wait for DB :: " + filePathResponse);
	}

	@Override
	public CommonResponse<String> uploadDocumentForFullfill(MultipartFile file, Long id, String clientShortCode) {
		
		TokenData tokenData = fetchTokenData.getTokenData();
		File convertFile = Util.convertMultipartToFile(file);
		log.info("We are Converted File Path is {} name is {} ", convertFile.getAbsolutePath(), convertFile.getName());
		
		String authorization = request.getHeader(Constants.AUTHORIZATION);
		asyncService.manageFullFillDocument(tokenData,id,convertFile, authorization, clientShortCode);
		return CommonResponse.success(
				messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.CREATE_SUCCESS,""), String.valueOf(id));
	}
	
	@Override
	public CommonResponse<String> uploadFileForSpecificDocument(MultipartFile file, String data) {

		TokenData tokenData = fetchTokenData.getTokenData();
		
		AccountDocumentsRequest accountDocumentsRequest = new AccountDocumentsRequest();
		try {
			accountDocumentsRequest = new ObjectMapper().readValue(data, AccountDocumentsRequest.class);
			log.info("accountDocumentsRequest {}", accountDocumentsRequest);
		} catch (JsonProcessingException e) {
			log.error("ERROR {} ",e.getMessage());
			return CommonResponse.failure("Provide a valid data");
		}
		
		DocType docType = getDocType(accountDocumentsRequest.getDocTypeCode());

		if (file == null || file.getSize() <= 0)
			return CommonResponse.failure(messageSupplier.get(FileOperationMessageConstants.FILE_NOT_VALID));

		File convertFile;
		try {
			convertFile = convertMultipartToFile(file);
		} catch (java.io.IOException e) {
			log.error("ERROR WHILE convert Multipart to file {}", e.getMessage(), e);
			return CommonResponse.failure(messageSupplier.get(FileOperationMessageConstants.ERROR_WHILE_UPLOAD_FILE));
		}

		String authorization = request.getHeader(Constants.AUTHORIZATION);
		Optional<ClientResponse> clientDetail =  databaseOperation.getMappedClientDetailForPartner(authorization, tokenData,
				accountDocumentsRequest.getClientShortCode());
		log.info("clientDetail {}", clientDetail);
		
		asyncService.uploadFileForAccounts(convertFile, tokenData, docType, accountDocumentsRequest, clientDetail);
		return CommonResponse
				.success(messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.CREATE_SUCCESS));
	}

	private static File convertMultipartToFile(MultipartFile multipartFile) throws java.io.IOException {
		File file = new File(
				System.getProperty("java.io.tmpdir") + File.separator + multipartFile.getOriginalFilename());

		try (OutputStream os = new FileOutputStream(file)) {
			os.write(multipartFile.getBytes());
		}
		return file;
	}

	private DocType getDocType(String docTypeCode) {
		return docTypeRepository.findByShortCode(docTypeCode).orElseThrow(() -> new InvalidArgumentException(
				messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, " " + docTypeCode)));
	}

	@Override
	public CommonResponse<String> uploadFileForAccount(MultipartFile file, String data) {
		TokenData tokenData = fetchTokenData.getTokenData();
		FileUploadRequest fileUploadRequest = new FileUploadRequest();
		try {
			fileUploadRequest = new ObjectMapper().readValue(data, FileUploadRequest.class);
		} catch (JsonProcessingException e) {
			log.error("ERROR {} ",e.getMessage());
			return CommonResponse.failure("Provide a valid data");
		}
		
		File convertFile = Util.convertMultipartToFile(file);
		log.info("We are Converted File Path is {} name is {} ", convertFile.getAbsolutePath(), convertFile.getName());
		String authorization = request.getHeader(Constants.AUTHORIZATION);
		asyncService.manageSingleFileUploadForAccountNo(convertFile,fileUploadRequest,authorization,tokenData);
		return CommonResponse
				.success(messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.CREATE_SUCCESS));
	}
}
