package com.equabli.file.operation.service;

import java.io.ByteArrayInputStream;
import java.util.List;

import com.equabli.common.response.CommonResponse;
import com.equabli.file.operation.request.FileDownloadRequest;
import com.equabli.file.operation.request.FolderDownloadRequest;

public interface FileDownloadService {

	ByteArrayInputStream downloadSendRequestSampleFile();

	CommonResponse<String> generatePresignUrl(String objectKey, Long fileSize);

	CommonResponse<String> downloadDocument(FileDownloadRequest fileDownloadRequest);

	CommonResponse<List<String>> downloadDocumentOfAccountNo(FolderDownloadRequest folderDownloadRequest);

}
