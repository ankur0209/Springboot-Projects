package com.equabli.file.operation.integration.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;
import com.equabli.common.entity.Document;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.response.PartnerResponse;
import com.equabli.common.response.ProcessIntegrationResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.file.operation.integration.FileOperation;
import com.equabli.file.operation.integration.ProcessIntegration;
import com.equabli.file.operation.integration.accounts.CommonIntegrationUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Qualifier("reAssignAccountService")
@Slf4j
public class ReassignAccountServiceImpl implements ProcessIntegration {

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	DocumentRepository documentRepository;

	@Qualifier(value = "s3FileOperation")
	@Autowired
	FileOperation fileOperation;

	@Autowired
	CommonIntegrationUtil commonIntegrationUtil;

	@Autowired
	FetchTokenData fetchTokenData;
	
	@Autowired
	RecallAccountServiceImpl recallAccountServiceImpl;

	@Override
	public List<ProcessIntegrationResponse> executeIntegration(List<Document> documents, PartnerResponse partner,
			TokenData tokenData, String clientOrgCode) {
		log.info("Call for Re-Assing document to partner for this account no {},");
		List<ProcessIntegrationResponse> processIntegrationResponses = new ArrayList<>();
		handleDocument(documents, tokenData, partner, clientOrgCode,processIntegrationResponses);
		return processIntegrationResponses;
	}

	private List<ProcessIntegrationResponse> handleDocument(List<Document> documents, TokenData tokenData,
			PartnerResponse partnerDetail, String clientOrgCode,
			List<ProcessIntegrationResponse> processIntegrationResponses) {
		List<Document> reassignDocuments = commonIntegrationUtil.processDocument(documents, processIntegrationResponses,
				tokenData, partnerDetail, clientOrgCode);
		deletePartnerDocument(documents, tokenData, clientOrgCode);
		documentRepository.saveAll(reassignDocuments);
		return processIntegrationResponses;
	}
	
	private void deletePartnerDocument(List<Document> documents, TokenData tokenData, String clientOrgCode) {
		Optional<List<Document>> newDocuments = Optional.ofNullable(documentRepository
				.findByClientAccountNoAndClientOrgCodeAndOrgTypeCodeAndIsDeleteFalse(
						commonIntegrationUtil.getAccountNoFromList(documents), clientOrgCode, Constants.PARTNER_CODE));
		if(newDocuments.isPresent()) {
			List<ProcessIntegrationResponse> processIntegrationResponses = new ArrayList<>();
			recallAccountServiceImpl.handleDeleteDocument(newDocuments.get(), tokenData, processIntegrationResponses);
		}
	}
}
