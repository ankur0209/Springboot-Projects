package com.equabli.file.operation.request;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(description = "Add File upload data configuration")
public class FileUploadDataRequest {

	@Schema(description = "Give orgTypeCode means which user is client, partner or any other need to specify here", example = "CL")
	private String orgType;
	
	@Schema(description = "Document type code means, which type of document is it", example = "AP")
	@JsonIgnore
	private String docType;
	
	@NotBlank
	@Schema(description = "Url for excel which uploaded", example = "/dev/abc.xlsx")
	private String excelUrl;
	
	@NotBlank
	@Schema(description = "Url for zip which uploaded", example = "/dev/abc.zip")
	private String zipUrl;
	
	@NotBlank
	@Schema(description = "Bulk type means, which type of bulk request is it", example = "upload")
	private String bulkType;
}
