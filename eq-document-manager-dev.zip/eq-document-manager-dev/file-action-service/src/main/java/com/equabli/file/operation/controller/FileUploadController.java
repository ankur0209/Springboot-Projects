package com.equabli.file.operation.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.FileOperationResponse;
import com.equabli.file.operation.constants.IntegrationConstants;
import com.equabli.file.operation.integration.accounts.AccountIntegration;
import com.equabli.file.operation.request.FileUploadDataRequest;
import com.equabli.file.operation.service.FileUploadService;
import com.equabli.file.operation.service.SFTPFileUploadService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/file/upload")
@Tag(name = "File upload API", description = "File upload API for document manager")
@Slf4j
@SecurityRequirement(name = "bearerAuth")
public class FileUploadController {

	@Autowired
	private FileUploadService fileUploadService;
	
	@Autowired
	private SFTPFileUploadService sftpFileUploadService;
	
	@Autowired
	private FetchTokenData fetchTokenData;
	
	@Autowired
	private AccountIntegration accountIntegration;

	@Operation(summary = "User Single File Upload", description = "To upload single file for document manager")
	@PostMapping(consumes = "multipart/form-data")
	public CommonResponse<String> uploadDocument(@RequestPart MultipartFile file,
			@RequestPart(name = "action", required = false) String action,
			@RequestPart(name = "actionToPartyCode", required = false) String actionToPartyCode) {

		TokenData tokenData = fetchTokenData.getTokenData();
		log.info("Upload Document/File action {} actionToPartyCode {}, fileName {}, tokenData {}", action,
				actionToPartyCode, file.getOriginalFilename(), tokenData);

		if (StringUtils.equals(IntegrationConstants.EQ, tokenData.getOrgType())) {
			return accountIntegration.uploadFileForClient(action, actionToPartyCode, file);
		}

		return fileUploadService.uploadFile(file);
	}

	@Operation(summary = "User Upload multiple files", description = "To upload multiple files for document manager")
	@PostMapping(value = "/multiple", consumes = "multipart/form-data")
	public CommonResponse<FileOperationResponse> uploadMultipleFile(@RequestPart List<MultipartFile> files,
			@RequestPart(required = false) String orgType) {
		log.info("Upload Multiple Document/File orgType {} file ziae {}", orgType, files.size());
		return fileUploadService.uploadMultipleFile(files);
	}

	@Operation(summary = "User Upload bulk file", description = "To upload zip for document manager")
	@PostMapping(value = "/bulk", consumes = "multipart/form-data")
	public CommonResponse<?> uploadBulkFile(@RequestPart List<MultipartFile> files,
			@RequestParam("fileUploadVan") String fileUploadJson) {
		log.info("Upload bulk Document/File {}", fileUploadJson);
		return fileUploadService.uploadBulkFile(files, fileUploadJson);
	}

	@Operation(summary = "Get Url after Upload bulk file", description = "To handle uploaded zip for document manager")
	@PostMapping(value = "/bulk/read")
	public CommonResponse<FileOperationResponse> handleBulkFile(@Valid @RequestBody FileUploadDataRequest dataRequest) {
		log.info("Get Url after Upload bulk file {}", dataRequest);
		return fileUploadService.handleBulkFile(dataRequest);
	}
	
	@Operation(summary = "This file will be uploaded on SFTP", description = "This file will be uploaded on SFTP")
	@PostMapping(value = "/sftp", consumes = "multipart/form-data")
	public CommonResponse<FileOperationResponse> uploadMultipleFileForSFTP(@RequestPart List<MultipartFile> files) {
		log.info("Upload Multiple Document/File on SFTP file ziae {}", files.size());
		return sftpFileUploadService.uploadFileToSFTP(files);
	}

	@Operation(summary = "User Single File FullFill", description = "To FullFill single file for document manager")
	@PostMapping(value = "/fullfill", consumes = "multipart/form-data")
	public CommonResponse<String> uploadDocumentForFullfill(@RequestPart MultipartFile file,
			@RequestParam(required = false) Long id,
			@RequestParam(required = false, name = "clientShortCode") String clientShortCode) {
		log.info("Upload Document/File Id {} fileName {} clientShortCode {}", id, file.getOriginalFilename(), clientShortCode);
		return fileUploadService.uploadDocumentForFullfill(file,id, clientShortCode);
	}

	@Operation(summary = "Upload document for specific document", description = "To upload file for specific document type of List of Accounts not having a specific document")
	@PostMapping(value = "/specific/accounts", consumes = "multipart/form-data")
	public CommonResponse<String> uploadDocumentForSpecificDocument(@RequestPart MultipartFile file,
			@RequestParam(name = "data") String data) {
		log.info("Upload Document for specific document data {} fileName {}", data, file.getOriginalFilename());
		return fileUploadService.uploadFileForSpecificDocument(file, data);
	}
	
	@Operation(summary = "User Single File Upload for client Account No", description = "To upload single file for client Account No for document manager")
	@PostMapping(value = "/account", consumes = "multipart/form-data")
	public CommonResponse<String> uploadDocumentForAccountNo(@RequestPart MultipartFile file,
			@RequestParam(name = "data") String data) {
		log.info("Upload Document/File for particular client {} ", data);
		return fileUploadService.uploadFileForAccount(file,data);
	}
}
