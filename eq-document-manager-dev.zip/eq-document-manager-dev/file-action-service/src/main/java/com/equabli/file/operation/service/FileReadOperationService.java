package com.equabli.file.operation.service;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.math.NumberUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;
import com.equabli.common.entity.Document;
import com.equabli.common.entity.UserDocConfig;
import com.equabli.common.enums.FileNameConfigEnum;
import com.equabli.common.exception.IOException;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.repository.DocCostRepository;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.repository.UserDocConfigRepository;
import com.equabli.common.request.ExcelFileRequest;
import com.equabli.common.request.FileUploadConfigRequest;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.file.operation.constants.FileOperationMessageConstants;
import com.equabli.file.operation.response.FileUploadConfigResponse;
import com.equabli.file.operation.response.integrationaccount.AccountsResponse;
import com.equabli.file.operation.response.integrationaccount.ClientResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FileReadOperationService {

	@Autowired
	DocCostRepository docCostRepository;

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	DocumentRepository documentRepository;

	@Autowired
	UserDocConfigRepository docConfigRepository;

	@Autowired
	FileUploadDatabaseOperation databaseOperation;
	
	@Autowired
	ValidateAccountsService validateAccountsService;

	private AsyncService asyncService;

	@Autowired
	public FileReadOperationService(AsyncService asyncService) {
		this.asyncService = asyncService;
	}

	public static final String POLICY_TYPE = "RE";
	private static final String CLIENT = "CL";
	private static final int SHEET_INDEX = 0;
	private static final int HEADER_RAW_NUMBER = 0;

	public List<String> readExcelFile(File file, FileUploadConfigRequest fileRequest, File[] listOfFile,
			TokenData tokenData, List<AccountsResponse> eqCollectAccount) {
		List<String> listOfresponse = new ArrayList<>();
		if (!validateHeader(file)) 
			throw new InvalidArgumentException(messageSupplier
					.get(FileOperationMessageConstants.FileOperationConfigs.UPLOADED_EXCEL_HEADER_NAME_INVALID));

		try (FileInputStream fis = new FileInputStream(file); XSSFWorkbook wb = new XSSFWorkbook(fis)) {
			XSSFSheet sheet = wb.getSheetAt(0);
			Iterator<Row> itr = sheet.iterator();
			// iterating over excel file
			while (itr.hasNext()) {
				Row row = itr.next();
				if (row.getRowNum() == 0)
					continue;

				List<String> validate = validateRow(row, fileRequest, listOfFile, tokenData, eqCollectAccount);
				if (!validate.isEmpty())
					listOfresponse.addAll(validate);
			}
		} catch (Exception e) {
			throw new IOException(e.getMessage());
		}
		return listOfresponse;	
	}

	private boolean validateHeader(File file) {
		boolean isValid = true;
		try (FileInputStream fis = new FileInputStream(file); XSSFWorkbook wb = new XSSFWorkbook(fis)) {
			Sheet sheet = wb.getSheetAt(SHEET_INDEX);
			Row headerRow = sheet.getRow(HEADER_RAW_NUMBER);
			for (int col = 0; col < FileOperationMessageConstants.FileOperationConfigs
					.getUploadBulkDocHeader().length; col++)
				if (!headerRow.getCell(col).getStringCellValue().equalsIgnoreCase(
						FileOperationMessageConstants.FileOperationConfigs.getUploadBulkDocHeader()[col])) {
					isValid = false;
					break;
				}
		} catch (Exception e) {
			throw new IOException(e.getMessage());
		}
		return isValid;
	}

	private List<String> validateRow(Row row, FileUploadConfigRequest fileRequest, File[] listOfFile,
			TokenData tokenData, List<AccountsResponse> eqCollectAccount) {

		ExcelFileRequest excelFileRequest = new ExcelFileRequest();
		String[] bulkHeader = FileOperationMessageConstants.FileOperationConfigs.getUploadBulkDocHeader();
		List<String> message = new ArrayList<>();
		int maxColumnNumber = Constants.PARTNER_CODE.equals(tokenData.getOrgType())
				? FileOperationMessageConstants.FileOperationConfigs.BULK_PARTNER_COLUMNS
				: FileOperationMessageConstants.FileOperationConfigs.BULK_CLIENT_COLUMNS;

		for (int cellNumber = 0; cellNumber < bulkHeader.length; cellNumber++) {
			Cell currentCell = row.getCell(cellNumber);
			if (currentCell == null || !StringUtils.hasText(getCellValue(currentCell))) {
				requiredColumn(row.getRowNum(), cellNumber, maxColumnNumber).ifPresent(message::add);
			} else {
				addCellValueToRequest(currentCell, excelFileRequest);
			}
		}
		log.info("RowNumber {}, maxColumnNumber {}, message {}, excelFileRequest {}", row.getRowNum(), maxColumnNumber, message, excelFileRequest);

		if (message.isEmpty()) {
			log.info("RowNumber {} is valid ", row.getRowNum());
			FileUploadConfigResponse response = new FileUploadConfigResponse();
			boolean status = updateFileDetails(tokenData, excelFileRequest, fileRequest, listOfFile, response,
					eqCollectAccount);
			if (status) {
				log.info("Update File status....{} ", status);
				File file = checkForFileExists(listOfFile, excelFileRequest.getFileName());
				asyncService.uploadFile(response, fileRequest, file, tokenData);
				// databaseOperation.updateFilePath(fileRequest, tokenData);
			} else
				message.add(
						messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.FILE_NOT_FOUND_IN_ZIP,
								excelFileRequest.getFileName()));
		}
		return message;
	}

	private String getCellValue(Cell cell) {
		String val = null;
		switch (cell.getCellType()) {
		case STRING -> val = cell.getStringCellValue();
		case NUMERIC -> val = String.format("%.0f", cell.getNumericCellValue());
		default -> log.error("Invalide value");
		}
		return val;
	}

	private String getNameOfCell(int index) {
		return FileOperationMessageConstants.FileOperationConfigs.getUploadBulkDocHeader()[index];
	}

	private void addCellValueToRequest(Cell cell, ExcelFileRequest excelFileRequest) {
		String cellValue = getCellValue(cell);
		int columnIndex = cell.getColumnIndex();

		switch (columnIndex) {
		case 0 -> excelFileRequest.setDocShortCode(cellValue);
		case 1 -> excelFileRequest.setProdCode(cellValue);
		case 2 -> excelFileRequest.setOriginalAccountNO(cellValue);
		case 3 -> excelFileRequest.setClientAccountNo(cellValue);
		case 4 -> excelFileRequest.setDocumentGenerationDate(cellValue);
		case 5 -> excelFileRequest.setEqaubliAccountNo(NumberUtils.createLong(cellValue));
		case 6 -> excelFileRequest.setFileName(cellValue);
		case 7 -> excelFileRequest.setClientShortCode(cellValue);
		default -> log.error("Invalide ColumnIndex {}", columnIndex);
		}
	}

	private Boolean updateFileDetails(TokenData tokenData, ExcelFileRequest excelFileRequest,
			FileUploadConfigRequest fileRequest, File[] listOfFile, FileUploadConfigResponse response,
			List<AccountsResponse> eqCollectAccount) {
		boolean isValidFile = false;
		// Get user doc configuration data by user type id
		List<UserDocConfig> fileNameConfigs = docConfigRepository
				.findByOrgCodeAndDocMgrConfig_ShortCodeStartsWithAndIsDeleteFalseOrderByDocMgrConfig_ShortCode(
						tokenData.getUserOrgCode(), FileNameConfigEnum.FIELD.getShortCode());
		String docPolicy = tokenData.getOrgType().equals(CLIENT) ? databaseOperation.getDocumentPolicy(tokenData) : "";
		boolean documentPolicy = tokenData.getOrgType().equals(CLIENT) ? docPolicy.equals(POLICY_TYPE) : true;
		File file = checkForFileExists(listOfFile, excelFileRequest.getFileName());
		if (file == null)
			return false;
		else {
			fileRequest.setFileSize(file.length());
			fileRequest.setIsFileValid(true);
			String docName = databaseOperation.getDocumentName(excelFileRequest.getDocShortCode());
			String dirPath = getDirStructure(excelFileRequest, fileRequest, fileNameConfigs);
			databaseOperation.deleteDocumentIfExsitsForAccountNo(excelFileRequest.getClientAccountNo(),
					excelFileRequest.getFileName(), documentPolicy, tokenData);

			String separator = databaseOperation.getSeperator(tokenData);
			String generatedFileName = databaseOperation.generatedFileName(fileRequest, docName, false,
					fileNameConfigs.size(), separator, tokenData.getUserOrgCode(), fileRequest.getFileName());
			fileRequest.setGeneratedFileName(generatedFileName);
			Document document = new Document();
			document.saveDocument(document, fileRequest, isValidFile, "", docName, tokenData, tokenData);
			documentRepository.save(document);
			
			validateAccountsService.validateClientAccountNumbers(eqCollectAccount, tokenData, document);
			
			Optional<ClientResponse> clientDetail = databaseOperation.getMappedClientDetailForPartner(tokenData.getToken(), tokenData,
					excelFileRequest.getClientShortCode());
			log.info("updateFileDetails clientDetail {}", clientDetail);
			databaseOperation.updateUsage(fileRequest.getFileSize(), 1l, tokenData, clientDetail);
			
			generateResponse(tokenData, isValidFile, documentPolicy, document.getId(), dirPath, response);
			return true;
		}
	}

	private String getDirStructure(ExcelFileRequest excelFileRequest, FileUploadConfigRequest fileUploadVo,
			List<UserDocConfig> fileNameConfigs) {
		for (UserDocConfig fileNameConfig : fileNameConfigs) {
			String fieldName = fileNameConfig.getDocMgrConfigValSelectedCode();
			switch (fieldName) {
			case "DT" -> fileUploadVo.setDocType(excelFileRequest.getDocShortCode());
			case "CAN" -> fileUploadVo.setClientAccountNo(excelFileRequest.getClientAccountNo());
			case "OAN" -> fileUploadVo.setOriginalAccountNo(excelFileRequest.getOriginalAccountNO());
			case "DGD" -> fileUploadVo.setDocumentGenerationDate(
					Util.convertLocalDateToUtc(excelFileRequest.getDocumentGenerationDate()));
			case "DN" -> fileUploadVo.setDocumentName(excelFileRequest.getDocShortCode());
			case "PC" -> fileUploadVo.setProductCode(excelFileRequest.getProdCode());
			default -> log.error("Invalide field short code");
			}
		}
		fileUploadVo.setFileName(excelFileRequest.getFileName());
		fileUploadVo.setEquabliAccNo(excelFileRequest.getEqaubliAccountNo() == null ? null : excelFileRequest.getEqaubliAccountNo());		
		return excelFileRequest.getClientAccountNo() + File.separator + excelFileRequest.getProdCode() + File.separator
				+ excelFileRequest.getOriginalAccountNO() + File.separator + excelFileRequest.getDocShortCode()
				+ File.separator + excelFileRequest.getDocumentGenerationDate() + File.separator
				+ excelFileRequest.getFileName();
	}

	private File checkForFileExists(File[] listOfFile, String name) {

		if (listOfFile != null && listOfFile.length > 0) {
			for (int i = 0; i < listOfFile.length; i++) {
				if (listOfFile[i].getName().equals(name)) {
					return listOfFile[i];
				}
			}
		}
		return null;
	}

	private FileUploadConfigResponse generateResponse(TokenData tokenData, boolean isValidFile, boolean documentPolicy,
			Long documentId, String dirPath, FileUploadConfigResponse configResponse) {
		configResponse.setDocumentId(documentId);
		configResponse.setDocumentPolicy(documentPolicy);
		configResponse.setIsFileValid(isValidFile);
		configResponse.setOrgTypeCode(tokenData.getUserOrgCode());
		configResponse.setDirStructure(dirPath);
		return configResponse;
	}

	private Optional<String> requiredColumn(int rowNumber, int columnNumber, int maxColumnNumber) {
	    if (columnNumber >= 0 && columnNumber <= maxColumnNumber && columnNumber != 5) {
	        String message = messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.INVALID_VALUE_IN_ROW,
	                getNameOfCell(columnNumber), (rowNumber + 1));
	        return Optional.ofNullable(message);
	    } else {
	        log.debug("Column is not required.");
	        return Optional.empty();
	    }
	}

}
