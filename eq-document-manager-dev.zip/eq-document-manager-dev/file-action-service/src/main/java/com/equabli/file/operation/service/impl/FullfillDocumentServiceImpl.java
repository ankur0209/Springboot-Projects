package com.equabli.file.operation.service.impl;

import java.io.File;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.Document;
import com.equabli.common.entity.SendReceiveDocument;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.repository.SentReceiveDocumentRepository;
import com.equabli.common.request.FileUploadConfigRequest;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.file.operation.integration.FileOperation;
import com.equabli.file.operation.response.FileUploadConfigResponse;
import com.equabli.file.operation.service.FileUploadDatabaseOperation;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FullfillDocumentServiceImpl {
	
	@Autowired FileUploadDatabaseOperation databaseOperation;
	@Autowired SentReceiveDocumentRepository sentReceiveDocumentRepository; 
	@Autowired MessageSupplier messageSupplier;
	
	@Qualifier(value = "s3FileOperation")
	@Autowired FileOperation fileOperation;
	
	private static final String SEPERATOR = File.separator;
	
	public SendReceiveDocument handleFullfillDocument(TokenData tokenData, Long id, File file, String authorization,
			String clientShortCode) {
		SendReceiveDocument sendReceiveDocument = sentReceiveDocumentRepository.findById(id)
				.orElseThrow(() -> new InvalidArgumentException(messageSupplier.get(MessageConstants.NOT_VALID, id)));
		String docName = sendReceiveDocument.getDocumentType();
		FileUploadConfigRequest fileRequest = getFileRequestForFullFillFile(sendReceiveDocument,file.getName(),file.length());
		FileUploadConfigResponse response = new FileUploadConfigResponse();
		Document document = databaseOperation.saveFullfillmentrequest(tokenData,fileRequest,docName,response, authorization, clientShortCode);
		String dirStructure = getDirStructureForFullfillFile(sendReceiveDocument,file.getName(), document.getProductCode());
		response.setDirStructure(dirStructure);
		fileOperation.uploadFile(fileRequest, response, file, "", tokenData);
		String filePathResponse = databaseOperation.updateFilePath(fileRequest, tokenData);
		databaseOperation.updateSendReceiveRequest(document, tokenData, id);
		log.info("Wait for DB :: " + filePathResponse);
		return sendReceiveDocument;
	}

	private String getDirStructureForFullfillFile(SendReceiveDocument sendReceiveDocument, String fileName, String prodCode) {
		return sendReceiveDocument.getClientAccountNo()+SEPERATOR+prodCode+
				SEPERATOR+sendReceiveDocument.getDocTypeCode()+SEPERATOR+fileName;
	}

	private FileUploadConfigRequest getFileRequestForFullFillFile(SendReceiveDocument sendReceiveDocument,
			String name, long size) {
		FileUploadConfigRequest configRequest = new FileUploadConfigRequest();
		configRequest.setDocType(sendReceiveDocument.getDocTypeCode());
		configRequest.setProductCode(sendReceiveDocument.getProductCode());
		configRequest.setPortfolioId(null);
		configRequest.setDocumentGenerationDate(LocalDateTime.now());
		configRequest.setFileName(name);
		configRequest.setFileSize(size);
		configRequest.setClientAccountNo(sendReceiveDocument.getClientAccountNo());
		configRequest.setOriginalAccountNo(sendReceiveDocument.getOriginalAccountNo());
		configRequest.setEquabliAccNo(sendReceiveDocument.getEquabliAccNo());
		return configRequest;
	}

}