package com.equabli.file.operation.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.equabli.common.configs.FeignClientConfig;
import com.equabli.common.constants.Constants;

@FeignClient(name = "eq-collect-service", url = "https://service2.equabli.net/Accounts/", configuration = FeignClientConfig.class)
public interface EQCollectService {

	@GetMapping(value = "accountDetails")
	String getAccountDetails(@RequestHeader(Constants.REQUEST_ORIGIN) String rqsOrigin,
			@RequestParam("clientId") Integer clientId,
			@RequestParam("clientAccountNumber") String clientAccountNumber);
}
