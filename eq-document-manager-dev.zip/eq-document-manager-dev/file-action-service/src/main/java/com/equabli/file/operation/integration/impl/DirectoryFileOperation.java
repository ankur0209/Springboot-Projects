package com.equabli.file.operation.integration.impl;

import java.io.File;
import java.nio.file.Path;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.request.FileUploadConfigRequest;
import com.equabli.common.utils.Util;
import com.equabli.file.operation.integration.FileOperation;
import com.equabli.file.operation.response.FileUploadConfigResponse;

import lombok.extern.slf4j.Slf4j;

@Qualifier("directoryFileOperation")
@Slf4j
@Service
public abstract class DirectoryFileOperation implements FileOperation {
	
	@Value("${files.upload.baseDir}")
	private String fileUploadBasePath;
	
	@Override
	public FileUploadConfigRequest uploadFile(FileUploadConfigRequest fileUploadVo, FileUploadConfigResponse response,
			File file, String bulk, TokenData tokenData) {
		log.info("Local Directory Calling........");

		boolean isFileValid = response.getIsFileValid();

		return getFileAfterWrite(fileUploadVo, isFileValid, file, file.getName(), response.getDocumentPolicy());

	}

	private FileUploadConfigRequest getFileAfterWrite(FileUploadConfigRequest fileUploadVo, boolean isFileValid,
			File file, String filename, boolean documentPolicy) {

		String uploadFilePath = null;
		String orgCodeType = isFileValid ? MessageConstants.INVALID_USER : fileUploadVo.getOrgType();
		// directory if exits then okay otherwise create directory as same as user type
		Path directoryPath = Util.createDirectoryIfNotExists(fileUploadBasePath, orgCodeType);

		// Check for user type if file is not valid then file upload at other directory
		// otherwise upload file in user type wise directory
		if (isFileValid) {
			Util.writeFileToPath(directoryPath.toAbsolutePath(), filename, file, documentPolicy);
			uploadFilePath = directoryPath.toString();
			fileUploadVo.setFilePath(uploadFilePath);
		} else {
			uploadFilePath = directoryPath.toString();
			Path userIdDirectoryPath = directoryPath.toAbsolutePath();
			Util.writeFileToPath(userIdDirectoryPath.toAbsolutePath(), filename, file, documentPolicy);
			fileUploadVo.setFilePath(uploadFilePath);
		}
		return fileUploadVo;
	}
}
