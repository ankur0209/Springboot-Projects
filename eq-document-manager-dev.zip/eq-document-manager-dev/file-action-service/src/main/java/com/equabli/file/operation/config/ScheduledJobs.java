package com.equabli.file.operation.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableScheduling
public class ScheduledJobs {

	@Bean(name = "accountsJob")
    @ConditionalOnProperty(value = "jobs.accounts.enabled", matchIfMissing = true, havingValue = "true")
    public AccountsJob scheduledJob() {
        return new AccountsJob();
    }
	
	@Bean(name = "subscriptonJob")
    @ConditionalOnProperty(value = "jobs.subscription.enabled", matchIfMissing = true, havingValue = "true")
    public SubscriptionJob subscriptonJob() {
        return new SubscriptionJob();
    }
}
