package com.equabli.file.operation.integration.accounts;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.StringUtils;

import com.equabli.common.auth.TokenData;
import com.equabli.common.auth.TokenValidation;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.ActivityLog;
import com.equabli.common.entity.Document;
import com.equabli.common.entity.UserDocConfig;
import com.equabli.common.enums.FileNameConfigEnum;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.feignclients.CommonConfigService;
import com.equabli.common.repository.ActivityLogRepository;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.repository.UserDocConfigRepository;
import com.equabli.common.response.PartnerResponse;
import com.equabli.common.response.ProcessIntegrationResponse;
import com.equabli.common.response.config.ConfigResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.file.operation.feignclient.UserService;
import com.equabli.file.operation.integration.FileOperation;
import com.equabli.file.operation.request.UserLoginRequest;
import com.equabli.file.operation.response.integrationaccount.AccountsResponse;
import com.equabli.file.operation.response.integrationaccount.ClientResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CommonIntegrationUtil {

	private static final String SEPERATOR = File.separator;

	@Autowired
	DocumentRepository documentRepository;

	@Autowired
	CommonConfigService commonConfigService;

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	MessageSupplier messageSupplier;

	@Qualifier(value = "s3FileOperation")
	@Autowired
	FileOperation fileOperation;
	
	@Autowired
	UserService userService;
	
	@Autowired
	TokenValidation tokenValidation;
	
	@Autowired
	ActivityLogRepository activityLogRepository;
	
	@Autowired
	UserDocConfigRepository docConfigRepository;
	

	/** Fetch document of using account number and client organization code
	 * @param account
	 * @param clientShortCode
	 * @return
	 */
	public List<Document> fetchDocuments(AccountsResponse account, String clientShortCode) {
		return documentRepository
				.findByClientAccountNoAndClientOrgCodeAndIsDeleteFalse(account.getClientAccountNumber(),
						clientShortCode)
				.stream().filter(document -> !clientShortCode.equals(document.getOrgCode())).toList();
	}

	/**
	 * Fetch document of using account number,client organization code and partner
	 * organization code
	 * 
	 * @param account
	 * @param clientShortCode
	 * @return
	 */
	public List<Document> fetchDocumentsOfPartner(String account, String clientShortCode,
			String partnerOrgCode) {
		List<Document> documents = documentRepository.findByClientAccountNoAndClientOrgCodeAndOrgCodeAndIsDeleteFalse(
				account, clientShortCode, partnerOrgCode);

		return documents.stream().filter(l -> !clientShortCode.equals(l.getOrgCode())).toList();
	}

	/** Method use for to process document for Assign as well as reassign account. 
	 * @param documents
	 * @param processIntegrationResponses
	 * @param tokenData
	 * @param partner
	 * @param clientOrgCode
	 * @return
	 */
	public List<Document> processDocument(List<Document> documents, List<ProcessIntegrationResponse> processIntegrationResponses,
			TokenData tokenData, PartnerResponse partner,String clientOrgCode) {
		Long userId = 0l;
		List<Document> processDocuments = new ArrayList<>();
		ProcessIntegrationResponse processIntegrationResponse = null;
		for (Document document : documents) {
			processIntegrationResponse = new ProcessIntegrationResponse();
			processIntegrationResponse.setExistingData(document);
			Document newDocument = saveDocument(document, tokenData, partner, userId,
					clientOrgCode);
			processIntegrationResponse.setNewData(newDocument);
			processDocuments.add(newDocument);
			processIntegrationResponses.add(processIntegrationResponse);
		}
		copyDocument(partner, documents);
		return processDocuments;
	}
	
	/**
	 * Copy document to one to another partner in amazon s3 bucket After that save
	 * document to database.
	 * 
	 * @param document
	 * @param tokenData
	 * @param partnerDetail
	 * @param userId
	 * @param clientShortCode
	 * @param long1
	 * @return
	 */
	public Document saveDocument(Document document, TokenData tokenData, PartnerResponse partnerDetail, Long userId,
			String clientShortCode) {
		Document toDocument = new Document();
		String newFileName = generatedFileName(document.getGeneratedFileName(), partnerDetail.getShortName(),clientShortCode);
		document.saveDocument(document, toDocument, userId, document.getOrgTypeCode(), document.getOrgCode(),
				tokenData);
		document.reAssignDocument(toDocument, tokenData, userId, partnerDetail.getShortName(), newFileName,
				clientShortCode);
		String newObjectKey = getObjectKey(document.getObjKey(), partnerDetail, SEPERATOR, toDocument.getOrgTypeCode());
		document.saveObjectKey(toDocument, newObjectKey, newObjectKey);
		return toDocument;
	}

	/**
	 * Copy document to one to another partner in amazon s3 bucket
	 * 
	 * @param objectKey
	 * @param partnerDetail
	 * @param seperator
	 * @param orgTypeCode
	 * @return
	 */
	public String getObjectKey(String objectKey, PartnerResponse partnerDetail, String seperator, String orgTypeCode) {
		String[] objectKeys = objectKey.split(seperator);
		objectKeys[0] = getOrgType(orgTypeCode);
		objectKeys[1] = partnerDetail.getShortName();

		return StringUtils.join(objectKeys, seperator);
	} 
	
	public void copyDocument(PartnerResponse partnerDetail, List<Document> documents) {
		String accountNo = getAccountNoFromList(documents);
		String clientOrgCode = getOrgCodeFromList(documents);
		String clientPath = MessageConstants.UploadFileConstants.CLIENT + SEPERATOR + clientOrgCode;
		String partnerPath = MessageConstants.UploadFileConstants.PARTNER + SEPERATOR + partnerDetail.getShortName();
		String clientFilePath = clientPath + SEPERATOR + MessageConstants.UploadFileConstants.MEDIA + SEPERATOR
				+ MessageConstants.UploadFileConstants.DOCUMENT + SEPERATOR + accountNo + SEPERATOR;
		String partnerFilePath = partnerPath + SEPERATOR + MessageConstants.UploadFileConstants.MEDIA + SEPERATOR
				+ MessageConstants.UploadFileConstants.DOCUMENT + SEPERATOR + accountNo + SEPERATOR;
		fileOperation.copyAccountFolder(clientFilePath, partnerFilePath);
	}

	public String deleteDocumentFromDB(Document document, TokenData tokenData) {
		document.deleteDocument(document, tokenData);
		documentRepository.save(document);
		return document.getObjKey();
	}
	
	/**
	 * Delete document of partner in amazon s3 bucket
	 * 
	 * @param documents
	 * @param tokenData
	 * @param clientShortCode
	 * @param processIntegrationResponse 
	 * @return
	 */
	public void deleteDocument(List<String> objectKeys) {
		fileOperation.deleteAccountNumberData(objectKeys);
	}
	
	/**
	 * Collect partner's detail using partnerId
	 * 
	 * @param partnerId
	 * @return
	 */
	public List<PartnerResponse> getPartnersByFullNames(TokenData clientTokenData, List<String> partnerNames) {
		String rqsOrigin = "web";
		try {
			String patnersJson = commonConfigService.getPartnersByFullNames(clientTokenData.getToken(), rqsOrigin, partnerNames);
			ConfigResponse<List<PartnerResponse>> partnersResponse = objectMapper.readValue(patnersJson,
					new TypeReference<ConfigResponse<List<PartnerResponse>>>() {
					});

			log.info("partnersResponse {}", partnersResponse);
			return partnersResponse.getResponse();
		} catch (Exception e) {
			log.error("ERROR WHILE FETCHING getPartnersByPartnerIds ->{}", e.getMessage(), e);
		}
		return Collections.emptyList();
	}

	public TokenData getUserToken(String loginKey, String loginSecret) {
		try {
			String rqsOrigin = "web";
			String loginResponse = userService.login(rqsOrigin,
					UserLoginRequest.builder().loginKey(loginKey).loginSecret(loginSecret).build());
			ConfigResponse<TokenData> commonResponse = objectMapper.readValue(loginResponse,
					new TypeReference<ConfigResponse<TokenData>>() {
					});

			String authorization = "Bearer " + commonResponse.getResponse().getToken();
			TokenData tokenData = tokenValidation.handleRequest(authorization).getPrinciple();
			tokenData.setToken(authorization);

			log.info("tokenData {}", tokenData);
			return tokenData;
		} catch (JsonProcessingException e) {
			log.error("ERROR JSON PROCESSING getUserToken ->{}", e.getMessage(), e);
		} catch (Exception e) {
			log.error("ERROR WHILE FETCHING getUserToken Detail ->{}", e.getMessage(), e);
		}
		throw new InvalidArgumentException(
				messageSupplier.get(MessageConstants.AuthConstants.USER_LOGIN_INVALID_CREDENTIALS));
	}

	/**
	 * Check for organization code of exist documents
	 * 
	 * @param toOrgTypeCode
	 * @return
	 */
	public String getOrgType(String toOrgTypeCode) {
		String orgType = Util.getOrgType(toOrgTypeCode);
		if (null == orgType)
			throw new InvalidArgumentException(
					messageSupplier.get(MessageConstants.NOT_VALID, "Organization Type Code " + toOrgTypeCode));
		return orgType;
	}

	public void addActivityLog(TokenData tokenData, Object existingData, Object newData) {
		try {
			log.info("existingData {}, newData {} ", existingData, newData);
			String existingDataJson = objectMapper.writeValueAsString(existingData);
			String newDataJson = objectMapper.writeValueAsString(newData);
			ActivityLog activityLog = new ActivityLog();
			activityLog.saveActivityLog(activityLog, tokenData, existingDataJson, newDataJson,
					ActivityLog.ActivityTypeEnum.ACCOUNT_INTEGRATION);
			activityLogRepository.save(activityLog);
		} catch (JsonProcessingException je) {
			log.error("ERROR WHILE ADD ActivityLog ", je);
		}
	}

	private String generatedFileName(String genarateFileName, String orgCode, String clientShortCode) {
		String seperatorForGeneratedFile = "-";
		String fileSeperator = getSeperator(clientShortCode);
		String[] path = genarateFileName.split(fileSeperator);
		path[0] = orgCode;

		return StringUtils.join(path, seperatorForGeneratedFile);
	}
	
	public Optional<List<ClientResponse>> getClientsByShortCode(TokenData clientTokenData, List<String> shortCode) {
		String rqsOrigin = "web";
		try {
			String clientJson = commonConfigService.getClientsByShortCode(clientTokenData.getToken(), rqsOrigin,
					shortCode);
			ConfigResponse<List<ClientResponse>> clientsResponse = objectMapper.readValue(clientJson,
					new TypeReference<ConfigResponse<List<ClientResponse>>>() {
					});

			log.info("clientsResponse {}", clientsResponse);
			return Optional.ofNullable(clientsResponse.getResponse());
		} catch (Exception e) {
			log.error("ERROR WHILE FETCHING getPartnersByPartnerIds ->{}", e.getMessage(), e);
		}
		return Optional.empty();
	}
	
	public String getAccountNoFromList(List<Document> documents) {
		return documents.stream().map(Document::getClientAccountNo).distinct().toList().get(0);
	}
	
	public String getOrgCodeFromList(List<Document> documents) {
		return documents.stream().map(Document::getOrgCode).distinct().toList().get(0);
	}
	
	public String getSeperator(String orgCode) {
		return docConfigRepository
				.findByOrgCodeAndDocMgrConfig_ShortCodeStartsWithAndIsDeleteFalseOrderByDocMgrConfig_ShortCode(
						orgCode, FileNameConfigEnum.SEPARATOR.getShortCode())
				.stream().map(UserDocConfig::getDocMgrConfigValSelectedCode).findFirst()
				.orElseThrow(() -> new InvalidArgumentException(
						messageSupplier.get(MessageConstants.NOT_VALID, FileNameConfigEnum.SEPARATOR.getShortCode())));
	}
	
	public Optional<String> uploadFile(Document document, File file) {
		return fileOperation.uploadFile(document, file);
	}
}
