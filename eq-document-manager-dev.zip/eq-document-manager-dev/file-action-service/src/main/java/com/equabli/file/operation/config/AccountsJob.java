package com.equabli.file.operation.config;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import com.equabli.file.operation.integration.accounts.AccountIntegration;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AccountsJob {

	public static final String ACCOUNTS_CRON= "0 0 0 * * *";

	@Autowired
	AccountIntegration accountIntegration;

	@Scheduled(cron = ACCOUNTS_CRON)
	public void fetchAccountDetail() {
		log.info("Integrate Account Job Start {}", LocalDateTime.now());
		accountIntegration.integrateAccount();
		log.info("Integrate Account Job Completed {}", LocalDateTime.now());
	}
}
