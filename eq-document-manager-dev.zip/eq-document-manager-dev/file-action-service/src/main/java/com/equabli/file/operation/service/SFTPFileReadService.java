package com.equabli.file.operation.service;

import com.equabli.common.response.CommonResponse;

public interface SFTPFileReadService {

	void readFileFromSFTP(String objectKey) throws Exception ;

	CommonResponse<String> pauseSqsListener();

	CommonResponse<String> startSqsListener();
	
}
