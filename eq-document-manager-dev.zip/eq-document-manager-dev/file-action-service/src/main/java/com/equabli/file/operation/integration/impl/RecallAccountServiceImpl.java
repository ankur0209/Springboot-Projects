package com.equabli.file.operation.integration.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.entity.Document;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.response.PartnerResponse;
import com.equabli.common.response.ProcessIntegrationResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.file.operation.integration.FileOperation;
import com.equabli.file.operation.integration.ProcessIntegration;
import com.equabli.file.operation.integration.accounts.CommonIntegrationUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Qualifier("recallAccountService")
@Slf4j
public class RecallAccountServiceImpl implements ProcessIntegration {

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	DocumentRepository documentRepository;

	@Qualifier(value = "s3FileOperation")
	@Autowired
	FileOperation fileOperation;

	@Autowired
	CommonIntegrationUtil commonIntegrationUtil;

	@Autowired
	FetchTokenData fetchTokenData;

	@Override
	public List<ProcessIntegrationResponse> executeIntegration(List<Document> documents, PartnerResponse partner,
			TokenData tokenData, String clientOrgCode) {
		log.info("Call for Re-Call document to partner for this account no {},");
		List<ProcessIntegrationResponse> processIntegrationResponses = new ArrayList<>();
		Optional<List<Document>> newDocuments = Optional.ofNullable(commonIntegrationUtil.fetchDocumentsOfPartner(
				commonIntegrationUtil.getAccountNoFromList(documents), clientOrgCode, partner.getShortName()));
		if(newDocuments.isPresent())
			handleDeleteDocument(newDocuments.get(), tokenData, processIntegrationResponses);
		return processIntegrationResponses;
	}

	public List<ProcessIntegrationResponse> handleDeleteDocument(List<Document> documents, TokenData tokenData,
			List<ProcessIntegrationResponse> processIntegrationResponses) {
		List<String> objectKey = new ArrayList<>();
		ProcessIntegrationResponse processIntegrationResponse = null;
		for (Document document : documents) {
			processIntegrationResponse = new ProcessIntegrationResponse();
			processIntegrationResponse.setExistingData(document);
			objectKey.add(commonIntegrationUtil.deleteDocumentFromDB(document, tokenData));
			processIntegrationResponse.setNewData(document);
			processIntegrationResponses.add(processIntegrationResponse);
		}
		commonIntegrationUtil.deleteDocument(objectKey);
		return processIntegrationResponses;
	}
}
