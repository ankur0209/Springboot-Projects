package com.equabli.file.operation.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.equabli.common.configs.FeignClientConfig;
import com.equabli.common.constants.Constants;
import com.equabli.common.request.UserEmailRequest;
import com.equabli.file.operation.request.UserLoginRequest;

@FeignClient(name = "user-service", path = "/user-service/api", configuration = FeignClientConfig.class)
//@FeignClient(name = "user-service", url = "http://k8s-equablid-equablii-3d7f80b23b-1277713601.us-east-1.elb.amazonaws.com/user-service/api", configuration = FeignClientConfig.class)
public interface UserService {

	@PostMapping(value = "/v1/users/email/exists", consumes = {MediaType.APPLICATION_JSON_VALUE})
	String emailExists(@RequestHeader(Constants.AUTHORIZATION) String bearerToken,
			@RequestBody UserEmailRequest userEmailRequest);
	
	@PostMapping(value = "/login", consumes = {MediaType.APPLICATION_JSON_VALUE})
	String login(@RequestHeader(Constants.REQUEST_ORIGIN) String rqsOrigin, @RequestBody UserLoginRequest userLoginRequest);
}
