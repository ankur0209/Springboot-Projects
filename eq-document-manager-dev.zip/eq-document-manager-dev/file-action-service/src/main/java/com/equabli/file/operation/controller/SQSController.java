package com.equabli.file.operation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.response.CommonResponse;
import com.equabli.file.operation.service.SFTPFileReadService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/file/sqs/")
@Tag(name = "SQS Listener API", description = "SQS Listener API for document manager")
@SecurityRequirement(name = "bearerAuth")
@Slf4j
public class SQSController {

	@Autowired
	SFTPFileReadService sftpFileReadService;

	@Autowired
	FetchTokenData fetchTokenData;

	@PostMapping("stop")
	@Operation(summary = "Stop SQS ", description = "stop the SQS listener", hidden = true)
	public CommonResponse<String> pauseSqsListener() {
		log.info("fetchTokenData  -> {}", fetchTokenData.getTokenData());
		return sftpFileReadService.pauseSqsListener();
	}

	@PostMapping("start")
	@Operation(summary = "Start SQS ", description = "start the SQS listener", hidden = true)
	public CommonResponse<String> starSQS() {
		log.info("fetchTokenData  -> {}", fetchTokenData.getTokenData());
		return sftpFileReadService.startSqsListener();
	}
}
