package com.equabli.file.operation.response;

import javax.validation.constraints.NotBlank;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class FileUploadConfigResponse {

	
	@NotBlank
	@Schema(description = "Give orgTypeCode means which user is client, partner or any other need to specify here", example = "CT")
	private String orgTypeCode;
	
	@NotBlank
	@Schema(description = "Get file is valid or not", example = "Client")
	private Boolean isFileValid;
	
	@Schema(description = "Document id which insert currently", example = "4")
	private Long documentId;
	
	@Schema(description = "upload file need to be replace or create new", example = "4")
	private Boolean documentPolicy;
	
	@Schema(description = "", example = "4")
	private int docNo;
	
	@Schema(description = "", example = "4")
	private String documentRejected;
	
	@Schema(description = "", example = "")
	private String dirStructure;
	
}
