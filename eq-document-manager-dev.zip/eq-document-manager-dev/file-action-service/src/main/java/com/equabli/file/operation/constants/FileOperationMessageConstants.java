package com.equabli.file.operation.constants;

public final class FileOperationMessageConstants {
	
	public static final String INCOMING_MEDIA = "incomingMedia";

	public static final String FILE_NOT_VALID = "file.not.valid";
	public static final String ERROR_WHILE_UPLOAD_FILE = "error.while.upload.file";
	
	public static final String SQS_START_SUCCESS = "sqs.start.success";
	public static final String SQS_STOP_SUCCESS = "sqs.stop.success";
	public static final String HYPHEN = "-";
	public static final String GENERATE_FILE_NAME_SEPERATOR = "-";
	
	/**
	 * Default separator when UserDocConfig not saved
	 */
	public static final String DEFAULT_SEPARATOR = "-";
	
	public final class FileOperationConfigs {

		private FileOperationConfigs() {
		}

		public static final String CREATE_SUCCESS = "file.operation.create.success";
		public static final String FETCH_SUCCESS = "file.operation.fetch.success";
		public static final String EXCEL_HEADER_REQUIRED = "excel.header.required";
		public static final String EXCEL_HEADER_NAME_INVALID = "excel.header.name.invalid";
		public static final String EXCEL_FILE_UPLOAD_SUCCESS = "excel.file.upload.success";
		public static final String EXCEL_FILE_INVALID_VALUES = "excel.file.invalid.values";
		public static final String EXCEL_FILE_UPLOAD_ERROR = "excel.file.upload.error";
		private static final String[] BULK_SEND_REQUEST_DOC_HEADER = { "Document Type", "Requested From",
				"Original Account Number", "Client Account Number", "Equabli Account Number", "Client Short Code" };

		public static String[] getBulkSendRequestDocHeader() {
			return BULK_SEND_REQUEST_DOC_HEADER.clone();
		}
		/**
		 * Number of columns required for excel sheet for Sent bulk document request 
		 */
		public static final int SENT_BULK_CLIENT_COLUMNS = 5;
		public static final int SENT_BULK_PARTNER_COLUMNS = 6;
		
		public static final String MULTIPLE_FILE_LENGTH_INVALID = "multiple.file.length.invalid";
		public static final Integer MULTIPLE_FILE_LENGTH = 10;
		
		public static final String PRE_SIGN_URL_SUCCESS = "preurl.generation.create.success";
		
		private static final String[] UPLOAD_BULK_DOC_HEADER = { "Document Type", "Product Code",
				"Original Account Number", "Client Account Number", "Document Generation Date",
				"Equabli Account Number", "File Name", "Client Short Code" };

		public static String[] getUploadBulkDocHeader() {
			return UPLOAD_BULK_DOC_HEADER.clone();
		}
		
		/**
		 * Number of columns required for excel sheet for bulk file
		 * start index from zero 
		 */
		public static final int BULK_CLIENT_COLUMNS = 6;
		public static final int BULK_PARTNER_COLUMNS = 7;
		
		public static final String INVALID_VALUE_IN_ROW = "invalid.value.in.row";
		public static final String FILE_NOT_FOUND_IN_ZIP = "file.not.found.in.zip";
		public static final String UPLOADED_EXCEL_HEADER_NAME_INVALID = "uploaded.excel.header.name.invalid";
		public static final String DOWNLOAD_FILE_SUCCESS = "download.file.successfully";
		public static final String DOWNLOAD_FOLDER_SUCCESS = "download.folder.successfully";
	}
	
	public final class DeleteDocument {
		private DeleteDocument() {
		}

		public static final String DOCUMENT_DELETE_SUCCESS = "document.delete.success";
	}
}
