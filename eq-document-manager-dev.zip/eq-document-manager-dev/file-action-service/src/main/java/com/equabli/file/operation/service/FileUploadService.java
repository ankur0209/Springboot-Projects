package com.equabli.file.operation.service;

import java.io.File;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.equabli.common.auth.TokenData;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.FileOperationResponse;
import com.equabli.file.operation.request.FileUploadDataRequest;

public interface FileUploadService {

	/**
	 * To upload single file
	 * 
	 * @param fileUploadJson
	 * @param file
	 * @param request
	 * @return
	 */
	CommonResponse<String> uploadFile(MultipartFile file);

	/**
	 * To upload multiple files
	 * 
	 * @param multipartFiles
	 * @param fileUploadJson
	 * @param fileUploadJson
	 * @return
	 */
	CommonResponse<FileOperationResponse> uploadMultipleFile(List<MultipartFile> multipartFiles);

	/**
	 * To upload zip file
	 * 
	 * @param multipartFiles
	 * @param fileUploadJson
	 * @param fileUploadJson
	 * @return
	 */
	CommonResponse<?> uploadBulkFile(List<MultipartFile> files, String fileUploadJson);

	CommonResponse<FileOperationResponse> handleBulkFile(FileUploadDataRequest dataRequest);

	CommonResponse<FileOperationResponse> uploadFile(File file, TokenData tokenData);
	
	CommonResponse<String> uploadDocumentForFullfill(MultipartFile file, Long id, String clientShortCode);

	/**
	 * UPload file for a specific document Type those account have not document
	 * 
	 * @param file
	 * @param documentType
	 * @param tenure
	 * @param productCode
	 * @param portFolio
	 * @param userId
	 * @return
	 */
	CommonResponse<String> uploadFileForSpecificDocument(MultipartFile file, String fileUploadJson);

	CommonResponse<String> uploadFileForAccount(MultipartFile file, String data);
}
