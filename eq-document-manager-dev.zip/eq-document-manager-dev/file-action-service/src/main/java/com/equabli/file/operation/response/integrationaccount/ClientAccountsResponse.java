package com.equabli.file.operation.response.integrationaccount;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Client Account respnse from the EQ Collect accountDetails API")
public class ClientAccountsResponse {
	private Long accountId;
	private String clientName;
	private Integer clientId;
	private String consumerName;
	private Long consumerId;
	private Long equabliAccountNumber;
	private String originalAccountNumber;
	private String accountQueue;
	private String accountStatus;
	private String productType;
	private String chargeOffDate;
	private String chargeOffBalance;
	private String currentBalance;
	private Long placementId;
	private String originalLender;
	private String delinquencyDate;
	private String compliance;
	private String partnerName;
	private Long consumerNumber;
}
