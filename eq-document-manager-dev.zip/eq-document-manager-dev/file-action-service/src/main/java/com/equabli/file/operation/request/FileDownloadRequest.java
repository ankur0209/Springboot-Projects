package com.equabli.file.operation.request;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FileDownloadRequest {

	@Schema(description = "Document id should not be blank", example = "[\"1\"]")
	private List<Long> documentIds;
}
