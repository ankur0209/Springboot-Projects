package com.equabli.file.operation.integration.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.TokenData;
import com.equabli.common.configs.AWSOperations;
import com.equabli.common.constants.Constants;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.Document;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.request.FileUploadConfigRequest;
import com.equabli.common.response.DocumentSummaryResponse;
import com.equabli.common.utils.Util;
import com.equabli.file.operation.integration.FileOperation;
import com.equabli.file.operation.response.FileUploadConfigResponse;

import lombok.extern.slf4j.Slf4j;

@Qualifier("s3FileOperation")
@Slf4j
@Service
public class S3FileOperation implements FileOperation{

	@Value("${spring.config.activate.on-profile}")
	private String activeProfile;
	
	@Value("${awsS3.bucket.name}")
	private String awsBucketName;
	
	@Value("${awsS3.url}")
	private String awsUrl;

	/**
	 * I have set required false because skip test cases
	 */
	@Autowired(required = false)
	AWSOperations awsOperations;
	
	private static final String SEPERATOR = File.separator;

	@Override
	public FileUploadConfigRequest uploadFile(FileUploadConfigRequest fileUploadVo, FileUploadConfigResponse response,
			File file, String bulkUpload, TokenData tokenData) {

		log.info("S3 Calling........");
		String objKey = null;
		String basePath = null;
		boolean isFilevalid = response.getIsFileValid();
		switch (tokenData.getOrgType()) {
		case "CL" -> basePath = MessageConstants.UploadFileConstants.CLIENT + SEPERATOR + tokenData.getUserOrgCode();
		case "PT" -> basePath = MessageConstants.UploadFileConstants.PARTNER + SEPERATOR + tokenData.getUserOrgCode();
		case "TH" -> basePath = MessageConstants.UploadFileConstants.THIRDPARTY + SEPERATOR + tokenData.getUserOrgCode();
		default -> log.info("Unexpected value{} ", fileUploadVo.getOrgType());
		}
		String path = isFilevalid ? MessageConstants.UploadFileConstants.OTHER + SEPERATOR + fileUploadVo.getFileName()
				: MessageConstants.UploadFileConstants.MEDIA + SEPERATOR
						+ MessageConstants.UploadFileConstants.DOCUMENT + SEPERATOR + response.getDirStructure();
		String finalPath = bulkUpload.isEmpty() ? path
				: MessageConstants.UploadFileConstants.BULK + SEPERATOR + bulkUpload + SEPERATOR
						+ fileUploadVo.getFileName();
		String filePath = basePath + SEPERATOR + finalPath;

		if (awsOperations != null) {
			String newFilePath = bulkUpload.isEmpty() ? newFileNamePath(filePath, response.getDocumentPolicy()) : filePath;
			objKey = awsOperations.uploadZipFileS3(newFilePath, file, awsBucketName);
		}else {
			objKey = filePath;
		}
		
		fileUploadVo.setFilePath(filePath);
		fileUploadVo.setObjKey(objKey);
		
		log.info("File uploaded success filePath -> {}", filePath);
		return fileUploadVo;
	}

	@Override
	public File downloadFile(String fileUrl, String fileName, File file) {
		log.info("S3 Calling........");
		if (awsOperations != null)
			return awsOperations.downloadZipFileS3(fileUrl, awsBucketName,file);
		else {
			byte[] byteArray;
			try {
				byteArray = IOUtils.toByteArray(new FileInputStream(new File(fileUrl)));
				try (FileOutputStream outputStream = new FileOutputStream(file)) {
				    outputStream.write(byteArray);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			return new File(file.getAbsolutePath());
		}
	}

	@Override
	public void deleteBulkAfterRead(String excelFileUrl, String uploadFileUrl) {
		if (awsOperations != null) {
			awsOperations.deleteObject(awsBucketName, excelFileUrl);
			awsOperations.deleteObject(awsBucketName, uploadFileUrl);
			log.info("Delete bulk Files successfully.");
		}
	}
	
	public String newFileNamePath(String filePath, boolean docPolicy) {
		String newFileNamePath = filePath;
		boolean checkIfExists = awsOperations.checkFileExitst(awsBucketName, filePath);
		if (checkIfExists) {
			if (docPolicy) {
				//awsOperations.deleteObject(awsBucketName, filePath);
				log.info("Deleted file successfully.");
			} else {
				String renameFile = Util.renameFile(newFileNamePath);
				newFileNamePath = newFileNamePath(renameFile, docPolicy);
			}
		}
		return newFileNamePath;
	}
	
	@Override
	public String uploadFileForAccounts(File file, TokenData tokenData,
			DocumentSummaryResponse documentSummaryResponse) {

		String objKey = null;
		String basePath = null;
		switch (tokenData.getOrgType()) {
		case "CL" -> basePath = MessageConstants.UploadFileConstants.CLIENT + SEPERATOR + tokenData.getUserOrgCode();
		case "PT" -> basePath = MessageConstants.UploadFileConstants.PARTNER + SEPERATOR + tokenData.getUserOrgCode();
		case "TP" ->
			basePath = MessageConstants.UploadFileConstants.THIRDPARTY + SEPERATOR + tokenData.getUserOrgCode();
		default -> log.info("Unexpected value{} ", tokenData.getOrgType());
		}

		String filePath = basePath + SEPERATOR + MessageConstants.UploadFileConstants.MEDIA + SEPERATOR
				+ MessageConstants.UploadFileConstants.DOCUMENT + SEPERATOR
				+ documentSummaryResponse.getClientAccountNumber() + SEPERATOR
				+ documentSummaryResponse.getProductCode() + SEPERATOR + documentSummaryResponse.getDocTypeCode()
				+ SEPERATOR + file.getName();

		if (awsOperations != null) {
			objKey = awsOperations.uploadZipFileS3(filePath, file, awsBucketName);
		}
		log.info("File uploaded success For Account objKey -> {}", objKey);
		return filePath;
	}

	@Override
	public String copyAccountFolder(String fromAccountPath, String toAccountPath) {
		String copyAccount = null;
		if (awsOperations != null) {
			String result = awsOperations.copyAccountFolder(awsBucketName, fromAccountPath, toAccountPath);
			copyAccount = (result != null) ? result : "";
		}
		return copyAccount;
	}

	@Override
	public void deleteAccountNumberData(List<String> obejectKeys) {
		if (awsOperations != null && !obejectKeys.isEmpty()) {
			awsOperations.deleteDocumentOfAccountNo(awsBucketName, obejectKeys);
			log.info("Delete Files of account number of given path {} ", obejectKeys);
		}
	}

	@Override
	public Boolean checkForExistance(String obejectKey) {
		if (awsOperations != null) {
			return awsOperations.checkFileExitst(awsBucketName, obejectKey);
		}
		return false;
	}
	
	@Override
	public List<String> getObjectKeyIfExists(String obejectKey){
		List<String> objectKeys = new ArrayList<>(); 
		if (awsOperations != null) {
			objectKeys = awsOperations.getObjectKeyIfExists(awsBucketName, obejectKey);
		}
		return objectKeys;
	}
	
	@Override
	public String uploadDownloadedFile(TokenData tokenData, File zipFilePath, String fileName) {
		String basePath = null;
		String objKey = null;
		switch (tokenData.getOrgType()) {
		case "CL" -> basePath = MessageConstants.UploadFileConstants.CLIENT + SEPERATOR + tokenData.getUserOrgCode();
		case "PT" -> basePath = MessageConstants.UploadFileConstants.PARTNER + SEPERATOR + tokenData.getUserOrgCode();
		case "TH" -> basePath = MessageConstants.UploadFileConstants.THIRDPARTY + SEPERATOR + tokenData.getUserOrgCode();
		default -> log.info("Unexpected value{} ", tokenData.getOrgType());
		}

		String finalPath = MessageConstants.UploadFileConstants.DOWNLOAD_ZIP + SEPERATOR + fileName;
		String filePath = basePath + SEPERATOR + finalPath;
		
		if (awsOperations != null) {
			boolean existingObjectKey = awsOperations.checkFileExitst(awsBucketName, filePath);
			log.info("KeyExisting {} ",existingObjectKey);
			if(existingObjectKey)
				awsOperations.deleteObject(awsBucketName, filePath);
			
			objKey = awsOperations.uploadZipFileS3(filePath, zipFilePath, awsBucketName);
		}else {
			objKey = filePath;
		}
		return objKey;
	}
	
	@Override
	public Optional<String> uploadFile(Document document, File file) {
		if (awsOperations != null) {
			String generatedFilePath = setAWSFilePath(document);
			String objectKey = awsOperations.uploadZipFileS3(generatedFilePath, file, awsBucketName);
			document.saveObjectKey(document, removeAwsUrl(objectKey), generatedFilePath);
			log.info("FileUploaded generatedFilePath {}, objectKey {}", generatedFilePath, objectKey);
			return Optional.ofNullable(objectKey);
		}
		return Optional.empty();
	}

	private String setAWSFilePath(Document document) {
		String basePath = switch (document.getOrgTypeCode()) {
		case Constants.CLIENT_CODE:
			yield (MessageConstants.UploadFileConstants.CLIENT + Constants.AWS_SEPARATOR + document.getOrgCode());
		case Constants.PARTNER_CODE:
			yield (MessageConstants.UploadFileConstants.PARTNER + Constants.AWS_SEPARATOR + document.getOrgCode());
		case Constants.THIRD_PARTY_CODE:
			yield (MessageConstants.UploadFileConstants.THIRDPARTY + Constants.AWS_SEPARATOR + document.getOrgCode());
		default:
			throw new InvalidArgumentException("setAWSFilePath Unexpected value: " + document.getOrgTypeCode());
		};

		return BooleanUtils.isTrue(document.getIsOthers())
				? String.join(Constants.AWS_SEPARATOR, basePath, MessageConstants.UploadFileConstants.OTHER,
						document.getReceiveFileName())
				: String.join(Constants.AWS_SEPARATOR, basePath, MessageConstants.UploadFileConstants.MEDIA,
						MessageConstants.UploadFileConstants.DOCUMENT, document.getClientAccountNo(),
						document.getProductCode(), document.getDocTypeCode(), document.getReceiveFileName());
	}

	private String removeAwsUrl(String objectKey) {
		return StringUtils.substring(objectKey, awsUrl.length());
	}
}
