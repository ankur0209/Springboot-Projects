package com.equabli.file.operation.service;

import static com.equabli.common.constants.NotificationConstant.BODY;
import static com.equabli.common.constants.NotificationConstant.DOWNLOAD_DOCUMENT;
import static com.equabli.common.constants.NotificationConstant.DOWNLOAD_READY_BODY_MESSAGE;
import static com.equabli.common.constants.NotificationConstant.TYPE;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.TokenData;
import com.equabli.common.configs.AWSOperations;
import com.equabli.common.entity.Document;
import com.equabli.common.entity.DownloadHistory;
import com.equabli.common.enums.DownloadStatusEnum;
import com.equabli.common.feignclients.CommonConfigService;
import com.equabli.common.repository.DownloadHistoryRepository;
import com.equabli.common.request.NotificationRequest;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.common.utils.ZipUtils;
import com.equabli.file.operation.feignclient.SentMail;
import com.equabli.file.operation.integration.FileOperation;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AsyncDownloadService {

	private static final String ACCOUNT = "account";
	private static final String DOWNLOAD_READY_DOCUMENT_TITLE = "send notification for download ready";
	private static final String SEPERATOR = File.separator;
	private static final String TEMP = SEPERATOR+"tmp"+SEPERATOR;
	private static final String URL = "https://eq-dev-dm.s3.amazonaws.com/";

	@Qualifier(value = "s3FileOperation")
	@Autowired
	FileOperation fileOperation;

	@Autowired
	DownloadHistoryRepository downloadHistoryRepository;

	@Autowired
	CommonConfigService commonConfigService;

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	SentMail sentMail;

	/**
	 * I have set required false because skip test cases
	 */
	@Autowired(required = false)
	AWSOperations awsOperations;

	public String downloadSingleDocument(Document document, String tempDir, TokenData tokenData, String authorization) {
		String accountNo = document.getClientAccountNo();

		DownloadHistory downloadHistory = saveDownloadHistory(document, tokenData);
		getFile(document, tempDir);
		downloadHistory.updateDownloadStatus(downloadHistory, DownloadStatusEnum.COMPLETE, tokenData);
		downloadHistoryRepository.save(downloadHistory);

		downloadReadyNotification(authorization, accountNo,tokenData);
		return uploadZipFile(tokenData, tempDir + document.getReceiveFileName());
	}

	public String downloadDocuments(List<Document> documents, String directoryPath, TokenData tokenData,
			String authorization) {
		String accountNo = documents.stream().map(Document::getClientAccountNo).distinct().toList().get(0);
		for (Document document : documents) {
			DownloadHistory downloadHistory = saveDownloadHistory(document, tokenData);
			getFile(document, directoryPath);
			downloadHistory.updateDownloadStatus(downloadHistory, DownloadStatusEnum.COMPLETE, tokenData);
			downloadHistoryRepository.save(downloadHistory);
		}
		downloadReadyNotification(authorization, accountNo,tokenData);
		String zipFilePath = ZipUtils.zipDirectory(Paths.get(directoryPath));
		log.info("Zip file path {}, ", zipFilePath);
		return uploadZipFile(tokenData, zipFilePath);
	}

	public String downloadFolder(List<Document> documents, String tempFile, TokenData tokenData, String accountNumber,
			String authorization) {
		log.info("Download file from bucket ");
		Path directoryPath = Util.createDirectoryIfNotExists(tempFile, accountNumber);
		for (Document document : documents) {
			DownloadHistory downloadHistory = saveDownloadHistory(document, tokenData);
			getFile(document, directoryPath.toString());
			downloadHistory.updateDownloadStatus(downloadHistory, DownloadStatusEnum.COMPLETE, tokenData);
			downloadHistoryRepository.save(downloadHistory);
		}
		downloadReadyNotification(authorization, accountNumber,tokenData);
		String zipFilePath = ZipUtils.zipDirectory(directoryPath);
		log.info("Zip file path {}, ", zipFilePath);
		return uploadZipFile(tokenData, zipFilePath);
	}

	private String uploadZipFile(TokenData tokenData, String zipFilePath) {
		String fileName = Util.getFileNameFromUrl(zipFilePath);
		File file = Util.getFileFromDirectory(TEMP,fileName);
		String objKey = fileOperation.uploadDownloadedFile(tokenData, file, fileName);
		Long fileSize = file.length();
		Util.deleteTempFile(file.toPath());
		String key = objKey.contains(URL) ? objKey.replace(URL, "") : objKey;
		return key + "," + fileSize;
	}

	private File getFile(Document document, String tempFile) {
		String fileName = document.getReceiveFileName();
		File file = new File(tempFile + SEPERATOR + fileName);
		return downloadFile(document.getObjKey(), fileName, file);
	}

	public File downloadFile(String fileUrl, String fileName, File tempFile) {
		return fileOperation.downloadFile(fileUrl, fileName, tempFile);
	}

	public DownloadHistory saveDownloadHistory(Document document, TokenData tokenData) {
		DownloadHistory downloadHistory = new DownloadHistory();
		downloadHistory.saveDocumentDownloadHistory(downloadHistory, document, tokenData);
		downloadHistoryRepository.save(downloadHistory);
		return downloadHistory;
	}

	/******* Notification Part Start 
	 * @param tokenData ****/

	private void downloadReadyNotification(String authorization, String accountNumber, TokenData tokenData) {
		String message = messageSupplier.get(DOWNLOAD_READY_BODY_MESSAGE, accountNumber);
		Map<String, Object> notificationData = saveNotificationData(accountNumber, DOWNLOAD_DOCUMENT, message);
		sendNotification(message, authorization, DOWNLOAD_READY_DOCUMENT_TITLE,notificationData,tokenData);
	}

	private Map<String, Object> saveNotificationData(String accountNumber, String type, String bodyMessage) {
		Map<String, Object> parameters = new LinkedHashMap<>();
		parameters.put(TYPE, type);
		parameters.put(ACCOUNT, accountNumber);
		parameters.put(BODY, bodyMessage);
		return parameters;
	}

	private void sendNotification(String message, String authorization, String title,
			Map<String, Object> notificationData, TokenData tokenData) {
		NotificationRequest notificationRequests = NotificationRequest.builder().userId(tokenData.getPrincipleId())
				.orgCode(tokenData.getUserOrgCode()).orgTypeCode(tokenData.getOrgType()).title(title).message(message)
				.dataMap(notificationData).build();
		String response = sentMail.sendNotification(authorization, notificationRequests);
		log.info("", response);
	}
	
}
