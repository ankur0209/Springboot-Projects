package com.equabli.file.operation.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.TokenData;
import com.equabli.common.configs.BaseConfigService;
import com.equabli.common.entity.Document;
import com.equabli.common.enums.RecordStatusCode;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.file.operation.integration.accounts.AccountsJson;
import com.equabli.file.operation.response.integrationaccount.AccountsResponse;
import com.equabli.file.operation.service.ValidateAccountsService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ValidateAccountsServiceImpl implements ValidateAccountsService {

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	DocumentRepository documentRepository;

	@Autowired
	AccountsJson accountsJson;

	@Autowired
	BaseConfigService baseConfigService;

	@Override
	public void validateClientAccountNumbers(List<AccountsResponse> eqCollectAccounts, TokenData tokenData,
			Document document) {
//		TODO: Once EQ Collect Fetch Account API is up comment out 
//		List<String> accounts;
//		if (eqCollectAccounts.isEmpty())
//			accounts = accountsJson.getAccountsList().stream().map(AccountsResponse::getClientAccountNumber).distinct()
//					.toList();
//		else
//			accounts = eqCollectAccounts.stream().map(AccountsResponse::getClientAccountNumber).distinct().toList();
//
//		log.info("eqCollectAccounts {}", accounts);
//
//		if (!accounts.contains(document.getClientAccountNo())) {
//			String recordStatusCode = baseConfigService.getRecordStatusByShortCode(RecordStatusCode.REJECT)
//					.getShortCode();
//			document.updateDocumentRecordStatus(document, tokenData, recordStatusCode);
//			documentRepository.save(document);
//			log.info("After update DocumentId {}, ClientAccountNumber {}", document.getId(),
//					document.getClientAccountNo());
//		}
	}
}
