package com.equabli.file.operation.response.integrationaccount;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Response of EQ Collection commnoAcctSerach API")
public class CommonAcctSearchResponse {
	private PageMetaData metadata;
	private List<AccountsResponse> accounts;
}
