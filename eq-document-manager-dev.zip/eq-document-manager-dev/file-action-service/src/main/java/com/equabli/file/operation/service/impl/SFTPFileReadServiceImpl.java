package com.equabli.file.operation.service.impl;

import java.io.File;
import java.nio.file.Files;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.equabli.common.auth.TokenData;
import com.equabli.common.configs.AWSOperations;
import com.equabli.common.constants.Constants;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.request.FileUploadConfigRequest;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.FileOperationResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.file.operation.constants.FileOperationMessageConstants;
import com.equabli.file.operation.service.AsyncService;
import com.equabli.file.operation.service.SFTPFileReadService;

import io.awspring.cloud.messaging.listener.SimpleMessageListenerContainer;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SFTPFileReadServiceImpl implements SFTPFileReadService {

	@Value("${spring.config.activate.on-profile}")
	private String activeProfile;

	@Value("${awsS3.bucket.name}")
	private String awsBucketName;

	/**
	 * I have set required false because skip test cases
	 */
	@Autowired(required = false)
	AWSOperations awsOperations;

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	FileUploadServiceImplementation fileUploadService;

	@Autowired
	AsyncService asyncService;

	@Autowired
	SimpleMessageListenerContainer simpleMessageListenerContainer;

	private static final String SEPERATOR = File.separator;
	private static final String FILE_TYPE_ZIP = "zip";
	private static final String MATRIX = "matrix";
	private static final String XLSX = ".xlsx";
	private static final String ZIP = ".zip";

	@Override
	public void readFileFromSFTP(String objectKey) throws Exception {

		String[] filePath = objectKey.split(SEPERATOR);
		String originalFilename = filePath[filePath.length - 1];
		String fileType = Util.getExtensionFromFileName(originalFilename);
		String fileName = Util.getNameFromFileName(originalFilename);

		TokenData tokenData = getTokenData(filePath[0], filePath[1]);

		log.info("originalFilename {}, fileName {}, fileType {}", originalFilename, fileName, fileType);

		if (FILE_TYPE_ZIP.equalsIgnoreCase(fileType)) {
			String matrixFileObjectKey = getFileURL(filePath, fileName, XLSX);
			if (awsOperations.checkFileExitst(awsBucketName, matrixFileObjectKey)) {
				asyncService.manageBulkFileSQS(objectKey, new FileUploadConfigRequest(), matrixFileObjectKey,
						tokenData);
				log.info("ZIP --> Reading zip and xlsx files {},  matrixFileObjectKey {}", objectKey,
						matrixFileObjectKey);
			}
		} else if (StringUtils.startsWithIgnoreCase(fileName, MATRIX)) {
			String zipFileObjectKey = getFileURL(filePath, fileName, ZIP);
			if (awsOperations.checkFileExitst(awsBucketName, zipFileObjectKey)) {
				asyncService.manageBulkFileSQS(zipFileObjectKey, new FileUploadConfigRequest(), objectKey, tokenData);
				log.info("MATRIX --> Reading zip and xlsx files {},  zipFileObjectKey {}", objectKey, zipFileObjectKey);
			}
		} else {
			File file = getFileFromAWS(objectKey);
			CommonResponse<FileOperationResponse> response = fileUploadService.uploadFile(file, tokenData);
			Files.delete(file.toPath());
			log.info("AFTER READ FILE response -> {}", response);
			awsOperations.deleteObject(awsBucketName, objectKey);
		}
	}

	private String getFileURL(String[] filePath, String fileName, String type) {
		return org.apache.commons.lang3.StringUtils.join(Arrays.copyOf(filePath, filePath.length - 1), SEPERATOR)
				+ SEPERATOR + fileName + type;
	}

	private File getFileFromAWS(String uploadFileUrl) {
		String fileName = Util.getFileNameFromUrl(uploadFileUrl);
		File tempFile = new File(System.getProperty("java.io.tmpdir") + SEPERATOR + fileName);
		return awsOperations.downloadZipFileS3(uploadFileUrl, awsBucketName, tempFile);
	}

	public static TokenData getTokenData(String orgType, String orgCode) {
		TokenData tokenData = new TokenData();
		tokenData.setPrincipleId(1L);
		tokenData.setLoginKey("Admin");
		tokenData.setFirstName("Admin User");
		tokenData.setEmailAddress("admin@gmail.com");
		tokenData.setOrgType(getShortCode(orgType));
		tokenData.setUserOrgCode(orgCode);
		return tokenData;
	}

	private static String getShortCode(String orgType) {
		String orgTypeCode = null;
		switch (orgType) {
		case MessageConstants.UploadFileConstants.CLIENT -> orgTypeCode = Constants.CLIENT_CODE;
		case MessageConstants.UploadFileConstants.PARTNER -> orgTypeCode = Constants.PARTNER_CODE;
		case MessageConstants.UploadFileConstants.THIRDPARTY -> orgTypeCode = Constants.THIRD_PARTY_CODE;
		default -> log.info("ORGANIZATION CODE IS NOT VALID -> {}", orgType);
		}
		return orgTypeCode;
	}

	@Override
	public CommonResponse<String> pauseSqsListener() {
		simpleMessageListenerContainer.stop();
		return CommonResponse.success(messageSupplier.get(FileOperationMessageConstants.SQS_STOP_SUCCESS));
	}

	@Override
	public CommonResponse<String> startSqsListener() {
		simpleMessageListenerContainer.start();
		return CommonResponse.success(messageSupplier.get(FileOperationMessageConstants.SQS_START_SUCCESS));
	}
}
