package com.equabli.file.operation.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "For upload document for specific document")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class AccountDocumentsRequest {

	private String docTypeCode;
	private String tenure;
	private String portfolio;
	private String productCode;
	private Long userId;
	
	@Schema(description = "Client Short code is required when parnter upload a file", example = "MRLT")
	private String clientShortCode;
}
