package com.equabli.file.operation.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Predicate;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.equabli.common.entity.DocTypeIdentification;
import com.equabli.common.repository.DocTypeIdentificationRepository;
import com.equabli.file.operation.response.ReadPdfResponse;

import lombok.extern.slf4j.Slf4j;
import technology.tabula.ObjectExtractor;
import technology.tabula.Page;
import technology.tabula.PageIterator;
import technology.tabula.RectangularTextContainer;
import technology.tabula.Table;
import technology.tabula.TextChunk;
import technology.tabula.extractors.SpreadsheetExtractionAlgorithm;

@Service
@Slf4j
public class ReadPdfServiceImpl {

	private static final String SPACE = " ";
	private static final String VERTICAL = "Vertical";
	private static final String HORIZONTAL = "Horizontal";

	private static final String CLIENT_ACCOUNT_NUMBER = "Client Account Number";
	private static final String ORIGINAL_ACCOUNT_NUMBER = "Original Account Number";
	private static final String EQUABLI_ACCOUNT_NUMBER = "Equabli Account Number";
	private static final String PRODUCT_CODE = "Product Code";

	@Autowired
	private DocTypeIdentificationRepository docTypeIdentificationRepository;

	public Optional<ReadPdfResponse> readDocument(File file) {

		List<DocTypeIdentification> docTypeIdentifications = docTypeIdentificationRepository
				.findByIsDeleteFalseOrderByUpdatedAtDesc();
		log.info("docTypeIdentifications {}", docTypeIdentifications);

		return docTypeIdentifications.stream()
				.map(docTypeIdentification -> readDocuemntFromFile(file, docTypeIdentification))
				.filter(Optional::isPresent).findFirst().orElseGet(() -> {
					log.info("FileName -> {}", file.getName());
					return Optional.empty();
				});
	}

	public Optional<ReadPdfResponse> readDocuemntFromFile(File file, DocTypeIdentification docTypeIdentification) {

		Map<String, HashMap<String, String>> metaData = new HashMap<>();
		final List<String> docTypeFields = docTypeIdentification.getDocTypeFields().getDocFields();
		log.info("docTypeIdentification ID {}, docTypeFields {}", docTypeIdentification.getId(), docTypeFields);

		Map<String, String> datas = readData(file, docTypeFields);
		metaData.put(file.getName(), new HashMap<>(datas));

		int attributeSize = docTypeFields.size();
		for (Map.Entry<String, HashMap<String, String>> data : metaData.entrySet()) {

			HashMap<String, String> values = data.getValue();
			int percentage = (values.size() * 100) / attributeSize;
			log.info("FileName ->{}, percentage ->{}, data ->{}", data.getKey(), percentage, values);
			if (percentage > 90) {
				ReadPdfResponse readPdfResponse = ReadPdfResponse.builder()
						.clientAccountNumber(data.getValue().get(CLIENT_ACCOUNT_NUMBER))
						.docType(docTypeIdentification.getDocType())
						.originalAccountNumber(data.getValue().get(ORIGINAL_ACCOUNT_NUMBER))
//						.equabliAccountNumber(Long.parseLong(data.getValue().get(EQUABLI_ACCOUNT_NUMBER)))
						.productCode(data.getValue().get(PRODUCT_CODE)).build();

				return Optional.of(readPdfResponse);
			}
		}
		return Optional.empty();
	}

	public Map<String, String> readData(File file, List<String> docTypeFields) {
		Map<String, String> data = new HashMap<>();

		try {
			String tableFormat = HORIZONTAL;
			PDDocument document = PDDocument.load(file);
			ObjectExtractor objectExtractor = new ObjectExtractor(document);
			PDFTextStripper stripper = new PDFTextStripper();
			CopyOnWriteArrayList<String> attributes = new CopyOnWriteArrayList<>(docTypeFields);

			if (!document.isEncrypted()) {
				for (int i = 1; i <= document.getNumberOfPages(); i++) {

					String lineDeparator = stripper.getLineSeparator();
					stripper.setStartPage(i);
					stripper.setEndPage(i);
					String text = stripper.getText(document);

					String[] lines = text.split(lineDeparator);

					for (int j = 0; j < lines.length; j++) {
						String line = lines[j];
						data.putAll(readValuesFromLine(attributes, line, data));
					}
				}
			} else {
				log.info("{} is encrypted", file.getName());
			}

			/**
			 * Check Data inside the table
			 */
			readFromTable(objectExtractor, data, tableFormat, docTypeFields);

			objectExtractor.close();
			document.close();
		} catch (IOException e) {
			log.info("ERROR WHILE READ PDF -> {}", e.getMessage(), e);
		}

		return data;
	}

	private Map<String, String> readValuesFromLine(List<String> attributes, String lineText, Map<String, String> data) {

		if (Objects.isNull(lineText))
			return Collections.emptyMap();

		for (String attribute : attributes) {

			if (lineText.toLowerCase().contains(attribute.toLowerCase()) && lineText.indexOf(attribute) > -1) {

				String text = lineText.substring(lineText.indexOf(attribute));
				String value = text.substring(attribute.length());
				if (!Objects.isNull(value)) {
					value = value.trim().split(SPACE)[0];
				}
				data.putIfAbsent(attribute, value);

				attributes.remove(attribute);
			}
		}

		return data;
	}

	private Map<String, String> readFromTable(ObjectExtractor objectExtractor, Map<String, String> data,
			String tableFormate, List<String> docTypeFields) {
		SpreadsheetExtractionAlgorithm sea = new SpreadsheetExtractionAlgorithm();

		CopyOnWriteArrayList<String> attributes = new CopyOnWriteArrayList<>(docTypeFields);

		PageIterator pageIterator = objectExtractor.extract();
		while (pageIterator.hasNext()) {
			Page page = pageIterator.next();

			List<? extends Table> tables = sea.extract(page);

			for (Table table : tables) {

				@SuppressWarnings("rawtypes")
				List<List<RectangularTextContainer>> rows = table.getRows();

				if (HORIZONTAL.equals(tableFormate))
					readFromTableForHorizontal(rows, attributes, data);
				else if (VERTICAL.equals(tableFormate))
					readFromTableForVertical(rows, attributes, data);
			}
		}

		return data;
	}

	@SuppressWarnings("rawtypes")
	private Map<String, String> readFromTableForHorizontal(List<List<RectangularTextContainer>> rows,
			List<String> attributes, Map<String, String> data) {

		for (int rw = 0; rw < rows.size(); rw++) {

			List<RectangularTextContainer> cells = rows.get(rw);
			for (int cel = 0; cel < cells.size(); cel++) {
				String text = cells.get(cel).getText().replace("\r", " ");
				if (attributes.contains(text) && (cells.size() > (cel + 1))) {
					String value = cells.get(cel + 1).getText().replace("\r", " ");
					data.put(text, value);
					attributes.remove(text);
				}
			}
		}

		return data;
	}

	@SuppressWarnings("rawtypes")
	private Map<String, String> readFromTableForVertical(List<List<RectangularTextContainer>> rows,
			List<String> attributes, Map<String, String> data) {

		int headerRawNumber = findHeaderRawNumber(rows);
		log.info("headerRawNumber ->{}", headerRawNumber);

		for (int rw = 0; rw < rows.size(); rw++) {

			List<RectangularTextContainer> cells = rows.get(rw);
			for (int cel = 0; cel < cells.size(); cel++) {

				String text = rows.get(headerRawNumber).get(cel).getText().replace("\r", " ");
				if (attributes.contains(text) && rows.size() > (rw + 1)) {
					String value = rows.get(rw + 1).get(cel).getText().replace("\r", " ");
					data.put(text, value);
				}
			}
		}

		return data;
	}

	private int findHeaderRawNumber(List<List<RectangularTextContainer>> rows) {
		for (int rw = 0; rw < rows.size(); rw++)
			if (rows.get(rw).stream().noneMatch(checkTextChunk()))
				return rw;
		return 0;
	}

	private Predicate<RectangularTextContainer> checkTextChunk() {
		return TextChunk.class::isInstance;
	}
}
