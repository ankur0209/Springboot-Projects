package com.equabli.file.operation.service.impl;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.configs.AWSOperations;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.FileOperationResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.file.operation.constants.FileOperationMessageConstants;
import com.equabli.file.operation.service.SFTPFileUploadService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SFTPFileUploadServiceImpl implements SFTPFileUploadService {

	@Value("${spring.config.activate.on-profile}")
	private String activeProfile;

	@Value("${awsS3.bucket.name}")
	private String awsBucketName;

	/**
	 * I have set required false because skip test cases
	 */
	@Autowired(required = false)
	AWSOperations awsOperations;

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	FetchTokenData fetchTokenData;

	private static final String SEPERATOR = File.separator;

	@Override
	public CommonResponse<FileOperationResponse> uploadFileToSFTP(List<MultipartFile> multipartFiles) {

		TokenData tokenData = fetchTokenData.getTokenData();

		if (multipartFiles.isEmpty())
			CommonResponse.failure(messageSupplier.get(FileOperationMessageConstants.FILE_NOT_VALID));

		String objKey = null;
		String basePath = null;

		switch (tokenData.getOrgType()) {
		case "CL" -> basePath = MessageConstants.UploadFileConstants.CLIENT + SEPERATOR + tokenData.getUserOrgCode()
				+ SEPERATOR + FileOperationMessageConstants.INCOMING_MEDIA + SEPERATOR;
		case "PT" -> basePath = MessageConstants.UploadFileConstants.PARTNER + SEPERATOR + tokenData.getUserOrgCode()
				+ SEPERATOR + FileOperationMessageConstants.INCOMING_MEDIA + SEPERATOR;
		case "TH" -> basePath = MessageConstants.UploadFileConstants.THIRDPARTY + SEPERATOR + tokenData.getUserOrgCode()
				+ SEPERATOR + FileOperationMessageConstants.INCOMING_MEDIA + SEPERATOR;
		default -> log.info("Unexpected value{} ");
		}

		if (awsOperations != null) {
			for (MultipartFile multipartFile : multipartFiles) {
				File convertFile = Util.convertMultipartToFile(multipartFile);
				String filePath = basePath + multipartFile.getOriginalFilename();
				objKey = awsOperations.uploadZipFileS3(filePath, convertFile, awsBucketName);
				log.info("After Uploaded file ->{}", filePath);
				log.info("SFTP FILE UPLOAD PATH {}", objKey);
			}
		}
		return CommonResponse
				.success(messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.CREATE_SUCCESS, ""));
	}
}
