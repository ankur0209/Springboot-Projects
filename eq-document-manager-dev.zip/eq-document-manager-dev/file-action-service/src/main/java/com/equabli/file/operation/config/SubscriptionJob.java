package com.equabli.file.operation.config;

import java.time.LocalDateTime;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import com.equabli.common.configs.BaseConfigService;
import com.equabli.file.operation.integration.accounts.AccountIntegration;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SubscriptionJob {

	public static final String SUBSCRIPTION_CRON = "0 0 */3 * * *";

	@Autowired
	AccountIntegration accountIntegration;

	@Autowired
	BaseConfigService baseConfigService;

	@Scheduled(cron = SUBSCRIPTION_CRON)
	public void fetchClientSubscriptionDetail() {
		log.info("Fetch the client subscription detail Start {}", LocalDateTime.now());
		baseConfigService.loadClientSubscriptions();
		log.info("Fetch the client subscription detail Completed {}", LocalDateTime.now());

		log.info("getClientSubscriptionResponse -> {} ",
				baseConfigService.getClientSubscriptionResponse(Arrays.asList("MRLT")));
	}
}
