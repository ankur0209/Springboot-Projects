package com.equabli.file.operation.service;

import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.BulkOperation;
import com.equabli.common.entity.DocCost;
import com.equabli.common.entity.DocType;
import com.equabli.common.entity.Document;
import com.equabli.common.entity.DocumentCostInvoice;
import com.equabli.common.entity.SendReceiveDocument;
import com.equabli.common.entity.ShareBy;
import com.equabli.common.entity.Usage;
import com.equabli.common.entity.UserDocConfig;
import com.equabli.common.enums.DocumentRequestStatusEnum;
import com.equabli.common.enums.DocumentShareTypeEnum;
import com.equabli.common.enums.FileNameConfigEnum;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.feignclients.CommonConfigService;
import com.equabli.common.repository.BulkOperationRepository;
import com.equabli.common.repository.DocCostRepository;
import com.equabli.common.repository.DocMgrConfigRepository;
import com.equabli.common.repository.DocMgrConfigValRepository;
import com.equabli.common.repository.DocTypeRepository;
import com.equabli.common.repository.DocumentCostInvoiceRepository;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.repository.SentReceiveDocumentRepository;
import com.equabli.common.repository.ShareByRepository;
import com.equabli.common.repository.UsageRepository;
import com.equabli.common.repository.UserDocConfigRepository;
import com.equabli.common.request.FileUploadConfigRequest;
import com.equabli.common.response.config.ConfigResponse;
import com.equabli.common.utils.DateUtils;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.file.operation.response.FileUploadConfigResponse;
import com.equabli.file.operation.response.ReadPdfResponse;

import com.equabli.file.operation.response.integrationaccount.ClientResponse;

import com.equabli.file.operation.service.impl.ReadPdfServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FileUploadDatabaseOperation {
	
	@Autowired
	UserDocConfigRepository docConfigRepository;
	
	@Autowired
	DocumentRepository documentRepository;
	
	@Autowired
	MessageSupplier messageSupplier;
	
	@Autowired
	DocCostRepository docCostRepository;

	@Autowired
	SentReceiveDocumentRepository receiveDocumentRepository;
	
	@Autowired
	BulkOperationRepository bulkOperationRepository;
	
	@Autowired
	DocTypeRepository docTypeRepository;
	
	@Autowired
	DocMgrConfigRepository docMgrConfigRepository;
	
	@Autowired
	DocMgrConfigValRepository docMgrConfigValRepository;
	
	@Autowired
	UsageRepository usageRepository;
	
	@Autowired
	SubscriptionService subscriptionService;
	
	@Autowired
	DocumentCostInvoiceRepository documentCostInvoiceRepository;
	
	@Autowired
	ShareByRepository shareByRepository;
	
	@Autowired
	ValidateAccountsService validateAccountsService;
	
	@Autowired
	ReadPdfServiceImpl readPdfService;
	
	@Autowired
	CommonConfigService configService;
	
	
	public static final String POLICY_TYPE = "RE";
	public static final Long PRODUCT_ID = 1l;
	public static final String DEFAULT_SEPERATOR = "_";
	private static final String CLIENT = "CL";
	
	@Transactional
	public String updateFilePath(FileUploadConfigRequest fileUploadVo, TokenData tokenData) {

		Document document = documentRepository.findById(fileUploadVo.getDocumentId()).orElse(new Document());
		document.saveObjectKey(document, fileUploadVo.getFilePath(), fileUploadVo.getFilePath());
		documentRepository.save(document);
		updateFullFillRequest(document, tokenData);
		return MessageConstants.SUCCESS_MESSAGE;
	}
	
	@Transactional
	public FileUploadConfigResponse handleFileNamingValidation(FileUploadConfigRequest fileUploadVo,
			TokenData tokenData, String authorization, File file) {

		// Get user doc configuration data by user type id
		List<UserDocConfig> fileNameConfigs = docConfigRepository
				.findByOrgCodeAndDocMgrConfig_ShortCodeStartsWithAndIsDeleteFalseOrderByDocMgrConfig_ShortCode(
						tokenData.getUserOrgCode(), FileNameConfigEnum.FIELD.getShortCode());

		String separator = getSeperator(tokenData);
		String docPolicy = tokenData.getOrgType().equals(CLIENT) ? getDocumentPolicy(tokenData) : "";
		boolean documentPolicy = docPolicy.equals(POLICY_TYPE);
		
		boolean isValidFile = false;
		isValidFile = getValidateFile(fileUploadVo, fileNameConfigs, separator);
		String docName = isValidFile ? "" : getDocumentName(fileUploadVo.getDocType());
		String dirStructure = isValidFile ? "" : fileUploadVo.getFileName().replace(separator, File.separator);
		deleteDocumentIfExsits(fileUploadVo.getFileName(), documentPolicy,tokenData);
		Document document = new Document();
		
//		Set document GeneratedFileName 
		String generatedFileName = generatedFileName(fileUploadVo, docName, isValidFile, fileNameConfigs.size(),
				separator, tokenData.getUserOrgCode(), null);
		fileUploadVo.setGeneratedFileName(generatedFileName);
		
		log.info("Before read file -> isValidFile {}, dirStructure {}, fileUploadVo {}", isValidFile, dirStructure, fileUploadVo);
		/**
		 * If naming configuration is invalid than read file
		 */
		if (isValidFile) {
			Optional<ReadPdfResponse> documentDetail = readPdfService.readDocument(file);
			if(documentDetail.isPresent()) {
				log.info("documentDetail {}", documentDetail.get());
				copyDataFromReadPdfResponse(fileUploadVo, documentDetail.get());
				dirStructure = setDirStructure(documentDetail.get(), file.getName());
				isValidFile = false;
				docName = fileUploadVo.getDocumentName();
			}
		}
		log.info("After read file -> isValidFile {}, dirStructure {}, fileUploadVo {}", isValidFile, dirStructure, fileUploadVo);
		
		// save all data of request or DTO into entity
		document.saveDocument(document, fileUploadVo, isValidFile, isValidFile ? MessageConstants.INVALID_FILE : "",
				docName, tokenData, tokenData);
		
		// save entity to database
		documentRepository.save(document);
		
		Optional<ClientResponse> clientDetail = getMappedClientDetailForPartner(authorization, tokenData,
				fileUploadVo.getClientShortCode());
		updateUsage(fileUploadVo.getFileSize(), 1l, tokenData, clientDetail);
		validateAccountsService.validateClientAccountNumbers(Collections.emptyList(), tokenData, document);
		
		return generateResponse(tokenData.getUserOrgCode(), documentPolicy, isValidFile, document.getId(),dirStructure);
	}
	
	private void updateFullFillRequest(Document document, TokenData tokenData) {
		// If document request already generate than update data else create new
		Optional<SendReceiveDocument> sendReceiveDocumentData = receiveDocumentRepository.getReciveveRequestData(
				document.getDocTypeCode(), document.getClientAccountNo(), tokenData.getUserOrgCode(),
				tokenData.getOrgType(),tokenData.getPrincipleId(), DocumentRequestStatusEnum.OPEN.getRequestStatus());
		if (sendReceiveDocumentData.isPresent()) {
			log.info("Check for send request detail exists {} ",sendReceiveDocumentData.get());
			SendReceiveDocument sendReceiveDocument = sendReceiveDocumentData.get();
			sendReceiveDocument.updateSendReceiveDocument(sendReceiveDocument, document,
					DocumentRequestStatusEnum.FULFILLED, tokenData,tokenData);
			receiveDocumentRepository.save(sendReceiveDocument);
			
			saveDocumentCostInvoice(sendReceiveDocument, document, tokenData);
			
			saveShareByDetail(document,tokenData);
		}
	}
	
	public FileUploadConfigResponse handleFileNameOfAccountNumber(FileUploadConfigRequest fileUploadVo,
			TokenData tokenData, String authorization) {
		String fileSize = String.valueOf(fileUploadVo.getFileSize());
		boolean isValidFile = false;
		String productCode = getProductCodeByAccountNo(fileUploadVo.getClientAccountNo());
		DocType docType = getDocTypeByCode(fileUploadVo.getDocType());
		String separator = getSeperator(tokenData);
		
		String docPolicy = tokenData.getOrgType().equals(CLIENT) ? getDocumentPolicy(tokenData) : "";
		boolean documentPolicy = docPolicy.equals(POLICY_TYPE);
		if(productCode == null || docType == null)
			isValidFile = true;

		String docName = isValidFile ? "" : getDocumentName(fileUploadVo.getDocType());
		String dirStructure = Util.getDirStructureForAccountNo(isValidFile,fileUploadVo,productCode); 
		deleteDocumentIfExsitsForAccountNo(fileUploadVo.getClientAccountNo(), fileUploadVo.getFileName(),
				documentPolicy, tokenData);
		// Set document GeneratedFileName
		String generatedFileName = generatedFileName(fileUploadVo, docName, isValidFile, Integer.parseInt(fileSize),
				separator, tokenData.getUserOrgCode(), fileUploadVo.getFileName());
		fileUploadVo.setGeneratedFileName(generatedFileName);
		fileUploadVo.setProductCode(productCode);
		
		// save all data of request or DTO into entity
		Document document = saveDocument(fileUploadVo, isValidFile, docName, tokenData);
		fileUploadVo.setDocumentId(document.getId());
		Optional<ClientResponse> clientDetail = getMappedClientDetailForPartner(authorization, tokenData,
				fileUploadVo.getClientShortCode());
		updateUsage(fileUploadVo.getFileSize(), 1l, tokenData, clientDetail);
		validateAccountsService.validateClientAccountNumbers(Collections.emptyList(), tokenData, document);
		return generateResponse(productCode, documentPolicy, isValidFile, document.getId(), dirStructure);
	}
	
	public Boolean getValidateFile(FileUploadConfigRequest fileUploadVo, List<UserDocConfig> fileNameConfigs,
			String fileSeperator) {
		String fileName = Util.getFileNameWithoutExtension(fileUploadVo.getFileName());
		// split file name using separator getting from user configuration table
		String[] arrOfStr = fileName.split(fileSeperator);

		// Check file name is valid or not
		boolean checkForFileName = validateFileNameFiled(arrOfStr.length, fileNameConfigs.size());
		log.info("arrOfStr {}, fileNameConfigs.size() {}", arrOfStr, fileNameConfigs.size());
		if (checkForFileName) {
			setFieldValueFromFileName(arrOfStr, fileNameConfigs, fileUploadVo);
			return false;
		} else {
			return true;
		}
	}

	/**
	 * Validate file with length
	 * 
	 * @param fileNameFieldLength
	 * @param fileNameConfigsFieldSize
	 * @return
	 */
	private Boolean validateFileNameFiled(int fileNameFieldLength, int fileNameConfigsFieldSize) {
		return fileNameFieldLength >= fileNameConfigsFieldSize;
	}
	
	/**
	 * Set file data to dto/request
	 * @param directoryFileUpload 
	 * 
	 * @param docyTypeId
	 */
	public void setFieldValueFromFileName(String[] arrOfStr, List<UserDocConfig> fileNameConfigs,
			FileUploadConfigRequest fileUploadVo) {
		int i = 0;
		for (UserDocConfig fileNameConfig : fileNameConfigs) {
			String fieldName = fileNameConfig.getDocMgrConfigValSelectedCode();
			String fieldValue = arrOfStr[i];
			i++;
			switch (fieldName) {
			case "DT" -> fileUploadVo.setDocType(fieldValue);
			case "CAN" -> fileUploadVo.setClientAccountNo(fieldValue);
			case "OAN" -> fileUploadVo.setOriginalAccountNo(fieldValue);
			case "DGD" -> fileUploadVo.setDocumentGenerationDate(Util.convertLocalDateToUtc(fieldValue));
			case "DN" -> fileUploadVo.setDocumentName(fieldValue);
			case "PC" -> fileUploadVo.setProductCode(fieldValue);
			case "CIDSC" -> fileUploadVo.setClientShortCode(fieldValue);
			default -> log.error("Invalide field short code");
			}
		}
	}

	private FileUploadConfigResponse generateResponse(String orgTypeCode, boolean documentPolicy, boolean isValidFile,
			Long documentId, String dirStructure) {

		// Response generation to send it to file operation service
		FileUploadConfigResponse response = new FileUploadConfigResponse();
		response.setOrgTypeCode(orgTypeCode);
		response.setDocumentPolicy(documentPolicy);
		response.setIsFileValid(isValidFile);
		response.setDocumentId(documentId);
		response.setDirStructure(dirStructure);
		return response;
	}

	public void saveBulkOperation(FileUploadConfigRequest fileUploadVo, String bulkType, boolean isOther, TokenData tokenData) {
		BulkOperation bulkOperation = new BulkOperation();
		bulkOperation.saveBulkOperation(fileUploadVo, bulkType, bulkOperation, isOther, tokenData, tokenData);
		bulkOperationRepository.save(bulkOperation);
	}
	
	public Document saveFullfillmentrequest(TokenData tokenData, FileUploadConfigRequest fileRequest,
			String docName, FileUploadConfigResponse response, String authorization, String clientShortCode) {
		String productCode = documentRepository.findProductCodeDistinctByClientAccountNo(fileRequest.getClientAccountNo())
				.stream().findFirst().orElseThrow(() -> new InvalidArgumentException(
						messageSupplier.get(MessageConstants.NOT_VALID, fileRequest.getClientAccountNo())));
		fileRequest.setProductCode(productCode);
		String docPolicy = tokenData.getOrgType().equals(CLIENT) ? getDocumentPolicy(tokenData) : "";
		boolean documentPolicy = docPolicy.equals(POLICY_TYPE);
		Document document = new Document();
		deleteDocumentIfExsitsForAccountNo(productCode, fileRequest.getFileName(), documentPolicy, tokenData);
		String[] fileNameArray = fileRequest.getFileName().split(getSeperator(tokenData));
		String generatedFileName = generatedFileName(fileRequest, docName, false, 0, null,
				tokenData.getUserOrgCode(), fileNameArray[fileNameArray.length - 1]);
		fileRequest.setGeneratedFileName(generatedFileName);
		
		// save all data of request or DTO into entity
		document.saveDocument(document, fileRequest, false, "", docName, tokenData, tokenData);
		documentRepository.save(document);
		fileRequest.setDocumentId(document.getId());
		response.setDocumentPolicy(documentPolicy);
		response.setIsFileValid(false);
		
		Optional<ClientResponse> clientDetail = getMappedClientDetailForPartner(authorization, tokenData,
				clientShortCode);
		updateUsage(fileRequest.getFileSize(), 1l, tokenData, clientDetail);
		validateAccountsService.validateClientAccountNumbers(Collections.emptyList(), tokenData, document);
		
		return document;
	}
	
	public void updateSendReceiveRequest(Document document, TokenData tokenData, Long id) {
		// If document request already generate than update data else create new
		Optional<SendReceiveDocument> sendReceiveDocumentData = receiveDocumentRepository.findById(id);

		if (sendReceiveDocumentData.isPresent()) {
			SendReceiveDocument sendReceiveDocument = sendReceiveDocumentData.get();
			sendReceiveDocument.updateSendReceiveDocument(sendReceiveDocument, document,
					DocumentRequestStatusEnum.FULFILLED, tokenData, tokenData);
			receiveDocumentRepository.save(sendReceiveDocument);
		}

	}

	public String getDocumentName(String docType) {
		return docTypeRepository.findByShortCode(docType).stream().map(DocType::getName).findFirst()
				.orElseThrow(() -> new InvalidArgumentException(
						messageSupplier.get(MessageConstants.NOT_VALID, "Document Code " + docType)));
	}

	public String getDocumentPolicy(TokenData tokenData) {
		return docConfigRepository
				.findByOrgCodeAndDocMgrConfig_ShortCodeStartsWithAndIsDeleteFalseOrderByDocMgrConfig_ShortCode(
						tokenData.getUserOrgCode(), FileNameConfigEnum.DOCUMENT_POLICY.getShortCode())
				.stream().map(UserDocConfig::getDocMgrConfigValSelectedCode).findFirst()
				.orElseThrow(() -> new InvalidArgumentException(messageSupplier.get(MessageConstants.NOT_VALID,
						FileNameConfigEnum.DOCUMENT_POLICY.getShortCode())));
	}

	public String getSeperator(TokenData tokenData) {
		return docConfigRepository
				.findByOrgCodeAndDocMgrConfig_ShortCodeStartsWithAndIsDeleteFalseOrderByDocMgrConfig_ShortCode(
						tokenData.getUserOrgCode(), FileNameConfigEnum.SEPARATOR.getShortCode())
				.stream().map(UserDocConfig::getDocMgrConfigValSelectedCode).findFirst()
				.orElseThrow(() -> new InvalidArgumentException(
						messageSupplier.get(MessageConstants.NOT_VALID, FileNameConfigEnum.SEPARATOR.getShortCode())));
	}
	
	/**
	 * When user upload document than update the Usage
	 * @param fileSize
	 * @param documentNumber
	 * @param tokenData
	 */
	public void updateUsage(Long fileSize, Long documentNumber, TokenData tokenData,
			Optional<ClientResponse> clientDetail) {

		Usage usage;
		if (clientDetail.isPresent() && Constants.PARTNER_CODE.equals(tokenData.getOrgType())) {
			usage = subscriptionService.getUsage(tokenData, clientDetail.get());
			usage.updateUsage(usage, fileSize, documentNumber, tokenData, Constants.CLIENT_CODE,
					clientDetail.get().getShortName());
		} else {
			usage = subscriptionService.getUsage(tokenData);
			usage.updateUsage(usage, fileSize, documentNumber, tokenData);
		}
		usageRepository.save(usage);
	}
	
	public DocType getDocType(String docTypeCode) {
		return docTypeRepository.findByShortCode(docTypeCode).orElseThrow(() -> new InvalidArgumentException(
				messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, docTypeCode)));
	}
	
	public String generatedFileName(FileUploadConfigRequest fileUploadVo, String documentType, boolean isValidFile,
			int fileNameConfigSize, String separator, String userOrgCode, String fileNameFromBulkRead) {

		if (isValidFile)
			return fileUploadVo.getFileName();

		StringBuilder generatedFileName = new StringBuilder();
		String seperatorForGeneratedFile = "-";

		generatedFileName.append(seperatorForGeneratedFile + userOrgCode);
		generatedFileName.append(seperatorForGeneratedFile + documentType);
		if (fileUploadVo.getDocumentGenerationDate() != null)
			generatedFileName.append(seperatorForGeneratedFile
					+ DateUtils.convertDateToYYYYDDMM(fileUploadVo.getDocumentGenerationDate()));
		generatedFileName.append(seperatorForGeneratedFile + fileUploadVo.getClientAccountNo());

		if(StringUtils.isNotBlank(fileNameFromBulkRead)) {
			generatedFileName.append(seperatorForGeneratedFile + fileNameFromBulkRead);
		}else {
			String[] originalFileName = fileUploadVo.getFileName().split(separator);
			String[] fileNameArr = Arrays.copyOfRange(originalFileName, fileNameConfigSize, originalFileName.length);
			String fileName = null;
			if(fileNameArr.length == 0)
				fileName = originalFileName[originalFileName.length - 1];
			else
				fileName = StringUtils.join(fileNameArr, seperatorForGeneratedFile);
			
			generatedFileName.append(seperatorForGeneratedFile + fileName);
		}
		
		return generatedFileName.substring(seperatorForGeneratedFile.length());
	}
	
	private String getProductCodeByAccountNo(String accountNumber) {
		return documentRepository.findProductCodeDistinctByClientAccountNo(accountNumber).stream().findFirst()
				.orElse(null);
	}

	public DocType getDocTypeByCode(String docTypeCode) {
		return docTypeRepository.findByShortCode(docTypeCode).orElse(new DocType());
	}
	
	public void deleteDocumentIfExsitsForAccountNo(String accountNo, String fileName, boolean documentPolicy,
			TokenData tokenData) {
		List<Document> documentList = documentRepository
				.findByClientAccountNoAndReceiveFileNameAndIsDeleteFalse(accountNo, fileName);
		if (documentPolicy && !documentList.isEmpty()) {
			for (Document doc : documentList) {
				doc.deleteDocument(doc, tokenData);
				documentRepository.save(doc);
			}
		}
	}

	private void deleteDocumentIfExsits(String fileName, boolean documentPolicy, TokenData tokenData) {
		List<Document> documentList = documentRepository.findByReceiveFileNameAndIsDeleteFalse(fileName);
		if (documentPolicy && !documentList.isEmpty()) {
			for (Document doc : documentList) {
				doc.deleteDocument(doc, tokenData);
				documentRepository.save(doc);
			}
		}
	}
	
	public Document saveDocument(FileUploadConfigRequest fileUploadVo, boolean isValidFile, String docName,
			TokenData tokenData) {
		Document document = new Document();
		document.saveDocument(document, fileUploadVo, isValidFile, isValidFile ? MessageConstants.INVALID_FILE : "",
				docName, tokenData, tokenData);
		// save entity to database
		documentRepository.save(document);
		return document;
	}
	
	private void saveDocumentCostInvoice(SendReceiveDocument sendReceiveDocument, Document document,
			TokenData tokenData) {
		DocCost docCost = getDocCost(document.getDocTypeCode(), tokenData.getUserOrgCode());
		Float doumentCost = null;
		if (docCost.getCost() == null)
			doumentCost = 0f;
		else
			doumentCost = docCost.getCost();

		DocumentCostInvoice documentCostInvoice = new DocumentCostInvoice();
		documentCostInvoice.saveDocumentCostInvoice(documentCostInvoice, document.getFileSize(), sendReceiveDocument,
				doumentCost, tokenData, tokenData);
		documentCostInvoiceRepository.save(documentCostInvoice);
	}
	
	private DocCost getDocCost(String docTypeCode, String orgCode) {
//		return docCostRepository.findByDocTypeCodeAndIsDeleteFalse(docTypeCode).orElseThrow(() -> new InvalidArgumentException(
//				messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, docTypeCode)));
		return docCostRepository.findByOrgCodeAndDocTypeCodeAndIsDeleteFalse(orgCode,docTypeCode).orElse(new DocCost());
	}
	
	/** Save the share by detail After full fill request of document
	 * @param document
	 * @param tokenData
	 */
	private void saveShareByDetail(Document document, TokenData tokenData) {
		ShareBy shareBy = shareByRepository.findByUserIdAndDocumentId(tokenData.getPrincipleId(), document.getId())
				.orElse(new ShareBy());
		shareBy.saveShareBy(shareBy, document, tokenData, tokenData, DocumentShareTypeEnum.FILE);
		shareByRepository.save(shareBy);
	}
	
	private FileUploadConfigRequest copyDataFromReadPdfResponse(FileUploadConfigRequest fileUploadVo,
			ReadPdfResponse readPdfResponse) {
		fileUploadVo.setDocType(readPdfResponse.getDocType().getShortCode());
		fileUploadVo.setClientAccountNo(readPdfResponse.getClientAccountNumber());
		fileUploadVo.setOriginalAccountNo(readPdfResponse.getOriginalAccountNumber());
		fileUploadVo.setEquabliAccNo(readPdfResponse.getEquabliAccountNumber());
		fileUploadVo.setDocumentName(readPdfResponse.getDocType().getName());
		fileUploadVo.setProductCode(
				StringUtils.isNotBlank(readPdfResponse.getProductCode()) ? readPdfResponse.getProductCode()
						: getProductCodeByAccountNo(readPdfResponse.getClientAccountNumber()));
		return fileUploadVo;
	}

	private String setDirStructure(ReadPdfResponse readPdfResponse, String fileName) {
		return readPdfResponse.getClientAccountNumber() + File.separator + readPdfResponse.getProductCode()
				+ File.separator + readPdfResponse.getDocType().getShortCode() + File.separator + fileName;
	}
	
	public Optional<ClientResponse> getMappedClientDetailForPartner(String authorization, TokenData tokenData,
			String clientShortCode) {

		if (StringUtils.isNotBlank(clientShortCode) && Constants.PARTNER_CODE.equals(tokenData.getOrgType())) {
			Optional<ClientResponse> client = Optional
					.ofNullable(getMappedClientByPartnerId(authorization, tokenData.getUserOrgId()).stream()
							.collect(Collectors.toMap(ClientResponse::getShortName, Function.identity()))
							.get(clientShortCode));
			log.info("Fetch Mapped Client For partner {} client {}", tokenData.getUserOrgCode(), client);
			return client;
		}
		return Optional.empty();
	}
	
	public List<ClientResponse> getMappedClientByPartnerId(String authorization, Integer userOrdId) {
		try {
			String response = configService.getMappedClientDetail(authorization, "web", userOrdId);
			log.info("response of MappedPartner -> {}", response);

			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

			ConfigResponse<List<ClientResponse>> commonResponse = mapper.readValue(response,
					new TypeReference<ConfigResponse<List<ClientResponse>>>() {
					});

			log.info("configResponse ->{}", commonResponse);
			return commonResponse.getResponse().isEmpty() ? Collections.emptyList() : commonResponse.getResponse();
		} catch (JsonProcessingException e) {
			log.error("ERROR JSON PROCESSING getMappedPartnerbyClientId ->{}", e.getMessage(), e);
		} catch (Exception e) {
			log.error("ERROR WHILE FETCHING mapped client detail ->{}", e.getMessage(), e);
		}
		return Collections.emptyList();
	}
}
