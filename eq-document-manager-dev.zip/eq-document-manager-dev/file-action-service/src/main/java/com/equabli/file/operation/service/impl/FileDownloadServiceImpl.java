package com.equabli.file.operation.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.configs.AWSOperations;
import com.equabli.common.constants.Constants;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.Document;
import com.equabli.common.exception.ExcelReaderException;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.file.operation.constants.FileOperationMessageConstants;
import com.equabli.file.operation.request.FileDownloadRequest;
import com.equabli.file.operation.request.FolderDownloadRequest;
import com.equabli.file.operation.service.AsyncDownloadService;
import com.equabli.file.operation.service.FileDownloadService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FileDownloadServiceImpl implements FileDownloadService {

	@Value("${awsS3.bucket.name}")
	private String awsBucketName;

	/**
	 * I have set required false because skip test cases
	 */
	@Autowired(required = false)
	AWSOperations awsOperations;

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	DocumentRepository documentRepository;

	@Autowired
	AsyncDownloadService asyncDownloadService;

	@Autowired
	FetchTokenData fetchTokenData;

	@Autowired
	HttpServletRequest request;

	private static final String SHEET_NAME = "Sheet1";
	private static final String TEMP_DIR = "java.io.tmpdir";
	private static final String DOCUMENT = "documents";

	@Override
	public ByteArrayInputStream downloadSendRequestSampleFile() {

		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			Sheet sheet = workbook.createSheet(SHEET_NAME);

			// Header
			Row headerRow = sheet.createRow(0);

			for (int col = 0; col < FileOperationMessageConstants.FileOperationConfigs
					.getBulkSendRequestDocHeader().length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(
						FileOperationMessageConstants.FileOperationConfigs.getBulkSendRequestDocHeader()[col]);
			}
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		} catch (IOException e) {
			log.error("Error while download sample file for send request document -> {}", e.getMessage());
			throw new ExcelReaderException("Fail to Export data to Excel file.");
		}
	}

	@Override
	public CommonResponse<String> generatePresignUrl(String objectKey, Long fileSize) {
		String url = awsOperations == null ? null
				: awsOperations.genaratePreSignUrl(awsBucketName, objectKey, Util.getExprireTimeByFileSize(fileSize));
		return CommonResponse.success(
				messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.PRE_SIGN_URL_SUCCESS), url);
	}

	@Override
	public CommonResponse<String> downloadDocument(FileDownloadRequest fileDownloadRequest) {
		TokenData tokenData = fetchTokenData.getTokenData();
		String tempDir = System.getProperty(TEMP_DIR) + File.separator;
		String authorization = request.getHeader(Constants.AUTHORIZATION);
		String response = null;
		if (fileDownloadRequest.getDocumentIds().size() > 1) {
			response = handleMultipleDocument(tempDir, fileDownloadRequest, authorization, tokenData);
		} else {
			List<Document> getDocuments = documentRepository
					.findByIdAndIsDeleteFalse(fileDownloadRequest.getDocumentIds().get(0));
			if (!getDocuments.isEmpty())
				response = asyncDownloadService.downloadSingleDocument(getDocuments.get(0), tempDir, tokenData,
						authorization);
			
			log.info("Check for objectKey {}",response);
		}
		List<String> preSignUrls = getPreSignUrl(Arrays.asList(response));
		return CommonResponse.success(
				messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.DOWNLOAD_FOLDER_SUCCESS),
				preSignUrls.get(0));
	}

	@Override
	public CommonResponse<List<String>> downloadDocumentOfAccountNo(FolderDownloadRequest folderDownloadRequest) {
		TokenData tokenData = fetchTokenData.getTokenData();
		String tempDir = System.getProperty(TEMP_DIR) + File.separator;
		String authorization = request.getHeader(Constants.AUTHORIZATION);
		List<String> objectKeys = new ArrayList<>();
		for (String accountNumber : folderDownloadRequest.getAccountNumbers()) {
			List<Document> getDocuments = documentRepository
					.findByClientAccountNoAndOrgCodeAndIsDeleteFalse(accountNumber, tokenData.getUserOrgCode());
			if (getDocuments.isEmpty())
				return CommonResponse
						.success(messageSupplier.get(MessageConstants.NOT_VALID_ACCOUNT_NUMBER, accountNumber));

			String objKey = asyncDownloadService.downloadFolder(getDocuments, tempDir, tokenData, accountNumber,
					authorization);
			objectKeys.add(objKey);
		}
		List<String> preSignUrls = getPreSignUrl(objectKeys);
		return CommonResponse.success(
				messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.DOWNLOAD_FOLDER_SUCCESS),
				preSignUrls);
	}

	private String handleMultipleDocument(String tempDir, FileDownloadRequest fileDownloadRequest, String authorization,
			TokenData tokenData) {
		String dirPath = Util.createDirectoryIfNotExists(tempDir, DOCUMENT).toString();
		List<Document> documents = new ArrayList<>();
		// Collect Data according to document id.
		for (Long id : fileDownloadRequest.getDocumentIds()) {
			List<Document> getDocuments = documentRepository.findByIdAndIsDeleteFalse(id);
			if (getDocuments.isEmpty())
				continue;
			documents.addAll(getDocuments);
		}

		if (documents.isEmpty())
			return messageSupplier.get(MessageConstants.INVALID_DATA);

		return asyncDownloadService.downloadDocuments(documents, dirPath, tokenData, authorization);
	}
	
	private List<String> getPreSignUrl(List<String> objectKeys) {
		List<String> preSignUrls = new ArrayList<>();
		String url = null;
		for(String objKey : objectKeys) {
			String[] keys = objKey.split(",");
			url = awsOperations == null ? null
					: awsOperations.genaratePreSignUrl(awsBucketName, keys[0], Util.getExprireTimeByFileSize(Long.valueOf(keys[1])));
			preSignUrls.add(url);
		}
		return preSignUrls;
	}
}
