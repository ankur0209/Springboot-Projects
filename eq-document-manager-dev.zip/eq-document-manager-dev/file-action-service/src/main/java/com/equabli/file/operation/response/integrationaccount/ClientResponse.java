package com.equabli.file.operation.response.integrationaccount;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "Client Response of the config service ")
@Data
public class ClientResponse {
	private Integer clientId;
	private String shortName;
	private String fullName;
	private String clientType;
	private String pocName;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String zip;
	private String phone1;
	private String phone2;
	private String emailAddress;
	private String website;
	private Integer quicksiteId;
	private Boolean isMasterserviced;
}
