package com.equabli.file.operation.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.equabli.common.response.CommonResponse;
import com.equabli.file.operation.request.FileDownloadRequest;
import com.equabli.file.operation.request.FolderDownloadRequest;
import com.equabli.file.operation.service.FileDownloadService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/file/download")
@Tag(name = "File download API", description = "File download API for document manager")
@SecurityRequirement(name = "bearerAuth")
@Slf4j
public class FileDownloadController {

	@Autowired
	FileDownloadService fileDownloadService;

	@GetMapping
	@Operation(summary = "Download sample file for Send Request Document", description = "Download sample file for Send Request Document")
	public ResponseEntity<Resource> getSendRequestDocumentSampleFile() {
		String filename = "SendRequestDocumentSample.xlsx";
		InputStreamResource file = new InputStreamResource(fileDownloadService.downloadSendRequestSampleFile());

		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
				.contentType(MediaType.parseMediaType("application/vnd.ms-excel")).body(file);
	}
	
	@Operation(summary = "Generate PreSignUrl for object key", description = "Generate PreSignUrl for object key")
	@GetMapping(value = "presignUrl")
	public CommonResponse<String> generatePresignUrl(@RequestParam("objectKey") String objectKey,
			@RequestParam("fileSize") Long fileSize){
		log.info("Generate Presing Url for key {} ", objectKey);
		return fileDownloadService.generatePresignUrl(objectKey, fileSize);
	}
	
	@Operation(summary = "Download single and multiple document", description = "Download single and multiple document")
	@PostMapping("/file")
	public CommonResponse<String> downloadDocument(@Valid @RequestBody FileDownloadRequest fileDownloadRequest) {
		log.info("Download single and multiple document {} ", fileDownloadRequest);
		return fileDownloadService.downloadDocument(fileDownloadRequest);
	}

	@Operation(summary = "Download all document of account no", description = "Download all document of account no")
	@PostMapping("/folder")
	public CommonResponse<List<String>> downloadDocumentOfAccountNo(
			@Valid @RequestBody FolderDownloadRequest folderDownloadRequest) {
		log.info("Download all document of account wise {} ", folderDownloadRequest);
		return fileDownloadService.downloadDocumentOfAccountNo(folderDownloadRequest);
	}
}
