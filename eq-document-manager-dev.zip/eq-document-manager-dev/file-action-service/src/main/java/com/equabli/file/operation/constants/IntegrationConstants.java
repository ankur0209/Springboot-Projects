package com.equabli.file.operation.constants;

public final class IntegrationConstants {

	private IntegrationConstants() {
	}
	
	public static final String HYPHEN = "-";
	/**
	 * Equabli Document manage Application Subscription code  
	 */
	public static final String ED = "ED";
	/**
	 * EQ Collect User Organization type
	 */
	public static final String EQ = "EQ";
	public static final String ACCOUNT_DETAIL_NOT_FOUND = "account.detail.not.found";
	
	public final class AccountStatus {
		private AccountStatus() {
		}

		public static final String NEW = "NEW";
		public static final String OPN = "OPN";
		public static final String RTR = "RTR";
		public static final String DNW = "DNW";
		public static final String HLD = "HLD";
		public static final String PAY = "PAY";
		public static final String STL = "STL";
		public static final String RCL = "RCL";
		public static final String PLC = "PLC";
		public static final String CLP = "CLP";
		public static final String CLS = "CLS";
		public static final String DNP = "DNP";
		public static final String RRN = "RRN";
		public static final String BRK = "BRK";
		public static final String TBP = "TBP";
		public static final String RET = "RET";
	}
}
