package com.equabli.file.operation.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amazonaws.services.s3.event.S3EventNotification;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.equabli.file.operation.constants.FileOperationMessageConstants;
import com.equabli.file.operation.service.SFTPFileReadService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@AllArgsConstructor
@Slf4j
public class SQSFileReader {

	final AmazonSQS sqs;
	
	@Autowired
	private SFTPFileReadService sftpFileReadService;
	
//	@PostConstruct
	public void readFiles() {

		ObjectMapper objectMapper = new ObjectMapper();
		String clientQueueUrl = sqs.getQueueUrl("DEV_dm_file").getQueueUrl();

		List<Message> messages = sqs
				.receiveMessage(new ReceiveMessageRequest(clientQueueUrl).withMaxNumberOfMessages(10)).getMessages();
		log.info("clientQueueUrl -> {}", clientQueueUrl);
		for (Message m : messages) {
			log.info("Message Received " + m.getBody());
			S3EventNotification s3EventNotificationRecord;
			try {
				s3EventNotificationRecord = objectMapper.readValue(m.getBody(), S3EventNotification.class);
				S3EventNotification.S3Entity s3Entity = s3EventNotificationRecord.getRecords().get(0).getS3();
				String objectKey = s3Entity.getObject().getKey();
				log.info("objectKey in Manual :: {}", objectKey);
				
				sqs.deleteMessage(clientQueueUrl, m.getReceiptHandle());
				
			} catch (JsonProcessingException e) {
				log.info("ERROR WHILE READING MESSAGE -> {}", e.getMessage(), e);
			}
		}

//		while (true) {
//			try {
//				List<Message> messages1 = sqs
//						.receiveMessage(new ReceiveMessageRequest(clientQueueUrl).withMaxNumberOfMessages(10))
//						.getMessages();
//				log.info(clientQueueUrl);
//				for (Message m : messages1) {
//					log.info("Message Received =============> {}", m.getBody());
//
//					sqs.deleteMessage(clientQueueUrl, m.getReceiptHandle());
//
//				}
//			} catch (Exception ex) {
//				log.error(ex.getMessage(), ex);
//			}
//		}
	}

//	@SqsListener(value = "https://sqs.us-east-1.amazonaws.com/400779737080/DEV_dm_file", deletionPolicy = SqsMessageDeletionPolicy.ON_SUCCESS)
	public void receiveMessage(final S3EventNotification s3EventNotificationRecord) throws Exception{
		S3EventNotification.S3Entity s3Entity = s3EventNotificationRecord.getRecords().get(0).getS3();
		String objectKey = s3Entity.getObject().getKey();
		
		log.info("SQS Listener ObjectKey :: {}", objectKey);
		
		if(objectKey.contains(FileOperationMessageConstants.INCOMING_MEDIA))
			sftpFileReadService.readFileFromSFTP(objectKey);
	}
}
