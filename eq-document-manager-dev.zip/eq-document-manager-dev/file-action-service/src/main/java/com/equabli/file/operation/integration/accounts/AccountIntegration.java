package com.equabli.file.operation.integration.accounts;

import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.configs.BaseConfigService;
import com.equabli.common.constants.Constants;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.Document;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.feignclients.CommonConfigService;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.response.ClientSubscription;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PartnerResponse;
import com.equabli.common.response.ProcessIntegrationResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.file.operation.constants.FileOperationMessageConstants;
import com.equabli.file.operation.constants.IntegrationConstants;
import com.equabli.file.operation.integration.ProcessIntegration;
import com.equabli.file.operation.response.integrationaccount.ClientAccountsResponse;
import com.equabli.file.operation.response.integrationaccount.ClientResponse;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AccountIntegration {

	@Autowired
	BaseConfigService baseConfigService;

	@Autowired
	AccountsJson accountsJson;

	@Autowired
	CommonConfigService commonConfigService;

	@Autowired
	CommonIntegrationUtil commonIntegrationUtil;

	@Autowired
	@Qualifier("recallAccountService")
	ProcessIntegration recalledProcess;

	@Autowired
	@Qualifier("reAssignAccountService")
	ProcessIntegration reAssignProcess;

	@Autowired
	@Qualifier("assignAccountService")
	ProcessIntegration assignProcess;

	@Autowired
	DocumentRepository documentRepository;

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	FetchTokenData fetchTokenData;

	public void integrateAccount() {

		TokenData clientTokenData = commonIntegrationUtil.getUserToken("ssingh2@q3tech.com", "Equabli@123456");
		List<String> clientShortCodes = documentRepository.groupByOrgcode();
		List<ClientResponse> clientResponses = getClientResponses(clientTokenData, clientShortCodes);

		Map<String, ClientSubscription> subscribedClientByShortCode = getSubscribedClients(clientShortCodes);
		log.info("clientResponses {}, subscribedClientByShortCode {}", clientResponses, subscribedClientByShortCode);

		clientResponses.forEach(client -> {

			if (subscribedClientByShortCode.containsKey(client.getShortName()) && subscribedClientByShortCode
					.get(client.getShortName()).getAppCodes().contains(IntegrationConstants.ED)) {
				List<String> clientAccountNumbers = documentRepository
						.groupByClientAccountNoByOrgCode(client.getShortName());
				log.info("clientAccountNumbers {}", clientAccountNumbers);

				clientAccountNumbers.forEach(clientAccountNumber -> {

//					accountsJson.getAccountDetail(3, "20002012");
					accountsJson.getAccountDetail(client.getClientId(), clientAccountNumber).ifPresent(account -> {
						Map<String, PartnerResponse> partnersByNames = getPartnersByFullNames(clientTokenData,
								Arrays.asList(account.getPartnerName()));

						log.info("clientAccountNumber {}, account {} partnersByNames {} ", clientAccountNumber, account,
								partnersByNames);

						List<Document> documents = documentRepository.findByClientAccountNoAndOrgCodeAndIsDeleteFalse(
								clientAccountNumber, client.getShortName());
						String accountStatus = getAccountStatus(account);
						log.info("accountStatus {}, documents {}", accountStatus, documents);

						processIntegration(clientTokenData, documents, accountStatus,
								partnersByNames.get(account.getPartnerName()), client.getShortName());

					});
				});
			}
		});
	}

	private void processIntegration(TokenData tokenData, List<Document> documents, String accountStatus,
			PartnerResponse partner, String clientShortCode) {

		List<ProcessIntegrationResponse> processIntegrationResponse = switch (accountStatus) {
		case IntegrationConstants.AccountStatus.NEW:
			yield (assignProcess.executeIntegration(documents, partner, tokenData, clientShortCode));
		case IntegrationConstants.AccountStatus.OPN:
			yield (reAssignProcess.executeIntegration(documents, partner, tokenData, clientShortCode));
		case IntegrationConstants.AccountStatus.RTR:
			yield (recalledProcess.executeIntegration(documents, partner, tokenData, clientShortCode));
		case IntegrationConstants.AccountStatus.DNW, IntegrationConstants.AccountStatus.HLD,
				IntegrationConstants.AccountStatus.PAY, IntegrationConstants.AccountStatus.STL,
				IntegrationConstants.AccountStatus.RCL, IntegrationConstants.AccountStatus.PLC,
				IntegrationConstants.AccountStatus.CLP, IntegrationConstants.AccountStatus.CLS,
				IntegrationConstants.AccountStatus.DNP, IntegrationConstants.AccountStatus.RRN,
				IntegrationConstants.AccountStatus.BRK, IntegrationConstants.AccountStatus.TBP,
				IntegrationConstants.AccountStatus.RET:
			yield (Collections.emptyList());
		default:
			yield (Collections.emptyList());
		};

		log.info("processIntegrationResponse {}", processIntegrationResponse);
		processIntegrationResponse.forEach(proccessLog -> {
			commonIntegrationUtil.addActivityLog(tokenData, proccessLog.getExistingData(), proccessLog.getNewData());
		});
	}

	private Map<String, ClientSubscription> getSubscribedClients(List<String> clientShortCodes) {
		return baseConfigService.getClientSubscriptionResponse(clientShortCodes);
	}

	private List<String> getPartnerName(List<ClientAccountsResponse> accounts) {
		return accounts.stream().map(ClientAccountsResponse::getPartnerName).distinct().toList();
	}

	private Map<String, PartnerResponse> getPartnersByFullNames(TokenData tokenData, List<String> partnerNames) {
		return partnerNames.isEmpty() ? Collections.emptyMap()
				: commonIntegrationUtil.getPartnersByFullNames(tokenData, partnerNames).stream()
						.collect(Collectors.toMap(PartnerResponse::getFullName, partner -> partner));
	}

	private String getAccountStatus(ClientAccountsResponse account) {
		return account.getAccountStatus().split(IntegrationConstants.HYPHEN)[0];
	}

	private List<ClientResponse> getClientResponses(TokenData tokenData, List<String> clientShortCodes) {
		return commonIntegrationUtil.getClientsByShortCode(tokenData, clientShortCodes)
				.orElseThrow(() -> new InvalidArgumentException(
						messageSupplier.get(MessageConstants.INVALID_DATA, clientShortCodes)));
	}

	/**
	 * 
	 * @param clientOrgCode
	 * @param clientAccountNumber
	 * @param multipartFile
	 * @return
	 */
	public CommonResponse<String> uploadFileForClient(String action, String actionToPartyCode,
			MultipartFile multipartFile) {

		File file = Util.multipartFileToFile(multipartFile).orElseThrow(() -> new InvalidArgumentException(
				messageSupplier.get(FileOperationMessageConstants.ERROR_WHILE_UPLOAD_FILE)));
		
		String clientOrgCode = "MRLT";
		String clientAccountNumber = "20002013";
		
		Optional<Document> document = saveDocumentForClient(file, clientOrgCode, clientAccountNumber);
		
		return CommonResponse.success("File Uploaded Id ");
	}
	
	public Optional<Document> saveDocumentForClient(File file, String clientOrgCode, String clientAccountNumber) {

//		TODO : what is the type of document when eq collect user upload file
		String documentTypeCode = "AP";
		String documentType = "Application";
		
		String generatedFileName = generatedFileName(file.getName(), documentType, clientOrgCode, clientAccountNumber);
		TokenData clientTokenData = commonIntegrationUtil.getUserToken("ssingh2@q3tech.com", "Equabli@123456");
		ClientResponse clientResponses = getClientResponses(clientTokenData, Arrays.asList(clientOrgCode)).get(0);
		log.info("generatedFileName {}, clientResponses {}", generatedFileName, clientResponses);

		Document document = new Document();
		document.updateDocument(document, clientTokenData, Constants.CLIENT_CODE, clientOrgCode, documentTypeCode,
				documentType, clientResponses.getShortName());
		document.documentSetFileName(document, file.getName(), generatedFileName, file.length());

		accountsJson.getAccountDetail(3, clientAccountNumber).ifPresentOrElse(
				account -> document.documentSetAccountNumber(document, clientAccountNumber,
						account.getEquabliAccountNumber(), account.getOriginalAccountNumber(),
						account.getProductType().split(IntegrationConstants.HYPHEN)[0]),
				() -> document.documentSetOthers(document,
						messageSupplier.get(IntegrationConstants.ACCOUNT_DETAIL_NOT_FOUND), true));

		String objectKey = commonIntegrationUtil.uploadFile(document, file)
				.orElseThrow(() -> new InvalidArgumentException(
						messageSupplier.get(FileOperationMessageConstants.ERROR_WHILE_UPLOAD_FILE)));
		documentRepository.save(document);
		log.info("objectKey {}, document {}", objectKey, document);
		return Optional.of(document);
	}

	public String generatedFileName(String fileName, String documentType, String orgCode, String clientAccountNumber) {
		return String.join(FileOperationMessageConstants.GENERATE_FILE_NAME_SEPERATOR, orgCode, documentType,
				clientAccountNumber, fileName);
	}
}
