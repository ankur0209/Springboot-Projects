package com.equabli.file.operation.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.equabli.common.entity.DocType;
import com.equabli.common.entity.DocTypeIdentification;
import com.equabli.common.repository.DocTypeIdentificationRepository;
import com.equabli.file.operation.service.ReadDocumentService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ReadDocumentServiceImpl implements ReadDocumentService {

	private static final int MATCH_PERCENTAGE = 90;
	private static final String CONTENT_TYPE_PDF = "application/pdf";
	private static final String CONTENT_TYPE_EXCEL = "application/vnd";

	@Autowired
	private DocTypeIdentificationRepository docTypeIdentificationRepository;

	@Override
	public Optional<DocType> readDocument(File file) {

		List<DocTypeIdentification> docTypeIdentifications = docTypeIdentificationRepository
				.findByIsDeleteFalseOrderByUpdatedAtDesc();
		log.info("docTypeIdentifications {}", docTypeIdentifications);

		return docTypeIdentifications.stream()
				.map(docTypeIdentification -> findDocumentType(file, docTypeIdentification)).filter(Optional::isPresent)
				.findFirst().orElseGet(() -> {
					log.info("FileName -> {}", file.getName());
					return Optional.empty();
				});
	}

	private Optional<DocType> findDocumentType(File file, DocTypeIdentification docTypeIdentification) {

		log.info("FileDetail {}", file);

		try {
			String contentType = Files.probeContentType(file.toPath());
			log.info("contentType {}", contentType);

			if (contentType.contains(CONTENT_TYPE_PDF))
				return findDocumentTypeFromPdfFile(file, docTypeIdentification);
			else if (contentType.contains(CONTENT_TYPE_EXCEL))
				return findDocumentTypeFromExcelFile(file, docTypeIdentification);

		} catch (IOException e) {
			log.error("Error on find contentType", e);
		}
		return Optional.empty();
	}

	private Optional<DocType> findDocumentTypeFromPdfFile(File file, DocTypeIdentification docTypeIdentification) {

		final List<String> docTypeFields = docTypeIdentification.getDocTypeFields().getDocFields();
		log.info("docTypeIdentification ID {}, docTypeFields {}", docTypeIdentification.getId(), docTypeFields);

		List<String> attributes = new ArrayList<>(docTypeFields);

		try (PDDocument document = PDDocument.load(file)) {
			PDFTextStripper stripper = new PDFTextStripper();

			for (int i = 1; i <= document.getNumberOfPages(); i++) {

				String lineDeparator = stripper.getLineSeparator();
				stripper.setStartPage(i);
				stripper.setEndPage(i);

				String text = stripper.getText(document);
				String[] lines = text.split(lineDeparator);

				for (String line : lines) {
					readValuesFromLine(attributes, line);
				}

				int percentage = calculatePercentage(docTypeFields.size(), attributes.size());
				log.info("PageNumber {}, percetage Match {}, docTypeIdentification {}", i, percentage,
						docTypeIdentification);

				if (percentage > MATCH_PERCENTAGE) {
					return Optional.of(docTypeIdentification.getDocType());
				}
			}
		} catch (IOException e) {
			log.error("ERROR WHILE READ PDF FILE -> {}", e.getMessage(), e);
		}

		return Optional.empty();
	}

	private Optional<DocType> findDocumentTypeFromExcelFile(File file, DocTypeIdentification docTypeIdentification) {

		final List<String> docTypeFields = docTypeIdentification.getDocTypeFields().getDocFields();
		log.info("docTypeIdentification ID {}, docTypeFields {}", docTypeIdentification.getId(), docTypeFields);

		try (InputStream inputstream = new FileInputStream(file);
				XSSFWorkbook workbook = new XSSFWorkbook(inputstream);) {

			List<List<String>> rows = new ArrayList<>();

			Iterator<Sheet> sheetIterator = workbook.iterator();

			while (sheetIterator.hasNext()) {
				Sheet sheet = sheetIterator.next();
				log.info("sheet {}", sheet.getSheetName());

				Iterator<Row> rowIterator = sheet.iterator();
				while (rowIterator.hasNext()) {
					Row row = rowIterator.next();
					log.info("row {}, NumberOfCells {}", row.getRowNum(), row.getPhysicalNumberOfCells());

					List<String> rowData = new ArrayList<>();
					Iterator<Cell> cellIterator = row.cellIterator();
					while (cellIterator.hasNext()) {
						Cell cell = cellIterator.next();
						log.info("CellIndex {}, Cell {}", cell.getColumnIndex(), cell);

						String cellValue = getCellValueAsString(cell);
						rowData.add(cellValue);
					}

					List<String> intersection = new ArrayList<>(rowData);
					intersection.retainAll(docTypeFields);

					double matchPercentage = (double) intersection.size() / docTypeFields.size() * 100;

					log.info("rowNum {}, matchPercentage {}", row.getRowNum(), matchPercentage);

					if (matchPercentage > MATCH_PERCENTAGE) {
						return Optional.of(docTypeIdentification.getDocType());
					}
					rows.add(rowData);
				}
			}

			log.info("rowsData {} ", rows);

		} catch (IOException e) {
			log.error("Error while reading Excel File ", e);
		}

		return Optional.empty();
	}

	private String getCellValueAsString(Cell cell) {
		switch (cell.getCellType()) {
		case STRING:
			return cell.getStringCellValue();
		case NUMERIC:
			return String.valueOf(cell.getNumericCellValue());
		case BOOLEAN:
			return String.valueOf(cell.getBooleanCellValue());
		case BLANK:
			return "";
		default:
			return "";
		}
	}

	private void readValuesFromLine(List<String> fileds, String lineText) {
		List<String> filedsToRemove = fileds.stream()
				.filter(filed -> lineText.toLowerCase().contains(filed.toLowerCase()) && lineText.indexOf(filed) > -1)
				.toList();

		fileds.removeAll(filedsToRemove);
	}

	private int calculatePercentage(float size, float remaining) {
		return Math.round((size - remaining) / size * 100);
	}
}
