package com.equabli.file.operation.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.FileOperationResponse;

public interface SFTPFileUploadService {

	CommonResponse<FileOperationResponse> uploadFileToSFTP(List<MultipartFile> multipartFiles);
	
}
