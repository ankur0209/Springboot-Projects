package com.equabli.file.operation.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.exception.ExcelReaderException;
import com.equabli.common.repository.DocTypeRepository;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.request.RequestNewDocumentRequest;
import com.equabli.common.request.UserEmailRequest;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.UserDetailResponse;
import com.equabli.common.response.UserMailResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.file.operation.constants.FileOperationMessageConstants;
import com.equabli.file.operation.feignclient.UserService;
import com.equabli.file.operation.response.RequestDocumentExcelResponse;
import com.equabli.file.operation.service.AsyncService;
import com.equabli.file.operation.service.BulkRequestDocumentService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BulkRequestDocumentServiceImpl implements BulkRequestDocumentService {

	private static final int SHEET_INDEX = 0;
	private static final int HEADER_RAW_NUMBER = 0;

	@Autowired
	private DocTypeRepository docTypeRepository;

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	DocumentRepository documentRepository;

	@Autowired
	FetchTokenData fetchTokenData;

	@Autowired
	private AsyncService asyncService;

	@Autowired
	UserService userService;

	@Autowired
	private HttpServletRequest request;

	@Override
	public CommonResponse<List<RequestDocumentExcelResponse>> saveBulkRequestDocument(MultipartFile file) {

		TokenData tokenData = fetchTokenData.getTokenData();
		try {
			if (!checkValidHeader(file.getInputStream(), tokenData.getOrgType()))
				return CommonResponse.failureWithErrors(messageSupplier
						.get(FileOperationMessageConstants.FileOperationConfigs.EXCEL_HEADER_NAME_INVALID), null);

			List<RequestDocumentExcelResponse> requestDocumentResponse = this
					.excelToRequestDocuments(file.getInputStream());

			if (requestDocumentResponse.isEmpty())
				return CommonResponse.success(messageSupplier
						.get(FileOperationMessageConstants.FileOperationConfigs.EXCEL_FILE_UPLOAD_SUCCESS));
			else
				return CommonResponse.failureWithErrors(
						messageSupplier
								.get(FileOperationMessageConstants.FileOperationConfigs.EXCEL_FILE_INVALID_VALUES),
						requestDocumentResponse);
		} catch (Exception e) {
			log.error("Error while reading data from file -> {}", e.getMessage());
			throw new ExcelReaderException(
					messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.EXCEL_FILE_UPLOAD_ERROR));
		}
	}

	public boolean checkValidHeader(InputStream is, String orgType) throws IOException {
		Workbook workbook = new XSSFWorkbook(is);
		Sheet sheet = workbook.getSheetAt(SHEET_INDEX);
		boolean isValid = true;
		int maxColumnNumber = getMaxColumnNumber(orgType);

		// Header
		Row headerRow = sheet.getRow(HEADER_RAW_NUMBER);

		for (int col = 0; col < maxColumnNumber; col++)
			if (!org.apache.commons.lang3.StringUtils.equals(
					FileOperationMessageConstants.FileOperationConfigs.getBulkSendRequestDocHeader()[col],
					getCellValue(headerRow.getCell(col)))) {
				isValid = false;
				break;
			}

		workbook.close();
		return isValid;
	}

	public List<RequestDocumentExcelResponse> excelToRequestDocuments(InputStream is) throws IOException {

		TokenData tokenData = fetchTokenData.getTokenData();
		Workbook workbook = new XSSFWorkbook(is);

		Sheet sheet = workbook.getSheetAt(SHEET_INDEX);
		Iterator<Row> rows = sheet.iterator();

		List<RequestNewDocumentRequest> requestDocuments = new ArrayList<>();
		List<RequestDocumentExcelResponse> requestDocumentResponses = new ArrayList<>();
		int maxColumnNumber = getMaxColumnNumber(tokenData.getOrgType());

		while (rows.hasNext()) {
			Row currentRow = rows.next();
			if (currentRow.getRowNum() == 0)
				continue;

			RequestNewDocumentRequest requestDocument = new RequestNewDocumentRequest();
			boolean isValidRaw = true;

			for (int cellNumber = 0; cellNumber < maxColumnNumber; cellNumber++) {

				Cell currentCell = currentRow.getCell(cellNumber);
				log.info("RowNumber {}, cellNumber {}, currentCell {}", currentRow.getRowNum(), cellNumber,
						currentCell);
				if (currentCell == null
						|| !StringUtils.hasText(BulkRequestDocumentServiceImpl.getCellValue(currentCell)))
					isValidRaw = checkValidCellValue(currentRow.getRowNum(), cellNumber, requestDocumentResponses,
							tokenData.getOrgType());
				else
					this.setDataIntoRequestNewDocumentRequest(currentRow, currentCell, requestDocument,
							requestDocumentResponses);
			}
			if (isValidRaw)
				requestDocuments.add(requestDocument);
		}
		workbook.close();

		/**
		 * if list is empty means no error in excel sheet than save document request
		 * into database
		 */
		if (requestDocumentResponses.isEmpty()) {
			List<String> mailList = requestDocuments.stream().map(RequestNewDocumentRequest::getSendRequest).distinct()
					.toList();
			log.info("MAIL LIST {}", mailList);
			String authorization = request.getHeader(Constants.AUTHORIZATION);
			List<UserDetailResponse> userDetailResponse = getUserDetail(authorization, mailList);
			asyncService.saveBulkSendReceiveDocumentFromExcel(authorization, requestDocuments, tokenData,
					userDetailResponse);
		}

		return requestDocumentResponses;
	}

	public List<UserDetailResponse> getUserDetail(String authorization, List<String> emails) {

		String response = userService.emailExists(authorization, UserEmailRequest.builder().datas(emails).build());
		log.info("response -> {}", response);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		try {
			UserMailResponse userMailResponse = mapper.readValue(response, UserMailResponse.class);
			return userMailResponse.getResponse();
		} catch (JsonProcessingException e) {
			log.error("ERROR WHILE CONVERT VALUES - > {}", e.getMessage(), e);
		}

		return Collections.emptyList();
	}

	private static String getCellValue(Cell cell) {
		String cellValue;
		switch (cell.getCellType()) {
		case STRING -> cellValue = cell.getStringCellValue();
		case NUMERIC -> cellValue = String.valueOf((long) cell.getNumericCellValue());
		case BLANK -> cellValue = null;
		default -> cellValue = null;
		}

		return cellValue;
	}

	/**
	 * Add appropriate message if cell value is blank
	 * 
	 * @param rowNumber
	 * @param columnNumber
	 * @param requestDocumentResponses
	 * @return
	 */
	private boolean checkValidCellValue(int rowNumber, int columnNumber,
			List<RequestDocumentExcelResponse> requestDocumentResponses, String orgType) {
		boolean isValidRaw = true;
		String message = null;

		switch (columnNumber) {
		case 0 -> {
			message = messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.EXCEL_HEADER_REQUIRED,
					FileOperationMessageConstants.FileOperationConfigs.getBulkSendRequestDocHeader()[0]);
			isValidRaw = false;
		}
		case 1 -> {
			message = messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.EXCEL_HEADER_REQUIRED,
					FileOperationMessageConstants.FileOperationConfigs.getBulkSendRequestDocHeader()[1]);
			isValidRaw = false;
		}
		case 3 -> {
			message = messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.EXCEL_HEADER_REQUIRED,
					FileOperationMessageConstants.FileOperationConfigs.getBulkSendRequestDocHeader()[3]);
			isValidRaw = false;
		}
		case 5 -> {
			if (Constants.PARTNER_CODE.equals(orgType)) {
				message = messageSupplier.get(FileOperationMessageConstants.FileOperationConfigs.EXCEL_HEADER_REQUIRED,
						FileOperationMessageConstants.FileOperationConfigs.getBulkSendRequestDocHeader()[5]);
				isValidRaw = false;
			}
		}
		default -> log.debug("Column is not required.");
		}

		if (message != null)
			requestDocumentResponses
					.add(new RequestDocumentExcelResponse((rowNumber + 1), (columnNumber + 1), message));

		return isValidRaw;
	}

	/**
	 * Set data
	 * 
	 * @param currentRow
	 * @param currentCell
	 * @param requestDocument
	 * @param requestDocumentResponses
	 */
	private void setDataIntoRequestNewDocumentRequest(Row currentRow, Cell currentCell,
			RequestNewDocumentRequest requestDocument, List<RequestDocumentExcelResponse> requestDocumentResponses) {
		switch (currentCell.getColumnIndex()) {
		case 0 -> docTypeRepository.findByShortCode(currentCell.getStringCellValue()).ifPresentOrElse(value -> {
			requestDocument.setDocumentType(value.getName());
			requestDocument.setDocTypeCode(currentCell.getStringCellValue());
		}, () -> requestDocumentResponses.add(new RequestDocumentExcelResponse((currentRow.getRowNum() + 1),
				(currentCell.getColumnIndex() + 1),
				messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, " " + currentCell.getStringCellValue())))

			);
		case 1 -> getUserDetailsRequest(BulkRequestDocumentServiceImpl.getCellValue(currentCell)).ifPresentOrElse(
				requestDocument::setSendRequest,
				() -> requestDocumentResponses.add(new RequestDocumentExcelResponse((currentRow.getRowNum() + 1),
						(currentCell.getColumnIndex() + 1), messageSupplier
								.get(MessageConstants.NOT_VALID_EMAIL_ADDRESS, currentCell.getStringCellValue()))));
		case 2 -> requestDocument.setOriginalAccountNumber(BulkRequestDocumentServiceImpl.getCellValue(currentCell));
		case 3 -> requestDocument.setClientAccountNumber(BulkRequestDocumentServiceImpl.getCellValue(currentCell));
		case 4 -> requestDocument.setEquabliAccountNumber((long) currentCell.getNumericCellValue());
		case 5 -> requestDocument.setClientShortCode(BulkRequestDocumentServiceImpl.getCellValue(currentCell));
		default -> log.debug("Extra column raw {}, column {}", currentRow.getRowNum(), currentCell.getColumnIndex());
		}
	}

	private Optional<String> getUserDetailsRequest(String emailAddress) {
		return Util.checkValidMail(emailAddress) ? Optional.of(emailAddress) : Optional.empty();
	}

	private int getMaxColumnNumber(String orgType) {
		return Constants.PARTNER_CODE.equals(orgType)
				? FileOperationMessageConstants.FileOperationConfigs.SENT_BULK_PARTNER_COLUMNS
				: FileOperationMessageConstants.FileOperationConfigs.SENT_BULK_CLIENT_COLUMNS;
	}
}
