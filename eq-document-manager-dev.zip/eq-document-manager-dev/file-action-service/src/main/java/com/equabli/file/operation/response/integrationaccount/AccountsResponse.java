package com.equabli.file.operation.response.integrationaccount;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Account respnse from the EQ Collect commonAcctSerarch API")
public class AccountsResponse {
	private Integer recordNumber;
	private String clientName;
	private Integer clientId;
	private String consumerName;
	private Long consumerId;
	private String consumerSSN;
	private Long equabliAccountNumber;
	private String originalAccountNumber;
	private String clientAccountNumber;
	private String accountQueue;
	private String accountStatus;
	private String accountReason;
	private Integer queueStatusId;
	private String productType;
	private Integer productId;
	private String chargeOffDate;
	private String assignedPartner;
	private Integer partnerId;
	private String chargeOffBalance;
	private String currentBalance;
	private String consumerAddressState;
	private Integer queueId;
	private Integer queueReasonId;
	private Long clientConsumerNumber;
	private String complianceIds;
	private Float eqvscore;
}
