package com.java.common;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;

import com.equabli.common.utils.Util;
import com.equabli.common.utils.ZipUtils;

class TestUtils {

	@Test
	void convertMultipartToFile() throws IOException {
		MockMultipartFile firstFile = new MockMultipartFile("data", "filename.txt", "text/plain",
				"some xml".getBytes());
		File file = Util.convertMultipartToFile(firstFile);
		assertNotNull(file);
		file.delete();
	}

	@Test
	void convertLocalDateToUtc() {
		LocalDateTime localDateTime = Util.convertLocalDateToUtc("12232023");
		assertEquals(2023, localDateTime.getYear());
	}

	@Test
	void getExtensionFromFileName() {
		String extension = Util.getExtensionFromFileName("test.txt");
		assertEquals("txt", extension);
	}

	@Test
	void isEndWith() {
		boolean isZip = Util.isEndWith("abc.zip");
		assertEquals(true, isZip);
	}

	@Test
	void isEndWith_NotValid() {
		boolean isZip = Util.isEndWith("abc.txx");
		assertEquals(false, isZip);
	}

    @Test
    void getFileNameWithoutExtension() {
    	String fileName = Util.getFileNameWithoutExtension("abc.txt");
    	assertEquals("abc", fileName);
    }

    @Test
    void createDirectoryIfNotExists() {
    	Path path = Util.createDirectoryIfNotExists("tmp", "test");
    	path.toFile().delete();
    	assertNotNull(path);
    }

	@Test
	void zipDirectory() throws IOException {
		Path tempFile = Files.createTempDirectory("zipDir");
		Files.createTempFile(tempFile, "test1", ".txt");
		Files.createTempFile(tempFile, "test2", ".txt");

		String zipPath = ZipUtils.zipDirectory(tempFile);
		
		tempFile.toFile().delete();
		assertNotNull(zipPath);

	}

}
