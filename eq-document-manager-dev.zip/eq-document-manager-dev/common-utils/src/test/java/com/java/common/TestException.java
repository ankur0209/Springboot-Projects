package com.java.common;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import com.equabli.common.exception.IOException;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.exception.ResourceNotFoundException;

class TestException {

	@Test
	void invalidArgumentExceptionTest() {
	    Throwable exception = assertThrows(InvalidArgumentException.class, () -> {
	      throw new InvalidArgumentException("Not supported");
	    });
	    assertEquals("Not supported", exception.getMessage());
	}
	
	@Test
	void shouldThrowException() {
	    Throwable exception = assertThrows(IOException.class, () -> {
	      throw new IOException("File Not found");
	    });
	    assertEquals("File Not found", exception.getMessage());
	}
	
	@Test
	void resourceNotFoundExceptionTest() {
		Throwable exception = assertThrows(ResourceNotFoundException.class, () -> {
		      throw new ResourceNotFoundException("File Not found");
		    });
		    assertEquals("File Not found", exception.getMessage());
	}
}
