package com.equabli.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QDocMgrConfig is a Querydsl query type for DocMgrConfig
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QDocMgrConfig extends EntityPathBase<DocMgrConfig> {

    private static final long serialVersionUID = -2133116770L;

    public static final QDocMgrConfig docMgrConfig = new QDocMgrConfig("docMgrConfig");

    public final QBaseEntity _super = new QBaseEntity(this);

    //inherited
    public final StringPath appCode = _super.appCode;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    //inherited
    public final StringPath createdBy = _super.createdBy;

    public final StringPath defaultValue = createString("defaultValue");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> deletedAt = _super.deletedAt;

    //inherited
    public final StringPath deletedBy = _super.deletedBy;

    public final StringPath description = createString("description");

    public final NumberPath<Long> id = createNumber("id", Long.class);

    //inherited
    public final StringPath ipAddress = _super.ipAddress;

    //inherited
    public final BooleanPath isDelete = _super.isDelete;

    //inherited
    public final StringPath macAddress = _super.macAddress;

    public final StringPath orgTypeCode = createString("orgTypeCode");

    //inherited
    public final StringPath recordSourceCode = _super.recordSourceCode;

    //inherited
    public final StringPath recordStatusCode = _super.recordStatusCode;

    public final StringPath shortCode = createString("shortCode");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedAt = _super.updatedAt;

    //inherited
    public final StringPath updatedBy = _super.updatedBy;

    public QDocMgrConfig(String variable) {
        super(DocMgrConfig.class, forVariable(variable));
    }

    public QDocMgrConfig(Path<? extends DocMgrConfig> path) {
        super(path.getType(), path.getMetadata());
    }

    public QDocMgrConfig(PathMetadata metadata) {
        super(DocMgrConfig.class, metadata);
    }

}

