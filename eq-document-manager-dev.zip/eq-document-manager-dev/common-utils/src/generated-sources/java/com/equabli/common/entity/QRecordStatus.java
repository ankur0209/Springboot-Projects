package com.equabli.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QRecordStatus is a Querydsl query type for RecordStatus
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QRecordStatus extends EntityPathBase<RecordStatus> {

    private static final long serialVersionUID = 2052981535L;

    public static final QRecordStatus recordStatus = new QRecordStatus("recordStatus");

    public final DateTimePath<java.time.LocalDateTime> createdAt = createDateTime("createdAt", java.time.LocalDateTime.class);

    public final StringPath createdBy = createString("createdBy");

    public final StringPath description = createString("description");

    public final NumberPath<Short> id = createNumber("id", Short.class);

    public final StringPath shortCode = createString("shortCode");

    public final StringPath shortName = createString("shortName");

    public final DateTimePath<java.time.LocalDateTime> updatedAt = createDateTime("updatedAt", java.time.LocalDateTime.class);

    public final StringPath updatedBy = createString("updatedBy");

    public QRecordStatus(String variable) {
        super(RecordStatus.class, forVariable(variable));
    }

    public QRecordStatus(Path<? extends RecordStatus> path) {
        super(path.getType(), path.getMetadata());
    }

    public QRecordStatus(PathMetadata metadata) {
        super(RecordStatus.class, metadata);
    }

}

