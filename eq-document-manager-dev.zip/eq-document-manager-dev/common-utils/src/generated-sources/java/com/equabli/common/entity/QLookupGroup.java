package com.equabli.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QLookupGroup is a Querydsl query type for LookupGroup
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QLookupGroup extends EntityPathBase<LookupGroup> {

    private static final long serialVersionUID = 1366736425L;

    public static final QLookupGroup lookupGroup = new QLookupGroup("lookupGroup");

    public final QBaseEntity _super = new QBaseEntity(this);

    //inherited
    public final StringPath appCode = _super.appCode;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    //inherited
    public final StringPath createdBy = _super.createdBy;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> deletedAt = _super.deletedAt;

    //inherited
    public final StringPath deletedBy = _super.deletedBy;

    public final StringPath description = createString("description");

    //inherited
    public final StringPath ipAddress = _super.ipAddress;

    public final BooleanPath isBusinessFunction = createBoolean("isBusinessFunction");

    //inherited
    public final BooleanPath isDelete = _super.isDelete;

    public final StringPath keyvalue = createString("keyvalue");

    //inherited
    public final StringPath macAddress = _super.macAddress;

    //inherited
    public final StringPath recordSourceCode = _super.recordSourceCode;

    //inherited
    public final StringPath recordStatusCode = _super.recordStatusCode;

    public final ComparablePath<java.util.UUID> uid = createComparable("uid", java.util.UUID.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedAt = _super.updatedAt;

    //inherited
    public final StringPath updatedBy = _super.updatedBy;

    public QLookupGroup(String variable) {
        super(LookupGroup.class, forVariable(variable));
    }

    public QLookupGroup(Path<? extends LookupGroup> path) {
        super(path.getType(), path.getMetadata());
    }

    public QLookupGroup(PathMetadata metadata) {
        super(LookupGroup.class, metadata);
    }

}

