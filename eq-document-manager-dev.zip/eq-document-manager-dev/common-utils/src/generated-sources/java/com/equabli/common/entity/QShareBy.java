package com.equabli.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QShareBy is a Querydsl query type for ShareBy
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QShareBy extends EntityPathBase<ShareBy> {

    private static final long serialVersionUID = -741899366L;

    public static final QShareBy shareBy = new QShareBy("shareBy");

    public final QBaseEntity _super = new QBaseEntity(this);

    public final StringPath actionByOrgCode = createString("actionByOrgCode");

    public final StringPath actionByOrgTypeCode = createString("actionByOrgTypeCode");

    public final NumberPath<Long> actionByUserId = createNumber("actionByUserId", Long.class);

    //inherited
    public final StringPath appCode = _super.appCode;

    public final StringPath clientAccountNo = createString("clientAccountNo");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    //inherited
    public final StringPath createdBy = _super.createdBy;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> deletedAt = _super.deletedAt;

    //inherited
    public final StringPath deletedBy = _super.deletedBy;

    public final StringPath docTypeCode = createString("docTypeCode");

    public final NumberPath<Long> documentId = createNumber("documentId", Long.class);

    public final NumberPath<Long> id = createNumber("id", Long.class);

    //inherited
    public final StringPath ipAddress = _super.ipAddress;

    public final BooleanPath isArchived = createBoolean("isArchived");

    //inherited
    public final BooleanPath isDelete = _super.isDelete;

    public final BooleanPath isUnshared = createBoolean("isUnshared");

    //inherited
    public final StringPath macAddress = _super.macAddress;

    public final StringPath orgAccountNo = createString("orgAccountNo");

    public final StringPath orgCode = createString("orgCode");

    public final StringPath orgTypeCode = createString("orgTypeCode");

    public final NumberPath<Integer> portfolioId = createNumber("portfolioId", Integer.class);

    public final StringPath productCode = createString("productCode");

    //inherited
    public final StringPath recordSourceCode = _super.recordSourceCode;

    //inherited
    public final StringPath recordStatusCode = _super.recordStatusCode;

    public final DateTimePath<java.time.LocalDateTime> sharedAt = createDateTime("sharedAt", java.time.LocalDateTime.class);

    public final StringPath sharedBy = createString("sharedBy");

    public final StringPath sharedText = createString("sharedText");

    public final EnumPath<com.equabli.common.enums.DocumentShareTypeEnum> sharedType = createEnum("sharedType", com.equabli.common.enums.DocumentShareTypeEnum.class);

    public final DateTimePath<java.time.LocalDateTime> unsharedAt = createDateTime("unsharedAt", java.time.LocalDateTime.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedAt = _super.updatedAt;

    //inherited
    public final StringPath updatedBy = _super.updatedBy;

    public final NumberPath<Long> userId = createNumber("userId", Long.class);

    public QShareBy(String variable) {
        super(ShareBy.class, forVariable(variable));
    }

    public QShareBy(Path<? extends ShareBy> path) {
        super(path.getType(), path.getMetadata());
    }

    public QShareBy(PathMetadata metadata) {
        super(ShareBy.class, metadata);
    }

}

