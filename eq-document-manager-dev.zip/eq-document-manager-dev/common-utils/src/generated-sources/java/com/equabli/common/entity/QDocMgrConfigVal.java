package com.equabli.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QDocMgrConfigVal is a Querydsl query type for DocMgrConfigVal
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QDocMgrConfigVal extends EntityPathBase<DocMgrConfigVal> {

    private static final long serialVersionUID = 654502307L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QDocMgrConfigVal docMgrConfigVal = new QDocMgrConfigVal("docMgrConfigVal");

    public final QBaseEntity _super = new QBaseEntity(this);

    //inherited
    public final StringPath appCode = _super.appCode;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    //inherited
    public final StringPath createdBy = _super.createdBy;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> deletedAt = _super.deletedAt;

    //inherited
    public final StringPath deletedBy = _super.deletedBy;

    public final StringPath description = createString("description");

    public final QDocMgrConfig docMgrConfig;

    public final StringPath fieldValue = createString("fieldValue");

    public final NumberPath<Long> id = createNumber("id", Long.class);

    //inherited
    public final StringPath ipAddress = _super.ipAddress;

    //inherited
    public final BooleanPath isDelete = _super.isDelete;

    //inherited
    public final StringPath macAddress = _super.macAddress;

    //inherited
    public final StringPath recordSourceCode = _super.recordSourceCode;

    //inherited
    public final StringPath recordStatusCode = _super.recordStatusCode;

    public final StringPath shortCode = createString("shortCode");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedAt = _super.updatedAt;

    //inherited
    public final StringPath updatedBy = _super.updatedBy;

    public QDocMgrConfigVal(String variable) {
        this(DocMgrConfigVal.class, forVariable(variable), INITS);
    }

    public QDocMgrConfigVal(Path<? extends DocMgrConfigVal> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QDocMgrConfigVal(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QDocMgrConfigVal(PathMetadata metadata, PathInits inits) {
        this(DocMgrConfigVal.class, metadata, inits);
    }

    public QDocMgrConfigVal(Class<? extends DocMgrConfigVal> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.docMgrConfig = inits.isInitialized("docMgrConfig") ? new QDocMgrConfig(forProperty("docMgrConfig")) : null;
    }

}

