package com.equabli.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QShareWith is a Querydsl query type for ShareWith
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QShareWith extends EntityPathBase<ShareWith> {

    private static final long serialVersionUID = -105655L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QShareWith shareWith = new QShareWith("shareWith");

    public final QBaseEntity _super = new QBaseEntity(this);

    //inherited
    public final StringPath appCode = _super.appCode;

    public final DateTimePath<java.time.LocalDateTime> archivedAt = createDateTime("archivedAt", java.time.LocalDateTime.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    //inherited
    public final StringPath createdBy = _super.createdBy;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> deletedAt = _super.deletedAt;

    //inherited
    public final StringPath deletedBy = _super.deletedBy;

    public final NumberPath<Long> id = createNumber("id", Long.class);

    //inherited
    public final StringPath ipAddress = _super.ipAddress;

    public final BooleanPath isArchived = createBoolean("isArchived");

    //inherited
    public final BooleanPath isDelete = _super.isDelete;

    public final BooleanPath isRegisteredUser = createBoolean("isRegisteredUser");

    public final BooleanPath isUnshared = createBoolean("isUnshared");

    //inherited
    public final StringPath macAddress = _super.macAddress;

    public final StringPath orgCode = createString("orgCode");

    public final StringPath orgTypeCode = createString("orgTypeCode");

    //inherited
    public final StringPath recordSourceCode = _super.recordSourceCode;

    //inherited
    public final StringPath recordStatusCode = _super.recordStatusCode;

    public final QShareBy shareById;

    public final EnumPath<com.equabli.common.enums.DocumentShareTypeEnum> sharedType = createEnum("sharedType", com.equabli.common.enums.DocumentShareTypeEnum.class);

    public final StringPath sharedWithEmailId = createString("sharedWithEmailId");

    public final StringPath shareWithName = createString("shareWithName");

    public final StringPath shareWithOrgTypeCode = createString("shareWithOrgTypeCode");

    public final StringPath shareWithUserOrgCode = createString("shareWithUserOrgCode");

    public final DateTimePath<java.time.LocalDateTime> unsharedAt = createDateTime("unsharedAt", java.time.LocalDateTime.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedAt = _super.updatedAt;

    //inherited
    public final StringPath updatedBy = _super.updatedBy;

    public final NumberPath<Long> userId = createNumber("userId", Long.class);

    public QShareWith(String variable) {
        this(ShareWith.class, forVariable(variable), INITS);
    }

    public QShareWith(Path<? extends ShareWith> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QShareWith(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QShareWith(PathMetadata metadata, PathInits inits) {
        this(ShareWith.class, metadata, inits);
    }

    public QShareWith(Class<? extends ShareWith> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.shareById = inits.isInitialized("shareById") ? new QShareBy(forProperty("shareById")) : null;
    }

}

