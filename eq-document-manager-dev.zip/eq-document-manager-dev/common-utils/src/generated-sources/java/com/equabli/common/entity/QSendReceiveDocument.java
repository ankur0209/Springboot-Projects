package com.equabli.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QSendReceiveDocument is a Querydsl query type for SendReceiveDocument
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QSendReceiveDocument extends EntityPathBase<SendReceiveDocument> {

    private static final long serialVersionUID = 2132360570L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QSendReceiveDocument sendReceiveDocument = new QSendReceiveDocument("sendReceiveDocument");

    public final QBaseEntity _super = new QBaseEntity(this);

    public final StringPath actionByOrgCode = createString("actionByOrgCode");

    public final StringPath actionByOrgTypeCode = createString("actionByOrgTypeCode");

    public final NumberPath<Long> actionByUserId = createNumber("actionByUserId", Long.class);

    //inherited
    public final StringPath appCode = _super.appCode;

    public final StringPath clientAccountNo = createString("clientAccountNo");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    //inherited
    public final StringPath createdBy = _super.createdBy;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> deletedAt = _super.deletedAt;

    //inherited
    public final StringPath deletedBy = _super.deletedBy;

    public final StringPath docTypeCode = createString("docTypeCode");

    public final StringPath documentName = createString("documentName");

    public final StringPath documentType = createString("documentType");

    public final DateTimePath<java.time.LocalDateTime> dueOnAt = createDateTime("dueOnAt", java.time.LocalDateTime.class);

    public final NumberPath<Long> equabliAccNo = createNumber("equabliAccNo", Long.class);

    public final QDocument fullfilledDocumentId;

    public final DateTimePath<java.time.LocalDateTime> fullfilledOn = createDateTime("fullfilledOn", java.time.LocalDateTime.class);

    public final NumberPath<Long> id = createNumber("id", Long.class);

    //inherited
    public final StringPath ipAddress = _super.ipAddress;

    //inherited
    public final BooleanPath isDelete = _super.isDelete;

    //inherited
    public final StringPath macAddress = _super.macAddress;

    public final StringPath originalAccountNo = createString("originalAccountNo");

    public final StringPath productCode = createString("productCode");

    public final StringPath receiveRequestOrgCode = createString("receiveRequestOrgCode");

    public final StringPath receiveRequestOrgTypeCode = createString("receiveRequestOrgTypeCode");

    public final NumberPath<Long> receiveRequestUserId = createNumber("receiveRequestUserId", Long.class);

    //inherited
    public final StringPath recordSourceCode = _super.recordSourceCode;

    //inherited
    public final StringPath recordStatusCode = _super.recordStatusCode;

    public final DateTimePath<java.time.LocalDateTime> requestedAt = createDateTime("requestedAt", java.time.LocalDateTime.class);

    public final StringPath requestedBy = createString("requestedBy");

    public final StringPath requestedTo = createString("requestedTo");

    public final StringPath requestStatus = createString("requestStatus");

    public final StringPath sentRequestOrgCode = createString("sentRequestOrgCode");

    public final StringPath sentRequestOrgTypeCode = createString("sentRequestOrgTypeCode");

    public final NumberPath<Long> sentRequestUserId = createNumber("sentRequestUserId", Long.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedAt = _super.updatedAt;

    //inherited
    public final StringPath updatedBy = _super.updatedBy;

    public QSendReceiveDocument(String variable) {
        this(SendReceiveDocument.class, forVariable(variable), INITS);
    }

    public QSendReceiveDocument(Path<? extends SendReceiveDocument> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QSendReceiveDocument(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QSendReceiveDocument(PathMetadata metadata, PathInits inits) {
        this(SendReceiveDocument.class, metadata, inits);
    }

    public QSendReceiveDocument(Class<? extends SendReceiveDocument> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.fullfilledDocumentId = inits.isInitialized("fullfilledDocumentId") ? new QDocument(forProperty("fullfilledDocumentId")) : null;
    }

}

