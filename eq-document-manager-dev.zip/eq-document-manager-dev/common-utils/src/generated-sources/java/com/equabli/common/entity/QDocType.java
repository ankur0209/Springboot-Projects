package com.equabli.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QDocType is a Querydsl query type for DocType
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QDocType extends EntityPathBase<DocType> {

    private static final long serialVersionUID = -968174698L;

    public static final QDocType docType = new QDocType("docType");

    public final QBaseEntity _super = new QBaseEntity(this);

    //inherited
    public final StringPath appCode = _super.appCode;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    //inherited
    public final StringPath createdBy = _super.createdBy;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> deletedAt = _super.deletedAt;

    //inherited
    public final StringPath deletedBy = _super.deletedBy;

    public final StringPath description = createString("description");

    public final NumberPath<Long> id = createNumber("id", Long.class);

    //inherited
    public final StringPath ipAddress = _super.ipAddress;

    //inherited
    public final BooleanPath isDelete = _super.isDelete;

    //inherited
    public final StringPath macAddress = _super.macAddress;

    public final StringPath name = createString("name");

    //inherited
    public final StringPath recordSourceCode = _super.recordSourceCode;

    //inherited
    public final StringPath recordStatusCode = _super.recordStatusCode;

    public final StringPath shortCode = createString("shortCode");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedAt = _super.updatedAt;

    //inherited
    public final StringPath updatedBy = _super.updatedBy;

    public QDocType(String variable) {
        super(DocType.class, forVariable(variable));
    }

    public QDocType(Path<? extends DocType> path) {
        super(path.getType(), path.getMetadata());
    }

    public QDocType(PathMetadata metadata) {
        super(DocType.class, metadata);
    }

}

