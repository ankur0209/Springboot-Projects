package com.equabli.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QTemplate is a Querydsl query type for Template
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QTemplate extends EntityPathBase<Template> {

    private static final long serialVersionUID = -2101803530L;

    public static final QTemplate template = new QTemplate("template");

    public final QBaseEntity _super = new QBaseEntity(this);

    //inherited
    public final StringPath appCode = _super.appCode;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    //inherited
    public final StringPath createdBy = _super.createdBy;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> deletedAt = _super.deletedAt;

    //inherited
    public final StringPath deletedBy = _super.deletedBy;

    public final StringPath description = createString("description");

    public final StringPath fileKey = createString("fileKey");

    public final StringPath fileName = createString("fileName");

    public final StringPath fileType = createString("fileType");

    public final NumberPath<Long> id = createNumber("id", Long.class);

    //inherited
    public final StringPath ipAddress = _super.ipAddress;

    //inherited
    public final BooleanPath isDelete = _super.isDelete;

    public final BooleanPath isSignRequired = createBoolean("isSignRequired");

    //inherited
    public final StringPath macAddress = _super.macAddress;

    public final StringPath name = createString("name");

    //inherited
    public final StringPath recordSourceCode = _super.recordSourceCode;

    //inherited
    public final StringPath recordStatusCode = _super.recordStatusCode;

    public final StringPath shortCode = createString("shortCode");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedAt = _super.updatedAt;

    //inherited
    public final StringPath updatedBy = _super.updatedBy;

    public QTemplate(String variable) {
        super(Template.class, forVariable(variable));
    }

    public QTemplate(Path<? extends Template> path) {
        super(path.getType(), path.getMetadata());
    }

    public QTemplate(PathMetadata metadata) {
        super(Template.class, metadata);
    }

}

