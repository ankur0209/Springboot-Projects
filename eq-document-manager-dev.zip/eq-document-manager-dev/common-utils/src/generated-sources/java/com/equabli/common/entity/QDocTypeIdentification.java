package com.equabli.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QDocTypeIdentification is a Querydsl query type for DocTypeIdentification
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QDocTypeIdentification extends EntityPathBase<DocTypeIdentification> {

    private static final long serialVersionUID = 1488053156L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QDocTypeIdentification docTypeIdentification = new QDocTypeIdentification("docTypeIdentification");

    public final QBaseEntity _super = new QBaseEntity(this);

    //inherited
    public final StringPath appCode = _super.appCode;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    //inherited
    public final StringPath createdBy = _super.createdBy;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> deletedAt = _super.deletedAt;

    //inherited
    public final StringPath deletedBy = _super.deletedBy;

    public final QDocType docType;

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final StringPath identificationJson = createString("identificationJson");

    //inherited
    public final StringPath ipAddress = _super.ipAddress;

    //inherited
    public final BooleanPath isDelete = _super.isDelete;

    //inherited
    public final StringPath macAddress = _super.macAddress;

    //inherited
    public final StringPath recordSourceCode = _super.recordSourceCode;

    //inherited
    public final StringPath recordStatusCode = _super.recordStatusCode;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedAt = _super.updatedAt;

    //inherited
    public final StringPath updatedBy = _super.updatedBy;

    public QDocTypeIdentification(String variable) {
        this(DocTypeIdentification.class, forVariable(variable), INITS);
    }

    public QDocTypeIdentification(Path<? extends DocTypeIdentification> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QDocTypeIdentification(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QDocTypeIdentification(PathMetadata metadata, PathInits inits) {
        this(DocTypeIdentification.class, metadata, inits);
    }

    public QDocTypeIdentification(Class<? extends DocTypeIdentification> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.docType = inits.isInitialized("docType") ? new QDocType(forProperty("docType")) : null;
    }

}

