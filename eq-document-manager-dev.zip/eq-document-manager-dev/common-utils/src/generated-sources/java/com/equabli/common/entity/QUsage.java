package com.equabli.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QUsage is a Querydsl query type for Usage
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QUsage extends EntityPathBase<Usage> {

    private static final long serialVersionUID = 1958942117L;

    public static final QUsage usage = new QUsage("usage");

    public final QBaseEntity _super = new QBaseEntity(this);

    //inherited
    public final StringPath appCode = _super.appCode;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    //inherited
    public final StringPath createdBy = _super.createdBy;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> deletedAt = _super.deletedAt;

    //inherited
    public final StringPath deletedBy = _super.deletedBy;

    public final NumberPath<Long> id = createNumber("id", Long.class);

    //inherited
    public final StringPath ipAddress = _super.ipAddress;

    //inherited
    public final BooleanPath isDelete = _super.isDelete;

    public final ComparablePath<java.util.UUID> lookupUid = createComparable("lookupUid", java.util.UUID.class);

    //inherited
    public final StringPath macAddress = _super.macAddress;

    public final StringPath orgCode = createString("orgCode");

    public final StringPath orgTypeCode = createString("orgTypeCode");

    //inherited
    public final StringPath recordSourceCode = _super.recordSourceCode;

    //inherited
    public final StringPath recordStatusCode = _super.recordStatusCode;

    public final NumberPath<Long> totalDocument = createNumber("totalDocument", Long.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedAt = _super.updatedAt;

    //inherited
    public final StringPath updatedBy = _super.updatedBy;

    public final NumberPath<Long> used = createNumber("used", Long.class);

    public final NumberPath<Long> userId = createNumber("userId", Long.class);

    public QUsage(String variable) {
        super(Usage.class, forVariable(variable));
    }

    public QUsage(Path<? extends Usage> path) {
        super(path.getType(), path.getMetadata());
    }

    public QUsage(PathMetadata metadata) {
        super(Usage.class, metadata);
    }

}

