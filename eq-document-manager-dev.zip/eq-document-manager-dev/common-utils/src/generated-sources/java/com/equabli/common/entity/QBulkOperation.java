package com.equabli.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QBulkOperation is a Querydsl query type for BulkOperation
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QBulkOperation extends EntityPathBase<BulkOperation> {

    private static final long serialVersionUID = 489294969L;

    public static final QBulkOperation bulkOperation = new QBulkOperation("bulkOperation");

    public final QBaseEntity _super = new QBaseEntity(this);

    public final StringPath actionByOrgCode = createString("actionByOrgCode");

    public final StringPath actionByOrgTypeCode = createString("actionByOrgTypeCode");

    public final NumberPath<Long> actionByUserId = createNumber("actionByUserId", Long.class);

    //inherited
    public final StringPath appCode = _super.appCode;

    public final StringPath bulkOperationType = createString("bulkOperationType");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    //inherited
    public final StringPath createdBy = _super.createdBy;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> deletedAt = _super.deletedAt;

    //inherited
    public final StringPath deletedBy = _super.deletedBy;

    public final StringPath documentName = createString("documentName");

    public final StringPath fileName = createString("fileName");

    public final StringPath filePath = createString("filePath");

    public final NumberPath<Long> fileSize = createNumber("fileSize", Long.class);

    public final NumberPath<Long> id = createNumber("id", Long.class);

    //inherited
    public final StringPath ipAddress = _super.ipAddress;

    //inherited
    public final BooleanPath isDelete = _super.isDelete;

    public final BooleanPath isOther = createBoolean("isOther");

    //inherited
    public final StringPath macAddress = _super.macAddress;

    public final StringPath objKey = createString("objKey");

    public final StringPath orgCode = createString("orgCode");

    public final StringPath orgTypeCode = createString("orgTypeCode");

    public final StringPath otherReason = createString("otherReason");

    //inherited
    public final StringPath recordSourceCode = _super.recordSourceCode;

    //inherited
    public final StringPath recordStatusCode = _super.recordStatusCode;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedAt = _super.updatedAt;

    //inherited
    public final StringPath updatedBy = _super.updatedBy;

    public final NumberPath<Long> userId = createNumber("userId", Long.class);

    public QBulkOperation(String variable) {
        super(BulkOperation.class, forVariable(variable));
    }

    public QBulkOperation(Path<? extends BulkOperation> path) {
        super(path.getType(), path.getMetadata());
    }

    public QBulkOperation(PathMetadata metadata) {
        super(BulkOperation.class, metadata);
    }

}

