package com.equabli.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QActivityLog is a Querydsl query type for ActivityLog
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QActivityLog extends EntityPathBase<ActivityLog> {

    private static final long serialVersionUID = -1187598663L;

    public static final QActivityLog activityLog = new QActivityLog("activityLog");

    public final EnumPath<ActivityLog.ActivityTypeEnum> activityType = createEnum("activityType", ActivityLog.ActivityTypeEnum.class);

    public final DateTimePath<java.time.LocalDateTime> createdAt = createDateTime("createdAt", java.time.LocalDateTime.class);

    public final StringPath createdBy = createString("createdBy");

    public final StringPath exisitingData = createString("exisitingData");

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final StringPath newData = createString("newData");

    public final StringPath orgCode = createString("orgCode");

    public final StringPath orgTypeCode = createString("orgTypeCode");

    public final NumberPath<Long> userId = createNumber("userId", Long.class);

    public QActivityLog(String variable) {
        super(ActivityLog.class, forVariable(variable));
    }

    public QActivityLog(Path<? extends ActivityLog> path) {
        super(path.getType(), path.getMetadata());
    }

    public QActivityLog(PathMetadata metadata) {
        super(ActivityLog.class, metadata);
    }

}

