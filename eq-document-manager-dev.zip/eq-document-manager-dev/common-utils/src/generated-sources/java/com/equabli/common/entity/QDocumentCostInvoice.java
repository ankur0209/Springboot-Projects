package com.equabli.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QDocumentCostInvoice is a Querydsl query type for DocumentCostInvoice
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QDocumentCostInvoice extends EntityPathBase<DocumentCostInvoice> {

    private static final long serialVersionUID = -687135863L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QDocumentCostInvoice documentCostInvoice = new QDocumentCostInvoice("documentCostInvoice");

    public final QBaseEntity _super = new QBaseEntity(this);

    public final StringPath actionByOrgCode = createString("actionByOrgCode");

    public final StringPath actionByOrgTypeCode = createString("actionByOrgTypeCode");

    public final NumberPath<Long> actionByUserId = createNumber("actionByUserId", Long.class);

    //inherited
    public final StringPath appCode = _super.appCode;

    public final StringPath clientOrgCode = createString("clientOrgCode");

    public final StringPath clientOrgTypeCode = createString("clientOrgTypeCode");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    //inherited
    public final StringPath createdBy = _super.createdBy;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> deletedAt = _super.deletedAt;

    //inherited
    public final StringPath deletedBy = _super.deletedBy;

    public final NumberPath<Float> docCost = createNumber("docCost", Float.class);

    public final NumberPath<Long> docSize = createNumber("docSize", Long.class);

    public final StringPath docTypeCode = createString("docTypeCode");

    public final ComparablePath<java.util.UUID> invoiceUid = createComparable("invoiceUid", java.util.UUID.class);

    //inherited
    public final StringPath ipAddress = _super.ipAddress;

    //inherited
    public final BooleanPath isDelete = _super.isDelete;

    //inherited
    public final StringPath macAddress = _super.macAddress;

    public final StringPath partnerOrgCode = createString("partnerOrgCode");

    public final StringPath partnerOrgTypeCode = createString("partnerOrgTypeCode");

    //inherited
    public final StringPath recordSourceCode = _super.recordSourceCode;

    //inherited
    public final StringPath recordStatusCode = _super.recordStatusCode;

    public final QSendReceiveDocument sendReceiveDocument;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedAt = _super.updatedAt;

    //inherited
    public final StringPath updatedBy = _super.updatedBy;

    public QDocumentCostInvoice(String variable) {
        this(DocumentCostInvoice.class, forVariable(variable), INITS);
    }

    public QDocumentCostInvoice(Path<? extends DocumentCostInvoice> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QDocumentCostInvoice(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QDocumentCostInvoice(PathMetadata metadata, PathInits inits) {
        this(DocumentCostInvoice.class, metadata, inits);
    }

    public QDocumentCostInvoice(Class<? extends DocumentCostInvoice> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.sendReceiveDocument = inits.isInitialized("sendReceiveDocument") ? new QSendReceiveDocument(forProperty("sendReceiveDocument"), inits.get("sendReceiveDocument")) : null;
    }

}

