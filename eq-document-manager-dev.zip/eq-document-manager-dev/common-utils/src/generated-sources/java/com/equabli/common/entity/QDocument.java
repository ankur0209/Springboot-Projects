package com.equabli.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QDocument is a Querydsl query type for Document
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QDocument extends EntityPathBase<Document> {

    private static final long serialVersionUID = 81463959L;

    public static final QDocument document = new QDocument("document");

    public final QBaseEntity _super = new QBaseEntity(this);

    public final StringPath actionByOrgCode = createString("actionByOrgCode");

    public final StringPath actionByOrgTypeCode = createString("actionByOrgTypeCode");

    public final NumberPath<Long> actionByUserId = createNumber("actionByUserId", Long.class);

    //inherited
    public final StringPath appCode = _super.appCode;

    public final StringPath clientAccountNo = createString("clientAccountNo");

    public final StringPath clientOrgCode = createString("clientOrgCode");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    //inherited
    public final StringPath createdBy = _super.createdBy;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> deletedAt = _super.deletedAt;

    //inherited
    public final StringPath deletedBy = _super.deletedBy;

    public final StringPath docTypeCode = createString("docTypeCode");

    public final DateTimePath<java.time.LocalDateTime> documentGenerationDate = createDateTime("documentGenerationDate", java.time.LocalDateTime.class);

    public final StringPath documentName = createString("documentName");

    public final NumberPath<Long> equabliAccountNo = createNumber("equabliAccountNo", Long.class);

    public final NumberPath<Long> fileSize = createNumber("fileSize", Long.class);

    public final StringPath generatedFileName = createString("generatedFileName");

    public final StringPath generatedFilePath = createString("generatedFilePath");

    public final NumberPath<Long> id = createNumber("id", Long.class);

    //inherited
    public final StringPath ipAddress = _super.ipAddress;

    //inherited
    public final BooleanPath isDelete = _super.isDelete;

    public final BooleanPath isOthers = createBoolean("isOthers");

    //inherited
    public final StringPath macAddress = _super.macAddress;

    public final StringPath objKey = createString("objKey");

    public final StringPath orgCode = createString("orgCode");

    public final StringPath orgTypeCode = createString("orgTypeCode");

    public final StringPath originalAccountNo = createString("originalAccountNo");

    public final StringPath otherReason = createString("otherReason");

    public final NumberPath<Long> portfolioId = createNumber("portfolioId", Long.class);

    public final StringPath productCode = createString("productCode");

    public final StringPath receiveFileName = createString("receiveFileName");

    //inherited
    public final StringPath recordSourceCode = _super.recordSourceCode;

    //inherited
    public final StringPath recordStatusCode = _super.recordStatusCode;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedAt = _super.updatedAt;

    //inherited
    public final StringPath updatedBy = _super.updatedBy;

    public final NumberPath<Long> userId = createNumber("userId", Long.class);

    public QDocument(String variable) {
        super(Document.class, forVariable(variable));
    }

    public QDocument(Path<? extends Document> path) {
        super(path.getType(), path.getMetadata());
    }

    public QDocument(PathMetadata metadata) {
        super(Document.class, metadata);
    }

}

