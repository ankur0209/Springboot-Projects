package com.equabli.common.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QLookup is a Querydsl query type for Lookup
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QLookup extends EntityPathBase<Lookup> {

    private static final long serialVersionUID = 336728566L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QLookup lookup = new QLookup("lookup");

    public final QBaseEntity _super = new QBaseEntity(this);

    //inherited
    public final StringPath appCode = _super.appCode;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdAt = _super.createdAt;

    //inherited
    public final StringPath createdBy = _super.createdBy;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> deletedAt = _super.deletedAt;

    //inherited
    public final StringPath deletedBy = _super.deletedBy;

    public final StringPath description = createString("description");

    public final NumberPath<Short> groupSequence = createNumber("groupSequence", Short.class);

    //inherited
    public final StringPath ipAddress = _super.ipAddress;

    //inherited
    public final BooleanPath isDelete = _super.isDelete;

    public final StringPath keycode = createString("keycode");

    public final StringPath keyvalue = createString("keyvalue");

    public final QLookupGroup lookupGroup;

    //inherited
    public final StringPath macAddress = _super.macAddress;

    //inherited
    public final StringPath recordSourceCode = _super.recordSourceCode;

    //inherited
    public final StringPath recordStatusCode = _super.recordStatusCode;

    public final NumberPath<Short> scrubtype = createNumber("scrubtype", Short.class);

    public final ComparablePath<java.util.UUID> uid = createComparable("uid", java.util.UUID.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedAt = _super.updatedAt;

    //inherited
    public final StringPath updatedBy = _super.updatedBy;

    public QLookup(String variable) {
        this(Lookup.class, forVariable(variable), INITS);
    }

    public QLookup(Path<? extends Lookup> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QLookup(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QLookup(PathMetadata metadata, PathInits inits) {
        this(Lookup.class, metadata, inits);
    }

    public QLookup(Class<? extends Lookup> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.lookupGroup = inits.isInitialized("lookupGroup") ? new QLookupGroup(forProperty("lookupGroup")) : null;
    }

}

