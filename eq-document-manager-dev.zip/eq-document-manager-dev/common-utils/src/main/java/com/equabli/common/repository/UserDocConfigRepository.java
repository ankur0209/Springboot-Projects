package com.equabli.common.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.equabli.common.entity.DocMgrConfig;
import com.equabli.common.entity.UserDocConfig;

@Repository
public interface UserDocConfigRepository extends JpaRepository<UserDocConfig, Long> {

	public List<UserDocConfig> findByOrgCodeAndDocMgrConfig_ShortCodeStartsWithAndIsDeleteFalseOrderByDocMgrConfig_ShortCode(
			String orgCode, String shortCode);

	public Optional<UserDocConfig> findByOrgCodeAndDocMgrConfig(String orgCode,
			DocMgrConfig docMgrConfig);

	public List<UserDocConfig> findByOrgCodeAndDocMgrConfigSelectedCodeStartsWithAndDocMgrConfigSelectedCodeNotIn(
			String orgCode, String shortCode, List<String> docMgrConfigSelectedCodes);
}
