package com.equabli.common.response;

import lombok.Data;

@Data
public class UserTokenResponse {

	private Long userId;
	private String token;

}
