package com.equabli.common.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.equabli.common.constants.Constants;

import lombok.Getter;

@Table(name = "doc_mgr_config_val", schema = Constants.CONF_SCHEMAS)
@Entity
@Getter
public class DocMgrConfigVal extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "doc_mgr_config_val_id")
	private Long id;

	@ManyToOne
	@JoinColumn(name = "doc_mgr_config_id")
	private DocMgrConfig docMgrConfig;
	private String shortCode;
	private String description;
	private String fieldValue;

	public void saveDocMgrConfigVal(DocMgrConfigVal docMgrConfigVal, DocMgrConfig docMgrConfig, String shortCode,
			String fieldValue) {
		docMgrConfigVal.docMgrConfig = docMgrConfig;
		docMgrConfigVal.shortCode = shortCode;
		docMgrConfigVal.fieldValue = fieldValue;
	}
}
