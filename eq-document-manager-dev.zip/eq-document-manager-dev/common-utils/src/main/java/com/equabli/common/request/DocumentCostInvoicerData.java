package com.equabli.common.request;

import java.time.LocalDateTime;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class DocumentCostInvoicerData {

	@Schema(description = "Document which is fullfilled.")
	private String documentName;

	@Schema(description = "Which type of document it is.", example = "Application")
	private String documentType;

	@Schema(description = "Document which is fullfilled.")
	private LocalDateTime fullfillmentDate;

	@Schema(description = "Which type of document it is.", example = "Application")
	private Long size;

	@Schema(description = "Which type of document it is.", example = "Application")
	private String fullfillBy;

	@Schema(description = "Which type of document it is.", example = "Application")
	private Float cost;

	private String partnerName;
	private Long partnerId;
	private String fullfillDate;
	private String fileSize;
	private String partnerCost;
	

	public DocumentCostInvoicerData(String documentName, String documentType, LocalDateTime fullfillmentDate, Long size,
			String fullfillBy, Float cost, String partnerName, Long id) {
		this.documentName = documentName;
		this.documentType = documentType;
		this.fullfillmentDate = fullfillmentDate;
		this.size = size;
		this.fullfillBy = fullfillBy;
		this.cost = cost;
		this.partnerName = partnerName;
		this.partnerId = id;
	}
}
