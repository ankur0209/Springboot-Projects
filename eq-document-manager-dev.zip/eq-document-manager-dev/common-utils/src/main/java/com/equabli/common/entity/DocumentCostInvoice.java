package com.equabli.common.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;

import lombok.Getter;

@Table(name = "document_cost_invoice", schema = Constants.DOCUMENT_SCHEMAS)
@Entity
@Getter
public class DocumentCostInvoice extends BaseEntity{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "document_cost_invoice_uid")
	private UUID invoiceUid;
	
	@Column(length = 2)
	private String clientOrgTypeCode;
	@Column(length = 10)
	private String clientOrgCode;
	
	@Column(length = 2)
	private String partnerOrgTypeCode;
	@Column(length = 10)
	private String partnerOrgCode;
	
	private Long actionByUserId;
	@Column(length = 2)
	private String actionByOrgTypeCode;
	@Column(length = 10)
	private String actionByOrgCode;
	
	@OneToOne
	@JoinColumn(name = "send_receive_document_id")
	private SendReceiveDocument sendReceiveDocument;
	
	@Column(length = 10)
	private String docTypeCode;
	private Float docCost;
	private Long docSize;

	public void saveDocumentCostInvoice(DocumentCostInvoice documentCostInvoice,Long size,
			SendReceiveDocument sendReceiveDocument, Float cost, TokenData tokenData, TokenData actionByToken) {
		documentCostInvoice.clientOrgCode = sendReceiveDocument.getSentRequestOrgCode();
		documentCostInvoice.clientOrgTypeCode = sendReceiveDocument.getSentRequestOrgTypeCode();
		
		documentCostInvoice.partnerOrgCode = tokenData.getUserOrgCode();
		documentCostInvoice.partnerOrgTypeCode = tokenData.getOrgType();
		
		documentCostInvoice.actionByUserId = actionByToken.getPrincipleId();
		documentCostInvoice.actionByOrgTypeCode = actionByToken.getOrgType();
		documentCostInvoice.actionByOrgCode = actionByToken.getUserOrgCode();
		if (documentCostInvoice.getInvoiceUid() == null)
			documentCostInvoice.create(actionByToken.getFirstName());
		else
			documentCostInvoice.update(actionByToken.getFirstName());
		
		documentCostInvoice.sendReceiveDocument = sendReceiveDocument;
		documentCostInvoice.docTypeCode = sendReceiveDocument.getDocTypeCode();
		documentCostInvoice.docCost = cost;
		documentCostInvoice.docSize = size;
		documentCostInvoice.delete(false);
	}
	
	public void updateDocumentCostInvoice(DocumentCostInvoice documentCostInvoice, Float cost,
			TokenData actionByToken) {
		
		documentCostInvoice.docCost = cost;
		documentCostInvoice.actionByUserId = actionByToken.getPrincipleId();
		documentCostInvoice.actionByOrgTypeCode = actionByToken.getOrgType();
		documentCostInvoice.actionByOrgCode = actionByToken.getUserOrgCode();
		if (documentCostInvoice.getInvoiceUid() == null)
			documentCostInvoice.create(actionByToken.getFirstName());
		else
			documentCostInvoice.update(actionByToken.getFirstName());
	}
	
	public void deleteDocumentCostInvoice(DocumentCostInvoice documentCostInvoice, TokenData tokenData) {
		documentCostInvoice.delete(true,tokenData.getFirstName());
	}
}
