package com.equabli.common.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;

import lombok.Getter;

@Table(name = "user_doc_config", schema = Constants.DOCUMENT_SCHEMAS)
@Entity
@Getter
public class UserDocConfig extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_doc_config_id")
	private Long id;

	@ManyToOne
	@JoinColumn(name = "doc_mgr_config_id")
	private DocMgrConfig docMgrConfig;

	@ManyToOne
	@JoinColumn(name = "doc_mgr_config_val_id")
	private DocMgrConfigVal docMgrConfigVal;

	private Long userId;
	@Column(length = 2)
	private String orgTypeCode;
	@Column(length = 10)
	private String orgCode;

	private String docMgrConfigSelectedCode;
	private String docMgrConfigValSelectedCode;

	public void saveUserDocConfig(UserDocConfig userDocConfig, DocMgrConfig docMgrConfig,
			DocMgrConfigVal docMgrConfigVal, TokenData tokenData) {
		userDocConfig.docMgrConfig = docMgrConfig;
		userDocConfig.docMgrConfigVal = docMgrConfigVal;
		userDocConfig.orgTypeCode = orgTypeCode;
		userDocConfig.docMgrConfigSelectedCode = docMgrConfig.getShortCode();
		userDocConfig.docMgrConfigValSelectedCode = docMgrConfigVal.getShortCode();
		userDocConfig.delete(false);

		userDocConfig.userId = tokenData.getPrincipleId();
		userDocConfig.orgTypeCode = tokenData.getOrgType();
		userDocConfig.orgCode = tokenData.getUserOrgCode();
		if (userDocConfig.getId() == null)
			userDocConfig.create(tokenData.getFirstName());
		else
			userDocConfig.update(tokenData.getFirstName());
	}

	public void deleteUserDocConfig(UserDocConfig userDocConfig, TokenData tokenData) {
		userDocConfig.delete(true, tokenData.getFirstName());
	}
}
