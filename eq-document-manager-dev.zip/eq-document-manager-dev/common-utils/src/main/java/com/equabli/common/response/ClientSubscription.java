package com.equabli.common.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Detail of the client who subscribed any application, without partner subscription detail")
public class ClientSubscription {
	private Integer clientId;
	private String shortName;
	private String fullName;
	private String clientType;
	private String appCodes; 
}
