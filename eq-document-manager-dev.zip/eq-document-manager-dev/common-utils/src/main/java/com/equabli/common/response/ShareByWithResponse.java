package com.equabli.common.response;

import org.apache.commons.lang3.StringUtils;

import com.equabli.common.constants.Constants;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.ShareBy;
import com.equabli.common.entity.ShareWith;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Schema(description = "Detail of share by")
@NoArgsConstructor
public class ShareByWithResponse {

	private String name;
	private String email;
	private String orgCode;
	private String orgTypeCode;
	private String profilePicture;
	
	@JsonIgnore
	private Long userId;

	public ShareByWithResponse(ShareBy shareBy) {
		this.name = shareBy.getSharedBy();
		this.orgCode = shareBy.getActionByOrgCode();
		this.orgTypeCode = getOrgName(shareBy.getActionByOrgTypeCode());
		this.userId = shareBy.getUserId();
	}

	public ShareByWithResponse(ShareWith shareWith) {
		this.name = shareWith.getShareWithName();
		this.email = shareWith.getSharedWithEmailId();
		this.orgCode = shareWith.getShareWithUserOrgCode();
		this.orgTypeCode = getOrgName(shareWith.getShareWithOrgTypeCode());
		this.userId = shareWith.getUserId();
	}

	public ShareByWithResponse(String name, String orgCode, String orgTypeCode, Long userId) {
		this.name = name;
		this.orgCode = orgCode;
		this.orgTypeCode = getOrgName(orgTypeCode);
		this.userId = userId;
	}

	public ShareByWithResponse(String name, String email, String orgCode, String orgTypeCode, Long userId) {
		this.name = name;
		this.email = email;
		this.orgCode = orgCode;
		this.orgTypeCode = getOrgName(orgTypeCode);
		this.userId =userId;
	}

	public static String getOrgName(String orgTypeCode) {
		if (StringUtils.isBlank(orgTypeCode))
			return null;

		return switch (orgTypeCode) {
		case Constants.CLIENT_CODE:
			yield (MessageConstants.UploadFileConstants.CLIENT);
		case Constants.PARTNER_CODE:
			yield (MessageConstants.UploadFileConstants.PARTNER);
		case Constants.THIRD_PARTY_CODE:
			yield (MessageConstants.UploadFileConstants.THIRDPARTY);
		default:
			yield null;
		};
	}
}
