package com.equabli.common.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "Account Number validate response from User service")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountValidateDetail {

	private String userId;
	private String accountNumber;
	private Boolean isExists;
}
