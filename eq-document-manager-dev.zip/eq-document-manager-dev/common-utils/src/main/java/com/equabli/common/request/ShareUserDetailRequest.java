package com.equabli.common.request;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Schema(description = "Share User Detail Request")
public class ShareUserDetailRequest {

	@Schema(description = "Name if user register other wise null", example = "abc")
	private String name;
	
	@Schema(description = "Email", example = "abc@gmail.com")
	@NotNull(message = "email must not be null")
	private String email;
	
	@Schema(description = "isregisteruser", example = "1")
	@NotNull(message = "isregisteruser must not be null")
	private Boolean isRegisterUser;
	
	private Long principleId;
	private String orgType;
	private String userOrgCode;
}
