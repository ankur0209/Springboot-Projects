package com.equabli.common.enums;

public enum DocumentShareTypeEnum {

	FILE,
	FOLDER
}
