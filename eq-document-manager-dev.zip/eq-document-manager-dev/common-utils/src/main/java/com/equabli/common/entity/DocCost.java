package com.equabli.common.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;

import lombok.Getter;

@Table(name = "doc_cost", schema = Constants.DOCUMENT_SCHEMAS)
@Entity
@Getter
public class DocCost extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "doc_cost_id")
	private Long id;

	private Long userId;
	@Column(length = 2)
	private String orgTypeCode;
	@Column(length = 10)
	private String orgCode;
	private String orgName;

	@OneToOne
	@JoinColumn(name = "doc_type_id")
	private DocType docType;

	private String docTypeCode;
	private Float cost;
	private String docCostUpdatedBy;
	private Short dueOnConfigureInDays;

	public void saveDocCost(DocCost docCost, Float cost, DocType docType, TokenData tokenData) {
		docCost.cost = cost;
		docCost.docType = docType;
		docCost.docTypeCode = docType.getShortCode();
		docCost.delete(false);

		docCost.userId = tokenData.getPrincipleId();
		docCost.orgTypeCode = tokenData.getOrgType();
		docCost.orgCode= tokenData.getUserOrgCode();
		docCost.orgName = tokenData.getUserOrgName();
		if (docCost.getId() == null)
			docCost.create(tokenData.getFirstName());
		else
			docCost.update(tokenData.getFirstName());
	}

	public void deleteDocCost(DocCost docCost, TokenData tokenData) {
		docCost.delete(true, tokenData.getFirstName());
	}
}
