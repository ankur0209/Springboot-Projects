package com.equabli.common.request;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DocumentCostInvoicerDataConfig {

	private String organization;
	private String organizationCode;
	private String organizationType;
	private String invoiceStartDate;
	private String invoiceEndDate;
	
	List<List<DocumentCostInvoicerData>> listOfpartnerDetail;
	
	private String totalAmount;
}
