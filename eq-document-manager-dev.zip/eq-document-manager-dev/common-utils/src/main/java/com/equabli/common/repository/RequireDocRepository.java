package com.equabli.common.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.equabli.common.entity.RequireDoc;
import com.equabli.common.response.RequireDocResponse;

public interface RequireDocRepository extends JpaRepository<RequireDoc, Long> {

	List<RequireDoc> findByOrgCodeAndProductCodeAndIsDeleteFalse(String orgCode, String productCode);

	Optional<RequireDoc> findByOrgCodeAndProductCodeAndDocTypeCode(String orgCode, String productCode,
			String documentCode);

	List<RequireDoc> findByOrgCodeAndProductCodeAndDocTypeCodeNotIn(String orgCode,
			String productCode, List<String> docTypeCode);
	
	@Query(value = "SELECT new com.equabli.common.response.RequireDocResponse( "
			+ " rd.productCode as productCode, rd.docTypeCode as docTypeCode, dt.name as documentType )"
			+ " from RequireDoc as rd "
			+ " JOIN DocType as dt ON dt.shortCode = rd.docTypeCode "
			+ " WHERE rd.orgCode = ?1 AND rd.isDelete = false AND ( ?2 IS NULL OR rd.productCode = ?2 )")
	List<RequireDocResponse> getByOrgTypeCodeAndIsDeleteFalse(String orgCode, String productCode);
	
	@Query(value = "SELECT new com.equabli.common.response.RequireDocResponse( "
			+ " rd.productCode as productCode, rd.docTypeCode as docTypeCode, dt.name as documentType )"
			+ " from RequireDoc as rd "
			+ " JOIN DocType as dt ON dt.shortCode = rd.docTypeCode "
			+ " WHERE rd.orgCode = ?1 AND rd.isDelete = false AND rd.docTypeCode = ?2 "
			+ " AND (?3 IS NULL OR rd.productCode = ?3) ")
	List<RequireDocResponse> getByOrgTypeCodeAndDocTypeCodeAndIsDeleteFalse(String orgCode, String docTypeCode, String productCode);
	
	List<RequireDoc> findByOrgCodeAndAndIsDeleteFalse(String orgCode);
	
	@Query(value = "SELECT rd FROM RequireDoc as rd WHERE rd.orgCode = ?1 AND rd.isDelete = false AND rd.docTypeCode = ?2 "
			+ " AND (?3 IS NULL OR rd.productCode = ?3)")
	List<RequireDoc> findByOrgCodeAndDocTypeCodeAndIsDeleteFalse(String orgCode, String docTypeCode,
			String productCode);
	
	
//	@Query(value = "SELECT new com.equabli.common.response.RequireDocResponse( "
//			+ " rd.productCode as productCode, rd.docTypeCode as docTypeCode, dt.name as documentType )"
//			+ " from RequireDoc as rd "
//			+ " JOIN DocType as dt ON dt.shortCode = rd.docTypeCode "
//			+ " WHERE rd.orgTypeCode = :orgTypeCode AND rd.isDelete = false AND rd.docTypeCode = :docTypeCode "
//			+ " AND (:productCode IS NULL OR rd.productCode = :productCode) ")
//	List<RequireDocResponse> getByOrgTypeCodeAndDocTypeCodeNotAndIsDeleteFalse(@Param("orgTypeCode") String orgTypeCode, @Param("docTypeCode")  String docTypeCode, 
//			@Param("productCode")  String productCode);
}
