package com.equabli.common.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.equabli.common.entity.Lookup;

@Repository
public interface LookupRepository extends JpaRepository<Lookup, UUID> {

	List<Lookup> findByLookupGroup_keyvalue(String lookupGroupKeyValue);
	
	Optional<Lookup> findByLookupGroup_keyvalueAndKeycode(String lookupGroupKeyValue, String keycode);
	
	Optional<Lookup> findByUid(UUID uid);
}
