package com.equabli.common.exception;


import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.utils.MessageSupplier;

@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice
public class ExceptionHandling extends ResponseEntityExceptionHandler {
	
	private static final String FAILURES = "Failures";
	
	@Autowired
	private MessageSupplier messageSupplier;
	
	
	@ExceptionHandler(ResourceNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ResponseEntity<Object> handleResourceNotFoundException(ResourceNotFoundException resourceNotFoundException){
		return ResponseEntity.ok(PagedResponse.empty()); 
	}
	
	@ExceptionHandler(InvalidArgumentException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ResponseEntity<Object> handleInvalidArgumentException(InvalidArgumentException invalidArgumentException){
		List<String> errorDatas = new ArrayList<>();
		errorDatas.add(invalidArgumentException.getMessage());
		return ResponseEntity.ok(CommonResponse.failureWithErrors(FAILURES, errorDatas)); 
	}
	
	@ExceptionHandler(IOException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ResponseEntity<Object> handleIOException(IOException ioException){
		List<String> errorDatas = new ArrayList<>();
		errorDatas.add(ioException.getMessage());
		return ResponseEntity.ok(CommonResponse.failureWithErrors(FAILURES, errorDatas)); 
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		List<String> errorDatas = new ArrayList<>();
		ex.getBindingResult().getAllErrors().forEach(error -> {
			String errorMessage = error.getDefaultMessage();
			errorDatas.add(errorMessage);
		});
		errorDatas.add(messageSupplier.get("request.body.invalid.params", null, null));

		return handleExceptionInternal(ex, CommonResponse.failureWithErrors(FAILURES, errorDatas), headers, status,
				request);
	}
	
	@ExceptionHandler(ExcelReaderException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ResponseEntity<Object> handleExcelReaderException(ExcelReaderException excelReaderException){
		List<String> errorDatas = new ArrayList<>();
		errorDatas.add(excelReaderException.getMessage());
		return ResponseEntity.ok(CommonResponse.failureWithErrors(FAILURES, errorDatas)); 
	}
	
	@ExceptionHandler({ SQLException.class })
	@ResponseStatus(HttpStatus.BAD_GATEWAY)
	public <T> ResponseEntity<CommonResponse<T>> handleSQLException(SQLException exception) {
		List<String> errorDatas = new ArrayList<>();
		errorDatas.add(exception.getMessage());
		return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
				.body(CommonResponse.failureWithErrors(FAILURES, errorDatas));
	}
	
}