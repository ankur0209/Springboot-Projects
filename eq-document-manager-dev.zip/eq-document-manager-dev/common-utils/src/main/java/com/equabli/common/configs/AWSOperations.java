package com.equabli.common.configs;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.amazonaws.AmazonClientException;
import com.amazonaws.HttpMethod;
import com.amazonaws.event.ProgressEvent;
import com.amazonaws.event.ProgressListener;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.CopyObjectRequest;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import com.amazonaws.services.s3.transfer.Upload;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component(value = "awss3Upload")
@Profile("!test")
public class AWSOperations {

	@Autowired
	private AmazonS3 amazonS3;

	public String uploadZipFileS3(String keyName, File file, String bucketName) {

		TransferManager transferManager = TransferManagerBuilder.standard().withS3Client(amazonS3).build();

		ProgressListener progressListener = ProgressEvent::getBytesTransferred;

		PutObjectRequest request = new PutObjectRequest(bucketName, keyName, file);

		request.setGeneralProgressListener(progressListener);

		Upload upload = transferManager.upload(request);

		try {
			upload.waitForCompletion();

			URL uploadedUrl = amazonS3.getUrl(bucketName, keyName);
			log.info("URL :: " + uploadedUrl);
			return uploadedUrl.toString();
		} catch (InterruptedException ie) {
			log.error("Interrupted! {}", ie);
			Thread.currentThread().interrupt();
		} catch (AmazonClientException e) {
			log.error("ERROR WHILE UPLOADING FILE ", e);
		}
		return null;
	}
	
	public File downloadZipFileS3(String keyName, String bucketName, File tempFile) {
		try {
			
			S3Object s3Object = amazonS3.getObject(new GetObjectRequest(bucketName, keyName));
			if (s3Object != null) {
				byte[] byteArray = IOUtils.toByteArray(s3Object.getObjectContent());
				try (FileOutputStream outputStream = new FileOutputStream(tempFile)) {
				    outputStream.write(byteArray);
				}
			}
		} catch (Exception e) {
			log.error("ERROR WHILE DOWNLOAD FILE {}",e.getMessage(), e);
		}
		return tempFile;
	}
	
	public String genaratePreSignUrl(String bucketName, String objeckKey, int presignUrlExpireTime) {
		// Set the expiry time
		Date expiration = new Date();
		long expTimeMillis = expiration.getTime();
		expTimeMillis += 1000 * 60 * presignUrlExpireTime;
		expiration.setTime(expTimeMillis);

		GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(bucketName, objeckKey)
				.withMethod(HttpMethod.GET).withExpiration(expiration);
		return amazonS3.generatePresignedUrl(generatePresignedUrlRequest).toString();
	}
	
	public boolean checkFileExitst(String awsBucketName, String key) {
		try {
			ObjectListing objects = amazonS3
					.listObjects(new ListObjectsRequest().withBucketName(awsBucketName).withPrefix(key));
			for (S3ObjectSummary objectSummary : objects.getObjectSummaries()) {
				if(objectSummary.getKey().equals(key))
					return true;
			}
		} catch (Exception e) {
			log.error("ERROR WHILE DOWNLOAD FILE ", e);
		}
		return false;
	}
	
	public void deleteObject(String awsBucketName, String folderPath) {
		try {
			for (S3ObjectSummary file : amazonS3.listObjects(awsBucketName, folderPath).getObjectSummaries()) {
				amazonS3.deleteObject(awsBucketName, file.getKey());
			}
		} catch (Exception e) {
			log.error("ERROR WHILE DELETE FILE ", e);
		}
	}
	
	public String copyAccountFolder(String bucketName, String fromAccountPath, String toAccountPath) {
		try {
			ObjectListing objects = amazonS3.listObjects(bucketName, fromAccountPath);
			List<S3ObjectSummary> objectSummaries = objects.getObjectSummaries();
			for (S3ObjectSummary objectSummary : objectSummaries) {
					String getObjectKey = objectSummary.getKey();
					String newObjectKey = toAccountPath + getObjectKey.replace(fromAccountPath, "");
					CopyObjectRequest copyRequest = new CopyObjectRequest(bucketName,getObjectKey,bucketName,newObjectKey);
					amazonS3.copyObject(copyRequest);
			}
		} catch (Exception e) {
			log.error("ERROR WHILE COPY FILE ", e.getMessage(), e);
		}
		return null;
	}
	
	public String getUserProfilePictureKey(String awsBucketName, String keyPrefix) {
		try {
			ObjectListing objects = amazonS3.listObjects(awsBucketName, keyPrefix);
			List<S3ObjectSummary> objectSummaries = objects.getObjectSummaries();
			for (S3ObjectSummary objectSummary : objectSummaries) {
				if (StringUtils.hasText(objectSummary.getKey()))
					return objectSummary.getKey();
			}
			return null;
		} catch (Exception e) {
			log.error("ERROR WHILE getUserProfilePictureKey {}", e.getMessage(), e);
			return null;
		}
	}
	
	public boolean checkAccountExitst(String awsBucketName, String key) {
		try {
			ObjectListing objects = amazonS3
					.listObjects(new ListObjectsRequest().withBucketName(awsBucketName).withPrefix(key));
			for (S3ObjectSummary objectSummary : objects.getObjectSummaries()) {
				if(objectSummary.getKey().contains(key))
					return true;
			}
		} catch (Exception e) {
			log.error("ERROR WHILE DOWNLOAD FILE ", e);
		}
		return false;
	}
	
	public List<String> getObjectKeyIfExists(String awsBucketName, String key) {
		List<String> objectKeys = new ArrayList<>();
		try {
			ObjectListing objects = amazonS3
					.listObjects(new ListObjectsRequest().withBucketName(awsBucketName).withPrefix(key));
			for (S3ObjectSummary objectSummary : objects.getObjectSummaries()) {
				if(objectSummary.getKey().contains(key))
					objectKeys.add(objectSummary.getKey());
			}
		} catch (Exception e) {
			log.error("ERROR WHILE DOWNLOAD FILE ", e);
		}
		return objectKeys;
	}
	
	public String createFolder(String bucketName, String objectKey) {
	   try {
		    ObjectMetadata metadata = new ObjectMetadata();
		    metadata.setContentLength(0);
		    InputStream emptyContent = new ByteArrayInputStream(new byte[0]);
		    PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName,
		    		objectKey, emptyContent, metadata);
		    amazonS3.putObject(putObjectRequest);
	   }catch (Exception e) {
		   log.error("ERROR WHILE DOWNLOAD FILE ", e);
	   }
	   return null;
	}
	
	public void deleteDocumentOfAccountNo(String awsBucketName, List<String> folderPath) {
		for(String objectKey : folderPath) {
			this.deleteObject(awsBucketName, objectKey);
		}
	}
}
