package com.equabli.common.configs;

import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

import feign.RequestInterceptor;
import io.opentracing.Tracer;

@Configuration
@EnableFeignClients(basePackages = "com.equabli.*")
@Order(1)
public class FeignClientConfig {

	@Bean
	public RequestInterceptor jaegerFeignInterceptor(Tracer tracer) {
		return new JaegerFeignInterceptor(tracer);
	}
}