package com.equabli.common.utils;

import java.net.URL;
import java.time.Instant;
import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.HttpMethod;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AwsS3SignedUrlUtility {
	

	//@Autowired
	public AmazonS3 s3Client;


	public String generatePreSignedUrl(String bucketName ,String objectKey,Long expireIn){
		try {
			java.util.Date expiration = new java.util.Date();
			long expTimeMillis = Instant.now().toEpochMilli();
			expTimeMillis += 1000 * 60 * 60;
			expiration.setTime(expTimeMillis);

			// Generate the presigned URL.
			log.info("Generating pre-signed URL.");
			GeneratePresignedUrlRequest generatePresignedUrlRequest =
					new GeneratePresignedUrlRequest(bucketName, objectKey)
					.withMethod(HttpMethod.GET)
					.withExpiration(expiration);
			URL url = s3Client.generatePresignedUrl(generatePresignedUrlRequest);
			log.info("Pre-Signed URL: {}" + url.toString());
			return url.toString();
		} catch (AmazonServiceException e) {
			// The call was transmitted successfully, but Amazon S3 couldn't process
			// it, so it returned an error response.
			e.printStackTrace();
		} catch (SdkClientException e) {
			// Amazon S3 couldn't be contacted for a response, or the client
			// couldn't parse the response from Amazon S3.
			e.printStackTrace();
		}
		return null;
	}



	public String generatePutPreSignedUrl(String bucketName,String identifier, String objectKey,
			String contentType,String refernceId,Long urlExpireIn,Map<String,String> metaDatas) {
		try {

			// Generate the presigned URL.
			log.info("Generating pre-signed URL for upload.");
			GeneratePresignedUrlRequest generatePresignedUrlRequest =
					new GeneratePresignedUrlRequest(bucketName, objectKey)
					.withMethod(HttpMethod.PUT).withContentType(contentType)
					.withExpiration(setExpirationDate(urlExpireIn));
			//Set Meta Data
			if(metaDatas != null && !metaDatas.isEmpty()) {
				log.info("Uploading MetaData {} ",metaDatas);
				for(String metaKey: metaDatas.keySet()) {
					generatePresignedUrlRequest .addRequestParameter(com.amazonaws.services.s3.Headers.S3_USER_METADATA_PREFIX +metaKey, metaDatas.get(metaKey));   
				}
			}

			URL url = s3Client.generatePresignedUrl(generatePresignedUrlRequest);
			log.info("Pre-Signed URL: {}" + url.toString());
			return url.toString();
		} catch (AmazonServiceException e) {
			// The call was transmitted successfully, but Amazon S3 couldn't process
			// it, so it returned an error response.
			e.printStackTrace(); 
		} catch (SdkClientException e) {
			// Amazon S3 couldn't be contacted for a response, or the client
			// couldn't parse the response from Amazon S3.
			e.printStackTrace();
		}
		return null;
	}

	private Date setExpirationDate(Long urlExpireIn){
		Date expiration = new Date();
		long expTimeMillis = Instant.now().toEpochMilli();
		expTimeMillis += urlExpireIn;
		expiration.setTime(expTimeMillis);
		return expiration;
	}

	public void deleteObjectFromBucket(String bucketName,String identifier, String objectKey) {
		try {
			s3Client.deleteObject(new DeleteObjectRequest(bucketName, objectKey));
		} catch (AmazonServiceException e) {
			// The call was transmitted successfully, but Amazon S3 couldn't process
			// it, so it returned an error response.
			e.printStackTrace();
		} catch (SdkClientException e) {
			// Amazon S3 couldn't be contacted for a response, or the client
			// couldn't parse the response from Amazon S3.
			e.printStackTrace();
		}
	}

}
