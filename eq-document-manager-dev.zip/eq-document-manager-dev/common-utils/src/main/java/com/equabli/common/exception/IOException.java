package com.equabli.common.exception;

public class IOException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public IOException(String message) {
	    super(message);
	  }
}
