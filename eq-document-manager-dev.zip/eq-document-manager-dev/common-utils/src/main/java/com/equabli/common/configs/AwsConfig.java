package com.equabli.common.configs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;

@Configuration
@Profile("!test")
public class AwsConfig {

	@Autowired
	SecretConfig secretConfig;

	@Bean
	public AmazonS3 amazonS3(Environment environment) {
		final BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(
				secretConfig.getAwsAccessKey(),secretConfig.getAwsSecretKey());

		return AmazonS3ClientBuilder.standard().withRegion(secretConfig.getRegion())
				.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials)).build();
	}
	
/**	@Bean
	public AmazonS3 amazonS3(Environment environment) {
		final BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(
				"AKIAV2UCVO74IGOLQ254",
				"wet0zfVXNXIzvCSkupplD2x3gWbG8pI+K4yOPp3J");

		return AmazonS3ClientBuilder.standard().withRegion(Regions.US_EAST_1)
				.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials)).build();
	}**/
}
