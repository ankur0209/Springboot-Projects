package com.equabli.common.request;

import java.time.LocalDateTime;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class FileUploadConfigRequest {

	@NotBlank
	@Schema(description = "Give orgTypeCode means which user is client, partner or any other need to specify here", example = "CL")
	private String orgType;
	
	@Schema(description = "Portfolio iD", example = "23476764")
	private Long portfolioId;
	
	@Schema(description = "Document type code means, which type of document is it", example = "AP")
	private String docType;
	
	@NotBlank
	@Schema(description = "Upload file name", example = "7643122_2376562_1.txt")
	private String fileName;
	
	@Schema(description = "upload file path which location is upload", example = "/home/file/Client/4/")
	private String filePath;
	
	@Schema(description = "Object key", example = "353454")
	private String objKey;
	
	@Schema(description = "Original Account no", example = "32456778374")
	private String originalAccountNo;
	
	@Schema(description = "Client account no", example = "34638798349")
	private String clientAccountNo;
	
	@Schema(description = "Equabli account no", example = "348748934")
	private Long equabliAccNo;
	
	@Schema(description = "Size of file which is upload", example = "21")
	private Long fileSize;
	
	@Schema(description = "document id ", example = "23")
	private Long documentId;
	
	@Schema(description = "document generation date ", example = "23-01-2022")
	private LocalDateTime documentGenerationDate;
	
	@Schema(description = "document Name ", example = "Application")
	private String documentName;
	
	@Schema(description = "Product Code", example = "Application")
	private String productCode;
	
	@Schema(description = "Client Short Code", example = "MRLT")
	private String clientShortCode;
	
	@Schema(description = "Get file is valid or not", example = "Client")
	private Boolean isFileValid;
	
	@JsonIgnore
	@Schema(description = "Generate the file name from file name data")
	private String generatedFileName;
}
