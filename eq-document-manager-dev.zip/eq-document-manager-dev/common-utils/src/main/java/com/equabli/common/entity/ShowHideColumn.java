package com.equabli.common.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.lang.NonNull;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;

import lombok.Getter;

@Table(name = "show_hide_column", schema = Constants.DOCUMENT_SCHEMAS)
@Entity
@Getter
public class ShowHideColumn extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "show_hide_column_id")
	private Long id;

	private Long userId;
	@Column(length = 2)
	private String orgTypeCode;
	@Column(length = 10)
	private String orgCode;
	
	private String tableName;
	@Column(length = 5000)
	private String columns;

	public void saveShowHideColumn(@NonNull ShowHideColumn showHideColumn, String tableName, String columns,
			TokenData tokenData) {

		showHideColumn.tableName = tableName;
		showHideColumn.columns = columns;
		
		showHideColumn.userId = tokenData.getPrincipleId();
		showHideColumn.orgTypeCode = tokenData.getOrgType();
		showHideColumn.orgCode = tokenData.getUserOrgCode();
		if (showHideColumn.getId() == null)
			showHideColumn.create(tokenData.getFirstName());
		else
			showHideColumn.update(tokenData.getFirstName());
	}

	public void deleteShowHideColumn(ShowHideColumn showHideColumn, TokenData tokenData) {
		showHideColumn.delete(true, tokenData.getFirstName());
	}
}
