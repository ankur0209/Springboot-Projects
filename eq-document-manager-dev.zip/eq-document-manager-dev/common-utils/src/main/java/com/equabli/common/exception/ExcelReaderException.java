package com.equabli.common.exception;

public class ExcelReaderException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ExcelReaderException(String message) {
	    super(message);
	  }
}
