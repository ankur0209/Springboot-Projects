package com.equabli.common.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "User Mail response from User service")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserDetailResponse {

	private String mailId;
	private Boolean isExists;
	private UserDetails userDetails;
}
