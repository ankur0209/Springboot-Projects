package com.equabli.common.configs;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("!test")
public class DatabaseConfig {

	@Autowired
	SecretConfig secretConfig;


	@Bean 
	@Profile("!local & !default")
	DataSource dataSource() { 
		return DataSourceBuilder.create().driverClassName(secretConfig.getDbDriver())
		                          .url(secretConfig.getDbURL())
		                          .username(secretConfig.getDbUser())
		                          .password(secretConfig.getDbPassword())
		                          .build();

	}
	
	
	 
}
