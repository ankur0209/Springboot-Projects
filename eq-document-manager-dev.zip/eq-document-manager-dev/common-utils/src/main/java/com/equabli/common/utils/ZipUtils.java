package com.equabli.common.utils;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import com.equabli.common.exception.IOException;

public class ZipUtils {

	private ZipUtils() {}
	public static String extractZip(File multipartFiles) {

		try (ZipInputStream inputStream = new ZipInputStream(new FileInputStream(multipartFiles))) {
			Path path = Files.createTempDirectory(Paths.get(System.getProperty("java.io.tmpdir")), "tmpDirPrefix");
			for (ZipEntry entry; (entry = inputStream.getNextEntry()) != null;) {
				Path resolvedPath = path.resolve(entry.getName());
				if (!entry.isDirectory()) {
					Files.createDirectories(resolvedPath.getParent());
					Files.copy(inputStream, resolvedPath);
				} else {
					Files.createDirectories(resolvedPath);
				}
			}
			return path.toString();
		}catch (Exception e) {
			throw new IOException(e.getMessage());
		}
	}

	public static String zipDirectory(Path path) throws IOException {

		File dir = new File(path.toString());
		if (!dir.isDirectory())
			throw new IllegalArgumentException("Directory not exists: " + dir.getAbsolutePath());

		File parent = dir.getParentFile();
		File f = zipFiles(new File(parent, dir.getName() + ".zip"), dir.listFiles());

		Util.deleteDirectory(dir);
		return f.toPath().toString();
	}

	private static File zipFiles(File zipFile, File[] listFiles) throws IOException {

		return zipFiles(zipFile, Arrays.asList(listFiles));
	}

	private static File zipFiles(File zipFile, List<File> asList) throws IOException {

		try (FileOutputStream fos = new FileOutputStream(zipFile);
				ZipOutputStream zipOut = new ZipOutputStream(new BufferedOutputStream(fos));) {
			for (File inputFile : asList) {
				try (FileInputStream fis = new FileInputStream(inputFile)) {
					ZipEntry ze = new ZipEntry(inputFile.getName());
					zipOut.putNextEntry(ze);
					byte[] tmp = new byte[4 * 1024]; // 4 KB at time
					int size = 0;
					while ((size = fis.read(tmp)) != -1) {
						zipOut.write(tmp, 0, size);
					}
					zipOut.flush();
				}
			}
		}catch (Exception e) {
			throw new IOException(e.getMessage());
		}
		return zipFile;
	}
}
