package com.equabli.common.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.validation.constraints.NotBlank;

import org.apache.commons.io.FilenameUtils;
import org.springframework.data.domain.Sort;
import org.springframework.lang.NonNull;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

import com.equabli.common.constants.MessageConstants;
import com.equabli.common.exception.IOException;
import com.equabli.common.request.FileUploadConfigRequest;
import com.equabli.common.response.PageRequestData;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Util {
	
	private static final String DATE_FORMAT_YYYYMMDD = "MMddyyyy";
	private static final String SEPARATOR = File.separator;
	private static final String PRODUCT_NAME = "productName";
	private static final String PRODUCT_CODE = "productCode";
	protected static final String[] EXTENSION = {"zip", "tar"};
	protected static final String[] FILE_EXTENTION = {"xlsx"};
	public static final String AWS_SEPARATOR = "/";
	/**
	 * User Profile picture pre-sign URl expire time in minute
	 */
	public static final int PROFILE_PRE_SIGN_URL_EXPIRE_TIME = 1440;
	
	private Util() {}
	
	public static File convertMultipartToFile(MultipartFile file) {
		File convFile = new File(file.getOriginalFilename());
		log.info("We are getting file Name as  {} ", file.getOriginalFilename());
		try (OutputStream os = new FileOutputStream(convFile)) {
			os.write(file.getBytes());
		} catch (Exception e) {
			log.error("ERROR OCCURED WHEN CONVERT MULTIPART FILE TO FILE {} ", e);
		}
		return convFile;
	}
	
	public static LocalDateTime convertLocalDateToUtc(String docGenerationDate){
		 DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT_YYYYMMDD);
		 LocalDate localDate = LocalDate.parse(docGenerationDate.length() == 8 ? docGenerationDate : "0"+docGenerationDate,formatter);
		 Date date = Date.from(localDate.atStartOfDay().toInstant(ZoneOffset.UTC));
		 return date.toInstant().atOffset(ZoneOffset.UTC).toLocalDateTime();
	}
	
	public static String getExtensionFromFileName(String filename) {
	    return FilenameUtils.getExtension(filename);
	}
	
	public static boolean isEndWith(String fileName) {
		boolean result = false;
        for (String fileExtension : EXTENSION) {
            if (fileName.endsWith(fileExtension)) {
                result = true;
                break;
            }
        }
        return result;
	}
	
	public static boolean isContains(String fileName) {
		boolean result = false;
        for (String fileExtension : EXTENSION) {
            if (fileName.contains(fileExtension)) {
                result = true;
                break;
            }
        }
        return result;
	}
	
	public static boolean deleteDirectory(File file) {
		return FileSystemUtils.deleteRecursively(file);
	}
	
	public static String getFileNameWithoutExtension(String fileName) {
		return fileName.replaceAll("\\.\\w+", "");
	}
	
	public static Path createDirectoryIfNotExists(String filePath, String nameOfDirectory) {
		Path directoryPath = Paths.get(filePath + SEPARATOR + nameOfDirectory);
		File uploadDirectory = new File(directoryPath.toAbsolutePath().toString());
		if (!uploadDirectory.exists()) {
			uploadDirectory.mkdir();
		}
		
		return directoryPath;
	}
	
	public static Path writeFileToPath(Path uploadPath, String filename, File file, boolean documentPolicy) {
		Path filePath = Paths.get(uploadPath + SEPARATOR + filename);
		byte[] bytes;
		try {
			bytes = Files.readAllBytes(file.toPath());
			File userIdUploadDirectory = new File(filePath.toString());
			if (userIdUploadDirectory.exists()) {
				// True then create new otherwise replace
				Path newFilePath = null;
				if (documentPolicy) {
					newFilePath = createNewFile(uploadPath, filename);
					Files.write(newFilePath, bytes);
				} else {
					Files.delete(filePath);
					Files.write(filePath, bytes);
				}
			} else {
				Files.write(filePath.toAbsolutePath(), bytes);
			}
		} catch (Exception e) {
			throw new IOException(e.getMessage());
		}
		return filePath;
	}

	private static Path createNewFile(Path filePath, String filename) {
		int i = 1;
		Path newFilePath = null;
		String[] arrOfFile = filename.split("\\.");
		String first = arrOfFile[1];
		if (first.contains("_")) {
			String[] check = arrOfFile[1].split("_");

			filename = filename.contains(arrOfFile[1]) ? filename.replace(arrOfFile[1], "") : filename;
			i = Integer.parseInt(check[1]);
			i++;
			filename = filename + check[0] + "_" + i;
			newFilePath = Paths.get(filePath + SEPARATOR + filename);
		} else {
			filename = filename + "_" + i;
			newFilePath = Paths.get(filePath + SEPARATOR + filename);
		}

		File newFileUploadDirectory = new File(newFilePath.toString());
		if (newFileUploadDirectory.exists()) {
			newFilePath = createNewFile(filePath, filename);
			return newFilePath;
		} else {
			return newFilePath;
		}
	}
	
	public static List<Map<String, String>> getProductMap(String prodCode) {
		Map<String, String> productMap = new LinkedHashMap<>();
		productMap.put(PRODUCT_NAME, "Credit Card");
		productMap.put(PRODUCT_CODE, "CC");
		Map<String, String> productMap1 = new LinkedHashMap<>();
		productMap1.put(PRODUCT_NAME, "Medical");
		productMap1.put(PRODUCT_CODE, "ML");
		Map<String, String> productMap2 = new LinkedHashMap<>();
		productMap2.put(PRODUCT_NAME, "Utility Debt");
		productMap2.put(PRODUCT_CODE, "UD");

		List<Map<String, String>> listOfMap = new ArrayList<>();
		listOfMap.add(productMap);
		listOfMap.add(productMap1);
		listOfMap.add(productMap2);

		if (prodCode.isBlank())
			return listOfMap;
		else {
			return getListByProdCode(listOfMap,prodCode);
		}
	}
	
	private static List<Map<String, String>> getListByProdCode(List<Map<String, String>> listOfMap, String prodCode){
		List<Map<String, String>> valueMapList = new ArrayList<>();
		Map<String, String> valueMap = new LinkedHashMap<>();
		for (Map<String, String> map : listOfMap) {
			if (map.containsValue(prodCode)) {
				valueMap.put(PRODUCT_CODE, map.get(PRODUCT_CODE));
				valueMap.put(PRODUCT_NAME, map.get(PRODUCT_NAME));
				valueMapList.add(valueMap);
			}
		}
		return valueMapList;
	}
	
	public static PageRequestData getPageRequestData(Integer pageSize, Integer pageNumber, String sortOrder, String sortParam) {
		pageSize = pageSize != null ? pageSize : 10;
		pageNumber = pageNumber != null ? pageNumber : 0;
		sortOrder = sortOrder != null ? sortOrder : "desc";
		sortParam = sortParam != null ? sortParam : "createdAt";
		return new PageRequestData(pageSize, pageNumber,sortOrder,sortParam);
	}

	public static String getFileNameFromUrl(String uploadFileUrl) {
		String[] str = uploadFileUrl.split(SEPARATOR);
		return str[str.length - 1];
	}
	
	public static boolean isDigit(@NonNull String str) {
		 return str.matches("[0-9]+");
	}
	
	public static void deleteTempFile(Path path) {
		try {
			Files.delete(path);
		} catch (java.io.IOException e) {
			log.info("ERROR WHEN DELETE TEMP FILE {} ",e.getMessage());
		}
	}
	
	public static String renameFile(String url) {
		int i = 1;
		String[] arrOfUrl = url.split("\\.");
		if (arrOfUrl.length == 3) {
			i = Integer.parseInt(arrOfUrl[1]);
			i++;
			return arrOfUrl[0] + "." + i + "." + arrOfUrl[2];
		} else {
			return arrOfUrl[0] + "." + i + "." + arrOfUrl[1];
		}
	}
	
	public static String getOrderDirection(String sortOrder) {
		String order = null;
		switch (sortOrder) {
		case "asc" -> order = "asc";
		case "desc" -> order = "desc";
		default -> order = "desc";
		}
		return order;
	}
	
	public static Sort getSortingOrder(String order, String param) {
		String orderDirection = getOrderDirection(order);
		return orderDirection.equals("asc") ? Sort.by(param).ascending() : Sort.by(param).descending();
	}
	
	public static String getNameFromFileName(String filename) {
	    return FilenameUtils.getBaseName(filename);
	}
	
	public static boolean checkValidMail(String emailAddress) {
		String regexPattern = "^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@"
				+ "[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
		return Pattern.compile(regexPattern).matcher(emailAddress).matches();
	}
	
	public static PageRequestData getPageRequestData(Integer pageSize, Integer pageNumber) {
		pageSize = pageSize != null ? pageSize : 10;
		pageNumber = pageNumber != null ? pageNumber : 0;
		return new PageRequestData(pageSize, pageNumber, null, null);
	}
	
	public static List<Long> convertStringToList(String values) {
		values = values.replace("[", "").replace("]", "");
		return Arrays.stream(values.split(",")).map(s -> Long.parseLong(s.trim())).collect(Collectors.toList());
	}

	public static String getDirStructureForAccountNo(boolean isValidFile, FileUploadConfigRequest fileUploadVo,
			String productCode) {
		return isValidFile ? ""
				: fileUploadVo.getClientAccountNo() + File.separator + productCode + File.separator
				+ fileUploadVo.getDocType() + File.separator + fileUploadVo.getFileName();
	}
	
	public static int getExprireTimeByFileSize(long fileSize) {
		Long fileSizeInMb = convertBytesToMb(fileSize);
		if(fileSizeInMb >=0 && fileSizeInMb <= 10)
			return 1;
		else if(fileSizeInMb >=11 && fileSizeInMb <= 50)
			return 2;
		else if(fileSizeInMb >=50 && fileSizeInMb <= 100)
			return 5;
		else if(fileSizeInMb >=100 && fileSizeInMb <= 500)
			return 30;
		else if(fileSizeInMb >=500 && fileSizeInMb <= 2048)
			return 60;
		else if(fileSizeInMb > 2048)
			return 90;
		
		return 0;
	}
	
	public static Long convertBytesToMb(long sizeInByte) {
		long convertToMb = 1024L * 1024L;
		long fileSizeInMb = sizeInByte / convertToMb;
		log.info(fileSizeInMb + " Mb");
		return fileSizeInMb;
	}
	
	public static String generatetempFile(String name) {
		return System.getProperty("java.io.tmpdir") + File.separator + name;
	}
	
	public static Long convertToKB(long sizeInByte) {
		long convertToMb = 1024L;
		long fileSizeInMb = sizeInByte / convertToMb;
		log.info(fileSizeInMb + " Kb");
		return fileSizeInMb;
	}
	
	public static Long convertToGB(long sizeInByte) {
		long convertToMb = 1024L * 1024L * 1024L;
		long fileSizeInMb = sizeInByte / convertToMb;
		log.info(fileSizeInMb + " Kb");
		return fileSizeInMb;
	}
	
	public static String getSize(Long sizeInByte) {
		String size = String.valueOf(convertBytesToMb(sizeInByte));
		if(size.equals("0"))
			return String.valueOf(convertToKB(sizeInByte))+ " KB";
		
		return size+ " MB";
	}
	
	/**
	 * User profile picture file path for upload image
	 * @param principleId
	 * @param fileName
	 * @return
	 */
	public static String profilePicturePath(String principleId, String fileName) {
		return "Profile Picture" + AWS_SEPARATOR + principleId + AWS_SEPARATOR + fileName;
	}
	
	/**
	 * User profile picture file path for generate pre-sign url
	 * @param principleId
	 * @return
	 */
	public static String profilePicturePath(String principleId) {
		return "Profile Picture" + AWS_SEPARATOR + principleId;
	}
	
	public static String getOrgType(@NotBlank String orgTypeCode) {

		String orgType = null;
		switch (orgTypeCode) {
		case "CL" -> orgType = MessageConstants.UploadFileConstants.CLIENT;
		case "PT" -> orgType = MessageConstants.UploadFileConstants.PARTNER;
		case "TH" -> orgType = MessageConstants.UploadFileConstants.THIRDPARTY;
		default -> orgType = null;
		}
		return orgType;
	}

	public static File getFileFromDirectory(String zipFilePath, String fileName) {
		//Creating a File object for directory
	      File directoryPath = new File(zipFilePath);
	      //List of all files and directories
	      File filesList[] = directoryPath.listFiles();
	      log.info("List of files and directories in the specified directory:");
	      for(File file : filesList) {
	    	  if(file.getName().equals(fileName))
	    		  return file;
	      }
		return null;
	}
	
	public static Optional<File> multipartFileToFile(MultipartFile multipartFile) {
		File file = new File(
				System.getProperty("java.io.tmpdir") + File.separator + multipartFile.getOriginalFilename());
		try (OutputStream os = new FileOutputStream(file)) {
			os.write(multipartFile.getBytes());
		} catch (Exception e) {
			log.error("Error on multipartFile to File ", e);
			return Optional.empty();
		}
		return Optional.of(file);
	}
}
