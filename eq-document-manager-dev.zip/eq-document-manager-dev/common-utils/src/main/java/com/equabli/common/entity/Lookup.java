package com.equabli.common.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;

import lombok.Getter;

@Table(name = "lookup", schema = Constants.CONF_SCHEMAS)
@Entity
@Getter
public class Lookup extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "lookup_uid")
	private UUID uid;
	
	@ManyToOne
	@JoinColumn(name = "lookup_group_uid", nullable = false)
	private LookupGroup lookupGroup;

	private Short groupSequence;
	
	@Column(length = 2)
	private String keycode;
	
	@Column(length = 50)
	private String keyvalue;
	
	@Column(length = 200)
	private String description;
	
	private Short scrubtype;
	
	public void saveLookup(Lookup lookup, String keycode, String keyvalue, LookupGroup lookupGroup, TokenData tokenData) {
		
		lookup.keycode = keycode;
		lookup.keyvalue = keyvalue;
		lookup.lookupGroup = lookupGroup;
		
		lookup.delete(false);
		if (lookup.getUid() == null)
			lookup.create(tokenData.getFirstName());
		else
			lookup.update(tokenData.getFirstName());
	}
}
