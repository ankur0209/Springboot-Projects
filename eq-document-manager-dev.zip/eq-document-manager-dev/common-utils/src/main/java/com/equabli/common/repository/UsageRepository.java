package com.equabli.common.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.equabli.common.entity.Usage;

@Repository
public interface UsageRepository extends JpaRepository<Usage, Long> {

	Optional<Usage> findByOrgCode(String userId);
}
