package com.equabli.common.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;


@Schema(description = "Entity representing paged data response")
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PagedData <T> {
	
	@Schema(description = "Meta data of paged response")
	private PageMetaData metadata;
	
    @Schema(description = "List of data for response ")
    private List<T> datas;

}
