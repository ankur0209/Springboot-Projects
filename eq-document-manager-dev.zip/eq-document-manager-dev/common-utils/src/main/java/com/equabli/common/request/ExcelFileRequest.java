package com.equabli.common.request;

import javax.validation.constraints.NotBlank;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema
public class ExcelFileRequest {

	@Schema(description = "Document short code", example = "AP")
	String docShortCode;
	
	@Schema(description = "Portfolio Id", example = "43")
	String prodCode;
	
	@Schema(description = "Email id for request whom to send", example = "abc@gmail.com")
	String email;
	
	@Schema(description = "Client account no", example = "34545656")
	String clientAccountNo;
	
	@Schema(description = "Original account no", example = "34545656")
	String originalAccountNO;
	
	@Schema(description = "Eqaubli account no", example = "34545656")
	Long eqaubliAccountNo;
	
	@NotBlank
	@Schema(description = "Upload file name", example = "7643122_2376562_1.txt")
	private String fileName;
	
	@Schema(description = "Size of file which is upload", example = "21")
	private Long fileSize;
	
	@Schema(description = "upload", example = "21")
	private String documentGenerationDate;
	
	@Schema(description = "Client Short Code ", example = "MRLT")
	private String clientShortCode;
	
}
