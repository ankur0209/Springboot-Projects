package com.equabli.common.configs;

import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder;
import com.amazonaws.services.secretsmanager.model.GetSecretValueRequest;
import com.amazonaws.services.secretsmanager.model.GetSecretValueResult;
import com.equabli.common.constants.Constants;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;


@Configuration
@Profile("!test")
public class AwsSecretConfig {

	
	@Value("${cloud.aws.credentials.secret-name}")
    private String secretName;
	@Value("${cloud.aws.credentials.access-key}")
    private String accessKey;
    @Value("${cloud.aws.credentials.secret-key}")
    private String secretkey;
    private SecretConfig secretConfig;

	@PostConstruct
    public void populateSecretConfig() {
		Region  region = Region.getRegion(Regions.US_EAST_1);
		AWSSecretsManager client  = AWSSecretsManagerClientBuilder.standard()
                .withRegion(region.getName())
                .withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(accessKey, secretkey)))
                .build();

		GetSecretValueRequest getSecretValueRequest = new GetSecretValueRequest().withSecretId(secretName);
			try {
			GetSecretValueResult getSecretValueResult = client.getSecretValue(getSecretValueRequest);
			if(StringUtils.isNotBlank(getSecretValueResult.getSecretString())) {
				String secret = getSecretValueResult.getSecretString();
				ObjectMapper objectMapper = new ObjectMapper();
				
				Map<String, String> secretMapData = objectMapper.readValue(secret, new TypeReference<Map<String, String>>(){});
				secretConfig = populateSecretConfig(secretMapData);
				System.out.println("tttt");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		//return null;
    }
	
	@Bean
	public SecretConfig secretConfig() {
		return secretConfig;
	}
	
	private  String decrypt(String encryptedValue) {
        StandardPBEStringEncryptor decryptor = new StandardPBEStringEncryptor();
        decryptor.setPassword("eqdoc2023");
        return decryptor.decrypt(encryptedValue);
	}
	
    private SecretConfig populateSecretConfig(Map<String, String> secrets) {
		return SecretConfig.builder().dbDriver(secrets.get(Constants.DB_DRIVER))
				.dbURL(secrets.get(Constants.DB_URL))
				.dbUser(decrypt(secrets.get(Constants.DB_USER)))
				.dbPassword(decrypt(secrets.get(Constants.DB_PASSWORD)))
				.awsAccessKey(decrypt(secrets.get(Constants.AWS_ACCESS_KEY)))
				.awsSecretKey(decrypt(secrets.get(Constants.AWS_SECRET_KEY)))
				.region(Regions.US_EAST_1.getName())
				.build();
	}
    
    public static void main(String ...args) {
        StandardPBEStringEncryptor decryptor = new StandardPBEStringEncryptor();
        decryptor.setPassword("java2020");
        String encrpt =  decryptor.encrypt("wet0zfVXNXIzvCSkupplD2x3gWbG8pI+K4yOPp3J");
        System.out.println("encrpt : "+encrpt);
        System.out.println("decryptor : "+decryptor.decrypt(encrpt));
    }

}