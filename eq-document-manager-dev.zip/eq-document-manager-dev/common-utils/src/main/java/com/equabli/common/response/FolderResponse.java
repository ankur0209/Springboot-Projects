package com.equabli.common.response;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.equabli.common.constants.MessageConstants;
import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "Fetch list of folder for user type")
@Data
public class FolderResponse {

	@Schema(description = "Account number ", example = "12346")
	private String folderName;
	
	@Schema(description = "Total file size of account number", example = "100")
	private Long fileSize;
	
	@Schema(description = "Last modfied date in MM/dd/yyyy", example = "11/25/2023")
	@JsonFormat(pattern = "MM/dd/yyyy")
	private LocalDateTime modifiedDate;
	private String shareDate;
	private String receiveDate;
	private List<ShareByWithResponse> shareBy;
	private List<ShareByWithResponse> sharedWith;
	private List<DocumentDetailsResponse> documents;
	
	public FolderResponse(String folderName, Long fileSize, LocalDateTime modifiedDate) {
		this.folderName = folderName;
		this.fileSize = fileSize;
		this.modifiedDate = modifiedDate;
	}
	public FolderResponse(Long equabliAccountNo, Long fileSize, LocalDateTime modifiedDate) {
		this.folderName = String.valueOf(equabliAccountNo);
		this.fileSize = fileSize;
		this.modifiedDate = modifiedDate;
	}
	public FolderResponse(Long fileSize, LocalDateTime modifiedDate) {
		this.folderName = MessageConstants.INVALID_USER;
		this.fileSize = fileSize;
		this.modifiedDate = modifiedDate;
	}
	
	public List<ShareByWithResponse> getShareBy() {
		return this.shareBy == null ? new ArrayList<>() : this.shareBy;
	}

	public List<ShareByWithResponse> getSharedWith() {
		return this.sharedWith == null ? new ArrayList<>() : this.sharedWith;
	}
	
	public List<DocumentDetailsResponse> getDocuments() {
		return this.documents == null ? new ArrayList<>() : this.documents;
	}
}
