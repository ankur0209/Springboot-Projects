package com.equabli.common.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.equabli.common.entity.DownloadHistory;

public interface DownloadHistoryRepository extends JpaRepository<DownloadHistory, Long>{

	Page<DownloadHistory> findByUserIdAndIsDeleteFalse(Long userId, Pageable pageable);

}
