package com.equabli.common.searchparam;

import java.time.LocalDate;
import java.util.Objects;
import java.util.stream.Stream;

import com.equabli.common.constants.MessageConstants;
import com.equabli.common.response.PageRequestData;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Search Parameter for Document Folders")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentForldersSearchParam extends PageRequestData{

	private String folderName;
	private String originalAccountNumber;
	private Long equabliAccountNumber;
	private String clientAccountNumber;
	private String docTypeCode;
	private String notHavingDocTypeCode;
	private String textSearch;
	private String shareBy;
	private String shareWith;
	
	@Schema(description = "Modified Date From "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate modifiedDateFrom;
	@Schema(description = "Modified Date To "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate modifiedDateTo;
	
	@Schema(description = "Receive Date From "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate receiveDateFrom;
	@Schema(description = "Receive Date To "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate receiveDateTo;
	
	@Schema(description = "Share Date From "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate shareDateFrom;
	@Schema(description = "Share Date To "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate shareDateTo;

	public boolean allNull() {
		return Stream.of(folderName, originalAccountNumber, equabliAccountNumber, clientAccountNumber, docTypeCode,
				notHavingDocTypeCode, textSearch, shareBy, shareWith, modifiedDateFrom, modifiedDateTo, receiveDateFrom,
				receiveDateTo, shareDateFrom, shareDateTo).allMatch(Objects::isNull);
	}
}
