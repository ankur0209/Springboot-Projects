package com.equabli.common.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;

import lombok.Getter;

@Table(name = "require_doc", schema = Constants.DOCUMENT_SCHEMAS)
@Entity
@Getter
public class RequireDoc extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "require_doc_id")
	private Long id;

	private Long userId;
	@Column(length = 2)
	private String orgTypeCode;
	@Column(length = 10)
	private String orgCode;

	@Column(length = 10)
	private String productCode;

	@Column(length = 10)
	private String docTypeCode;

	public void deleteRequireDoc(RequireDoc requireDoc, TokenData tokenData) {
		requireDoc.delete(true, tokenData.getFirstName());
	}

	public void saveRequireDoc(RequireDoc requireDoc, String prodCode, String docCode, TokenData tokenData) {
		requireDoc.docTypeCode = docCode;
		requireDoc.productCode = prodCode;
		requireDoc.delete(false);

		requireDoc.userId = tokenData.getPrincipleId();
		requireDoc.orgTypeCode = tokenData.getOrgType();
		requireDoc.orgCode = tokenData.getUserOrgCode();
		if (requireDoc.getId() == null)
			requireDoc.create(tokenData.getFirstName());
		else
			requireDoc.update(tokenData.getFirstName());
	}
}