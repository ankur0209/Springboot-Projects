package com.equabli.common.response;

import java.util.Map;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Schema(description = "Notification response for fetch list of notification for specific User")
@Getter
@Setter
public class WebNotificationResponse {

	private Map<String, Object> notificationDetail;
	
}
