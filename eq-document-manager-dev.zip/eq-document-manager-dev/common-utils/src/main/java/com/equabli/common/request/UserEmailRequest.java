package com.equabli.common.request;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserEmailRequest {

	@Schema(description = "mail Address")
    private List<String> datas;
}
