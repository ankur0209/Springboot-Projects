package com.equabli.common.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;
import com.equabli.common.utils.DocTypeFields;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Table(name = "doc_type_identification", schema = Constants.DOCUMENT_SCHEMAS)
@Entity
@Getter
@Slf4j
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
public class DocTypeIdentification extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "doc_type_identification_id")
	private Long id;

	@OneToOne
	@JoinColumn(name = "doc_type_id")
	private DocType docType;

	@Column(columnDefinition = "jsonb")
	@Type(type = "jsonb")
	private String identificationJson;

	public DocTypeFields getDocTypeFields() {
		return StringUtils.isNotBlank(identificationJson) ? new Gson().fromJson(identificationJson, DocTypeFields.class) : null;
	}

	public void setIdentificationJson(List<String> docFields) {
		ObjectMapper objectMapper = new ObjectMapper();
		DocTypeFields billOfSaleDto = new DocTypeFields();
		billOfSaleDto.setDocFields(docFields);
		try {
			this.identificationJson = objectMapper.writeValueAsString(billOfSaleDto);
		} catch (Exception e) {
			log.error("ERORR in Convert DocTypeFields to JSON String", e);
		}
	}

	public void saveDocTypeIdentification(DocTypeIdentification docTypeIdentification, DocType docType, TokenData tokenData) {
		docTypeIdentification.docType = docType;
		docTypeIdentification.delete(false);
		if (docTypeIdentification.getId() == null)
			docTypeIdentification.create(tokenData.getFirstName());
		else
			docTypeIdentification.update(tokenData.getFirstName());
	}

	public void deleteDocTypeIdentification(DocTypeIdentification docTypeIdentification, TokenData tokenData) {
		docTypeIdentification.delete(true, tokenData.getFirstName());
	}

	@Override
	public String toString() {
		return "DocTypeIdentification [id=" + id + ", docType=" + docType + ", identificationJson=" + identificationJson + "]";
	}

}
