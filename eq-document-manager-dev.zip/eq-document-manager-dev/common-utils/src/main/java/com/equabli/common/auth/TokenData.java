package com.equabli.common.auth;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "Model representing information required for Token Deseriallizing")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TokenData {

	private Long principleId;
	private String loginKey;
	private String firstName;
	private String middleName;
	private String lastName;
	private String emailAddress;
	private String phone;
	private String orgType;
	private String token;
	private String accessKey;
	private String authType;
	private String userOrgCode;
	private Integer userOrgId;
	private String userOrgName;

}