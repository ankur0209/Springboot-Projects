package com.equabli.common.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AccountNumberValidateRequest {

//	@Schema(description = "User ID", example = "1l")
	
	@Schema(description = "Account Number", example = "123456")
	String accountNumber;
}
