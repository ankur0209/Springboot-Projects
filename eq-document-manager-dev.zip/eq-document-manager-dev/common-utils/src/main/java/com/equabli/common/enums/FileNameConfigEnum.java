package com.equabli.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum FileNameConfigEnum {

	FIELD("Field", "field"),
	RETENTION_POLICY("Retention Policy", "RP"), SEPARATOR("Separator", "SEPARATOR"), DOCUMENT_POLICY("Document Policy", "DP");

	private final String fullName;
	private final String shortCode;

}
