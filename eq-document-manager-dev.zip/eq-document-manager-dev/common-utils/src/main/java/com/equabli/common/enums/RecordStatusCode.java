package com.equabli.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum RecordStatusCode {
	RAW("RS_RAW"), CLEAN("RS_CLEAN"), SUSPECT("RS_SUSPECT"), ORPHAN("RS_ORPHAN"), ENABLE("RS_ENABLE"),
	DISABLE("RS_DISABLE"), START("RS_START"), INPROG("RS_INPROG"), COMPLT("RS_COMPLT"), INCLUDE("RS_INCLUDE"),
	EXCLUDE("RS_EXCLUDE"), REQUEST("RS_REQUEST"), APPROVE("RS_APPROVE"), REJECT("RS_REJECT"), CANCEL("RS_CANCEL"),
	SUCCESS("RS_SUCCESS"), FAIL("RS_FAIL"), MAILST("RS_MAILST"), MAILNST("RS_MAILNST"), PARTIAL("RS_PARTIAL");

	private String shortCode;

}
