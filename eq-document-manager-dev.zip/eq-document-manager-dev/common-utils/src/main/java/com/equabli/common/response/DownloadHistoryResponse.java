package com.equabli.common.response;

import com.equabli.common.entity.DownloadHistory;
import com.equabli.common.utils.DateUtils;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Schema(description = "Fetch saved docuemnt cost configuration for partner or thir party organization type")
@Getter
@Setter
@NoArgsConstructor
public class DownloadHistoryResponse {

	@Schema(description = "Id", example = "1")
	private Long id;
	
	@Schema(description = "Name of document", example = "Application")
	private String documentName;
	
	@Schema(description = "Size of document", example = "10")
	private Long documentsize;
	
	@Schema(description = "date of download", example = "2022-01-02")
	private String downloadAt;
	
	@Schema(description = "status of download", example = "2022-01-02")
	private String downloadStatus;
	
	@Schema(description = "document file path", example = "2022-01-02")
	private String filePath;
	
	public DownloadHistoryResponse(DownloadHistory downloadHistory) {
		this.id= downloadHistory.getId();
		this.documentName = downloadHistory.getDocument().getGeneratedFileName();
		this.documentsize = downloadHistory.getDocSize();
		this.downloadAt = DateUtils.convertLocalDateTimeToString(downloadHistory.getDownloadAt());
		this.downloadStatus = downloadHistory.getDownloadStatus().name();
		this.filePath = downloadHistory.getDocument().getGeneratedFilePath();
	}
}
