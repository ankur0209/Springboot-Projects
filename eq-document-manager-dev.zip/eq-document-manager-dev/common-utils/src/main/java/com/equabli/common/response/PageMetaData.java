package com.equabli.common.response;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PageMetaData<K> {

	@Schema(description = "Page Size of to be batch 10,20 ")
	private Integer pageSize;

	@Schema(description = "Current Page Number in response ")
    private Integer pageNumber;

	@Schema(description = "Total number of record ")
	private Integer recordCount;
    
	@Schema(description = "Total Page Count ")
    private Integer pageCount;
    
	@Schema(description = "Start Record index ")
    private Integer startRecord; 
	
	private K columns;

}
