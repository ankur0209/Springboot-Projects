//package com.equabli.common.entity;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//import com.equabli.common.auth.TokenData;
//import com.equabli.common.constants.Constants;
//import com.equabli.common.request.ShiftDocumentRequest;
//
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//
//@Table(name = "shift_document", schema = Constants.DOCUMENT_SCHEMAS)
//@Entity
//@Getter
//@NoArgsConstructor
//public class ShiftDocument extends BaseEntity{
//
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@Column(name = "shift_document_id")
//	private Long id;
//	
//	private String shiftDocumentIdFrom;
//	private String shiftDocumentIdTo;
//	
//	private Long shiftUserIdFrom;
//	@Column(length = 10)
//	private String shiftOrgCodeFrom;
//	@Column(length = 2)
//	private String shiftOrgCodeTypeFrom;
//	
//	private Long shiftUserIdTo;
//	@Column(length = 10)
//	private String shiftOrgCodeTo;
//	@Column(length = 2)
//	private String shiftOrgCodeTypeTo;
//	
//	@Column(length = 50)
//	private String accountNumber;
//	
//	public void saveShiftDocument(ShiftDocument shiftDocument,
//			ShiftDocumentRequest shiftDocumentRequest, String shiftDocumentIdFrom, String shiftDocumentIdTo, String accountNo) {
//		shiftDocument.shiftDocumentIdFrom = shiftDocumentIdFrom;
//		shiftDocument.shiftDocumentIdTo = shiftDocumentIdTo;
//		shiftDocument.shiftUserIdFrom = shiftDocumentRequest.getFromUserId();
//		shiftDocument.shiftOrgCodeFrom = shiftDocumentRequest.getFromOrgCode();
//		shiftDocument.shiftOrgCodeTypeFrom = shiftDocumentRequest.getFromOrgTypeCode();
//		shiftDocument.shiftUserIdTo = shiftDocumentRequest.getToUserId();
//		shiftDocument.shiftOrgCodeTo = shiftDocumentRequest.getToOrgCode();
//		shiftDocument.shiftOrgCodeTypeTo = shiftDocumentRequest.getToOrgTypeCode();
//		shiftDocument.accountNumber = accountNo;
//		shiftDocument.delete(false);
//	}
//	
//	public void deleteShiftDocument(ShiftDocument shiftDocument, TokenData tokenData) {
//		shiftDocument.delete(true, tokenData.getFirstName());
//	}
//}
