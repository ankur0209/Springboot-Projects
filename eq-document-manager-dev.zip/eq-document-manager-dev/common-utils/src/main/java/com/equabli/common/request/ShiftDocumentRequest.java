package com.equabli.common.request;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Schema(description = "Shift Document one partner to another")
@ToString
public class ShiftDocumentRequest {

	@NotBlank(message = "fromOrgCode should not be blank")
	@Schema(description = "From Organization Code", example = "MRLT")
	private String fromOrgCode;
	
	@NotBlank(message = "fromOrgTypeCode should not be blank")
	@Schema(description = "From Organization Type Code", example = "CL")
	private String fromOrgTypeCode;
	
	@NotNull(message = "fromUserId should not be blank")
	@Schema(description = "From UserId ", example = "21")
	private Long fromUserId;

	@NotBlank(message = "toOrgCode should not be blank")
	@Schema(description = "To Organization Code", example = "TRAKA")
	private String toOrgCode;
	
	@NotBlank(message = "toOrgTypeCode should not be blank")
	@Schema(description = "To Organization Type Code", example = "PT")
	private String toOrgTypeCode;
	
	@NotNull(message = "toUserId should not be blank")
	@Schema(description = "To UserId ", example = "9")
	private Long toUserId;

	@Schema(description = "Client Account number", example = "[\"123456\"]")
	@NotNull(message = "accountNumber should not be blank")
	private List<String> accountNumber;

}
