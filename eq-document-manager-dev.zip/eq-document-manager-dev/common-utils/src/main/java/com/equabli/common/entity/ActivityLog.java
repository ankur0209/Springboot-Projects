package com.equabli.common.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;

@Table(name = "activity_log", schema = Constants.DOCUMENT_SCHEMAS)
@Entity
@Getter
@Immutable
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
public class ActivityLog {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "activity_log_id")
	private Long id;

	private Long userId;

	@Column(length = 2)
	private String orgTypeCode;

	@Column(length = 10)
	private String orgCode;

	@Schema(description = "Type of activity")
    @Enumerated(EnumType.STRING)
	private ActivityTypeEnum activityType;

	@Schema(description = "Store the json data before update")
	@Column(columnDefinition = "jsonb")
	@Type(type = "jsonb")
	private String exisitingData;

	@Schema(description = "Store the data json data after update")
	@Column(columnDefinition = "jsonb")
	@Type(type = "jsonb")
	private String newData;

	@Column(name = "dtm_utc_create", columnDefinition = "TIMESTAMP WITH TIME ZONE")
	@CreationTimestamp
	private LocalDateTime createdAt;

	@Column(length = 50)
	private String createdBy;

	public enum ActivityTypeEnum {
		ACCOUNT_INTEGRATION
	}
	
	public void saveActivityLog(ActivityLog activityLog, TokenData tokenData, String existingData, String newData,
			ActivityTypeEnum activityTypeEnum) {
		activityLog.userId = tokenData.getPrincipleId();
		activityLog.orgTypeCode = tokenData.getOrgType();
		activityLog.orgCode = tokenData.getUserOrgCode();
		activityLog.createdBy = tokenData.getFirstName();
		activityLog.exisitingData = existingData;
		activityLog.newData = newData;
		activityLog.activityType = activityTypeEnum;
	}

	
}
