package com.equabli.common.enums;

public enum DownloadStatusEnum {

	PENDING,
	PAUSE,
	COMPLETE;
}
