package com.equabli.common.feignclients;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.equabli.common.configs.FeignClientConfig;
import com.equabli.common.constants.Constants;
import com.equabli.common.response.ClientSubscription;
import com.equabli.common.response.config.ConfigResponse;

@FeignClient(name = "config-service", path = "/common-config-service/api", configuration = FeignClientConfig.class)
//@FeignClient(name = "config-service", url = "http://localhost:8063/common-config-service/api", configuration = FeignClientConfig.class)
public interface CommonConfigService {

	@GetMapping(value = "/subscription/detail")
	ResponseEntity<ConfigResponse<List<ClientSubscription>>> getSubscribedClientDetail(@RequestHeader(Constants.EQBINT) String eqbint,
			@RequestHeader(Constants.REQUEST_ORIGIN) String rqsOrigin);

	@GetMapping(value = "/v1/partner/mappedClient")
	String getMappedClientDetail(@RequestHeader(Constants.AUTHORIZATION) String bearerToken,
			@RequestHeader(Constants.REQUEST_ORIGIN) String rqsOrigin, @RequestParam("partnerId") Integer partnerId);

	@GetMapping(value = "/v1/token")
	String getToken(@RequestHeader(Constants.AUTHORIZATION) String bearerToken,
			@RequestHeader(Constants.REQUEST_ORIGIN) String origin, @RequestParam("userId") Long userId);

	@GetMapping(value = "/v1/partner/byFullName")
	String getPartnersByFullNames(@RequestHeader(Constants.AUTHORIZATION) String bearerToken,
			@RequestHeader(Constants.REQUEST_ORIGIN) String origin,
			@RequestParam("partnerFullNames") List<String> partnerNames);

	@GetMapping(value = "/v1/client")
	String getClientsByShortCode(@RequestHeader(Constants.AUTHORIZATION) String bearerToken,
			@RequestHeader(Constants.REQUEST_ORIGIN) String origin, @RequestParam("shortNames") List<String> shortCode);

	@GetMapping(value = "/v1/product")
	String getProductList(@RequestHeader(Constants.AUTHORIZATION) String bearerToken,
			@RequestHeader(Constants.REQUEST_ORIGIN) String origin);
}
