package com.equabli.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.equabli.common.entity.BulkOperation;

public interface BulkOperationRepository extends JpaRepository<BulkOperation, Long>{

}
