package com.equabli.common.response;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class PartnerResponse {
	private Integer partnerId;
	private String shortName;
	private String fullName;
	private String address1;
	private String address2;
	private String city;
	private String zip;
	private String emailAddress;
	private String phone1;
	private String phone2;
	private String pocName;
	private Double amtMinCollLimit;
	private Double amtMaxCollLimit;
	private Integer servicetypeId;
	private Integer recordStatusId;

	@JsonFormat(pattern = "MM/dd/yyyy")
	@Schema(description = "Partner Updated date MM/dd/yyy", example = "11/25/2022")
	private String dtmUtcUpdate;
	private Integer recordSourceId;
	private Integer appId;
	private String stateCode;
	private String website;
	private Integer quicksightId;
	private String namePronunciation;
	private String emailPronunciation;
	private String phonePronunciation;
	private String addressPronunciation;
	private Boolean isEqassociate;

}
