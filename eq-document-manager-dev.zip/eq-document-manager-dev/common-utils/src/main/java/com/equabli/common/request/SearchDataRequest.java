package com.equabli.common.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Entity representing request of Paged Data")
public class SearchDataRequest{
	@Schema(description =  "Page Size of limit , or number of record")
	private Integer pageSize;
	@Schema(description =  "Page Number request")
	private Integer pageNumber;
	@Schema(description =  "Sort on Column")
	private String sortColumn;
	@Schema(description =  "Sort Direction")
	private SortDirection sortDirection;

}

enum SortDirection{
	ASC,DESC;
}