package com.equabli.common.response;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema
public class FileOperationResponse {

	@Schema(description = "File Name url", example = "/directory/hello.txt")
	private List<String> fileUrl;
	
	@Schema(description = "No of file upload", example = "4")
	private String fileNo;
	
	@Schema(description = "List of file which was uploaded", example = "hello.txt")
	private List<String> fileNames;
	
	@Schema(description = "No of document reject", example = "4")
	private String documentRejectNo;
	
	@Schema(description = "List of document which was rejected", example = "hello.txt")
	private List<String> documentRejectFile;
}
