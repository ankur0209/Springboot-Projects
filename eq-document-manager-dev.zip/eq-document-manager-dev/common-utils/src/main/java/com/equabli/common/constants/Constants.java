package com.equabli.common.constants;

public final class Constants {

	private Constants() {
	}

	public static final String AUTH_HEADER = "authorization";
	public static final String ORIGIN_HEADER = "origin";
	public static final String USER_AGENT_HEADER = "user-agent";
	public static final String REMOTE_IP = "remote-ip";
	public static final String TOKEN_PREFIX = "Bearer ";
	public static final String AUTHORITIES = "authorities";

	public static final String DB_DRIVER = "dbDriver";
	public static final String DB_URL = "dbUrl";
	public static final String DB_USER = "dbUser";
	public static final String DB_PASSWORD = "dbPassword";
	public static final String AWS_ACCESS_KEY = "awsAccessKey";
	public static final String AWS_SECRET_KEY = "awsSecretKey";
	
	public static final String DOCUMENT_SCHEMAS = "data";
	public static final String CONF_SCHEMAS = "conf";
	
	public static final String AUTHORIZATION = "Authorization";
	
	public static final String CLIENT_CODE = "CL";
	public static final String PARTNER_CODE = "PT";
	public static final String THIRD_PARTY_CODE = "TP";
	
	public static final String PENDING = "Pending";
	
	public static final String REQUEST_ORIGIN = "rqsOrigin";
	public static final String EQBINT = "eqbint";
	public static final String EQ_INTEGRATION = "equabliIntegration";
	public static final String AWS_SEPARATOR = "/";
}
