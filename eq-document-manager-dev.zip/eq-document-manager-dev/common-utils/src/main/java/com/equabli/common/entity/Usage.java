package com.equabli.common.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.lang.NonNull;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;

import lombok.Getter;

@Table(name = "usage", schema = Constants.DOCUMENT_SCHEMAS)
@Entity
@Getter
public class Usage extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "usage_id")
	private Long id;

	private Long userId;
	@Column(length = 2)
	private String orgTypeCode;
	@Column(length = 10)
	private String orgCode;

	private Long used;
	private Long totalDocument;
	
	private UUID lookupUid;

	public void saveUsage(Usage usage, Long used, Long totalDocument, TokenData tokenData) {
		usage.used = used;
		usage.totalDocument = totalDocument;
		usage.delete(false);

		usage.userId = tokenData.getPrincipleId();
		usage.orgTypeCode = tokenData.getOrgType();
		usage.orgCode = tokenData.getUserOrgCode();
		if (usage.getId() == null)
			usage.create(tokenData.getFirstName());
		else
			usage.update(tokenData.getFirstName());
	}

	public void updateUsage(Usage usage, Long fileSize, Long totalDocument, TokenData tokenData) {
		if (usage.used != null)
			usage.used = usage.used + fileSize;
		else
			usage.used = fileSize;

		if (usage.totalDocument != null)
			usage.totalDocument = usage.totalDocument + totalDocument;
		else
			usage.totalDocument = totalDocument;
		usage.delete(false);

		usage.userId = tokenData.getPrincipleId();
		usage.orgTypeCode = tokenData.getOrgType();
		usage.orgCode = tokenData.getUserOrgCode();
		usage.update(tokenData.getFirstName());
	}
	
	/**
	 * Update the Usages after update in subscription plan
	 * @param usage
	 * @param lookupUid
	 * @param tokenData
	 */
	public void saveUsage(Usage usage, @NonNull UUID lookupUid, TokenData tokenData) {
		usage.lookupUid = lookupUid;
		usage.delete(false);

		usage.userId = tokenData.getPrincipleId();
		usage.orgTypeCode = tokenData.getOrgType();
		usage.orgCode = tokenData.getUserOrgCode();
		if (usage.getId() == null)
			usage.create(tokenData.getFirstName());
		else
			usage.update(tokenData.getFirstName());
	}
	
	public void updateUsage(Usage usage, Long fileSize, Long totalDocument, TokenData tokenData, String orgTypecode,
			String orgCode) {
		if (usage.used != null)
			usage.used = usage.used + fileSize;
		else
			usage.used = fileSize;

		if (usage.totalDocument != null)
			usage.totalDocument = usage.totalDocument + totalDocument;
		else
			usage.totalDocument = totalDocument;
		usage.delete(false);

		usage.userId = tokenData.getPrincipleId();
		usage.orgTypeCode = orgTypecode;
		usage.orgCode = orgCode;
		usage.update(tokenData.getFirstName());
	}
}
