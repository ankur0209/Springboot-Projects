package com.equabli.common.response;

import java.util.List;

import com.equabli.common.entity.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProcessIntegrationResponse {

	private Document existingData;
	private Document newData;
}
