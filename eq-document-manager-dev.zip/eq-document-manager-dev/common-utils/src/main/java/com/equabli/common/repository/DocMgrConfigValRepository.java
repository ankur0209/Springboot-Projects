package com.equabli.common.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.equabli.common.entity.DocMgrConfigVal;

@Repository
public interface DocMgrConfigValRepository extends JpaRepository<DocMgrConfigVal, Long> {

	public List<DocMgrConfigVal> findBydocMgrConfig_id(Long docMgrConfigId);
	
	public Optional<DocMgrConfigVal> findByShortCodeAndDocMgrConfig_Id(String docMgrConfigValShortCode, Long docMgrConfigId);
}
