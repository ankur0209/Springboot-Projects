package com.equabli.common.response.config;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Resonse of config service customer error")
public class CustomError {

	private int errorCode;
	private String errorMessage;
	private String type;

	public long getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
