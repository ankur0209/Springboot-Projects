package com.equabli.common.configs;

import java.time.format.DateTimeFormatter;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.filter.CommonsRequestLoggingFilter;

import com.equabli.common.constants.MessageConstants;
import com.equabli.common.utils.RequestResponseLoggingFilter;

@Configuration
public class CommonServiceConfig {
	
	public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern(MessageConstants.DATE_FORMATE);

    @Bean(name="messageSource")
    public MessageSource messageSource() {
        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
        messageSource.setBasenames("messages","messages_common");
        messageSource.setDefaultEncoding("UTF-8");
        return messageSource;
    }

    @Bean
    public CommonsRequestLoggingFilter logFilter() {
        final RequestResponseLoggingFilter filter = new RequestResponseLoggingFilter();
        filter.setIncludeQueryString(true);
        filter.setIncludePayload(true);
        filter.setIncludeAfterCompletion(true);
        filter.setMaxPayloadLength(10000);
        filter.setIncludeClientInfo(true);
        filter.setIncludeResponsePayload(true);
        return filter;
    }
}
