package com.equabli.common.request;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(description = "Request a new document")
@JsonIgnoreProperties(value = { "requestedTo", "requestedBy", "sentRequestUserId", "fullfilledUserId",
		"sentRequestOrgTypeCode", "receiveRequestOrgTypeCode" })
public class RequestNewDocumentRequest {

	@Schema(description = "User Detail Mail")
	@NotNull(message = "sendRequests should not be blank")
	@Valid
	private List<String> sendRequests;
	
	@JsonIgnore
	@Schema(description = "Users Detail Mail")
	private String sendRequest;
	
	@Schema(description = "Original Account Number", example = "456789")
	private String originalAccountNumber;

	@Schema(description = "Client Account Number", example = "123456")
	private String clientAccountNumber;

	@Schema(description = "Equabli Account Number", example = "123456")
	private Long equabliAccountNumber;

	@Schema(description = "Code of document type", example = "BRA")
	private String docTypeCode;
	
	@JsonIgnore
	@Schema(description = "Type of document", example = "Transation History")
	private String documentType;

	private String sentRequestOrgTypeCode;
	private String receiveRequestOrgTypeCode;
	private String requestedTo;
	private String requestedBy;
	private Long sentRequestUserId;
	private Long fullfilledUserId;
	
	@Schema(description = "Client Short Code", example = "MRLT")
	private String clientShortCode;
}
