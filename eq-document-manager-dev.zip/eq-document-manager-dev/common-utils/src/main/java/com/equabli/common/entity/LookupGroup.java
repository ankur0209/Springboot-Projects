package com.equabli.common.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.equabli.common.constants.Constants;

import lombok.Getter;

@Table(name = "lookup_group", schema = Constants.CONF_SCHEMAS)
@Entity
@Getter
public class LookupGroup extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "lookup_group_uid")
	private UUID uid;

	@Column(length = 50)
	private String keyvalue;
	
	@Column(length = 200)
	private String description;
	
	private Boolean isBusinessFunction;
}
