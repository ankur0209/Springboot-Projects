package com.equabli.common.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Entity representing response if all inputs were valid or Errors")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CommonResponse<T> {

    public enum OperationStatus {
        SUCCESS, FAILURE,BUSINESS_FAILURE,UNAUTHORIZED,USER_NOT_REGISTERED;
    }

    @Schema(description =  "Any relevant message related to the overall state of operation")
    private final String message;

    @Schema(description = "Status of operation, either SUCCESS or FAILURE")
    private final OperationStatus status;

    @Schema(description = "Any entity or data associated with success of operation")
    private final T response;
    
    @Schema(description = "is Request is valid or not")
    private final boolean validation;
    
    @Schema(description = "Errors if we have mutiple error")
    private final List<String> errors;

    public static <T> CommonResponse<T> failure(String message) {
        return CommonResponse.failure(message, null);
    }

    public static <T> CommonResponse<T> failure(String message, T response) {
        return new CommonResponse<>(message, OperationStatus.FAILURE, response,false,null);
    }

    public static  <T> CommonResponse<T> success(String message) {
        return CommonResponse.success(message, null);
    }

    public static <T> CommonResponse<T> success(String message, T response) {
        return new CommonResponse<>(message, OperationStatus.SUCCESS, response,true,null);
    }
    
    public static <T> CommonResponse<T> failureWithErrors(String message, List<String> errors) {
        return new CommonResponse<>(message, OperationStatus.SUCCESS, null,false,errors);
    }
    
    public static <T> CommonResponse<T> failureWithErrors(String message, T errors) {
        return new CommonResponse<>(message, OperationStatus.FAILURE, errors,false, null);
    }

    @JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
    public CommonResponse(String message, OperationStatus status) {
        this(message, status, null,true,null);
    }

    @JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
    public CommonResponse(String message, OperationStatus status, T response, final boolean valid,final List<String> errors) {
        this.message = message;
        this.status = status;
        this.response = response;
        this.validation = valid;
        this.errors = errors;
    }
    
    

}
