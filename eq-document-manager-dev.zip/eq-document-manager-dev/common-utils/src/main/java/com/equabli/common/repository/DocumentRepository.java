package com.equabli.common.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.equabli.common.entity.Document;
import com.equabli.common.response.DocumentDetailsResponse;

import com.equabli.common.response.FolderResponse;
import com.equabli.common.searchparam.DocumentForldersSearchParam;

@Repository
public interface DocumentRepository extends JpaRepository<Document, Long>, QuerydslPredicateExecutor<Document> {

	@Query(value = "SELECT dm from Document as dm where dm.orgCode = ?1 "
			+ " and ( dm.originalAccountNo = ?2 OR dm.clientAccountNo = ?2 OR CAST(dm.equabliAccountNo AS string) = ?2) ")
	public Page<Document> findByAccountNumber(String orgCode, String accountNumber, Pageable pageable);

	@Query(value = "SELECT dm from Document as dm where dm.orgCode = ?1 AND dm.isOthers = ?2 ")
	public Page<Document> findByUserTypeAndIsOthers(String orgCode, Boolean isOther, Pageable pageable);

	@Query(value = "SELECT new com.equabli.common.response.FolderResponse( dm.clientAccountNo as folderName, "
			+ " SUM(dm.fileSize) as fileSize, MAX(dm.updatedAt) as modifiedDate )"
			+ " FROM Document as dm where dm.orgCode = ?1 AND dm.clientAccountNo IS NOT NULL AND dm.isDelete = false "
			+ " GROUP BY dm.clientAccountNo ")
	public List<FolderResponse> groupByClientAccountNo(String orgCode);

	@Query(value = "SELECT new com.equabli.common.response.FolderResponse( dm.originalAccountNo as folderName, "
			+ " SUM(dm.fileSize) as fileSize, MAX(dm.updatedAt) as modifiedDate )"
			+ " FROM Document as dm where dm.orgCode = ?1 AND dm.originalAccountNo IS NOT NULL AND dm.isDelete = false "
			+ " GROUP BY dm.originalAccountNo ")
	public List<FolderResponse> groupByOriginalAccountNo(String orgCode);

	@Query(value = "SELECT new com.equabli.common.response.FolderResponse( dm.equabliAccountNo as folderName, "
			+ " SUM(dm.fileSize) as fileSize, MAX(dm.updatedAt) as modifiedDate )"
			+ " FROM Document as dm where dm.orgCode = ?1 AND dm.equabliAccountNo IS NOT NULL AND dm.isDelete = false "
			+ " GROUP BY dm.equabliAccountNo ")
	public List<FolderResponse> groupByEquabliAccountNo(String orgCode);

	@Query(value = "SELECT COUNT(dm) from Document as dm where dm.orgCode = ?1 "
			+ " and dm.originalAccountNo = ?2 AND dm.clientAccountNo = ?3 AND dm.equabliAccountNo = ?4 AND dm.docTypeCode = ?5 ")
	public Long findDocumentByAccountNumber(String orgCode, String originalAccountNo, String clientAccountNo,
			Long equabliAccountNo, String docTypeCode);

	@Query(value = "SELECT new com.equabli.common.response.FolderResponse("
			+ " SUM(dm.fileSize) as fileSize, MAX(dm.updatedAt) as modifiedDate )"
			+ " FROM Document as dm where dm.orgCode = ?1 AND dm.isOthers = true  AND dm.isDelete = false ")
	public FolderResponse getOtherDocuments(String orgCode);

	@Query(value = "SELECT new com.equabli.common.response.FolderResponse( dm.clientAccountNo as folderName, "
			+ " SUM(dm.fileSize) as fileSize, MAX(dm.updatedAt) as modifiedDate )"
			+ " FROM Document as dm "
			+ " LEFT JOIN com.equabli.common.entity.ShareBy as sb ON sb.documentId = dm.id AND sb.isUnshared = false "
			+ " LEFT JOIN com.equabli.common.entity.ShareWith as sw ON sw.shareById.id = sb.id AND sw.isUnshared = false "
			+ " LEFT JOIN com.equabli.common.entity.SendReceiveDocument as sd ON sd.fullfilledDocumentId.id = dm.id AND sd.sentRequestOrgCode = :orgCode "
			+ " WHERE (dm.orgCode = :orgCode OR sd.sentRequestOrgCode = :orgCode OR sw.shareWithUserOrgCode = :orgCode OR sb.orgCode = :orgCode )"
			+ " AND dm.isDelete = false AND dm.clientAccountNo IS NOT NULL AND dm.isOthers = false "
			+ " AND ( :#{#folderParam.originalAccountNumber} IS NULL OR dm.originalAccountNo = :#{#folderParam.originalAccountNumber}) "
			+ " AND ( :#{#folderParam.equabliAccountNumber} IS NULL OR dm.equabliAccountNo = :#{#folderParam.equabliAccountNumber}) " 
			+ " AND ( :#{#folderParam.clientAccountNumber} IS NULL OR dm.clientAccountNo = :#{#folderParam.clientAccountNumber}) "
			+ " AND ( :#{#folderParam.docTypeCode} IS NULL OR dm.docTypeCode = :#{#folderParam.docTypeCode}) "
			+ " AND ( :#{#folderParam.notHavingDocTypeCode} IS NULL OR dm.docTypeCode != :#{#folderParam.notHavingDocTypeCode}) "
			+ " AND ( cast(:receiveDateFrom as date) IS NULL OR dm.createdAt >= cast( :receiveDateFrom as date) ) "
			+ " AND ( cast(:receiveDateTo as date) IS NULL OR dm.createdAt <= cast( :receiveDateTo as date) ) "
			+ " AND ( cast(:shareDateFrom as date) IS NULL OR sb.createdAt >= cast( :shareDateFrom as date) ) "
			+ " AND ( cast(:shareDateTo as date) IS NULL OR sb.createdAt <= cast( :shareDateTo as date) ) "
			+ " AND ( :#{#folderParam.shareBy} IS NULL OR sb.sharedBy = :#{#folderParam.shareBy} ) "
			+ " AND ( :#{#folderParam.shareWith} IS NULL OR sw.shareWithName = :#{#folderParam.shareWith} ) "
			+ " AND ( :textSearch IS NULL OR (LOWER(dm.clientAccountNo) LIKE CONCAT('%',LOWER(:textSearch ),'%')) "
			+ " OR (LOWER(dm.originalAccountNo) LIKE CONCAT('%',LOWER(:textSearch),'%')) "
			+ " OR ( CAST( dm.equabliAccountNo AS string) LIKE CONCAT('%',:textSearch,'%'))"
			+ " OR (LOWER(dm.docTypeCode) LIKE CONCAT('%',LOWER(:textSearch),'%')) "
			+ " OR (LOWER(sb.sharedBy) LIKE CONCAT('%',LOWER(:textSearch),'%')) "
			+ " OR (LOWER(sw.shareWithName) LIKE CONCAT('%',LOWER(:textSearch),'%')) ) " 
			+ " GROUP BY dm.clientAccountNo ")
	public List<FolderResponse> groupByClientAccountNoList(@Param("orgCode") String orgCode,
			@Param("folderParam") DocumentForldersSearchParam folderParam, @Param("textSearch") String textSearch,
			@Param("receiveDateFrom") LocalDateTime receiveDateFrom, @Param("receiveDateTo") LocalDateTime receiveDateTo, 
			@Param("shareDateFrom") LocalDateTime shareDateFrom, @Param("shareDateTo") LocalDateTime shareDateTo);

	@Query(value = "SELECT dm.objKey FROM Document as dm "
			+ " LEFT JOIN com.equabli.common.entity.SendReceiveDocument as sd ON sd.fullfilledDocumentId.id = dm.id AND sd.sentRequestOrgCode = :orgCode "
			+ " where (dm.orgCode = :orgCode OR sd.sentRequestOrgCode = :orgCode) AND dm.isDelete = false AND dm.clientAccountNo = :clientAccountNumber ")
	public List<String> getObjectKeyByClientAccountNumber(@Param("orgCode") String orgCode, @Param("clientAccountNumber") String clientAccountNumber);

	@Query(value = "SELECT dm.objKey FROM Document as dm where dm.orgCode = ?1 AND dm.isDelete = false AND dm.equabliAccountNo = ?2  ")
	public List<String> getObjectKeyByEquabliAccountNo(String orgCode, String equabliAccountNo);

	@Query(value = "SELECT dm.objKey FROM Document as dm where dm.orgCode = ?1 AND dm.isDelete = false AND dm.originalAccountNo = ?2  ")
	public List<String> getObjectKeyByOriginalAccountNo(String orgCode, String originalAccountNo);

	@Query(value = "SELECT dm.objKey FROM Document as dm where dm.orgCode = ?1 AND dm.isOthers = true  AND dm.isDelete = false ")
	public List<String> getObjectKeyByOther(String orgCode);

	@Query(value = "SELECT DISTINCT(dm.clientAccountNo) "
			+ " FROM Document as dm where dm.orgCode = :orgCode AND dm.isOthers = false AND dm.isDelete = false "
			+ " AND dm.productCode IN (:requiredProductCode) "
			+ " AND dm.clientAccountNo IS NOT NULL " 
			+ " AND dm.docTypeCode = :docTypeCode AND dm.updatedAt >= :startDate AND dm.updatedAt <= :endDate "
			+ " AND (:productCode IS NULL OR dm.productCode = :productCode) "
			+ " AND (:userId IS NULL OR dm.userId = :userId ) AND (:clientAccountNumber IS NULL OR dm.clientAccountNo = :clientAccountNumber) "
			+ " GROUP BY dm.clientAccountNo")
	public List<String> getCompletedDocumentSummary(@Param("orgCode") String orgCode,
			@Param("requiredProductCode") List<String> requiredProductCode, @Param("docTypeCode") String docTypeCode,
			@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate,
			@Param("userId") Long userId, @Param("clientAccountNumber") String clientAccountNumber,
			@Param("productCode") String productCode);

	@Query(value = "SELECT DISTINCT(dm.clientAccountNo) "
			+ " FROM Document as dm where dm.orgCode = ?1 AND dm.isOthers = false AND dm.isDelete = false "
			+ " AND dm.clientAccountNo IS NOT NULL " + " AND dm.updatedAt >= ?3 AND dm.updatedAt <= ?4 "
			+ " AND dm.productCode IN (?7) "
			+ " AND (?5 IS NULL OR dm.userId = ?5) AND (?6 IS NULL OR dm.clientAccountNo = ?6) "
			+ " AND (?2 IS NULL OR dm.productCode = ?2) GROUP BY dm.clientAccountNo")
	public List<String> getTotalDocumentSummary(String orgCode, String productCode,
			LocalDateTime startDate, LocalDateTime endDate, Long userId, String clientAccountNumber, List<String> requiredProductCode);
	
	public List<Document> findByClientAccountNoAndIsDeleteFalse(String clientAccountNo);

	@Query(value = "SELECT DISTINCT(dm.clientAccountNo) "
			+ " FROM Document as dm where dm.isOthers = false AND dm.isDelete = false AND dm.userId = ?1 AND dm.productCode IS NOT NULL"
			+ " AND dm.clientAccountNo IS NOT NULL ")
	public List<String> getClientAccountNumber(Long userId);

	@Query(value = "SELECT dm FROM Document as dm where "
			+ " dm.isOthers = false AND dm.isDelete = false AND dm.orgCode = :orgCode "
			+ " AND dm.docTypeCode = :docTypeCode AND dm.updatedAt >= :startDate AND dm.updatedAt <= :endDate AND dm.productCode IS NOT NULL "
			+ " AND dm.clientAccountNo IS NOT NULL "
			+ " AND ( (:accounts) IS NULL OR dm.clientAccountNo IN (:accounts)) "
			+ " AND (:userId IS NULL OR dm.userId = :userId ) AND (:clientAccountNo IS NULL OR dm.clientAccountNo = :clientAccountNo ) "
			+ " AND (:productCode IS NULL OR dm.productCode = :productCode) "
			+ " AND ( LOWER(dm.clientAccountNo) LIKE CONCAT ('%',LOWER(:search),'%') "
			+ " OR LOWER(dm.originalAccountNo) LIKE CONCAT ('%',LOWER(:search),'%') "
			+ " OR LOWER( CAST( dm.equabliAccountNo AS text)) LIKE CONCAT('%',LOWER(:search),'%') "
			+ " OR LOWER(dm.generatedFileName) LIKE CONCAT ('%',LOWER(:search),'%') " + " ) "
			+ " AND ( :#{#documentId.empty? T(java.util.Arrays).asList(null) : #documentId} IS NULL OR dm.id IN (:documentId) )")
	Page<Document> getDocumentList(@Param("orgCode") String orgCode, @Param("docTypeCode") String docTypeCode, @Param("search") String search, 
			@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate, @Param("userId") Long userId, 
			@Param("clientAccountNo") String clientAccountNo, @Param("productCode") String productCode, @Param("accounts") List<String> accounts, 
			@Param("documentId") List<Long> documentId, Pageable pageable);
	
	@Query(value = "SELECT MAX(dm.id) FROM Document as dm where "
			+ " dm.isOthers = false AND dm.isDelete = false AND dm.orgCode = ?1 "
			+ " AND dm.docTypeCode = ?2 AND dm.updatedAt >= ?4 AND dm.updatedAt <= ?5 AND dm.productCode IS NOT NULL "
			+ " AND dm.clientAccountNo IS NOT NULL " 
			+ " AND ( (?9) IS NULL OR dm.clientAccountNo IN (?9)) "
			+ " AND (?6 IS NULL OR dm.userId = ?6) AND (?7 IS NULL OR dm.clientAccountNo = ?7 ) "
			+ " AND (?8 IS NULL OR dm.productCode = ?8) "
			+ " AND ( ?3 IS NULL OR LOWER(dm.clientAccountNo) LIKE CONCAT ('%',LOWER(?3),'%') "
			+ " OR LOWER(dm.originalAccountNo) LIKE CONCAT ('%',LOWER(?3),'%') "
			+ " OR LOWER( CAST( dm.equabliAccountNo AS text)) LIKE CONCAT('%',LOWER(?3),'%') "
			+ " OR LOWER(dm.generatedFileName) LIKE CONCAT ('%',LOWER(?3),'%') " + " )"
			+ " GROUP BY dm.clientAccountNo ")
	List<Long> getDocumentids(String orgCode, String docTypeCode, String search, LocalDateTime startDate,
			LocalDateTime endDate, Long userId, String clientAccountNo, String productCode, List<String> accounts);

	@Query(value = "SELECT DISTINCT(dm.productCode) "
			+ " FROM Document as dm where dm.clientAccountNo = ?1 AND dm.isDelete = false AND dm.productCode IS NOT NULL")
	public List<String> findProductCodeDistinctByClientAccountNo(String clientAccountNo);

	public List<Document> findByReceiveFileNameAndIsDeleteFalse(String fileName);
	
	public List<Document> findByUserIdAndOrgTypeCodeAndOrgCodeAndClientAccountNoInAndIsDeleteFalse(Long userId,
			String orgTypeCode, String orgCode, List<String> clientAccountNo);
	
	public List<Document> findByUserIdAndOrgTypeCodeAndOrgCodeAndClientAccountNoAndIsDeleteFalse(Long userId,
			String orgTypeCode, String orgCode, String clientAccountNo);

	public List<Document> getAllByIdIn(List<Long> documentIdList);

	public List<Document> findByClientAccountNoAndReceiveFileNameAndIsDeleteFalse(String accountNo, String fileName);

	@Query(value = "SELECT dm FROM Document as dm WHERE dm.clientAccountNo = ?1 AND dm.orgCode = ?2 AND dm.isDelete = false ")
	public List<Document> getDocumentList(String clientAccountNo, String orgCode);

	@Query(value = "SELECT new com.equabli.common.response.DocumentDetailsResponse(dm.objKey as objKey, dm.fileSize as docSize) "
			+ " FROM Document as dm "
			+ " LEFT JOIN com.equabli.common.entity.SendReceiveDocument as sd ON sd.fullfilledDocumentId.id = dm.id AND sd.sentRequestOrgCode = :orgCode "
			+ " where (dm.orgCode = :orgCode OR sd.sentRequestOrgCode = :orgCode) AND dm.isDelete = false AND dm.clientAccountNo = :clientAccountNumber ")
	public List<DocumentDetailsResponse> getByClientAcountNoAndOrgCode(String clientAccountNumber, String orgCode);

	@Query(value = "SELECT new com.equabli.common.response.DocumentDetailsResponse(dm.objKey as objKey, dm.fileSize as docSize) "
			+ " FROM Document as dm where dm.orgCode = ?1 AND dm.isOthers = true  AND dm.isDelete = false ")
	public List<DocumentDetailsResponse> getDocumentsByOther(String orgCode);

	//public List<Document> findByClientAccountNoAndOrgCodeAndIsDeleteFalse(String clientAccountNumber, String shortName);

	public List<Document> findByClientAccountNoAndClientOrgCodeAndIsDeleteFalse(String clientAccountNumber,
			String clientOrgCode);

	public List<Document> findByIdAndIsDeleteFalse(Long id);

	public List<Document> findByClientAccountNoAndOrgCodeAndIsDeleteFalse(String accountNumber, String userOrgCode);

	public List<Document> findByClientAccountNoAndClientOrgCodeAndOrgCodeAndIsDeleteFalse(
			String clientAccountNumber, String clientShortCode, String partnerOrgCode);

	@Query(value = "SELECT DISTINCT dm.orgCode from Document dm where dm.isDelete = false and dm.clientAccountNo is not null group by dm.orgCode ")
	public List<String> groupByOrgcode();
	
	@Query(value = "SELECT dm.clientAccountNo FROM Document as dm where dm.orgCode = ?1 AND dm.clientAccountNo IS NOT NULL AND dm.isDelete = false "
			+ " GROUP BY dm.clientAccountNo ")
	public List<String> groupByClientAccountNoByOrgCode(String orgCode);

	public List<Document> findByClientAccountNoAndClientOrgCodeAndOrgTypeCodeAndIsDeleteFalse(String account,
			String clientOrgCode, String partnerTypeCode);
}
