package com.equabli.common.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductResponse {

	@Schema(description = "Short code of product", example = "CR")
	private String shortName;
	
	@Schema(description = "Name of product", example = "CR")
	private String fullName;

	@Schema(description = "document description")
	private String description;
	
	private Integer debtcategoryId;
}
