package com.equabli.common.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.equabli.common.entity.DocCost;

@Repository
public interface DocCostRepository extends JpaRepository<DocCost, Long> {

	Page<DocCost> findByOrgCodeAndCostNotNullAndIsDeleteFalse(String orgCode, Pageable pageable);

	Optional<DocCost> findByOrgCodeAndDocTypeCodeAndIsDeleteFalse(String orgCode, String docTypeCode);

	Optional<DocCost> findByDocTypeCodeAndIsDeleteFalse(String docTypeCode);
}
