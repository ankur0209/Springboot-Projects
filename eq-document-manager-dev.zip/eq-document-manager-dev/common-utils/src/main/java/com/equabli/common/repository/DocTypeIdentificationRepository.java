package com.equabli.common.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.equabli.common.entity.DocTypeIdentification;

@Repository
public interface DocTypeIdentificationRepository extends JpaRepository<DocTypeIdentification, Long> {

	Optional<DocTypeIdentification> findByDocType_ShortCode(String docTypeShorCode);

	@Query(value = "SELECT di FROM DocTypeIdentification as di where di.isDelete = FALSE"
			+ " AND ( :docType IS NULL OR LOWER(di.docType.name) LIKE CONCAT ('%',LOWER(:docType),'%') ) ")
	Page<DocTypeIdentification> getDocumentTypeIdentification(@Param("docType") String docType, Pageable pageable);
	
	List<DocTypeIdentification> findByIsDeleteFalseOrderByUpdatedAtDesc();
}
