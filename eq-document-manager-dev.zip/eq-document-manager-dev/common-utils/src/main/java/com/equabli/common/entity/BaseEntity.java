package com.equabli.common.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;

@MappedSuperclass
@Getter
public class BaseEntity {

	@Column(name = "dtm_utc_create", columnDefinition = "TIMESTAMP WITH TIME ZONE")
	@CreationTimestamp
	private LocalDateTime createdAt;

	@Column(name = "dtm_utc_update", columnDefinition = "TIMESTAMP WITH TIME ZONE")
	@UpdateTimestamp
	private LocalDateTime updatedAt;

	@Column(name = "dtm_utc_delete", columnDefinition = "TIMESTAMP WITH TIME ZONE")
	private LocalDateTime deletedAt;

	@Column(length = 50)
	private String createdBy;

	@Column(length = 50)
	private String updatedBy;

	@Column(length = 50)
	private String deletedBy;

	@Column(length = 10)
	private String recordStatusCode;
	
	@Column(length = 10)
	private String recordSourceCode;
	
	@Column(length = 10)
	private String appCode;
	
	private String ipAddress;
	private String macAddress;
	
	private Boolean isDelete;

	public BaseEntity() {
	}

	public BaseEntity(LocalDateTime createdAt, LocalDateTime updatedAt) {
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
	}
	
	protected void delete(boolean isDelete) {
		this.deletedAt= LocalDateTime.now();
		this.isDelete = isDelete;
	}
	
	protected void create(String createdBy) {
		this.createdBy = createdBy;
	}
	
	protected void update(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	protected void delete(boolean isDelete, String deletedBy) {
		this.deletedAt= LocalDateTime.now();
		this.isDelete = isDelete;
		this.deletedBy = deletedBy;
	}
	
	protected void updateRecordStatus(String recordStatusCode, String updatedBy) {
		this.updatedAt = LocalDateTime.now();
		this.recordStatusCode = recordStatusCode;
		this.updatedBy = updatedBy;
	}
}
