package com.equabli.common.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.equabli.common.entity.ShowHideColumn;

@Repository
public interface ShowHideColumnRepository extends JpaRepository<ShowHideColumn, Long> {

	Optional<ShowHideColumn> findByUserIdAndTableName(Long orgCode, String tableName);
}
