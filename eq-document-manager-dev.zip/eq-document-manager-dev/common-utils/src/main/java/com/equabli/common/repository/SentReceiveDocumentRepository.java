package com.equabli.common.repository;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import com.equabli.common.entity.SendReceiveDocument;

@Repository
public interface SentReceiveDocumentRepository
		extends JpaRepository<SendReceiveDocument, Long>, QuerydslPredicateExecutor<SendReceiveDocument> {

	@Query(value = "SELECT sd FROM SendReceiveDocument as sd where "
			+ " sd.isDelete = FALSE AND sd.originalAccountNo = ?1 AND sd.clientAccountNo = ?2 "
			+ " AND sd.docTypeCode = ?3 AND sd.receiveRequestUserId = ?4 ")
	Optional<SendReceiveDocument> getBySendReceiveDocument(String originalAccountNo, String clientAccountNo,
			String docTypeCode, Long receiveRequestUserId);

	Integer countBySentRequestOrgCodeAndRequestStatusAndIsDeleteFalse(String orgCode, String requestStatus);

	Integer countBySentRequestOrgCodeAndRequestStatusAndRequestedAtLessThanAndIsDeleteFalse(String orgCode,
			String requestStatus, LocalDateTime requestedAt);
	
	
	Integer countByReceiveRequestOrgCodeAndRequestStatusAndIsDeleteFalse(String orgCode, String requestStatus);

	Integer countByReceiveRequestOrgCodeAndRequestStatusAndRequestedAtLessThanAndIsDeleteFalse(String orgCode,
			String requestStatus, LocalDateTime requestedAt);
	
	@Query(value = "SELECT sd FROM SendReceiveDocument as sd where "
			+ " sd.isDelete = FALSE AND sd.sentRequestUserId = ?1 "
			+ " AND ( "
			+ " LOWER(sd.clientAccountNo) LIKE CONCAT ('%',LOWER(?2),'%') "
			+ " OR LOWER(sd.documentName) LIKE CONCAT ('%',LOWER(?2),'%') "
			+ " OR LOWER(sd.originalAccountNo) LIKE CONCAT ('%',LOWER(?2),'%') "
			+ " OR LOWER(sd.requestedTo) LIKE CONCAT ('%',LOWER(?2),'%') "
			+ " OR LOWER(sd.requestStatus) LIKE CONCAT ('%',LOWER(?2),'%') "
			+ " OR LOWER(sd.documentType) LIKE CONCAT ('%',LOWER(?2),'%') "
			+ " OR LOWER(sd.originalAccountNo) LIKE CONCAT ('%',LOWER(?2),'%') "
			+ " OR LOWER(CAST(sd.equabliAccNo AS text) ) LIKE CONCAT ('%',LOWER(?2),'%') "
			+ " ) ")
	Page<SendReceiveDocument> getSendReceiveDocumentList(Long sentRequestUserId, String search, Pageable pageable);
	
	@Query(value = "SELECT sd FROM SendReceiveDocument as sd where "
			+ " sd.isDelete = FALSE AND sd.clientAccountNo = ?1 AND sd.docTypeCode = ?2 AND sd.receiveRequestUserId = ?3 ")
	Optional<SendReceiveDocument> getBySendReceiveDocument(String clientAccountNo, String docTypeCode,
			Long receiveRequestUserId);
	
	@Query(value = "SELECT MAX(sd.fullfilledOn) as receiveDate FROM SendReceiveDocument as sd "
			+ "join Document as dm on dm.id = sd.fullfilledDocumentId "
			+ "where sd.isDelete = false and dm.id = ?1")
	public LocalDateTime getReceiveDateById(Long id);
	
	@Query(value = "SELECT MAX(sd.fullfilledOn) as receiveDate FROM SendReceiveDocument as sd "
			+ "join Document as dm on dm.id = sd.fullfilledDocumentId "
			+ "where sd.isDelete = false and dm.clientAccountNo = ?1")
	public LocalDateTime getReceiveDateByClientAccountNo(String accountNo);
	
	@Query(value = "SELECT COUNT(id) FROM SendReceiveDocument as sd where "
			+ " sd.isDelete = FALSE AND sd.sentRequestOrgCode = ?1 "
			+ " AND (?2 IS NULL OR LOWER(sd.requestStatus) = LOWER(?2)) "
			+ " AND sd.requestedAt >= ?3 AND sd.requestedAt <= ?4 "
			+ " AND (?5 IS NULL OR sd.sentRequestUserId = ?5) "
			+ " AND (?6 IS NULL OR sd.clientAccountNo = ?6) AND sd.requestedAt < ?7 AND (?8 IS NULL OR sd.productCode = ?8) ")
	Integer countBySentRequestOrgCodeAndIsDeleteFalse(String userOrgCode, String requestStatus, LocalDateTime firstDay,
			LocalDateTime lastDay, Long userId, String portfolio, LocalDateTime localDateTime, String prodCode);
	
	@Query(value = "SELECT COUNT(id) FROM SendReceiveDocument as sd where "
			+ " sd.isDelete = FALSE AND sd.sentRequestOrgCode = ?1 "
			+ " AND (?2 IS NULL OR LOWER(sd.requestStatus) = LOWER(?2)) "
			+ " AND sd.requestedAt >= ?3 AND sd.requestedAt <= ?4 "
			+ " AND (?5 IS NULL OR sd.sentRequestUserId = ?5) AND (?6 IS NULL OR sd.clientAccountNo = ?6) "
			+ " AND (?7 IS NULL OR sd.productCode = ?7) ")
	Integer countBySentRequestOrgCodeAndIsDeleteFalse(String userOrgCode, String requestStatus, LocalDateTime firstDay,
			LocalDateTime lastDay, Long userId, String portfolio, String prodCode);
	
	@Query(value = "SELECT COUNT(id) FROM SendReceiveDocument as sd where "
			+ " sd.isDelete = FALSE AND sd.receiveRequestOrgCode = ?1 "
			+ " AND (?2 IS NULL OR LOWER(sd.requestStatus) = LOWER(?2)) "
			+ " AND sd.requestedAt >= ?3 AND sd.requestedAt <= ?4 "
			+ " AND (?5 IS NULL OR sd.receiveRequestUserId = ?5) "
			+ " AND (?6 IS NULL OR sd.clientAccountNo = ?6) AND sd.requestedAt < ?7 AND (?8 IS NULL OR sd.productCode = ?8) ")
	Integer countByReceiveRequestOrgCodeAndIsDeleteFalse(String userOrgCode, String requestStatus, LocalDateTime firstDay,
			LocalDateTime lastDay, Long userId, String portfolio, LocalDateTime localDateTime, String prodCode);
	
	@Query(value = "SELECT COUNT(id) FROM SendReceiveDocument as sd where "
			+ " sd.isDelete = FALSE AND sd.receiveRequestOrgCode = ?1 "
			+ " AND (?2 IS NULL OR LOWER(sd.requestStatus) = LOWER(?2)) "
			+ " AND sd.requestedAt >= ?3 AND sd.requestedAt <= ?4 "
			+ " AND (?5 IS NULL OR sd.receiveRequestUserId = ?5) AND (?6 IS NULL OR sd.clientAccountNo = ?6) "
			+ " AND (?7 IS NULL OR sd.productCode = ?7) ")
	Integer countByReceiveRequestOrgCodeAndIsDeleteFalse(String userOrgCode, String requestStatus, LocalDateTime firstDay,
			LocalDateTime lastDay, Long userId, String portfolio, String prodCode);
	
	@Query(value = "SELECT sd FROM SendReceiveDocument as sd where "
			+ " sd.isDelete = FALSE AND sd.docTypeCode = ?1 AND sd.clientAccountNo = ?2 "
			+ " AND sd.receiveRequestOrgCode = ?3 AND sd.receiveRequestOrgTypeCode = ?4 AND sd.receiveRequestUserId = ?5 "
			+ " AND sd.requestStatus = ?6 ")
	Optional<SendReceiveDocument> getReciveveRequestData(String docTypeCode, String clientAccountNo, String userOrgCode,
			String orgType, Long principleId, String status);
}
