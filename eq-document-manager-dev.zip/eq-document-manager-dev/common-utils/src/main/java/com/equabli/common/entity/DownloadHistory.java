package com.equabli.common.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;
import com.equabli.common.enums.DownloadStatusEnum;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Table(name = "download_history", schema = Constants.DOCUMENT_SCHEMAS)
@Entity
@Getter
@NoArgsConstructor
public class DownloadHistory extends BaseEntity{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "download_history_id")
	private Long id;
	
	@ManyToOne
	@JoinColumn(name = "document_id")
	private Document document;
	
	@Column(length = 10)
	private String docTypeCode;
	
	@Column(length = 10)
	private String productCode;
	
	private Long userId;
	@Column(length = 2)
	private String orgTypeCode;
	@Column(length = 10)
	private String orgCode;
	
	private String otherMailId;
	private Long docSize;
	
	@Column(name="dtm_utc_download" ,columnDefinition= "TIMESTAMP WITH TIME ZONE")
	private LocalDateTime downloadAt;
	
	@Enumerated(EnumType.STRING)
	private DownloadStatusEnum downloadStatus;
	
	private Integer downloadPercentage;
	private String downloadedBy;
	
	public void saveDocumentDownloadHistory(DownloadHistory downloadHistory, Document document, TokenData tokenData) {
		downloadHistory.document = document;
		downloadHistory.docTypeCode = document.getDocTypeCode();
		downloadHistory.productCode = document.getProductCode();
		downloadHistory.docSize = document.getFileSize();
		downloadHistory.downloadAt = LocalDateTime.now();
		downloadHistory.downloadStatus = DownloadStatusEnum.PENDING;
		downloadHistory.delete(false);
		
		downloadHistory.userId = tokenData.getPrincipleId();
		downloadHistory.orgTypeCode = tokenData.getOrgType();
		downloadHistory.orgCode = tokenData.getUserOrgCode();
		if (downloadHistory.getId() == null)
			downloadHistory.create(tokenData.getFirstName());
		else
			downloadHistory.update(tokenData.getFirstName());
	}

	public void deleteDownloadHistory(DownloadHistory downloadHistory) {
		downloadHistory.delete(true);
	}
	
	public void updateDownloadStatus(DownloadHistory downloadHistory, DownloadStatusEnum status, TokenData tokenData) {
		downloadHistory.downloadStatus = status;
		downloadHistory.delete(false);
		
		downloadHistory.userId = tokenData.getPrincipleId();
		downloadHistory.orgTypeCode = tokenData.getOrgType();
		downloadHistory.orgCode = tokenData.getUserOrgCode();
		if (downloadHistory.getId() == null)
			downloadHistory.create(tokenData.getFirstName());
		else
			downloadHistory.update(tokenData.getFirstName());
	}
}
