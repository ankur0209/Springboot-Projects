package com.equabli.common.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "Token response from Config service")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TokenValidateResponse {

	private Boolean validation;
	private String error;
	private String message;
	private List<UserTokenResponse> response;
}
