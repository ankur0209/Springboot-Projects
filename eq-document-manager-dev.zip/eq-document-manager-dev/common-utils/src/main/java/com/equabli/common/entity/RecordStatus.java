package com.equabli.common.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.equabli.common.constants.Constants;

import lombok.Getter;

@Table(name = "record_status", schema = Constants.CONF_SCHEMAS)
@Entity
@Getter
public class RecordStatus {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "record_status_id")
	private Short id;

	@Column(length = 10)
	private String shortCode;

	@Column(length = 15)
	private String shortName;

	@Column(length = 200)
	private String description;

	@Column(name = "dtm_utc_create", columnDefinition = "TIMESTAMP WITH TIME ZONE")
	@CreationTimestamp
	private LocalDateTime createdAt;

	@Column(name = "dtm_utc_update", columnDefinition = "TIMESTAMP WITH TIME ZONE")
	@UpdateTimestamp
	private LocalDateTime updatedAt;

	@Column(length = 50)
	private String createdBy;

	@Column(length = 50)
	private String updatedBy;
}
