package com.equabli.common.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;
import com.equabli.common.request.FileUploadConfigRequest;

import lombok.Getter;

@Table(name = "document", schema = Constants.DOCUMENT_SCHEMAS)
@Entity
@Getter
public class Document extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "document_id")
	private Long id;

	@Column(length = 10)
	private String clientOrgCode;

	private Long userId;
	@Column(length = 2)
	private String orgTypeCode;
	@Column(length = 10)
	private String orgCode;

	private Long actionByUserId;
	@Column(length = 2)
	private String actionByOrgTypeCode;
	@Column(length = 10)
	private String actionByOrgCode;

	@Column(length = 10)
	private String docTypeCode;
	@Column(length = 10)
	private String productCode;

	private Long portfolioId;
	private String documentName;

	@Column(name = "dtm_document_generation_date")
	private LocalDateTime documentGenerationDate;

	private String receiveFileName;
	private String generatedFileName;
	@Column(columnDefinition = "TEXT")
	private String generatedFilePath;

	@Column(length = 1000)
	private String objKey;

	@Column(length = 50)
	private String originalAccountNo;

	@Column(length = 50)
	private String clientAccountNo;
	private Long equabliAccountNo;

	private Boolean isOthers;
	private String otherReason;
	private Long fileSize;

	public void saveDocument(Document document, FileUploadConfigRequest fileUploadVo, Boolean isOther, String reason,
			String docName, TokenData tokenData, TokenData actionby) {
		document.docTypeCode = fileUploadVo.getDocType();
		document.productCode = fileUploadVo.getProductCode();
		document.documentName = docName;
		document.portfolioId = fileUploadVo.getPortfolioId();
		document.documentGenerationDate = fileUploadVo.getDocumentGenerationDate() == null ? LocalDateTime.now()
				: fileUploadVo.getDocumentGenerationDate();
		document.receiveFileName = fileUploadVo.getFileName();
		document.fileSize = fileUploadVo.getFileSize();
		document.originalAccountNo = fileUploadVo.getOriginalAccountNo();
		document.clientAccountNo = fileUploadVo.getClientAccountNo();
		document.equabliAccountNo = fileUploadVo.getEquabliAccNo();
		document.isOthers = isOther;
		document.otherReason = reason;
		document.delete(false);

		document.userId = tokenData.getPrincipleId();
		document.orgTypeCode = tokenData.getOrgType();
		document.orgCode = tokenData.getUserOrgCode();
		if (document.getId() == null)
			document.create(tokenData.getFirstName());
		else
			document.update(tokenData.getFirstName());

		document.actionByUserId = actionby.getPrincipleId();
		document.actionByOrgTypeCode = actionby.getOrgType();
		document.actionByOrgCode = actionby.getUserOrgCode();

		document.generatedFileName = fileUploadVo.getGeneratedFileName();
		document.clientOrgCode = Constants.CLIENT_CODE.equals(tokenData.getOrgType()) ? tokenData.getUserOrgCode() : "";
	}

	public void saveObjectKey(Document document, String objectKey, String generatedFilePath) {
		document.objKey = objectKey;
		document.generatedFilePath = generatedFilePath;
	}

	public void deleteDocument(Document document, TokenData tokenData) {
		document.delete(true, tokenData.getFirstName());
	}

	/**
	 * Save Document
	 * 
	 * @param document
	 * @param tokenData
	 * @param actionby
	 * @param docTypeCode
	 * @param productCode
	 * @param documentName
	 * @param receiveFileName
	 * @param fileSize
	 * @param clientAccountNumber
	 */
	public void saveDocument(Document document, TokenData tokenData, TokenData actionby, String docTypeCode,
			String productCode, String documentName, String receiveFileName, Long fileSize, String clientAccountNumber,
			String objectKey, String generatedFileName) {
		document.docTypeCode = docTypeCode;
		document.productCode = productCode;
		document.documentName = documentName;
		document.receiveFileName = receiveFileName;
		document.generatedFileName = generatedFileName;
		document.fileSize = fileSize;
		document.clientAccountNo = clientAccountNumber;
		document.objKey = objectKey;
		document.generatedFilePath = objectKey;
		document.isOthers = false;
		document.delete(false);

		document.userId = tokenData.getPrincipleId();
		document.orgTypeCode = tokenData.getOrgType();
		document.orgCode = tokenData.getUserOrgCode();
		if (document.getId() == null)
			document.create(tokenData.getFirstName());
		else
			document.update(tokenData.getFirstName());

		document.actionByUserId = actionby.getPrincipleId();
		document.actionByOrgTypeCode = actionby.getOrgType();
		document.actionByOrgCode = actionby.getUserOrgCode();
	}

	/**
	 * Copy Document
	 * 
	 * @param fromDocument
	 * @param toDocument
	 * @param userId
	 * @param orgTypeCode
	 * @param orgCode
	 * @param actionby
	 */
	public void saveDocument(Document fromDocument, Document toDocument, Long userId, String orgTypeCode,
			String orgCode, TokenData actionby) {

		toDocument.userId = userId;
		toDocument.orgTypeCode = orgTypeCode;
		toDocument.orgCode = orgCode;
		toDocument.actionByUserId = actionby.getPrincipleId();
		toDocument.actionByOrgTypeCode = actionby.getOrgType();
		toDocument.actionByOrgCode = actionby.getUserOrgCode();
		if (toDocument.getId() == null)
			toDocument.create(actionby.getFirstName());
		else
			toDocument.update(actionby.getFirstName());

		toDocument.docTypeCode = fromDocument.docTypeCode;
		toDocument.productCode = fromDocument.productCode;
		toDocument.portfolioId = fromDocument.portfolioId;
		toDocument.documentName = fromDocument.documentName;
		toDocument.documentGenerationDate = fromDocument.documentGenerationDate;
		toDocument.receiveFileName = fromDocument.receiveFileName;
		toDocument.generatedFileName = fromDocument.generatedFileName;
		toDocument.generatedFilePath = fromDocument.generatedFilePath;
		toDocument.objKey = fromDocument.objKey;
		toDocument.originalAccountNo = fromDocument.originalAccountNo;
		toDocument.clientAccountNo = fromDocument.clientAccountNo;
		toDocument.equabliAccountNo = fromDocument.equabliAccountNo;
		toDocument.isOthers = fromDocument.isOthers;
		toDocument.otherReason = fromDocument.otherReason;
		toDocument.fileSize = fromDocument.fileSize;
		toDocument.delete(false);
	}

	public void revokeDocument(Document document) {
		document.delete(false);
	}

	public void reAssignDocument(Document document, TokenData tokenData, long userId, String orgCode, String fileName,
			String clientShortCode) {
//		document.equabliAccountNo = equabliAccountNo;
		document.userId = userId;
		document.orgTypeCode = Constants.PARTNER_CODE;
		document.orgCode = orgCode;
		document.actionByUserId = tokenData.getPrincipleId();
		document.actionByOrgTypeCode = tokenData.getOrgType();
		document.actionByOrgCode = tokenData.getUserOrgCode();
		if (document.getId() == null)
			document.create(tokenData.getFirstName());
		else
			document.update(tokenData.getFirstName());

		document.clientOrgCode = clientShortCode;
		document.generatedFileName = fileName;
	}

	public void assignDocument(Document document, TokenData actionby, Long userId, String orgTypeCode, String orgCode) {
		document.userId = userId;
		document.orgTypeCode = orgTypeCode;
		document.orgCode = orgCode;
		if (document.getId() == null)
			document.create(actionby.getFirstName());
		else
			document.update(actionby.getFirstName());

		document.actionByUserId = actionby.getPrincipleId();
		document.actionByOrgTypeCode = actionby.getOrgType();
		document.actionByOrgCode = actionby.getUserOrgCode();
		document.isOthers = false;
		document.otherReason = "";
		document.delete(false);
	}

	/**
	 * Update the document RecordStatus
	 * 
	 * @param document
	 * @param tokenData
	 * @param actionBy
	 * @param recordStatusCode
	 */
	public void updateDocumentRecordStatus(Document document, TokenData actionBy, String recordStatusCode) {
		document.updateRecordStatus(recordStatusCode, actionBy.getFirstName());
		document.delete(true, actionBy.getFirstName());
		document.actionByUserId = actionBy.getPrincipleId();
		document.actionByOrgTypeCode = actionBy.getOrgType();
		document.actionByOrgCode = actionBy.getUserOrgCode();
	}

	/**
	 * 
	 * @param document
	 * @param actionBy
	 * @param orgTypeCode
	 * @param orgCode
	 * @param docTypecode
	 * @param documentType
	 * @param clientOrgCode
	 */
	public void updateDocument(Document document, TokenData actionBy, String orgTypeCode, String orgCode,
			String docTypecode, String documentType, String clientOrgCode) {
		document.orgTypeCode = orgTypeCode;
		document.orgCode = orgCode;
		document.docTypeCode = docTypecode;
		document.documentName = documentType;
		document.clientOrgCode = clientOrgCode;
		document.documentSetAction(document, actionBy);
		document.delete(false);
		document.isOthers = false;
	}

	public void documentSetAccountNumber(Document document, String clientAccountNumber, Long equabliAccountNumber,
			String originalAccountNumber, String productCode) {
		document.clientAccountNo = clientAccountNumber;
		document.equabliAccountNo = equabliAccountNumber;
		document.originalAccountNo = originalAccountNumber;
		document.productCode = productCode;
	}

	public void documentSetAction(Document document, TokenData actionBy) {
		document.actionByUserId = actionBy.getPrincipleId();
		document.actionByOrgTypeCode = actionBy.getOrgType();
		document.actionByOrgCode = actionBy.getUserOrgCode();
		if (document.getId() == null)
			document.create(actionBy.getFirstName());
		else
			document.update(actionBy.getFirstName());
	}

	public void documentSetFileName(Document document, String receiveFileName, String generatedFileName,
			Long fileSize) {
		document.receiveFileName = receiveFileName;
		document.generatedFileName = generatedFileName;
		document.fileSize = fileSize;
	}

	public void documentSetOthers(Document document, String otherReason, boolean isOther) {
		document.isOthers = isOther;
		document.otherReason = otherReason;
	}
}
