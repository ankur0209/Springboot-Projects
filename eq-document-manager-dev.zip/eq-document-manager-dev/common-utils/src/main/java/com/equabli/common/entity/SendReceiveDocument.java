package com.equabli.common.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;
import com.equabli.common.enums.DocumentRequestStatusEnum;
import com.equabli.common.request.RequestNewDocumentRequest;
import com.equabli.common.response.UserDetails;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Table(name = "send_receive_document", schema = Constants.DOCUMENT_SCHEMAS)
@Entity
@Getter
@NoArgsConstructor
public class SendReceiveDocument extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "send_receive_document_id")
	private Long id;

	@Column(length = 10)
	private String docTypeCode;

	@Column(length = 10)
	private String productCode;

	private String documentName;

	@Column(length = 50)
	private String originalAccountNo;
	@Column(length = 50)
	private String clientAccountNo;
	private Long equabliAccNo;

	private Long actionByUserId;
	@Column(length = 2)
	private String actionByOrgTypeCode;
	@Column(length = 10)
	private String actionByOrgCode;

	private Long sentRequestUserId;
	@Column(length = 2)
	private String sentRequestOrgTypeCode;
	@Column(length = 10)
	private String sentRequestOrgCode;

	private Long receiveRequestUserId;
	@Column(length = 2)
	private String receiveRequestOrgTypeCode;
	@Column(length = 10)
	private String receiveRequestOrgCode;

	@Column(name = "dtm_utc_fullfilled_on", columnDefinition = "TIMESTAMP WITH TIME ZONE")
	private LocalDateTime fullfilledOn;

	@OneToOne
	@JoinColumn(name = "fullfilled_document_id")
	private Document fullfilledDocumentId;

	@Column(name = "dtm_utc_requested", columnDefinition = "TIMESTAMP WITH TIME ZONE")
	private LocalDateTime requestedAt;

	@Column(name = "dtm_utc_due_on", columnDefinition = "TIMESTAMP WITH TIME ZONE")
	private LocalDateTime dueOnAt;

	private String requestedTo;
	private String requestedBy;

	private String requestStatus;
	private String documentType;

	public void saveSendReceiveDocument(SendReceiveDocument sendReceiveDocument,
			RequestNewDocumentRequest requestNewDoc, DocumentRequestStatusEnum documentRequestStatusEnum,
			TokenData loggedInUser, TokenData sentRequestBy, UserDetails userDetails, Integer documentOverDue) {

		sendReceiveDocument.documentType = requestNewDoc.getDocumentType();
		sendReceiveDocument.docTypeCode = requestNewDoc.getDocTypeCode();
		sendReceiveDocument.requestedAt = LocalDateTime.now();
		sendReceiveDocument.dueOnAt = LocalDateTime.now().plusDays(documentOverDue);
		sendReceiveDocument.originalAccountNo = requestNewDoc.getOriginalAccountNumber();
		sendReceiveDocument.clientAccountNo = requestNewDoc.getClientAccountNumber();
		sendReceiveDocument.equabliAccNo = requestNewDoc.getEquabliAccountNumber();
		sendReceiveDocument.requestStatus = documentRequestStatusEnum.getRequestStatus();
		sendReceiveDocument.delete(false);

		sendReceiveDocument.actionByUserId = loggedInUser.getPrincipleId();
		sendReceiveDocument.actionByOrgTypeCode = loggedInUser.getOrgType();
		sendReceiveDocument.actionByOrgCode = loggedInUser.getUserOrgCode();
		if (sendReceiveDocument.getId() == null)
			sendReceiveDocument.create(loggedInUser.getFirstName());
		else
			sendReceiveDocument.update(loggedInUser.getFirstName());

		sendReceiveDocument.sentRequestUserId = sentRequestBy.getPrincipleId();
		sendReceiveDocument.sentRequestOrgTypeCode = sentRequestBy.getOrgType();
		sendReceiveDocument.sentRequestOrgCode = sentRequestBy.getUserOrgCode();
		sendReceiveDocument.requestedBy = sentRequestBy.getFirstName();

		sendReceiveDocument.requestedTo = userDetails.getFirstName();
		sendReceiveDocument.receiveRequestUserId = userDetails.getPrincipleId();
		sendReceiveDocument.receiveRequestOrgTypeCode = userDetails.getOrgType();
		sendReceiveDocument.receiveRequestOrgCode = userDetails.getOrgCode();

	}

	public void deleteSendReceiveDocument(SendReceiveDocument sendReceiveDocument, TokenData tokenData) {
		sendReceiveDocument.delete(true, tokenData.getFirstName());
	}

	public void updateSendReceiveDocument(SendReceiveDocument sendReceiveDocument, Document document,
			DocumentRequestStatusEnum documentRequestStatusEnum, TokenData tokenData, TokenData receiveRequestBy) {
		sendReceiveDocument.productCode = document.getProductCode();
		sendReceiveDocument.documentName = document.getGeneratedFileName();
		sendReceiveDocument.fullfilledOn = LocalDateTime.now();
		sendReceiveDocument.fullfilledDocumentId = document;
		sendReceiveDocument.requestStatus = documentRequestStatusEnum.getRequestStatus();

		sendReceiveDocument.actionByUserId = tokenData.getPrincipleId();
		sendReceiveDocument.actionByOrgTypeCode = tokenData.getOrgType();
		sendReceiveDocument.actionByOrgCode = tokenData.getUserOrgCode();
		if (sendReceiveDocument.getId() == null)
			sendReceiveDocument.create(tokenData.getFirstName());
		else
			sendReceiveDocument.update(tokenData.getFirstName());

		sendReceiveDocument.receiveRequestUserId = tokenData.getPrincipleId();
		sendReceiveDocument.receiveRequestOrgTypeCode = receiveRequestBy.getOrgType();
		sendReceiveDocument.receiveRequestOrgCode = tokenData.getUserOrgCode();
	}
}
