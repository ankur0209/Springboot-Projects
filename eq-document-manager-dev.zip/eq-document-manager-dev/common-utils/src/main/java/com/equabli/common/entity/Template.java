package com.equabli.common.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.equabli.common.constants.Constants;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Table(name = "templates", schema = Constants.CONF_SCHEMAS)
@Entity
@Getter
@NoArgsConstructor
public class Template extends BaseEntity{

	@Id
	@GeneratedValue(strategy =  GenerationType.IDENTITY)
	@Column(name = "template_id")
	private Long id;
	
	private String shortCode;
	private String name;
	private String description;
	private Boolean isSignRequired;
	private String fileKey;
	private String fileName;
	private String fileType;
}
