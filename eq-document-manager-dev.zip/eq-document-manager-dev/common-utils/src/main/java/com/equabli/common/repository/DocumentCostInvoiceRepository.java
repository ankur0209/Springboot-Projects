package com.equabli.common.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.equabli.common.entity.DocumentCostInvoice;
import com.equabli.common.request.DocumentCostInvoicerData;
import com.equabli.common.response.DocumentCostInvoiceConfig;

@Repository
public interface DocumentCostInvoiceRepository extends JpaRepository<DocumentCostInvoice, UUID> {

	@Query(value = "SELECT dci FROM DocumentCostInvoice as dci where "
			+ " dci.isDelete = FALSE AND dci.docTypeCode = ?1 "
			+ " AND dci.partnerOrgCode = ?2 AND dci.partnerOrgTypeCode = ?3 ")
	Optional<DocumentCostInvoice> getDocumentCostInvoice(String docTypeCode, String userOrgCode, String orgType);

	@Query(value = "SELECT new com.equabli.common.response.DocumentCostInvoiceConfig( dsi.partnerOrgCode ,SUM(dsi.docCost) )"
			+ " FROM DocumentCostInvoice dsi "
			+ " WHERE dsi.isDelete = false AND dsi.clientOrgTypeCode = ?1 AND dsi.clientOrgCode = ?2 "
			+ " AND dsi.createdAt >= ?3 AND dsi.createdAt <= ?4 "
			+ " group by dsi.partnerOrgCode ")
	List<DocumentCostInvoiceConfig> groupByDocumentCostForClient(String orgType, String userOrgCode,
			LocalDateTime startDate, LocalDateTime endDate);

	@Query(value = "SELECT new com.equabli.common.response.DocumentCostInvoiceConfig( dsi.partnerOrgCode ,SUM(dsi.docCost) )"
			+ " FROM DocumentCostInvoice dsi "
			+ " WHERE dsi.isDelete = false AND dsi.partnerOrgTypeCode = ?1 AND dsi.partnerOrgCode = ?2 "
			+ " AND dsi.createdAt >= ?3 AND dsi.createdAt <= ?4 "
			+ " group by dsi.partnerOrgCode ")
	List<DocumentCostInvoiceConfig> groupByDocumentCostForPartner(String orgType, String userOrgCode,
			LocalDateTime startDate, LocalDateTime endDate);

	@Query(value = "SELECT dsi.partnerOrgCode" + " FROM DocumentCostInvoice dsi "
			+ " WHERE dsi.isDelete = false AND dsi.clientOrgTypeCode = ?1 AND dsi.clientOrgCode = ?2"
			+ " group by dsi.partnerOrgCode ")
	List<String> getPartnerOrgCodeForClient(String orgType, String userOrgCode);

	@Query(value = "SELECT new com.equabli.common.request.DocumentCostInvoicerData( srd.documentName, srd.documentType, "
			+ " srd.fullfilledOn, dsi.docSize, srd.requestedTo, dsi.docCost, srd.requestedTo, srd.receiveRequestUserId ) "
			+ " FROM DocumentCostInvoice dsi " + " JOIN SendReceiveDocument srd ON srd.id = dsi.sendReceiveDocument "
			+ " WHERE dsi.isDelete = false AND dsi.partnerOrgCode = ?1 AND srd.isDelete = false "
			+ " AND dsi.createdAt >= ?2 AND dsi.createdAt <= ?3 AND dsi.docCost != 0 ")
	List<DocumentCostInvoicerData> documentCostInvoiceDataForClient(String userOrgCode, LocalDateTime startDay, LocalDateTime endDay);

	@Query(value = "SELECT dsi.partnerOrgCode" + " FROM DocumentCostInvoice dsi "
			+ " WHERE dsi.isDelete = false AND dsi.clientOrgTypeCode = ?1 AND dsi.clientOrgCode = ?2"
			+ " group by dsi.partnerOrgCode ")
	List<String> getPartnerOrgCodeForEquabli(String orgType, String userOrgCode);
}
