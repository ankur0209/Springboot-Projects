package com.equabli.common.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "User Mail response from User service")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountValidateResponse {

	private Boolean validation;
	private String error;
	private String message;
	private List<AccountValidateDetail> response;
}
