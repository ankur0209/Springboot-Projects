package com.equabli.common.auth;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.PublicKey;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProjectAuthKeys {
	public static PublicKey privateKey = null;
//	static ObjectMapper mapper = new ObjectMapper();
//	static ClassLoader classLoader = ProjectAuthKeys.class.getClassLoader();

	 public static final int DEFAULT_BUFFER_SIZE = 8192;

	  private  void copyInputStreamToFile(InputStream inputStream, File file)
	            throws IOException {

	        // append = false
	        try (FileOutputStream outputStream = new FileOutputStream(file, false)) {
	            int read;
	            byte[] bytes = new byte[DEFAULT_BUFFER_SIZE];
	            while ((read = inputStream.read(bytes)) != -1) {
	                outputStream.write(bytes, 0, read);
	            }
	        }

	    }
	  
	@PostConstruct
	public void privateAndPublicKeyReader() {
		JWKSet publicKeys = null;
		try {
			log.info("File Temp privateAndPublicKeyReader ");   
			File file = null;
			file = new File(System.getProperty("java.io.tmpdir")+"/"+"tempcert.json");
			log.info("File Temp "+file.getAbsolutePath());   
	        try {
				copyInputStreamToFile(this.getClass().getClassLoader().getResourceAsStream("cert.json"), file);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
	        log.info("Loading Public Keys "+file.getAbsolutePath());   
			publicKeys = JWKSet.load(file);
		} catch (Exception el) {
			log.error("Error Getting ",el);
			el.printStackTrace();
		}
		RSAKey rsaKey =  (RSAKey) publicKeys.getKeys().get(0);

		privateKey = null;
		try {
			privateKey = rsaKey.toRSAPublicKey();
		} catch (JOSEException e) {
			e.printStackTrace();
		}
	}
}