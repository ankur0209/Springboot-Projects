package com.equabli.common.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Schema(description = "")
@Getter
@Setter
public class DocumentCostInvoiceConfig {

	String partnerName;
	String amountPay;
	
	public DocumentCostInvoiceConfig(String partnerName, double amountpay) {
		this.partnerName = partnerName;
		this.amountPay = String.valueOf(amountpay);
	}
}
