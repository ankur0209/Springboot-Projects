package com.equabli.common.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DocumentSummaryResponse {
	private String clientAccountNumber;
	private String productCode;
	private String docTypeCode;
	
	public DocumentSummaryResponse(String clientAccountNumber) {
		this.clientAccountNumber = clientAccountNumber;
	}
}
