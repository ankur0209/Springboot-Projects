package com.equabli.common.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RequireDocResponse {
	private String productCode;
	private String docTypeCode;
	private String documentType;
}
