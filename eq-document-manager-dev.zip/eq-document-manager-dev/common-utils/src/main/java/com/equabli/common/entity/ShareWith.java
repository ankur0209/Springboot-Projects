package com.equabli.common.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;
import com.equabli.common.enums.DocumentShareTypeEnum;
import com.equabli.common.request.ShareUserDetailRequest;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Table(name = "share_with", schema = Constants.DOCUMENT_SCHEMAS)
@Entity
@Getter
@NoArgsConstructor
public class ShareWith extends BaseEntity{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "share_with_id")
	private Long id;
	
	@ManyToOne
	@JoinColumn(name = "share_by_id")
	private ShareBy shareById;
	
	
	private Long userId;
	@Column(length = 2)
	private String orgTypeCode;
	@Column(length = 10)
	private String orgCode;
	
	private String sharedWithEmailId;
	private Boolean isRegisteredUser;
	
	@Enumerated(EnumType.STRING)
	private DocumentShareTypeEnum sharedType; 
	
	@Column(name="dtm_utc_unshared" ,columnDefinition= "TIMESTAMP WITH TIME ZONE")
	private LocalDateTime unsharedAt;
	
	@Column(name="dtm_utc_archived" ,columnDefinition= "TIMESTAMP WITH TIME ZONE")
	private LocalDateTime archivedAt;
	
	private Boolean isUnshared;
	private Boolean isArchived;
	
	private String shareWithName;
	@Column(length = 2)
	private String shareWithOrgTypeCode;
	@Column(length = 10)
	private String shareWithUserOrgCode;
	
	
	
	public void saveShareWith(ShareWith shareWith, ShareBy shareBy, TokenData tokenData, DocumentShareTypeEnum file,
			ShareUserDetailRequest detail) {
		shareWith.shareById = shareBy;
		shareWith.userId = detail.getPrincipleId();
		shareWith.orgTypeCode = detail.getOrgType();
		shareWith.orgCode = detail.getUserOrgCode();
		if(shareWith.getId() == null)
			shareWith.create(tokenData.getFirstName());
		else
			shareWith.update(tokenData.getFirstName());
		
		shareWith.sharedWithEmailId = detail.getEmail();
		shareWith.isRegisteredUser = detail.getIsRegisterUser();
		shareWith.shareWithName = (detail.getName() == null || detail.getName().isEmpty()) ? detail.getEmail()
				: detail.getName();
		shareWith.shareWithOrgTypeCode = detail.getOrgType();
		shareWith.shareWithUserOrgCode = detail.getUserOrgCode();
		
		shareWith.sharedType = file;
		shareWith.isUnshared = false;
		shareWith.isArchived = false;
		shareWith.delete(false);
	}
	
	public void saveUnShareWith(ShareWith shareWith) {
		shareWith.unsharedAt = LocalDateTime.now();
		shareWith.isUnshared = true;
		shareWith.delete(false);
	}
}
