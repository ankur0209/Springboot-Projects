package com.equabli.common.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.equabli.common.entity.DocType;

@Repository
public interface DocTypeRepository extends JpaRepository<DocType, Long> {
	Optional<DocType> findByShortCode(String shortName);

	List<DocType> findByShortCodeIn(List<String> shortName);
}
