package com.equabli.common.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "Product response from Config service")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductValidateResponse {

	private Boolean validation;
	private String error;
	private String message;
	private List<ProductResponse> response;
}
