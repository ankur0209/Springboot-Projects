package com.equabli.common.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.equabli.common.entity.ShareBy;
import com.equabli.common.response.ShareByWithResponse;

@Repository
public interface ShareByRepository extends JpaRepository<ShareBy, Long>{

	Optional<ShareBy> findByDocumentId(Long id);
	List<ShareBy> findByDocumentIdAndIsUnsharedFalse(Long id);
	Optional<ShareBy> findByUserIdAndDocumentId(Long principleId, Long id);
	
	@Query(value ="select MAX(sharedAt) as shareDate from ShareBy as sb where sb.documentId = ?1 and sb.isUnshared = false")
	LocalDateTime getByDocumentIdAndIsUnsharedFalse(Long id);
	
	@Query(value = "select new com.equabli.common.response.ShareByWithResponse("
			+ " sb.sharedBy as name, sb.actionByOrgCode, sb.actionByOrgTypeCode, sb.userId) from ShareBy as sb "
			+ " join Document as dm on dm.id = sb.documentId "
			+ " where dm.clientAccountNo = ?1 "
			+ " group by sb.sharedBy, sb.actionByOrgCode, sb.actionByOrgTypeCode, sb.userId")
	List<ShareByWithResponse> getByClientAcountNo(String clientAccountNo);
	
	@Query(value = "select MAX(sb.sharedAt) as shareAt from ShareBy as sb "
			+ " join Document as dm on dm.id = sb.documentId "
			+ " where dm.clientAccountNo = ?1 ")
	LocalDateTime getShareAtByClientAcountNo(String clientAccountNo);
}
