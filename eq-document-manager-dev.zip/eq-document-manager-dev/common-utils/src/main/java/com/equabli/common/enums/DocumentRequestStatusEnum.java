package com.equabli.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum DocumentRequestStatusEnum {

	FULFILLED("Fulfilled", "Document request is fulfilled"),
	OPEN("Open", "Document request is open"),
	OVERDUE("OverDue", "Document request is overdue");

	private final String requestStatus;
	private final String description;

}
