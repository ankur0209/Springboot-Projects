package com.equabli.common.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;
import com.equabli.common.enums.DocumentShareTypeEnum;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Table(name = "share_by", schema = Constants.DOCUMENT_SCHEMAS)
@Entity
@Getter
@NoArgsConstructor
public class ShareBy extends BaseEntity{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "share_by_id")
	private Long id;
	
	@Column(length = 10)
	private String docTypeCode;
	@Column(length = 10)
	private String productCode;
	
	private Long userId;
	@Column(length = 2)
	private String orgTypeCode;
	@Column(length = 10)
	private String orgCode;
	
	private Long actionByUserId;
	@Column(length = 2)
	private String actionByOrgTypeCode;
	@Column(length = 10)
	private String actionByOrgCode;
	
	@Column(length = 50)
	private String sharedBy;
	
	@Enumerated(EnumType.STRING)
	private DocumentShareTypeEnum sharedType; 
	
	private String sharedText;
	private Integer portfolioId;
	private String clientAccountNo;
	private String orgAccountNo;
	
	private Long documentId;
	
	@Column(name="dtm_utc_shared" ,columnDefinition= "TIMESTAMP WITH TIME ZONE")
	private LocalDateTime sharedAt;
	
	private Boolean isUnshared;
	private Boolean isArchived;
	
	@Column(name="dtm_utc_unshared" ,columnDefinition= "TIMESTAMP WITH TIME ZONE")
	private LocalDateTime unsharedAt;

	public void saveShareBy(ShareBy shareBy, Document document, TokenData tokenData, TokenData actionBy,
			DocumentShareTypeEnum shareType) {
		shareBy.docTypeCode = document.getDocTypeCode();
		shareBy.productCode = document.getProductCode();
		
		shareBy.userId = tokenData.getPrincipleId();
		shareBy.orgTypeCode = tokenData.getOrgType();
		shareBy.orgCode = tokenData.getUserOrgCode();
		if(shareBy.getId() == null)
			shareBy.create(tokenData.getFirstName());
		else
			shareBy.update(tokenData.getFirstName());
		
		shareBy.actionByUserId = actionBy.getPrincipleId();
		shareBy.actionByOrgTypeCode = actionBy.getOrgType();
		shareBy.actionByOrgCode = actionBy.getUserOrgCode();
		
		shareBy.sharedBy = tokenData.getFirstName();
		shareBy.sharedType = shareType;
		shareBy.clientAccountNo = document.getClientAccountNo();
		shareBy.orgAccountNo = document.getOriginalAccountNo();
		shareBy.documentId = document.getId();
		shareBy.sharedAt = LocalDateTime.now();
		shareBy.isUnshared = false;
		shareBy.isArchived = false;
		shareBy.delete(false);
	}
	
	public void saveUnShareBy(ShareBy shareBy) {
		shareBy.isUnshared = true;
		shareBy.unsharedAt = LocalDateTime.now();
		shareBy.delete(false);
	}
}
