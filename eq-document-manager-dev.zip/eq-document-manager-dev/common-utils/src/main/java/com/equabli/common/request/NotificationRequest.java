package com.equabli.common.request;

import java.util.Map;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NotificationRequest {

	private Long userId;
	private String orgCode;
	private String orgTypeCode;
	private String title;
	private String message;
	private Map<String, Object> dataMap;
}
