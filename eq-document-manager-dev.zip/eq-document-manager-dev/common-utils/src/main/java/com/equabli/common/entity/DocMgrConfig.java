package com.equabli.common.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.equabli.common.constants.Constants;

import lombok.Getter;

@Table(name = "doc_mgr_config", schema = Constants.CONF_SCHEMAS)
@Entity
@Getter
public class DocMgrConfig extends BaseEntity{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "doc_mgr_config_id")
	private Long id;
	
	private String shortCode;
	private String description;
	private String defaultValue;
	
	@Column(length = 2)
	private String orgTypeCode;
}
