package com.equabli.common.constants;

public final class MessageConstants {
	
	public static final String NOT_VALID = "not.valid";
	public static final String INVALID_DATA = "invalid.data";
	public static final String NOT_NULL = "not.null";
	public static final String USER_TYPE = "User Type"; 
	public static final String NOT_VALID_ID = "not.valid.id";
	public static final String SUCCESS_MESSAGE = "Data update successfully";
	public static final String INVALID_USER = "Other";
	public static final String INVALID_FILE = "Upload file is not valid according to file filenaming";
	public static final String DOCUMENT_TYPE = "Document Type";
	public static final String NOT_VALID_SHORT_CODE = "not.valid.short.code";
	public static final String NOT_VALID_EMAIL_ADDRESS = "not.valid.email.address";
	
	public static final String DOC_MGR_CONFIG = "DocMgrConfig";
	public static final String DOC_MGR_CONFIG_VAL = "DocMgrConfigVal";
	
	public static final String DATE_FORMATE = "MM/dd/yyyy";
	public static final String DATE_FORMATE_EX = "01/26/2023";
	
	public final class PageConstants {
		private PageConstants() {
		}

		public static final String DEFAULT_PAGE_NUMBER = "0";
		public static final String DEFAULT_PAGE_SIZE = "10";
		public static final String DEFAULT_SORT_BY = "id";
		public static final String DEFAULT_SORT_DIRECTION = "asc";
	}
	
	
	public final class AuthConstants {


		public static final String MISSING_TOKEN = "authorization.token.missing";
		public static final String TOKEN_EXPIRED = "authorization.token.expired";
		public static final String MISSING_BEARER = "authorization.token.missing.bearer";
		public static final String INVALID_LOGIN_KEY = "authorization.token.invalid.login.key";
		public static final String USER_LOGIN_INVALID_CREDENTIALS = "user.login.invalid.credentials";

	}
	
	public final class UploadFileConstants{
		private UploadFileConstants() {}
		
		public static final String CLIENT = "Client";
		public static final String PARTNER = "Partner";
		public static final String THIRDPARTY = "3rdParty";
		public static final String OTHER = "Other";
		public static final String MEDIA = "Media";
		public static final String BULK = "Bulk";
		public static final String DOCUMENT = "Document";
		public static final String DOWNLOAD_ZIP = "download";
	}
	
	public final class Subscription {
		private Subscription() {
		}
		
		/**
		 * Subscription plan keyvalue in lookup group table
		 */
		public static final String SUBSCRIPTION_TYPE = "subscription_type";
		/**
		 * Default subscription plan key code
		 */
		public static final String SUBSCRIPTION_KEY_CODE = "BT";
		
		public static final String SUBSCRIPTION_FETCH_SUCCESS = "subscription.fetch.success";
		public static final String SUBSCRIPTION_UPDATE_SUCCESS = "subscription.update.success";
	}
	
	public static final String NOT_VALID_ACCOUNT_NUMBER = "not.valid.account.number";
}
