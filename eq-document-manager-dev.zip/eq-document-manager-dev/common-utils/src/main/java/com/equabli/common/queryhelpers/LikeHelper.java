package com.equabli.common.queryhelpers;

public class LikeHelper {

	private LikeHelper() {
	}

	public static String startsWith(String value) {
		if (value == null) {
			return null;
		} else if (value.isEmpty()) {
			return value;
		}

		return value + '%';
	}

	public static String endsWith(String value) {
		if (value == null) {
			return null;
		} else if (value.isEmpty()) {
			return value;
		}

		return '%' + value;
	}

	public static String anyPosition(String value) {
		if (value == null) {
			return null;
		} else if (value.isEmpty()) {
			return value;
		}

		return '%' + value + '%';
	}
}