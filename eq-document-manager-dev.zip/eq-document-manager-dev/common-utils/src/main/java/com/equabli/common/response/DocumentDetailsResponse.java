package com.equabli.common.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "Fetch list of folder for user type")
@Data
public class DocumentDetailsResponse {

	private String documentPath;
	private Long docSize;
	
	public DocumentDetailsResponse(String documentPath, Long size) {
		this.documentPath = documentPath;
		this.docSize = size;
	}
}
