package com.equabli.common.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.equabli.common.entity.DocMgrConfig;

@Repository
public interface DocMgrConfigRepository extends JpaRepository<com.equabli.common.entity.DocMgrConfig, Long> {

	public List<DocMgrConfig> findByOrgTypeCodeAndShortCodeStartsWithOrderByShortCode(String orgTypeCode, String shortCode);
	
	public Optional<DocMgrConfig> findByShortCodeAndOrgTypeCode(String shortCode, String orgTypeCode);
}
