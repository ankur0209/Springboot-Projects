package com.equabli.common.configs;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;

import com.equabli.common.constants.Constants;
import com.equabli.common.entity.RecordStatus;
import com.equabli.common.enums.RecordStatusCode;
import com.equabli.common.feignclients.CommonConfigService;
import com.equabli.common.repository.RecordStatusRepository;
import com.equabli.common.response.ClientSubscription;
import com.equabli.common.response.config.ConfigResponse;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class BaseConfigService {

	@Autowired
	private RecordStatusRepository recordStatusRepository;

	@Autowired
	private CommonConfigService commonConfigService;

	private Map<String, RecordStatus> recordStatusByCode;
	private Map<String, ClientSubscription> subscriptionByClientShortCode;

	@PostConstruct
	public void loadBaseConfig() {
		loadRecordStatusData();
		loadClientSubscriptions();
	}

	private void loadRecordStatusData() {
		List<RecordStatus> recordStatuses = recordStatusRepository.findAll();
		recordStatusByCode = recordStatuses.stream()
				.collect(Collectors.toMap(RecordStatus::getShortCode, confRecordStatus -> confRecordStatus));
		log.info("recordStatusByCode {}", recordStatusByCode);
	}

	public void loadClientSubscriptions() {
		try {
			ResponseEntity<ConfigResponse<List<ClientSubscription>>> clientSubscribedResponse = commonConfigService
					.getSubscribedClientDetail("true", Constants.EQ_INTEGRATION);
			log.info("loadClientSubscriptions clientSubscribedResponse {}", clientSubscribedResponse);
			
			if (clientSubscribedResponse.getStatusCode().is2xxSuccessful()) {
				ConfigResponse<List<ClientSubscription>> clientSubscriptions = clientSubscribedResponse.getBody();
				if (clientSubscriptions != null) {
					subscriptionByClientShortCode = clientSubscriptions.getResponse().parallelStream()
							.collect(Collectors.toMap(ClientSubscription::getShortName, client -> client));
					return;
				}
			}
		} catch (Exception e) {
			log.error("ERROR WHILE FETCHING loadClientSubscriptions -> {}", e.getMessage(), e);
		}
		subscriptionByClientShortCode = Collections.emptyMap();
	}

	public RecordStatus getRecordStatusByShortCode(RecordStatusCode recordSourceCode) {
		return recordStatusByCode.get(recordSourceCode.getShortCode());
	}

	public Map<String, ClientSubscription> getClientSubscriptionResponse(List<String> clientShortCode) {
		return subscriptionByClientShortCode.entrySet().stream()
				.filter(entry -> clientShortCode.contains(entry.getKey()))
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
	}

}
