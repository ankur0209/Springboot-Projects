package com.equabli.common.configs;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import io.opentracing.Span;
import io.opentracing.Tracer;
import io.opentracing.propagation.Format;
import io.opentracing.propagation.TextMapAdapter;

public class JaegerFeignInterceptor implements RequestInterceptor {

	private final Tracer tracer;

	@Autowired
	public JaegerFeignInterceptor(Tracer tracer) {
		this.tracer = tracer;
	}

	@Override
	public void apply(RequestTemplate template) {
		Span span = tracer.activeSpan();
		if (span != null) {
			Map<String, String> headers = new HashMap<>();
			tracer.inject(span.context(), Format.Builtin.HTTP_HEADERS, new TextMapAdapter(headers));
			headers.forEach(template::header);
		}
	}
}