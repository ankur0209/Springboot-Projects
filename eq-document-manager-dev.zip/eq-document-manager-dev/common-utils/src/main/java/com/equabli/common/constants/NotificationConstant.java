package com.equabli.common.constants;

public final class NotificationConstant {

	private NotificationConstant() {
	}
	
	public static final String TITLE = "title";
	public static final String MESSAGE = "message";
	public static final String TOKEN = "token";
	
	public static final String TYPE = "type";
	public static final String ACCOUNT = "account";
	public static final String BODY = "body";
	public static final String DOCUMENT_TYPE = "documentType";
	public static final String ORG_CODE = "orgCode";
	public static final String ORG_TYPE_CODE = "orgTypeCode";
	
	
	public static final String DOCUMENT_REQUEST = "request";
	public static final String SHARE_DOCUMENT = "share";
	public static final String FULLFILL_DOCUMENT = "fulfillment";
	public static final String UPLOAD_DOCUMENT = "upload";
	
	public static final String DATA_NOT_FOUND = "data.not.found";
	public static final String NOTIFICATION_READ_SUCCESS = "notification.read.success";
	
	public static final String SHARE_FILE_NOTIFICATIO_BODY_MESSAGE = "share.file.notification.body.message";
	public static final String SHARE_FOLDER_NOTIFICATIO_BODY_MESSAGE = "share.folder.notification.body.message";
	public static final String UPLOAD_NOTIFICATIO_BODY_MESSAGE = "upload.notification.body.message";
	public static final String FULLFILL_NOTIFICATIO_BODY_MESSAGE = "fullfill.notification.body.message";
	public static final String REQUEST_NOTIFICATIO_BODY_MESSAGE = "request.notification.body.message";
	
	public static final String TOKEN_EVICT_CACHE_CONST = "UserTokenResponse";
	
	public static final String DOWNLOAD_STARTED_BODY_MESSAGE = "download.started.body.message";
	public static final String DOWNLOAD_READY_BODY_MESSAGE = "download.ready.body.message";
	public static final String DOWNLOAD_DOCUMENT = "download";
	
}
