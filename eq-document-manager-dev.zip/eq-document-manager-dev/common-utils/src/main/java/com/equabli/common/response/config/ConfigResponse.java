package com.equabli.common.response.config;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Schema(description = "Resonse of Config service, representing response if all inputs were valid or Errors")
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
public class ConfigResponse<T> {

	public enum OperationStatus {
		SUCCESS, FAILURE, BUSINESS_FAILURE, UNAUTHORIZED, USER_NOT_REGISTERED;
	}

	@Schema(description = "Any relevant message related to the overall state of operation")
	private String message;

	@Schema(description = "Status of operation, either SUCCESS or FAILURE")
	private OperationStatus status;

	@Schema(description = "Any entity or data associated with success of operation")
	private T response;

	@Schema(description = "is Request is valid or not")
	private boolean validation;

	@Schema(description = "Errors if we have mutiple error")
	private List<CustomError> error;

	public static <T> ConfigResponse<T> failure(String message, List<CustomError> errors) {
		return new ConfigResponse<>(message, OperationStatus.FAILURE, null, false, errors);
	}
	
	public ConfigResponse(String message, OperationStatus status, T response, final boolean valid,
			final List<CustomError> errors) {
		this.message = message;
		this.status = status;
		this.response = response;
		this.validation = valid;
		this.error = errors;
	}
}
