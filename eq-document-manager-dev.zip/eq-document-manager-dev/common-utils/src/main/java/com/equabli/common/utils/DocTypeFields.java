package com.equabli.common.utils;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "User Document configuaration pojo for the Document type identification")
public class DocTypeFields {

	private List<String> docFields;
}
