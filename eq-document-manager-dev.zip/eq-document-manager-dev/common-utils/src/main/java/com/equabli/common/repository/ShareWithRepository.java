package com.equabli.common.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.equabli.common.entity.ShareWith;
import com.equabli.common.response.ShareByWithResponse;

@Repository
public interface ShareWithRepository extends JpaRepository<ShareWith, Long>{

	Optional<ShareWith> findByShareById_IdAndSharedWithEmailId(Long id, String email);
	List<ShareWith> getByShareById_Id(Long id);
	List<ShareWith> getByShareById_IdAndIsUnsharedFalse(Long id);
	
	@Query(value ="select sw from ShareWith as sw where sw.shareById.documentId = ?1 and sw.isUnshared = false")
	List<ShareWith> getByShareWithDocumentId(Long documentId);
	
	List<ShareWith> findBySharedWithEmailId(String email);
	
	@Query(value = "select new com.equabli.common.response.ShareByWithResponse("
			+ " sw.shareWithName as name, sw.sharedWithEmailId as email , sw.shareWithUserOrgCode as orgCode, sw.shareWithOrgTypeCode as orgTypeCode, sw.userId) "
			+ " from ShareWith as sw "
			+ " join ShareBy as sb on sb.id = sw.shareById " + "join Document as dm on dm.id = sb.documentId "
			+ " where dm.clientAccountNo = ?1 AND sw.isUnshared = false"
			+ " group by sw.shareWithName, sw.sharedWithEmailId, sw.shareWithUserOrgCode, sw.shareWithOrgTypeCode, sw.userId")
	List<ShareByWithResponse> getByClientAcountNo(String clientAccountNo);
}
