package com.equabli.common.configs;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class SecretConfig {


	private String dbDriver;
	private String dbURL;
	private String dbUser;
	private String dbPassword;
	private String awsAccessKey;
	private String awsSecretKey;
	private String region;
}
