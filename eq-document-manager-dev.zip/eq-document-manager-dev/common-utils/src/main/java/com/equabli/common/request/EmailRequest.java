package com.equabli.common.request;

import java.util.List;
import java.util.Map;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EmailRequest {


	@Schema(description = "To whom this mail needs to send ")
    private List<String> recipients;
    
    @Schema(description = "Subject of email ",example = "Sending Testing mail")
    private String subject;
    
    @Schema(description = "Template name of email ",example = "sample-template.html")
    private String templateName;
    @Schema(description = "Salutations of mail to Send ",example = "Steve")
    private String salutations;
    	@Schema(description = "parameters to be used in template ")
    private Map<String, Object> parameters;
    private List<String> blindCCRecipients;
    private List<String> carbonCopyRecipients;
}
