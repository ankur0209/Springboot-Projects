INSERT INTO conf.doc_type(dtm_utc_create, name, description, short_code)
    VALUES (NOW(), 'Application', 'Application', 'AP'),
    (NOW(), 'Bill of Sale', 'Bill of Sale', 'BS'),
    (NOW(), 'Business Record Affidavit', 'Business Record Affidavit', 'BRA'),
    (NOW(), 'Military Affidavit', 'Military Affidavit', 'MA'),
    (NOW(), 'Transaction History', 'Transaction History', 'TH');
    
INSERT INTO conf.doc_mgr_config(short_code, description, org_type_code, default_value, dtm_utc_create)
    VALUES ('field1', '', 'CL', 'Client Account Number', NOW()),
    ('field2', '', 'CL', 'Product Code', NOW()),
    ('field3', '', 'CL', 'Document Type ID', NOW()),
    ('field4', '', 'CL', 'Original Account Number', NOW()),
    ('field5', '', 'CL', 'Document Generation Date', NOW()),
    ('field6', '', 'CL', 'Document Name', NOW());
    
    
INSERT INTO conf.doc_mgr_config(
    short_code, description, org_type_code, default_value, dtm_utc_create)
    VALUES ('SEPARATOR', 'file seperator', 'CL', 'Underscore[_]', NOW()),
    ('RP', 'retention policy in day', 'CL', '60', NOW()),
    ('DP', 'Specify document policy like allow create new document or replace', 'CL', 'Keep Both File', NOW());

-- For Partner
INSERT INTO conf.doc_mgr_config(
    short_code, description, org_type_code, default_value, dtm_utc_create)
    VALUES ('field1', '', 'PT', 'Client ID or Client Short Code', NOW()),
    ('field2', '', 'PT', 'Product Code', NOW()),
    ('field3', '', 'PT', 'Document Type ID', NOW()),
    ('field4', '', 'PT', 'Client Account Number', NOW()),
    ('field5', '', 'PT', 'Original Account Number', NOW()),
    ('field6', '', 'PT', 'Document Generation Date', NOW()),
    ('field7', '', 'PT', 'Document Name', NOW());

INSERT INTO conf.doc_mgr_config(
    short_code, description, org_type_code, default_value, dtm_utc_create)
    VALUES ('SEPARATOR', 'file seperator', 'PT', 'Underscore[_]', NOW());


--- For 3rd Party


INSERT INTO conf.doc_mgr_config(
    short_code, description, org_type_code, default_value, dtm_utc_create)
    VALUES ('field1', '', 'TP', 'Client ID or Client Short Code', NOW()),
    ('field2', '', 'TP', 'Product Code', NOW()),
    ('field3', '', 'TP', 'Document Type ID', NOW()),
    ('field4', '', 'TP', 'Client Account Number', NOW()),
    ('field5', '', 'TP', 'Original Account Number', NOW()),
    ('field6', '', 'TP', 'Document Generation Date', NOW()),
    ('field7', '', 'TP', 'Document Name', NOW());

INSERT INTO conf.doc_mgr_config(
    short_code, description, org_type_code, default_value, dtm_utc_create)
    VALUES ('SEPARATOR', 'file seperator', 'TP', 'Underscore[_]', NOW());


--=============== Client =================
INSERT INTO conf.doc_mgr_config_val(doc_mgr_config_id, short_code, description, dtm_utc_create, field_value)
 VALUES ((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'CL'),'CAN', 'client account number', NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'CL'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'CL'),'OAN', 'Original account number', NOW(), 'Orignal Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'CL'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'CL'),'DN', 'Document Name', NOW(), 'Document Name'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'CL'),'PC', 'Product Code', NOW(), 'Product Code'),

((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'CL'),'CAN', 'client account number', NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'CL'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'CL'),'OAN', 'Original account number', NOW(), 'Orignal Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'CL'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'CL'),'DN', 'Document Name', NOW(), 'Document Name'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'CL'),'PC', 'Product Code', NOW(), 'Product Code'),


((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'CL'),'CAN', 'client account number', NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'CL'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'CL'),'OAN', 'Original account number', NOW(), 'Orignal Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'CL'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'CL'),'DN', 'Document Name', NOW(), 'Document Name'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'CL'),'PC', 'Product Code', NOW(), 'Product Code'),


((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'CL'),'CAN', 'client account number', NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'CL'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'CL'),'OAN', 'Original account number', NOW(), 'Orignal Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'CL'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'CL'),'DN', 'Document Name', NOW(), 'Document Name'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'CL'),'PC', 'Product Code', NOW(), 'Product Code'),


((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'CL'),'CAN', 'client account number', NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'CL'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'CL'),'OAN', 'Original account number', NOW(), 'Orignal Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'CL'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'CL'),'DN', 'Document Name', NOW(), 'Document Name'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'CL'),'PC', 'Product Code', NOW(), 'Product Code'),



((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'CL'),'CAN', 'client account number', NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'CL'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'CL'),'OAN', 'Original account number', NOW(), 'Orignal Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'CL'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'CL'),'DN', 'Document Name', NOW(), 'Document Name'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'CL'),'PC', 'Product Code', NOW(), 'Product Code');


INSERT INTO conf.doc_mgr_config_val(doc_mgr_config_id, short_code, description, dtm_utc_create, field_value)
 VALUES ((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'SEPARATOR' and dm.org_type_code = 
         'CL'),'-', 'Hyphne[-]', NOW(), 'Hyphne[-]'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'SEPARATOR' and dm.org_type_code = 
         'CL'),'_', 'Underscore[_]', NOW(), 'Underscore[_]'),      
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'RP' and dm.org_type_code = 
         'CL'),'60', 'retention policy in 60 days', NOW(), '60'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'RP' and dm.org_type_code = 
         'CL'),'90', 'retention policy in 90 days', NOW(), '90'),         
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'DP' and dm.org_type_code = 
         'CL'),'KBF', 'Keep Both File', NOW(), 'Keep Both File'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'DP' and dm.org_type_code = 
         'CL'),'RE', 'Replace  Existing', NOW(), 'Replace Existing');

               
-- For Partner
INSERT INTO conf.doc_mgr_config_val(doc_mgr_config_id, short_code, description, dtm_utc_create, field_value)
 VALUES ((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'PT'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
 ((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'PT'),'PC', 'Product Code', NOW(), 'Product Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'PT'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'PT'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'PT'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'PT'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'PT'),'DN', 'Document Name', NOW(), 'Document Name'),

((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'PT'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'PT'),'PC', 'Product Code', NOW(), 'Product Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'PT'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'PT'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'PT'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'PT'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'PT'),'DN', 'Document Name', NOW(), 'Document Name'),


((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'PT'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'PT'),'PC', 'Product Code', NOW(), 'Product Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'PT'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'PT'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'PT'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'PT'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'PT'),'DN', 'Document Name', NOW(), 'Document Name'),


((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'PT'),'CIDSC', 'Client ID or Client Short Code',NOW(), 'Client ID or Client Short Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'PT'),'PC', 'Product Code', NOW(), 'Product Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'PT'),'DT', 'Document Type Id',NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'PT'),'CAN', 'Client Account Number',NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'PT'),'OAN', 'Original Account Number',NOW(), 'Original Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'PT'),'DGD', 'Document Generation Date',NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'PT'),'DN', 'Document Name',NOW(), 'Document Name'),


((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'PT'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'PT'),'PC', 'Product Code', NOW(), 'Product Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'PT'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'PT'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'PT'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'PT'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'PT'),'DN', 'Document Name', NOW(), 'Document Name'),


((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'PT'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'PT'),'PC', 'Product Code', NOW(), 'Product Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'PT'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'PT'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'PT'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'PT'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'PT'),'DN', 'Document Name', NOW(), 'Document Name');

INSERT INTO conf.doc_mgr_config_val(doc_mgr_config_id, short_code, description, dtm_utc_create, field_value)
 VALUES ((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'SEPARATOR' and dm.org_type_code = 
         'PT'),'-', 'Hyphne[-]', NOW(), 'Hyphne[-]'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'SEPARATOR' and dm.org_type_code = 
         'PT'),'_', 'Underscore[_]', NOW(), 'Underscore[_]'); 

--Third Party

INSERT INTO conf.doc_mgr_config_val(doc_mgr_config_id, short_code, description, dtm_utc_create, field_value)
 VALUES ((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'TP'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
 ((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'TP'),'PC', 'Product Code', NOW(), 'Product Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'TP'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'TP'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'TP'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'TP'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field1' and dm.org_type_code = 
         'TP'),'DN', 'Document Name', NOW(), 'Document Name'),

((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'TP'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'TP'),'PC', 'Product Code', NOW(), 'Product Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'TP'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'TP'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'TP'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'TP'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field2' and dm.org_type_code = 
         'TP'),'DN', 'Document Name', NOW(), 'Document Name'),


((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'TP'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'TP'),'PC', 'Product Code', NOW(), 'Product Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'TP'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'TP'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'TP'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'TP'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field3' and dm.org_type_code = 
         'TP'),'DN', 'Document Name', NOW(), 'Document Name'),


((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'TP'),'CIDSC', 'Client ID or Client Short Code',NOW(), 'Client ID or Client Short Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'TP'),'PC', 'Product Code', NOW(), 'Product Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'TP'),'DT', 'Document Type Id',NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'TP'),'CAN', 'Client Account Number',NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'TP'),'OAN', 'Original Account Number',NOW(), 'Original Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'TP'),'DGD', 'Document Generation Date',NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field4' and dm.org_type_code = 
         'TP'),'DN', 'Document Name',NOW(), 'Document Name'),


((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'TP'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'TP'),'PC', 'Product Code', NOW(), 'Product Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'TP'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'TP'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'TP'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'TP'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field5' and dm.org_type_code = 
         'TP'),'DN', 'Document Name', NOW(), 'Document Name'),

((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'TP'),'CIDSC', 'Client ID or Client Short Code', NOW(), 'Client ID or Client Short Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'TP'),'PC', 'Product Code', NOW(), 'Product Code'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'TP'),'DT', 'Document Type Id', NOW(), 'Document Type Id'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'TP'),'CAN', 'Client Account Number', NOW(), 'Client Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'TP'),'OAN', 'Original Account Number', NOW(), 'Original Account Number'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'TP'),'DGD', 'Document Generation Date', NOW(), 'Document Generation Date'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'field6' and dm.org_type_code = 
         'TP'),'DN', 'Document Name', NOW(), 'Document Name');

INSERT INTO conf.doc_mgr_config_val(doc_mgr_config_id, short_code, description, dtm_utc_create, field_value)
 VALUES ((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'SEPARATOR' and dm.org_type_code = 
         'TP'),'-', 'Hyphne[-]', NOW(), 'Hyphne[-]'),
((select doc_mgr_config_id from conf.doc_mgr_config as dm where dm.short_code = 'SEPARATOR' and dm.org_type_code = 
         'TP'),'_', 'Underscore[_]', NOW(), 'Underscore[_]');

				