package com.equabli.documents.controller;

import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.documents.TestAppConfig;
import com.equabli.documents.constants.ColumnConstants;
import com.equabli.documents.request.ShowHideColumnRequest;
import com.equabli.documents.response.DocumentResponse;
import com.equabli.documents.response.ShowHideColumnResponse;

public class TestColumnController extends TestAppConfig {

	public static final String URI = "http://localhost:8081/user/document/column";

	@MockBean(reset = MockReset.BEFORE)
	FetchTokenData fetchTokenData;

	@Autowired
	MessageSupplier messageSupplier;

	@BeforeEach
	public void setTokenData() {
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
	}

	@Test
	void saveTableColumns() throws Exception {

		String json = convertJsonToString(getShowHideColumnRequest(ColumnConstants.TABLE_DOCUMENT));

		@SuppressWarnings("unchecked")
		CommonResponse<DocumentResponse> commonResponse = getBaseResponseForPOST(URI, json);
		Assert.assertEquals(messageSupplier.get(ColumnConstants.COLUMN_CREATE_SUCCESS, ColumnConstants.TABLE_DOCUMENT),
				commonResponse.getMessage());
	}

	@Test
	void saveTableColumns_1() throws Exception {

		String json = convertJsonToString(getShowHideColumnRequest("InvalidTableName"));

		@SuppressWarnings("unchecked")
		CommonResponse<DocumentResponse> commonResponse = getBaseResponseForPOST(URI, json);
		Assert.assertEquals(messageSupplier.get(ColumnConstants.NOT_VALID_TABLE_NAME, "InvalidTableName" + " "),
				commonResponse.getErrors().get(0));
	}

	@Test
	void getTableColumns() throws Exception {

		String uri = URI + "/all";
		@SuppressWarnings("unchecked")
		CommonResponse<List<ShowHideColumnResponse>> pagedResponse = getBaseResponseForGET(uri);
		Assert.assertEquals(messageSupplier.get(ColumnConstants.COLUMN_FETCH_SUCCESS), pagedResponse.getMessage());
	}

	private ShowHideColumnRequest getShowHideColumnRequest(String tableName) {
		ShowHideColumnRequest showHideColumnRequest = new ShowHideColumnRequest();
		showHideColumnRequest.setTableName(tableName);
		showHideColumnRequest.setColumnNames(getColumnsForDocument());
		return showHideColumnRequest;
	}

	private List<String> getColumnsForDocument() {
		return Arrays.asList(ColumnConstants.COLUMN_NAME, ColumnConstants.COLUMN_DOCUMENT_TYPE,
				ColumnConstants.COLUMN_ORIGINAL_ACCOUNT_NUMBER, ColumnConstants.COLUMN_EQUABLI_ACCOUNT_NUMBER,
				ColumnConstants.COLUMN_CLIENT_ACCOUNT_NUMBER, ColumnConstants.COLUMN_GENERATED_DATE,
				ColumnConstants.COLUMN_UPLOAD_DATE, ColumnConstants.COLUMN_SHARE_DATE,
				ColumnConstants.COLUMN_RECEIVE_DATE, ColumnConstants.COLUMN_FILE_SIZE, ColumnConstants.COLUMN_SHARED_BY,
				ColumnConstants.COLUMN_SHARED_WITH);
	}
}
