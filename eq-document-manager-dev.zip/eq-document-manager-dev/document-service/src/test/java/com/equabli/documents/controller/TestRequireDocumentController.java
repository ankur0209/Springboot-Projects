package com.equabli.documents.controller;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.response.CommonResponse;
import com.equabli.documents.TestAppConfig;
import com.equabli.documents.request.RequiredDocConfigRequest;
import com.equabli.documents.response.DocumentTypeResponse;

@TestInstance(Lifecycle.PER_CLASS)
class TestRequireDocumentController extends TestAppConfig{

	public static final String URI = "http://localhost:8081/user/document/require";
	private static final String PRODUCT_CODE = "productCode", CREDIT_CARD = "CC", APPLICATION_CODE = "AP",
			DOCUMENT_NAME = "Application";
	
	@MockBean(reset = MockReset.BEFORE) 
	FetchTokenData fetchTokenData;

	@BeforeEach
	public void setTokenData() {
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
	}
	
	@Test
	@Order(1)
	void getDocument() throws Exception {

		String uri = URI + "/product/type";
		MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>(1);
		multiValueMap.add(PRODUCT_CODE, CREDIT_CARD);

		@SuppressWarnings("unchecked")
		CommonResponse<DocumentTypeResponse> pagedResponse = getBaseResponseForGET(uri, multiValueMap);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}

	@Test
	@Order(2)
	void requiredDocument() throws Exception {
		testRequiredDoc("AC", CREDIT_CARD);
	}

	@Test
	@Order(3)
	void deleteRequiredDocument() throws Exception {

		String uri = URI + "/"+ CREDIT_CARD;

		@SuppressWarnings("unchecked")
		CommonResponse<DocumentTypeResponse> commonResponse = getBaseResponseForPatch(uri);
		assertEquals(CommonResponse.OperationStatus.SUCCESS, commonResponse.getStatus());
	}

//	@Test
//	void getRequiredDocument() throws Exception {
//
//		String uri = URI;
//		MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>(1);
//		multiValueMap.add(PRODUCT_CODE, CREDIT_CARD);
//
//		@SuppressWarnings("unchecked")
//		CommonResponse<DocumentTypeResponse> pagedResponse = getBaseResponseForGET(uri, multiValueMap);
//		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
//	}

	@Test
	@Order(4)
	void requiredDocRemove() throws Exception {
		testRequiredDoc("DT", CREDIT_CARD);
	}
	
	@Test
	void getAllRequiredDocument() throws Exception {

		String uri = URI + "/all";

		@SuppressWarnings("unchecked")
		CommonResponse<DocumentTypeResponse> pagedResponse = getBaseResponseForGET(uri);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}

	private void testRequiredDoc(String removeDoc, String creditCard) throws Exception {
		String json = convertJsonToString(getRequiredDocumentConfigRequest(removeDoc, creditCard));
		String uri = URI;
		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	private RequiredDocConfigRequest getRequiredDocumentConfigRequest(String statusCode, String productCode) {
		RequiredDocConfigRequest configRequest = new RequiredDocConfigRequest();
		configRequest.setProductCode(productCode);

		List<String> docList = new ArrayList<>();
		docList.add("AP");
		docList.add("TH");
		docList.add("MA");
		docList.add("BS");

		configRequest.setDocTypeCode(docList);
		return configRequest;
	}

}
