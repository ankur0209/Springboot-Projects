package com.equabli.documents.controller;

import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.lang.NonNull;
import org.springframework.util.StringUtils;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.DocType;
import com.equabli.common.entity.Document;
import com.equabli.common.entity.Lookup;
import com.equabli.common.entity.LookupGroup;
import com.equabli.common.entity.QDocument;
import com.equabli.common.queryhelpers.LikeHelper;
import com.equabli.common.repository.DocTypeRepository;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.repository.LookupRepository;
import com.equabli.common.repository.RequireDocRepository;
import com.equabli.common.request.FileUploadConfigRequest;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.DocumentSummaryResponse;
import com.equabli.common.response.PageRequestData;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.response.RequireDocResponse;
import com.equabli.common.utils.DateUtils;
import com.equabli.common.utils.DurationDateUtils;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.documents.TestAppConfig;
import com.equabli.documents.constants.ColumnConstants;
import com.equabli.documents.constants.DocumentMessageConstants;
import com.equabli.documents.request.UserDocConfigRequest;
import com.equabli.documents.response.AccountDocumentResponse;
import com.equabli.documents.response.DocumentCoverageResponse;
import com.equabli.documents.response.UsageResponse;
import com.equabli.documents.searchparams.AccountDocumentSearchParam;
import com.equabli.documents.searchparams.AccountNOTDocumentSearchParam;
import com.equabli.documents.searchparams.DocumentCoverageSearchParam;
import com.equabli.documents.service.GlobalConfigService;
import com.querydsl.core.BooleanBuilder;


class TestDocumentSummaryController extends TestAppConfig {

	public static final String URI = "http://localhost:8081/user/document/summary";
	private static final String FAILURES = "Failures";
	private static final QDocument qDocument = QDocument.document;

	@MockBean(reset = MockReset.BEFORE)
	FetchTokenData fetchTokenData;

	@Autowired
	MessageSupplier messageSupplier;
	
	@Autowired
	private GlobalConfigService globalConfigService;
	
	@Autowired
	private DocTypeRepository docTypeRepository;
	
	@MockBean
	private DocumentRepository documentRepository;
	
	@MockBean
    RequireDocRepository requireDocRepository;
	
	@MockBean
	LookupRepository lookupRepository;
	

	@BeforeEach
	public void setTokenData() {
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
	}

	@Test
	void getDocumentSummaryCoverage() throws Exception {

		@SuppressWarnings("unchecked")
		CommonResponse<List<DocumentCoverageResponse>> commonResponse = getBaseResponseForPOST(URI + "/coverage");
		Assert.assertEquals(messageSupplier.get(DocumentMessageConstants.Summary.COVERAGE_SUMMARY_FETCH_SUCCESS),
				commonResponse.getMessage());
	}
	
	@Test
	void getDocumentSummaryCoverage_1() throws Exception {

		TokenData tokenData = getTokenData();
		DocumentCoverageSearchParam documentCoverageSearchParam = getDocumentCoverageSearchParam(); 
		DurationDateUtils duration = new DurationDateUtils(documentCoverageSearchParam.getDuration(),
				LocalDateTime.now());
		
		Mockito.when(requireDocRepository.getByOrgTypeCodeAndIsDeleteFalse(tokenData.getUserOrgCode(),
				documentCoverageSearchParam.getProduct())).thenReturn(getRequireDocResponseList());
		
		Mockito.when(documentRepository.getCompletedDocumentSummary(tokenData.getUserOrgCode(), Arrays.asList("CC"), "AP",
				duration.getFirstDay(), duration.getLastDay(), documentCoverageSearchParam.getUserId(),
				documentCoverageSearchParam.getPortfolio(), "CC")).thenReturn(Arrays.asList("CC"));
		
		Mockito.when(documentRepository.getTotalDocumentSummary(tokenData.getUserOrgCode(), "CC", duration.getFirstDay(),
				duration.getLastDay(), documentCoverageSearchParam.getUserId(),
				documentCoverageSearchParam.getPortfolio(), Arrays.asList("CC"))).thenReturn(Arrays.asList("CC"));
		
		
		String json = convertJsonToString(documentCoverageSearchParam);
		@SuppressWarnings("unchecked")
		CommonResponse<List<DocumentCoverageResponse>> commonResponse = getBaseResponseForPOST(URI + "/coverage", json);
		Assert.assertEquals(messageSupplier.get(DocumentMessageConstants.Summary.COVERAGE_SUMMARY_FETCH_SUCCESS),
				commonResponse.getMessage());
	}
	
	@Test
	void getClientAccountNumber() throws Exception {

		@SuppressWarnings("unchecked")
		CommonResponse<List<String>> commonResponse = getBaseResponseForGET(URI + "/clientAccount");
		Assert.assertEquals(messageSupplier.get(DocumentMessageConstants.Summary.CLIENT_ACCOUNT_FETCH_SUCCESS),
				commonResponse.getMessage());
	}
	
	@Test
	void getAccountListForDocument() throws Exception {
		
		globalConfigService.saveUserFileConfig(getUserDocConfigRequest("CL"));
		AccountDocumentSearchParam documentsSearchParam = getAccountDocumentSearchParam("AP");
		DurationDateUtils tenture = new DurationDateUtils(documentsSearchParam.getTenure(), LocalDateTime.now());
		Page<Document> paged = new PageImpl<>(Arrays.asList(saveDocument()));
		Mockito.when(documentRepository.findAll(getPredicateForDocuments(documentsSearchParam, getTokenData(), tenture),
				getPeagble(documentsSearchParam))).thenReturn(paged);
		
		String json = getJsonStringUsingObjectMapper(documentsSearchParam);
		String uri = URI + "/accounts";
		@SuppressWarnings("unchecked")
		PagedResponse<AccountDocumentResponse> pagedResponse = getPagedResponseForPOST(uri, json);
		Assert.assertNotEquals(FAILURES, pagedResponse.getMessage());
	}
	
	@Test
	void getAccountListForDocument_3() throws Exception {
		globalConfigService.saveUserFileConfig(getUserDocConfigRequest("CL"));
		
		AccountDocumentSearchParam documentsSearchParam = getAccountDocumentSearchParam("invalide");
		DurationDateUtils tenture = new DurationDateUtils(documentsSearchParam.getTenure(), LocalDateTime.now());
		Page<Document> paged = new PageImpl<>(Arrays.asList(saveDocument()));
		Mockito.when(documentRepository.findAll(getPredicateForDocuments(documentsSearchParam, getTokenData(), tenture),
				getPeagble(documentsSearchParam))).thenReturn(paged);
		
		String json = getJsonStringUsingObjectMapper(documentsSearchParam);
		String uri = URI + "/accounts";
		@SuppressWarnings("unchecked")
		PagedResponse<AccountDocumentResponse> pagedResponse = getPagedResponseForPOST(uri, json);
		Assert.assertEquals(messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, " " + "invalide"), pagedResponse.getErrors().get(0));
	}
	
	@Test
	void getAccountListForDocument_2() throws Exception {
		
		globalConfigService.saveUserFileConfig(getUserDocConfigRequest("CL"));
		
		AccountDocumentSearchParam documentsSearchParam = getAccountDocumentSearchParamAll("AP");
		DurationDateUtils tenture = new DurationDateUtils(documentsSearchParam.getTenure(), LocalDateTime.now());
		Page<Document> paged = new PageImpl<>(Arrays.asList(saveDocument()));
		Mockito.when(documentRepository.findAll(getPredicateForDocuments(documentsSearchParam, getTokenData(), tenture),
				getPeagble(documentsSearchParam))).thenReturn(paged);
		
		String json = getJsonStringUsingObjectMapper(documentsSearchParam);
		
		String uri = URI + "/accounts";
		@SuppressWarnings("unchecked")
		PagedResponse<AccountDocumentResponse> pagedResponse = getPagedResponseForPOST(uri, json);
		Assert.assertNotEquals(FAILURES, pagedResponse.getMessage());
	}
	
	@Test
	void getAccountListForDocument_1() throws Exception {
		PagedResponse<AccountDocumentResponse> pagedResponse = testForSpecificAccount("AP", true, "123456");
		Assert.assertNotEquals(FAILURES, pagedResponse.getMessage());
	}
	
	@Test
	void getAccountListForDocument_4() throws Exception {
		PagedResponse<AccountDocumentResponse> pagedResponse = testForSpecificAccount("AP", false, "123456");
		Assert.assertNotEquals(FAILURES, pagedResponse.getMessage());
	}
	
	@Test
	void getAccountListForDocument_5() throws Exception {
		PagedResponse<AccountDocumentResponse> pagedResponse = testForSpecificAccount("BS", false, "123456");
		Assert.assertNotEquals(FAILURES, pagedResponse.getMessage());
	}
	
	@Test
	void getUsage() throws Exception {

		when(lookupRepository.findByLookupGroup_keyvalueAndKeycode(MessageConstants.Subscription.SUBSCRIPTION_TYPE,
				MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE))
				.thenReturn(Optional.of(getLookup(MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE)));
		when(lookupRepository.findByUid(null)).thenReturn(Optional.of(getLookup(MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE)));
		
		@SuppressWarnings("unchecked")
		CommonResponse<UsageResponse> commonResponse = getBaseResponseForGET(URI + "/usage");
		Assert.assertEquals(messageSupplier.get(DocumentMessageConstants.Summary.COVERAGE_USAGE_FETCH_SUCCESS),
				commonResponse.getMessage());
	}
	
	@Test
	void getAccountNOTListForDocument() throws Exception {

		PagedResponse<AccountDocumentResponse> pagedResponse = setDataForNOTSpecificAccount("AP", "CC", null, null);
		Assert.assertNotEquals(FAILURES, pagedResponse.getMessage());
	}

	@Test
	void getAccountNOTListForDocument_1() throws Exception {

		PagedResponse<AccountDocumentResponse> pagedResponse = setDataForNOTSpecificAccount("AP", "CC",
				ColumnConstants.COLUMN_CLIENT_ACCOUNT_NUMBER, "desc");

		Assert.assertNotEquals(FAILURES, pagedResponse.getMessage());
	}
	
	@Test
	void getAccountNOTListForDocument_2() throws Exception {

		PagedResponse<AccountDocumentResponse> pagedResponse = setDataForNOTSpecificAccount("AP", "CC",
				ColumnConstants.COLUMN_CLIENT_ACCOUNT_NUMBER, null);

		Assert.assertNotEquals(FAILURES, pagedResponse.getMessage());
	}
	
	private PagedResponse<AccountDocumentResponse> testForSpecificAccount(String docTypecode, boolean specificDocument,
			String clientAccountNmber) throws Exception {
		
		globalConfigService.saveUserFileConfig(getUserDocConfigRequest("CL"));
		
		AccountDocumentSearchParam documentsSearchParam = getAccountDocumentSearchParam(docTypecode, clientAccountNmber);
		DurationDateUtils tenture = new DurationDateUtils(documentsSearchParam.getTenure(), LocalDateTime.now());
		Page<Document> paged = new PageImpl<>(Arrays.asList(saveDocument()));
		
		Mockito.when(documentRepository.getDocumentList(getTokenData().getUserOrgCode(),
				documentsSearchParam.getDocTypeCode(), documentsSearchParam.getTextSearch(), tenture.getFirstDay(),
				tenture.getLastDay(), documentsSearchParam.getUserId(), documentsSearchParam.getClientAccountNumber(),
				documentsSearchParam.getProductCode(), documentsSearchParam.getAccounts(), Collections.emptyList(),
				getPeagble(documentsSearchParam))).thenReturn(paged);
		
		
		String json = getJsonStringUsingObjectMapper(documentsSearchParam);
		
		String uri = URI + "/accounts";

		@SuppressWarnings("unchecked")
		PagedResponse<AccountDocumentResponse> pagedResponse = getPagedResponseForPOST(uri, json);

		return pagedResponse;
	}
	
	private DocumentCoverageSearchParam getDocumentCoverageSearchParam() {
		DocumentCoverageSearchParam documentCoverageSearchParam = new DocumentCoverageSearchParam();
		documentCoverageSearchParam.setProduct("CC");;
		return documentCoverageSearchParam;
	}
	
	private AccountDocumentSearchParam getAccountDocumentSearchParam(String docTypeCode) {
		return AccountDocumentSearchParam.builder().docTypeCode(docTypeCode).build();
	}

	private AccountDocumentSearchParam getAccountDocumentSearchParam(String docTypeCode, String textSearch) {
		return AccountDocumentSearchParam.builder().docTypeCode(docTypeCode).textSearch(textSearch).build();
	}
	
	private AccountDocumentSearchParam getAccountDocumentSearchParamAll(String docTypeCode) {
		return AccountDocumentSearchParam.builder().docTypeCode(docTypeCode).originalAccountNumber("456789")
				.equabliAccountNumber(7890L).clientAccountNumber("123456")
				.generationDateFrom(LocalDate.now()).portfolio("123456").userId(21L).documentName("text.txt")
				.uploadDateFrom(LocalDate.now()).productCode("CC").sortOrder("asc").sortParam("fileSize")
				.uploadDateTo(LocalDate.now()).generationDateTo(LocalDate.now()).pageNumber(0).pageSize(10).build();
	}

	private List<UserDocConfigRequest> getUserDocConfigRequest(String orgType) {

		List<UserDocConfigRequest> userDocConfigRequests = new ArrayList<>();
		userDocConfigRequests.add(getUserDocConfigRequest("field1", "CAN", orgType));
		userDocConfigRequests.add(getUserDocConfigRequest("field2", "OAN", orgType));
		userDocConfigRequests.add(getUserDocConfigRequest("SEPARATOR", "-", orgType));
		return userDocConfigRequests;
	}
	
	private Document saveDocument() {
		Document document = new Document();

		FileUploadConfigRequest fileUploadConfigRequest = new FileUploadConfigRequest();
		fileUploadConfigRequest.setClientAccountNo("123456");
		fileUploadConfigRequest.setDocumentGenerationDate(LocalDateTime.now());
		fileUploadConfigRequest.setDocType("AP");
		fileUploadConfigRequest.setProductCode("CC");

		DocType docType = docTypeRepository.findByShortCode("AP").orElseThrow();

		document.saveDocument(document, fileUploadConfigRequest, false, null, docType.getName(),  getTokenData(), getTokenData());
		return document;
	}
	
	private Pageable getPeagble(AccountDocumentSearchParam documentsSearchParam) {
		
		PageRequestData pageRequestData = Util.getPageRequestData(documentsSearchParam.getPageSize(),
				documentsSearchParam.getPageNumber(), documentsSearchParam.getSortOrder(),
				documentsSearchParam.getSortParam() != null ? documentsSearchParam.getSortParam() : ColumnConstants.COLUMN_UPDATED_AT);

		Sort sort = Util.getSortingOrder(pageRequestData.getSortOrder(),
				getAccountSortParam(pageRequestData.getSortParam()));
		return PageRequest.of(pageRequestData.getPageNumber(), pageRequestData.getPageSize(), sort);
	}
	
	public String getAccountSortParam(String sortParams) {
		String sortParamsVal = null;
		switch (sortParams) {
		case ColumnConstants.COLUMN_DOCUMENT_NAME -> sortParamsVal = "generatedFileName";
		case ColumnConstants.COLUMN_ORIGINAL_ACCOUNT_NUMBER -> sortParamsVal = "originalAccountNo";
		case ColumnConstants.COLUMN_EQUABLI_ACCOUNT_NUMBER -> sortParamsVal = "eqaubliAccountNo";
		case ColumnConstants.COLUMN_CLIENT_ACCOUNT_NUMBER -> sortParamsVal = "clientAccountNo";
		case ColumnConstants.COLUMN_GENERATED_DATE -> sortParamsVal = ColumnConstants.COLUMN_UPDATED_AT;
		case ColumnConstants.COLUMN_UPLOAD_DATE -> sortParamsVal = ColumnConstants.COLUMN_UPDATED_AT;
		case ColumnConstants.COLUMN_FILE_SIZE -> sortParamsVal = "fileSize";
		case ColumnConstants.COLUMN_SHARED_BY -> sortParamsVal = "shareBy";
		default -> sortParamsVal = ColumnConstants.COLUMN_UPDATED_AT;
		}
		return sortParamsVal;
	}
	
	private BooleanBuilder getPredicateForDocuments(@NonNull AccountDocumentSearchParam documentsSearchParam,
			TokenData tokenData, DurationDateUtils tenture) {
		BooleanBuilder booleanBuilder = new BooleanBuilder();
		booleanBuilder.and(qDocument.orgCode.eq(tokenData.getUserOrgCode()));
		booleanBuilder.and(qDocument.isDelete.isFalse());
		booleanBuilder.and(qDocument.isOthers.isFalse());
		booleanBuilder.and(qDocument.docTypeCode.eq(documentsSearchParam.getDocTypeCode()));
		booleanBuilder.and(qDocument.updatedAt.goe(tenture.getFirstDay()));
		booleanBuilder.and(qDocument.updatedAt.loe(tenture.getLastDay()));

		if (documentsSearchParam.getAccounts() != null )
			booleanBuilder.and(qDocument.clientAccountNo.in(documentsSearchParam.getAccounts()));

		if (StringUtils.hasText(documentsSearchParam.getPortfolio()))
			booleanBuilder.and(qDocument.clientAccountNo.eq(documentsSearchParam.getPortfolio()));

		if (StringUtils.hasText(documentsSearchParam.getProductCode()))
			booleanBuilder.and(qDocument.productCode.eq(documentsSearchParam.getProductCode()));

		if (documentsSearchParam.getUserId() != null)
			booleanBuilder.and(qDocument.userId.eq(documentsSearchParam.getUserId()));

		if (StringUtils.hasText(documentsSearchParam.getDocumentName()))
			booleanBuilder.and(qDocument.generatedFileName
					.likeIgnoreCase(LikeHelper.anyPosition(documentsSearchParam.getDocumentName())));

		if (StringUtils.hasText(documentsSearchParam.getClientAccountNumber()))
			booleanBuilder.and(qDocument.clientAccountNo.eq(documentsSearchParam.getClientAccountNumber()));

		if (documentsSearchParam.getEquabliAccountNumber() != null)
			booleanBuilder.and(qDocument.equabliAccountNo.eq(documentsSearchParam.getEquabliAccountNumber()));

		if (StringUtils.hasText(documentsSearchParam.getOriginalAccountNumber()))
			booleanBuilder.and(qDocument.originalAccountNo.eq(documentsSearchParam.getOriginalAccountNumber()));

		if (documentsSearchParam.getGenerationDateFrom() != null
				&& documentsSearchParam.getGenerationDateTo() != null) {
			booleanBuilder.and(qDocument.documentGenerationDate
					.goe(DateUtils.atStartOfDay(documentsSearchParam.getGenerationDateFrom())));
			booleanBuilder.and(qDocument.documentGenerationDate
					.loe(DateUtils.atEndOfDay(documentsSearchParam.getGenerationDateTo())));
		}

		if (documentsSearchParam.getUploadDateFrom() != null && documentsSearchParam.getUploadDateTo() != null) {
			booleanBuilder
					.and(qDocument.createdAt.goe(DateUtils.atStartOfDay(documentsSearchParam.getUploadDateFrom())));
			booleanBuilder.and(qDocument.createdAt.loe(DateUtils.atEndOfDay(documentsSearchParam.getUploadDateTo())));
		}

		return booleanBuilder;
	}
	
	private List<RequireDocResponse> getRequireDocResponseList() {
		RequireDocResponse requireDocResponse = new RequireDocResponse();
		requireDocResponse.setDocTypeCode("AP");
		requireDocResponse.setProductCode("CC");

		return Arrays.asList(requireDocResponse);
	}

	private List<DocumentSummaryResponse> getDocumentSummaryResponseList() {
		DocumentSummaryResponse documentSummaryResponse = new DocumentSummaryResponse();
		documentSummaryResponse.setClientAccountNumber("123456");
		documentSummaryResponse.setDocTypeCode("AP");
		documentSummaryResponse.setProductCode("CC");
		return Arrays.asList(documentSummaryResponse);
	}

	@SuppressWarnings("unchecked")
	private PagedResponse<AccountDocumentResponse> setDataForNOTSpecificAccount(String docTypeCode, String productCode,
			String clientAccountColumnName, String sortOrder) throws Exception {
		TokenData tokenData = getTokenData();

		AccountNOTDocumentSearchParam documentsSearchParam = getAccountNOTDocumentSearchParam(docTypeCode,
				clientAccountColumnName, sortOrder);
		DurationDateUtils tenture = new DurationDateUtils(documentsSearchParam.getTenure(), LocalDateTime.now());

		Mockito.when(requireDocRepository.getByOrgTypeCodeAndDocTypeCodeAndIsDeleteFalse(tokenData.getUserOrgCode(),
				docTypeCode, documentsSearchParam.getProductCode())).thenReturn(getRequireDocResponseList());
		Mockito.when(
				documentRepository.getTotalDocumentSummary(tokenData.getUserOrgCode(), productCode, tenture.getFirstDay(),
						tenture.getLastDay(), documentsSearchParam.getUserId(), documentsSearchParam.getPortfolio(), Arrays.asList("CC")))
				.thenReturn(Arrays.asList("CC"));
		
		String json = getJsonStringUsingObjectMapper(documentsSearchParam);
		String uri = URI + "/accounts/not";
		
		return getPagedResponseForPOST(uri, json);
	}

	private AccountNOTDocumentSearchParam getAccountNOTDocumentSearchParam(String docTypeCode, String sortParam,
			String sortOrder) {
		return AccountNOTDocumentSearchParam.builder().docTypeCode(docTypeCode).sortParam(sortParam)
				.sortOrder(sortOrder).build();
	}
	
	private Lookup getLookup(String keycode) {
		Lookup lookup = new Lookup();
		lookup.saveLookup(lookup, keycode, "15 GB", new LookupGroup(), getTokenData());
		return lookup;
	}
}
