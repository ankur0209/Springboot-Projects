package com.equabli.documents.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.Assert;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.mockito.Mockito;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.documents.TestAppConfig;
import com.equabli.documents.request.DocumentCostRequest;
import com.equabli.documents.response.DocumentCostConfigResponse;
import com.equabli.documents.response.DocumentCostResponse;


@TestMethodOrder(OrderAnnotation.class)
class TestDocumentCostController extends TestAppConfig {

	public static final String URI = "http://localhost:8081/user/document/cost";
	private static final String DOCUMENT_CODE = "docTypeCode", APPLICATION_CODE = "AP", FAILURES = "Failures";

	@MockBean(reset = MockReset.BEFORE) 
	FetchTokenData fetchTokenData;

	@BeforeEach
	public void setTokenData() {
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
	}
	
	@Test
	@Order(1)
	void userFileConfig() throws Exception {
		String json = convertJsonToString(getDocumentCostRequest(APPLICATION_CODE, (float) 10));

		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(URI, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}

	@Test
	void userFileConfig_1() throws Exception {
		String json = convertJsonToString(getDocumentCostRequest("TEST", (float) 10));

		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(URI, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}

	@Test
	@Order(2)
	void getCosts() throws Exception {

		String uri = URI + "/all";
		@SuppressWarnings("unchecked")
		PagedResponse<DocumentCostConfigResponse> pagedResponse = getPagedResponseForGET(uri,
				new LinkedMultiValueMap<>());
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}

	@Test
	@Order(3)
	void getDocumentCost() throws Exception {

		MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>(1);
		multiValueMap.add(DOCUMENT_CODE, APPLICATION_CODE);

		@SuppressWarnings("unchecked")
		CommonResponse<DocumentCostResponse> commonResponse = getBaseResponseForGET(URI, multiValueMap);
		assertNotNull(commonResponse.getResponse());
	}

	@Test
	@Order(4)
	void deleteDocumentCost() throws Exception {
		String uri = URI + "/"+ APPLICATION_CODE;

		@SuppressWarnings("unchecked")
		CommonResponse<DocumentCostResponse> commonResponse = getBaseResponseForPatch(uri);
		assertEquals(CommonResponse.OperationStatus.SUCCESS, commonResponse.getStatus());
	}

	@Test
	@Order(5)
	void getDocumentCost_1() throws Exception {

		MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>(1);
		multiValueMap.add(DOCUMENT_CODE, APPLICATION_CODE);

		@SuppressWarnings("unchecked")
		CommonResponse<DocumentCostResponse> commonResponse = getBaseResponseForGET(URI, multiValueMap);
		assertEquals(FAILURES, commonResponse.getMessage());
	}
	
	private DocumentCostRequest getDocumentCostRequest(String documentCode, Float cost) {
		DocumentCostRequest documentCostRequest = new DocumentCostRequest();
		documentCostRequest.setCost(cost);
		documentCostRequest.setDocTypeCode(documentCode);
		return documentCostRequest;
	}
}
