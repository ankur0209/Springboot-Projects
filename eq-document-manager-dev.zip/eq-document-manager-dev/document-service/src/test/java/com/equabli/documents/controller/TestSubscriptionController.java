package com.equabli.documents.controller;

import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.Lookup;
import com.equabli.common.entity.LookupGroup;
import com.equabli.common.repository.LookupRepository;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.documents.TestAppConfig;
import com.equabli.documents.response.SubscriptionResponse;

class TestSubscriptionController extends TestAppConfig {

	public static final String URI = "http://localhost:8081/user/subscription";

	@MockBean(reset = MockReset.BEFORE)
	FetchTokenData fetchTokenData;

	@Autowired
	MessageSupplier messageSupplier;

	@MockBean
	LookupRepository lookupRepository;

	@BeforeEach
	public void setTokenData() {
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
	}

	@Test
	void getSavedSubscriptons() throws Exception {

		when(lookupRepository.findByLookupGroup_keyvalueAndKeycode(MessageConstants.Subscription.SUBSCRIPTION_TYPE,
				MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE))
				.thenReturn(Optional.of(getLookup(MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE)));
		when(lookupRepository.findByUid(null)).thenReturn(Optional.of(getLookup(MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE)));

		@SuppressWarnings("rawtypes")
		CommonResponse commonResponse = getBaseResponseForGET(URI);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, commonResponse.getStatus());
	}
	
	@Test
	void getAllSubscriptons() throws Exception {

		when(lookupRepository.findByLookupGroup_keyvalue(MessageConstants.Subscription.SUBSCRIPTION_TYPE))
				.thenReturn(getLookups());

		@SuppressWarnings("unchecked")
		CommonResponse<List<SubscriptionResponse>> commonResponse = getBaseResponseForGET(URI + "/all");
		Assert.assertEquals(1, commonResponse.getResponse().size());
	}
	
	@Test
	void saveSubscriptons() throws Exception {

		when(lookupRepository.findByLookupGroup_keyvalueAndKeycode(MessageConstants.Subscription.SUBSCRIPTION_TYPE,
				MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE))
				.thenReturn(Optional.of(getLookup(MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE)));
		when(lookupRepository.findByUid(null)).thenReturn(Optional.of(getLookup(MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE)));

		@SuppressWarnings("rawtypes")
		CommonResponse commonResponse = mockMvcRequestPUT(URI + "/" +MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, commonResponse.getStatus());
	}
	

	private List<Lookup> getLookups() {
		return Arrays.asList(getLookup(MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE));
	}

	private Lookup getLookup(String keycode) {
		Lookup lookup = new Lookup();
		lookup.saveLookup(lookup, keycode, "15 GB", new LookupGroup(), getTokenData());
		return lookup;
	}
}
