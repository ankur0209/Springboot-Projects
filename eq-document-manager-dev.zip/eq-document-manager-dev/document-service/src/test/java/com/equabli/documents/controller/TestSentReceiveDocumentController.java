package com.equabli.documents.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.feignclients.CommonConfigService;
import com.equabli.common.request.EmailRequest;
import com.equabli.common.request.RequestNewDocumentRequest;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.response.UserDetailResponse;
import com.equabli.common.response.UserDetails;
import com.equabli.common.response.UserMailResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.documents.TestAppConfig;
import com.equabli.documents.feignclient.SentMail;
import com.equabli.documents.feignclient.UserService;
import com.equabli.documents.request.UserDocConfigRequest;
import com.equabli.documents.response.DocumentCostResponse;
import com.equabli.documents.response.SentDocumentResponse;
import com.equabli.documents.searchparams.SentReceiveSummarySearchParam;
import com.equabli.documents.searchparams.SentRequestDocumentSearchParam;
import com.equabli.documents.service.GlobalConfigService;
import com.equabli.documents.service.impl.SentReceiveDocumentServiceImpl;

class TestSentReceiveDocumentController extends TestAppConfig {

	private static final String URI = "http://localhost:8081/user/document/request";

	@Autowired
	private SentReceiveDocumentServiceImpl sendReceiveDocumentService;
	
	@Autowired
	private GlobalConfigService globalConfigService;
	
	@Autowired
	private MessageSupplier messageSupplier;
	
	@MockBean 
	private UserService userService;
	
	@MockBean
	private SentMail sentMail;
	
	@MockBean(reset = MockReset.BEFORE) 
	FetchTokenData fetchTokenData;
	
	@MockBean(reset = MockReset.BEFORE)
	CommonConfigService commonConfigService;
	
	@BeforeEach
	public void setTokenData() {
		Mockito.when(userService.emailExists(any(), any()))
				.thenReturn(convertJsonToString(getListUserDetailResponse()));
		Mockito.when(sentMail.sendEmails(any(), anyList())).thenReturn("Mail Sent");
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
		Mockito.when(commonConfigService.getToken(any(), any(), any())).thenReturn(getFcmToken());
		Mockito.when(sentMail.sendNotification(any(), any())).thenReturn("send Successfully");
	}

	@Test
	void sendRequestDocuement() throws Exception {
		
		String json = convertJsonToString(getRequestNewDocumentRequest("TH"));

		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(URI, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	@Test
	void sendRequestDocuement_1() throws Exception {
		String json = convertJsonToString(getRequestNewDocumentRequest("Test"));

		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(URI, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}

	@Test
	void getSendReceiveDocs() throws Exception {

		globalConfigService.saveUserFileConfig(getUserDocConfigRequest("CL"));
		sendReceiveDocumentService.saveRequestNewDocument(getRequestNewDocumentRequest("TH"));
		String json = getJsonStringUsingObjectMapper(getSentRequestDocumentSearchParam(0, 10));

		String uri = URI + "/all";
		@SuppressWarnings("unchecked")
		PagedResponse<SentDocumentResponse> pagedResponse = getPagedResponseForPOST(uri, json);
		Assert.assertNotEquals("Failures", pagedResponse.getMessage());
	}
	
	@Test
	void getSendReceiveDocTextSearch() throws Exception {

		globalConfigService.saveUserFileConfig(getUserDocConfigRequest("CL"));
		sendReceiveDocumentService.saveRequestNewDocument(getRequestNewDocumentRequest("TH"));
		String json = getJsonStringUsingObjectMapper(getSentRequestDocumentSearchParam(0, 10, "123456"));

		String uri = URI + "/all";
		@SuppressWarnings("unchecked")
		PagedResponse<SentDocumentResponse> pagedResponse = getPagedResponseForPOST(uri, json);
		Assert.assertNotEquals("Failures", pagedResponse.getMessage());
	}
	
	@Test
	void getSendReceiveDocs_2() throws Exception {

		globalConfigService.saveUserFileConfig(getUserDocConfigRequest("CL"));
		sendReceiveDocumentService.saveRequestNewDocument(getRequestNewDocumentRequest("TH"));

		String uri = URI + "/all";
		@SuppressWarnings("unchecked")
		PagedResponse<SentDocumentResponse> pagedResponse = getPagedResponseForPOST(uri);
		Assert.assertNotEquals("Failures", pagedResponse.getMessage());
	}
	
	@Test
	void getSendReceiveDocs_3() throws Exception {

		globalConfigService.saveUserFileConfig(getUserDocConfigRequest("CL"));
		sendReceiveDocumentService.saveRequestNewDocument(getRequestNewDocumentRequest("TH"));
		String json = getJsonStringUsingObjectMapper(SentRequestDocumentSearchParam.builder().pageSize(10).pageNumber(0).build());
		
		String uri = URI + "/all";
		@SuppressWarnings("unchecked")
		PagedResponse<SentDocumentResponse> pagedResponse = getPagedResponseForPOST(uri, json);
		Assert.assertNotEquals("Failures", pagedResponse.getMessage());
	}
	
//	@Test
//	void setDocumentName() {
//		List<String> fileNameConfigs = new ArrayList<>(Arrays.asList("CIDSC", "DT", "CAN", "OAN", "DGD", "DN", "NA", "PC"));
//		String fileName = sendReceiveDocumentService.setDocumentName("123456-PC-456789.pdf", fileNameConfigs, "-", new Document());
//		Assert.assertNotNull(fileName);
//	}

	@Test
	void deleteSendRequestDocuement() throws Exception {

		CommonResponse<String> response = sendReceiveDocumentService
				.saveRequestNewDocument(getRequestNewDocumentRequest("TH"));
//		TODO : need to verify 
		String uri = URI + "/" + Long.parseLong("1");
		@SuppressWarnings("unchecked")
		CommonResponse<DocumentCostResponse> commonResponse = getBaseResponseForPatch(uri);
		assertEquals(CommonResponse.OperationStatus.SUCCESS, commonResponse.getStatus());
	}
	
	@Test
	void deleteSendRequestDocuement_1() throws Exception {

		String uri = URI + "/112311";
		@SuppressWarnings("unchecked")
		CommonResponse<DocumentCostResponse> commonResponse = getBaseResponseForPatch(uri);
		assertEquals(CommonResponse.OperationStatus.SUCCESS, commonResponse.getStatus());
	}
	
	@Test
	void sendRequestDocuementSummary() throws Exception {

		globalConfigService.saveUserFileConfig(getUserDocConfigRequest("CL"));
		sendReceiveDocumentService.saveRequestNewDocument(getRequestNewDocumentRequest("TH"));
		String json = convertJsonToString(sentReceiveSummarySearchParam("TH"));
		
		String uri = URI + "/summary";
		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	@Test
	void sendRequestDocuementSummaryInvalid() throws Exception {

		globalConfigService.saveUserFileConfig(getUserDocConfigRequest("CL"));
		sendReceiveDocumentService.saveRequestNewDocument(getRequestNewDocumentRequest("TH"));
		String json = convertJsonToString(new SentReceiveSummarySearchParam());
		String uri = URI + "/summary";
		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	@Test
	void sendRequestDocuementSummaryInvalidProdCode() throws Exception {

		globalConfigService.saveUserFileConfig(getUserDocConfigRequest("CL"));
		sendReceiveDocumentService.saveRequestNewDocument(getRequestNewDocumentRequest("TH"));
		String json = convertJsonToString(sentReceiveSummarySearchParam(null));
		
		String uri = URI + "/summary";
		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}

	private RequestNewDocumentRequest getRequestNewDocumentRequest(String docTypeCode) {
		RequestNewDocumentRequest requestNewDocumentRequest = new RequestNewDocumentRequest();
		requestNewDocumentRequest.setSendRequests(getUserDetailsRequest());
		requestNewDocumentRequest.setOriginalAccountNumber("456789");
		requestNewDocumentRequest.setClientAccountNumber("123456");
		requestNewDocumentRequest.setEquabliAccountNumber(7890L);
		requestNewDocumentRequest.setDocTypeCode(docTypeCode);

		return requestNewDocumentRequest;
	}
	
	private SentReceiveSummarySearchParam sentReceiveSummarySearchParam(String prodCode) {
		SentReceiveSummarySearchParam receiveSummarySearchParam = new SentReceiveSummarySearchParam();
		receiveSummarySearchParam.setDuration("month");
		receiveSummarySearchParam.setPortfolio("123456");
		if(prodCode != null)
			receiveSummarySearchParam.setProduct(prodCode);
		receiveSummarySearchParam.setUserId(21l);
		return receiveSummarySearchParam;
	}
	
	private List<UserDocConfigRequest> getUserDocConfigRequest(String orgType) {

		List<UserDocConfigRequest> userDocConfigRequests = new ArrayList<>();
		userDocConfigRequests.add(getUserDocConfigRequest("field1", "CAN", orgType));
		userDocConfigRequests.add(getUserDocConfigRequest("field2", "OAN", orgType));
		userDocConfigRequests.add(getUserDocConfigRequest("SEPARATOR", "-", orgType));
		return userDocConfigRequests;
	}
	
	private SentRequestDocumentSearchParam getSentRequestDocumentSearchParam(Integer pageNumber, Integer pageSize) {
		return SentRequestDocumentSearchParam.builder().clientAccountNumber("123456").documentName("abc.txt")
				.documentType("TH").dueDateFrom(LocalDate.now()).dueDateTo(LocalDate.now())
				.equabliAccountNumber(7891230L).originalAccountNumber("456789").fullfillmentDateFrom(LocalDate.now())
				.fullfillmentDateFrom(LocalDate.now()).pageNumber(pageNumber).pageSize(pageSize)
				.requestedDateFrom(LocalDate.now()).requestedDateTo(LocalDate.now()).requestedFrom("Test User")
				.requestStatus("Open").build();
	}

	private SentRequestDocumentSearchParam getSentRequestDocumentSearchParam(Integer pageNumber, Integer pageSize, String textSearch) {
		return SentRequestDocumentSearchParam.builder().textSearch(textSearch).pageNumber(pageNumber).pageSize(pageSize).build();
	}
	
	private List<String> getUserDetailsRequest(){
		return Arrays.asList("ssingh2@q3tech.com", "abehal@equabli.com");
	}
	
	private UserMailResponse getListUserDetailResponse() {
		UserDetailResponse userDetailResponse = new UserDetailResponse();
		userDetailResponse.setIsExists(true);
		userDetailResponse.setMailId("ssingh2@q3tech.com");
		
		UserDetails userDetails = new UserDetails();
		userDetails.setFirstName("Sachin");
		userDetails.setPrincipleId(21L);
		userDetails.setOrgType("CL");
		userDetails.setOrgCode("MRLT");
		userDetailResponse.setUserDetails(userDetails);
		
		UserDetailResponse userDetailResponse2 = new UserDetailResponse();
		userDetailResponse2.setIsExists(true);
		userDetailResponse2.setMailId("abehal@equabli.com");
		UserDetails userDetails2 = new UserDetails();
		userDetails2.setFirstName("Aakash");
		userDetails2.setPrincipleId(9L);
		userDetails2.setOrgType("PT");
		userDetails2.setOrgCode("TRAKA");
		userDetailResponse2.setUserDetails(userDetails2);
		
		UserMailResponse userMailResponse = new UserMailResponse();
		userMailResponse.setError(null);
		userMailResponse.setValidation(true);
		userMailResponse.setMessage("success");
		userMailResponse.setResponse(Arrays.asList(userDetailResponse, userDetailResponse2));
		
		return userMailResponse;
	}
	
	private List<EmailRequest> getEmailRequest(String email) {
		return Arrays.asList(EmailRequest.builder().recipients(Arrays.asList(email)).subject("Testing mail")
				.parameters(null).templateName("sample.html").build());
	}
}
