package com.equabli.documents;

import java.time.LocalDate;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.util.MultiValueMap;

import com.equabli.common.auth.TokenData;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.utils.LocalDateDeserializer;
import com.equabli.documents.request.UserDocConfigRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.gson.Gson;

@SpringBootTest
@AutoConfigureMockMvc
@ExtendWith(SpringExtension.class)
@ActiveProfiles("test")
public class TestAppConfig {

	public static final String TOKEN = "Bearer eyJhbGciOiJIUzUxMiJ9.eyJhdWQiOiJjaHJvbWUtZXh0ZW5zaW9uOi8vYWljbWtncGdha2RkZ25hcGhoaHBsaWlmcGNmaGljZm8iLCJyZW1vdGUtaXAiOiIwOjA6MDowOjA6MDowOjEiLCJqdGkiOiI4YjcxMmFhMGZiMDhmZjcxMjAxZWJmNWEzMWU1YjY0NDY5MmEyYTQ4ZmM0MWIzMTBiOTkxNmIxODMxMTg4YTA0IiwiYXV0aG9yaXRpZXMiOlsiQ09MT1JfUiIsIkNPTE9SX1ciXSwidXNlci1hZ2VudCI6Ik1vemlsbGEvNS4wIChXaW5kb3dzIE5UIDEwLjA7IFdpbjY0OyB4NjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xMDguMC4wLjAgU2FmYXJpLzUzNy4zNiJ9.gjzYhB6bg4_rtSoiVrsr9uGP9juk53WnJwitStEabtOdlcVaJuJixULUOSghYtB4RjW59K3BpsBcfPa-EQicwQ";
	public static final String AUTHORIZATION = "Authorization";
	public static final String PAGE_SIZE = "pageSize",  PAGE_NUMBER = "pageNumber";

	@Autowired
	private MockMvc mockMvc;
	
	
	public static CommonResponse getErrorMessageFromTest(MockHttpServletResponse baseResponseForPOST) throws Exception {
		return new Gson().fromJson(baseResponseForPOST.getContentAsString(), 
				CommonResponse.class);
	}
	 
	public static <T> String convertJsonToString(T element) {
		return new Gson().toJson(element);
	}
	
	public static CommonResponse<?> getBaseResponseFromMockResponse(MockHttpServletResponse baseResponseForPOST) throws Exception {
		return new Gson().fromJson(baseResponseForPOST.getContentAsString(), 
				CommonResponse.class);
	}
	
	public static PagedResponse<?> getPagedResponse(MockHttpServletResponse baseResponseForPOST) throws Exception {
		return new Gson().fromJson(baseResponseForPOST.getContentAsString(), 
				PagedResponse.class);
	}
	
	/**
	 * For POST API
	 * 
	 * @param matcher
	 * @param uri
	 * @param json
	 * @return
	 * @throws Exception
	 */
	public CommonResponse getBaseResponseForPOST(String uri, String json)
			throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(uri).header(AUTHORIZATION, TOKEN)
				.contentType(MediaType.APPLICATION_JSON).content(json);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}
	
	/**
	 * 
	 * @param matcher
	 * @param uri
	 * @param json
	 * @return
	 * @throws Exception
	 */
	public MockHttpServletResponse getBaseResponseForPOST(ResultMatcher matcher, String uri, MultiValueMap<String, String> params)
			throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(uri).header(AUTHORIZATION, TOKEN)
				.params(params);
		MvcResult result = mockMvc.perform(requestBuilder).andExpect(matcher).andReturn();
		return result.getResponse();
	}

	/**
	 * For GET API with parameters
	 * 
	 * @param matcher
	 * @param uri
	 * @param json
	 * @return
	 * @throws Exception
	 */
	public CommonResponse getBaseResponseForGET(String uri,
			MultiValueMap<String, String> params) throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(uri).header(AUTHORIZATION, TOKEN).params(params);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}
	
	/**
	 * For GET API without parameters
	 * 
	 * @param matcher
	 * @param uri
	 * @param json
	 * @return
	 * @throws Exception
	 */
	public CommonResponse getBaseResponseForGET(String uri) throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(uri).header(AUTHORIZATION, TOKEN);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}
	
	public PagedResponse getPagedResponseForGET(String uri,
			MultiValueMap<String, String> params) throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(uri).header(AUTHORIZATION, TOKEN).params(params)
				.contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getPagedResponse(result.getResponse());
	}
	
	public static UserDocConfigRequest getUserDocConfigRequest(String docMrgConfig, String docMrgConfigVal, String orgType) {
		UserDocConfigRequest userDocConfigRequest = new UserDocConfigRequest();
		userDocConfigRequest.setConfigShortCode(docMrgConfig);
		userDocConfigRequest.setConfigValShortCode(docMrgConfigVal);
		return userDocConfigRequest;
	}
	
	/**
	 * For GET API with parameters
	 * 
	 * @param matcher
	 * @param uri
	 * @param json
	 * @return
	 * @throws Exception
	 */
	public CommonResponse getBaseResponseForPatch(String uri,
			MultiValueMap<String, String> params) throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders.patch(uri).header(AUTHORIZATION, TOKEN).params(params);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}
	
	public CommonResponse getBaseResponseForPatch(String uri) throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders.patch(uri).header(AUTHORIZATION, TOKEN);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}
	
	public PagedResponse getPagedResponseForGET(String uri) throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(uri).header(AUTHORIZATION, TOKEN)
				.contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getPagedResponse(result.getResponse());
	}
	
	public PagedResponse getPagedResponseForPOST(String uri) throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(uri).header(AUTHORIZATION, TOKEN);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getPagedResponse(result.getResponse());
	}
	
	public PagedResponse getPagedResponseForPOST(String uri, String json) throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(uri).header(AUTHORIZATION, TOKEN)
				.contentType(MediaType.APPLICATION_JSON).content(json);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getPagedResponse(result.getResponse());
	}
	
	public CommonResponse getBaseResponseForPOST(String uri)
			throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(uri).header(AUTHORIZATION, TOKEN);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}
	
	public CommonResponse mockMvcRequestPUT(String uri) throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders.put(uri).header(AUTHORIZATION, TOKEN);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return getErrorMessageFromTest(result.getResponse());
	}

	/**
	 * It's used for set customer date format in ObjectMapper
	 * @param value
	 * @return
	 * @throws JsonProcessingException
	 */
	public static String getJsonStringUsingObjectMapper(Object value) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		JavaTimeModule javaTimeModule = new JavaTimeModule();
		javaTimeModule.addDeserializer(LocalDate.class, new LocalDateDeserializer());
		objectMapper.registerModule(javaTimeModule);
		return objectMapper.writeValueAsString(value);
	}
	
	public static TokenData getTokenData() {
		TokenData tokenData = new TokenData();
		tokenData.setPrincipleId(21L);
		tokenData.setLoginKey("ssingh2@q3tech.com");
		tokenData.setFirstName("Sachin");
		tokenData.setEmailAddress("ssingh2@q3tech.com");
		tokenData.setOrgType("CL");
		tokenData.setUserOrgCode("XYZ");
		tokenData.setUserOrgId(2);
		tokenData.setUserOrgName("XYZ Bank");
		return tokenData;
	}
	
	public static String getFcmToken() {
		return "{\"message\":\"Web Token fetch successfully\",\"status\":\"SUCCESS\",\"response\":[{\"userId\":21,\"token\":\"d_Ee3a-9Fn_TpuEIjqtCAM:APA91bFW82G9YGNNylBOhv4PS2rSoL6iGiS_614H-WUqmPa1YM3VNlRe1qVvv9DObQ2SHCldDko8cxzxHRmHanAXusHgHABDTBiJVFjz3gtOdfco0lzzxE0WGHzYTPNyXE0SKNeG0Qvm\"}],\"validation\":true} ";
	}
}
