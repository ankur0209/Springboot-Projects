package com.equabli.documents.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.documents.TestAppConfig;
import com.equabli.documents.response.DocumentCostConfigResponse;

@TestMethodOrder(OrderAnnotation.class)
public class TestDocumentCostInvoiceController extends TestAppConfig{

	public static final String URI = "http://localhost:8081/user/document/cost/invoice";
	
	@MockBean(reset = MockReset.BEFORE) 
	FetchTokenData fetchTokenData;
	
	@Autowired
	private MockMvc mockMvc;
	
	@BeforeEach
	public void setTokenData() {
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
	}
	
	@Test
	void testShowInvoiceCost() throws Exception {
		MultiValueMap<String, String> param = new LinkedMultiValueMap<>();
		param.add("tenure", "year");
		@SuppressWarnings("unchecked")
		PagedResponse<DocumentCostConfigResponse> pagedResponse = getPagedResponseForGET(URI,param);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}
	
	@Test
	void testDownloadInvoice() throws Exception {
		String uri = URI + "/download";
		MultiValueMap<String, String> param = new LinkedMultiValueMap<>();
		param.add("tenure", "year");
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(uri).header(AUTHORIZATION, TOKEN).params(param);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		assertNotNull(result.getResponse().getContentAsString());
		assertEquals("application/vnd.ms-pdf", result.getResponse().getContentType());
	}
}
