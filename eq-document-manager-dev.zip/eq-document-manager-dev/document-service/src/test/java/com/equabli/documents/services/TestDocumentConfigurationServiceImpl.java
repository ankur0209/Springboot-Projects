package com.equabli.documents.services;

import static org.junit.Assert.assertNotNull;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.documents.TestAppConfig;
import com.equabli.documents.response.DocumentResponse;
import com.equabli.documents.service.impl.DocumentConfigurationServiceImpl;

class TestDocumentConfigurationServiceImpl extends TestAppConfig {

	@Autowired
	DocumentConfigurationServiceImpl documentConfigurationServiceImpl;

	@Autowired
	MessageSupplier messageSupplier;
	
//	@Test
//	void getFileNameFromFileConfig_test() {
//		String filename = "abc.txt";
//		List<String> fileNameConfigs = new ArrayList<>(Arrays.asList("CIDSC", "DT", "CAN", "OAN", "DGD", "DN", "NA", "PC"));
//		String seperator = "-";
//		String fileNameNew = documentConfigurationServiceImpl.getFileNameFromFileConfig(filename, fileNameConfigs,
//				seperator, getDocumentResponse());
//
//		assertNotNull(fileNameNew);
//
//	}

	@Test
	void getProduct() {
		String shortCode = "CC";
		List<Map<String, String>> fileNameNew = Util.getProductMap(shortCode);

		assertNotNull(fileNameNew);

	}

//	@Test
//	void getInvalidProduct() {
//		String shortCode = "HM";
//		assertThrows(InvalidArgumentException.class, () -> Util.getProductMap(shortCode),
//				messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, shortCode));
//
//	}

//	@Test
//	void isDataPresent() {
//		String productCode = "ML";
//		String docName = "Application";
//		String docCode = "AP";
//		String prodName = "Medical";
//		Long productId = 5l;
//		MapProductDocType fileNameNew = documentConfigurationServiceImpl.saveMapProductDocType(productCode,docCode,docName,productId,prodName);
//
//		assertNotNull(fileNameNew);
//	}

	private DocumentResponse getDocumentResponse() {
		DocumentResponse documentResponse = new DocumentResponse();
		documentResponse.setId(1L);
		documentResponse.setDocumentName("Application");
		documentResponse.setOriginalAccountNo("456789");
		documentResponse.setDocumentType("Application");
		documentResponse.setEquabliAccountNo(123456L);
		documentResponse.setClientAccountNo("123456");
		documentResponse.setGenerateDate(LocalDateTime.now());
		documentResponse.setOrgTypeCode("CL");
		documentResponse.setFileName("test.txt");
		documentResponse.setFileSize(123L);
		return documentResponse;
	}
}
