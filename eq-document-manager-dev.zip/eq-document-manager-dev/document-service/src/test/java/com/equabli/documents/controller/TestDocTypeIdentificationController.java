package com.equabli.documents.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.DocType;
import com.equabli.common.entity.DocTypeIdentification;
import com.equabli.common.repository.DocTypeIdentificationRepository;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.documents.TestAppConfig;
import com.equabli.documents.constants.DocumentMessageConstants;
import com.equabli.documents.request.DocTypeIdentificationRequest;
import com.equabli.documents.response.DocTypeIdentificationResponse;
import com.equabli.documents.response.DocumentResponse;
import com.equabli.documents.searchparams.DocTypeIdentificationSearchParam;

class TestDocTypeIdentificationController extends TestAppConfig {

	public static final String URI = "http://localhost:8081/user/document/identification";

	@MockBean
	FetchTokenData fetchTokenData;

	@Autowired
	MessageSupplier messageSupplier;

	@MockBean
	DocTypeIdentificationRepository docTypeIdentificationRepository;

	@BeforeEach
	public void setTokenData() {
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
	}

	@Test
	void saveDocTypeIdentification() throws Exception {

		String json = convertJsonToString(getDocTypeIdentificationRequest("AP"));

		@SuppressWarnings("unchecked")
		CommonResponse<DocumentResponse> commonResponse = getBaseResponseForPOST(URI, json);
		Assert.assertEquals(
				messageSupplier.get(
						DocumentMessageConstants.DocumentTypeIdentification.DOCUMENT_TYPE_IDENTIFICATION_SAVED_SUCCESS),
				commonResponse.getMessage());
	}

	@Test
	void saveDocTypeIdentification_1() throws Exception {

		String docTypeCode = "Test";
		String json = convertJsonToString(getDocTypeIdentificationRequest(docTypeCode));

		@SuppressWarnings("unchecked")
		CommonResponse<DocumentResponse> commonResponse = getBaseResponseForPOST(URI, json);
		Assert.assertEquals(messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, " " + docTypeCode),
				commonResponse.getErrors().get(0));
	}

	@Test
	void deleteDocTypeIdentification() throws Exception {

		String docTypeCode = "AP";

		when(docTypeIdentificationRepository.findByDocType_ShortCode(docTypeCode))
				.thenReturn(Optional.of(new DocTypeIdentification()));

		@SuppressWarnings("unchecked")
		CommonResponse<DocumentResponse> commonResponse = getBaseResponseForPatch(URI + "/" + docTypeCode);
		Assert.assertEquals(messageSupplier
				.get(DocumentMessageConstants.DocumentTypeIdentification.DOCUMENT_TYPE_IDENTIFICATION_DELETE_SUCCESS),
				commonResponse.getMessage());
	}

	@Test
	void deleteDocTypeIdentification_1() throws Exception {

		String docTypeCode = "Test";

		when(docTypeIdentificationRepository.findByDocType_ShortCode(docTypeCode)).thenReturn(Optional.empty());

		@SuppressWarnings("unchecked")
		CommonResponse<DocumentResponse> commonResponse = getBaseResponseForPatch(URI + "/" + docTypeCode);
		Assert.assertEquals(messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, docTypeCode),
				commonResponse.getErrors().get(0));
	}

	@Test
	void getAllDocTypeIdentification() throws Exception {

		String uri = URI + "/all";

		Page<DocTypeIdentification> paged = new PageImpl<>(Arrays.asList(getDocTypeIdentification()));
		when(docTypeIdentificationRepository.getDocumentTypeIdentification(any(), any())).thenReturn(paged);

		@SuppressWarnings("unchecked")
		PagedResponse<DocTypeIdentificationResponse> pagedResponse = getPagedResponseForPOST(uri);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}

	@Test
	void getAllDocTypeIdentification_1() throws Exception {

		String uri = URI + "/all";
		String json = convertJsonToString(new DocTypeIdentificationSearchParam());
		Page<DocTypeIdentification> paged = new PageImpl<>(Collections.emptyList());

		when(docTypeIdentificationRepository.getDocumentTypeIdentification(any(), any())).thenReturn(paged);

		@SuppressWarnings("unchecked")
		PagedResponse<DocTypeIdentificationResponse> pagedResponse = getPagedResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}

	private DocTypeIdentificationRequest getDocTypeIdentificationRequest(String docTypeCode) {
		DocTypeIdentificationRequest docTypeIdentification = new DocTypeIdentificationRequest();
		docTypeIdentification.setDocTypeCode(docTypeCode);
		docTypeIdentification.setDocTypeFields(
				Arrays.asList("Client Account Number", "Original Account Number", "Equabli Account Number"));
		return docTypeIdentification;
	}

	private DocTypeIdentification getDocTypeIdentification() {
		DocTypeIdentification docTypeIdentification = new DocTypeIdentification();
		docTypeIdentification.saveDocTypeIdentification(docTypeIdentification, new DocType(), getTokenData());
		return docTypeIdentification;
	}

}
