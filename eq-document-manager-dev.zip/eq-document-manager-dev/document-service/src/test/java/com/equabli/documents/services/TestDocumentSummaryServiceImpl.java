package com.equabli.documents.services;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.equabli.common.utils.MessageSupplier;
import com.equabli.documents.TestAppConfig;
import com.equabli.documents.constants.ColumnConstants;
import com.equabli.documents.service.impl.DocumentSummaryServiceImpl;

class TestDocumentSummaryServiceImpl extends TestAppConfig {

	@Autowired
	DocumentSummaryServiceImpl documentSummaryServiceImpl;

	@Autowired
	MessageSupplier messageSupplier;

	@Test
	void getFileNameFromFileConfig_test() {
		List<String> result = new ArrayList<>();
		List<String> columnList = new ArrayList<>(
				Arrays.asList(ColumnConstants.COLUMN_DOCUMENT_NAME, ColumnConstants.COLUMN_ORIGINAL_ACCOUNT_NUMBER,
						ColumnConstants.COLUMN_EQUABLI_ACCOUNT_NUMBER, ColumnConstants.COLUMN_CLIENT_ACCOUNT_NUMBER,
						ColumnConstants.COLUMN_GENERATED_DATE, ColumnConstants.COLUMN_UPLOAD_DATE,
						ColumnConstants.COLUMN_FILE_SIZE, ColumnConstants.COLUMN_SHARED_BY));

		for (String columnName : columnList) {
			result.add(documentSummaryServiceImpl.getAccountSortParam(columnName));
		}
		assertEquals(columnList.size(), result.size());
	}
}
