package com.equabli.documents.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.entity.DocType;
import com.equabli.common.entity.Document;
import com.equabli.common.feignclients.CommonConfigService;
import com.equabli.common.repository.DocTypeRepository;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.request.EmailRequest;
import com.equabli.common.request.FileUploadConfigRequest;
import com.equabli.common.request.ShareUserDetailRequest;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.UserDetailResponse;
import com.equabli.common.response.UserDetails;
import com.equabli.common.response.UserMailResponse;
import com.equabli.documents.TestAppConfig;
import com.equabli.documents.feignclient.SentMail;
import com.equabli.documents.feignclient.UserService;
import com.equabli.documents.request.ShareDocumentRequest;
import com.equabli.documents.request.ShareFolderRequest;

@TestInstance(Lifecycle.PER_CLASS)
@TestMethodOrder(OrderAnnotation.class)
class TestShareDocumentController extends TestAppConfig{

	public static final String URI = "http://localhost:8081/user/document/share";
	private static final String CLIENT_AC_NO = "123456";
	private static final Long DOCUMENT_ID = 1l;
	
	@Autowired
	DocTypeRepository docTypeRepository;
	
	@Autowired
	DocumentRepository documentRepository;
	
	@MockBean(reset = MockReset.BEFORE) 
	FetchTokenData fetchTokenData;
	
	@MockBean 
	private UserService userService;
	
	@MockBean
	private SentMail sentMail;
	
	@MockBean
	CommonConfigService configService;

	@BeforeEach
	public void setTokenData() {
		Mockito.when(userService.emailExists(any(), any()))
				.thenReturn(convertJsonToString(getListUserDetailResponse()));
		Mockito.when(sentMail.sendEmails(any(), anyList())).thenReturn("Mail Sent");
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
		Mockito.when(configService.getToken(any(), any(), any())).thenReturn(getFcmToken());
		Mockito.when(sentMail.sendNotification(any(), any())).thenReturn("send Successfully");
	}
	
	@Test
	void testShareDocument() throws Exception {
		String uri = URI + "/file";
		String json = convertJsonToString(getShareDocumentRequest(DOCUMENT_ID));

		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	@Test
	void testShareDocumentInvalid() throws Exception {
		String uri = URI + "/file";
		String json = convertJsonToString(getShareDocumentRequest(0l));

		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	@Test
	void testUnSharedDocument() throws Exception {
		String uri = URI + "/file/abc@gmail.com";
		
		@SuppressWarnings("unchecked")
		CommonResponse<String> pagedResponse = getBaseResponseForPatch(uri);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}
	
	@Test
	void testUnSharedDocumentInvalid() throws Exception {
		String uri = URI + "/file/a@gmail.com";
		
		@SuppressWarnings("unchecked")
		CommonResponse<String> pagedResponse = getBaseResponseForPatch(uri);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}
	
	@Test
	void testShareFolder() throws Exception {
		saveDocument(CLIENT_AC_NO);
		String uri = URI + "/folder";
		String json = convertJsonToString(getShareFolderRequest(true));

		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	@Test
	void testShareFolderInvalid() throws Exception {
		saveDocument(CLIENT_AC_NO);
		String uri = URI + "/folder";
		String json = convertJsonToString(getShareFolderRequest(false));

		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	private ShareDocumentRequest getShareDocumentRequest(long id) {
		ShareDocumentRequest shareDocumentRequest = new ShareDocumentRequest();
		shareDocumentRequest.setDocumentId(id);
		List<ShareUserDetailRequest> shareUserDetail = new ArrayList<>();
		ShareUserDetailRequest detailRequest = new ShareUserDetailRequest();
		detailRequest.setEmail("abc@gmail.com");
		detailRequest.setIsRegisterUser(true);
		detailRequest.setName("Aakash");
		detailRequest.setOrgType("PT");
		detailRequest.setPrincipleId(9l);
		detailRequest.setUserOrgCode("TRAKA");
		shareUserDetail.add(detailRequest);
		
		shareDocumentRequest.setShareDetail(shareUserDetail);
		return shareDocumentRequest;
	}
	
	private ShareFolderRequest getShareFolderRequest(boolean isValidData) {
		ShareFolderRequest shareFolderRequest = new ShareFolderRequest();
		if(isValidData)
			shareFolderRequest.setClientAccountNo("123456");
		else
			shareFolderRequest.setClientAccountNo(null);
		List<ShareUserDetailRequest> shareUserDetail = new ArrayList<>();
		ShareUserDetailRequest detailRequest = new ShareUserDetailRequest();
		detailRequest.setEmail("abc@gmail.com");
		detailRequest.setIsRegisterUser(true);
		detailRequest.setName("Aakash");
		detailRequest.setOrgType("PT");
		detailRequest.setPrincipleId(9l);
		detailRequest.setUserOrgCode("TRAKA");
		shareUserDetail.add(detailRequest);
		
		shareFolderRequest.setShareDetail(shareUserDetail);
		return shareFolderRequest;
	}
	
	private void saveDocument(String acNo) {
		Document document = new Document();

		FileUploadConfigRequest fileUploadConfigRequest = new FileUploadConfigRequest();
		fileUploadConfigRequest.setClientAccountNo(acNo);
		fileUploadConfigRequest.setDocumentGenerationDate(LocalDateTime.now());
		fileUploadConfigRequest.setDocType("AP");

		DocType docType = docTypeRepository.findByShortCode("AP").orElseThrow();

		document.saveDocument(document, fileUploadConfigRequest, false, null, docType.getName(),  getTokenData(), getTokenData());
		documentRepository.save(document);
	}
	
	private List<String> getUserDetailsRequest(){
		return Arrays.asList("ssingh2@q3tech.com", "abehal@equabli.com");
	}
	
	private UserMailResponse getListUserDetailResponse() {
		UserDetailResponse userDetailResponse = new UserDetailResponse();
		userDetailResponse.setIsExists(true);
		userDetailResponse.setMailId("ssingh2@q3tech.com");
		
		UserDetails userDetails = new UserDetails();
		userDetails.setFirstName("Sachin");
		userDetails.setPrincipleId(21L);
		userDetails.setOrgType("CL");
		userDetails.setOrgCode("MRLT");
		userDetailResponse.setUserDetails(userDetails);
		
		UserDetailResponse userDetailResponse2 = new UserDetailResponse();
		userDetailResponse2.setIsExists(true);
		userDetailResponse2.setMailId("abehal@equabli.com");
		UserDetails userDetails2 = new UserDetails();
		userDetails2.setFirstName("Aakash");
		userDetails2.setPrincipleId(9L);
		userDetails2.setOrgType("PT");
		userDetails2.setOrgCode("TRAKA");
		userDetailResponse2.setUserDetails(userDetails2);
		
		UserMailResponse userMailResponse = new UserMailResponse();
		userMailResponse.setError(null);
		userMailResponse.setValidation(true);
		userMailResponse.setMessage("success");
		userMailResponse.setResponse(Arrays.asList(userDetailResponse, userDetailResponse2));
		
		return userMailResponse;
	}
	
	private List<EmailRequest> getEmailRequest(String email) {
		return Arrays.asList(EmailRequest.builder().recipients(Arrays.asList(email)).subject("Testing mail")
				.parameters(null).templateName("sample.html").build());
	}
}
