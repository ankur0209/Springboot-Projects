package com.equabli.documents.controller;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.entity.DocType;
import com.equabli.common.entity.Document;
import com.equabli.common.repository.DocTypeRepository;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.request.FileUploadConfigRequest;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.searchparam.DocumentForldersSearchParam;
import com.equabli.documents.TestAppConfig;
import com.equabli.documents.request.UserDocConfigRequest;
import com.equabli.documents.response.DocumentResponse;
import com.equabli.documents.response.DocumentTypeResponse;
import com.equabli.documents.searchparams.DocumentsSearchParam;
import com.equabli.documents.service.GlobalConfigService;

@TestInstance(Lifecycle.PER_CLASS)
@TestMethodOrder(OrderAnnotation.class)
class TestDocumentConfigController extends TestAppConfig {

	@Autowired
	private DocumentRepository documentRepository;

	@Autowired
	private GlobalConfigService globalConfigService;

	@Autowired
	private DocTypeRepository docTypeRepository;

	public static final String URI = "http://localhost:8081/user/document";
	private static final String CLIENT = "CL", INVALID_USER_TYPE = "Abc", OTHER = "Other";
	private static final String APPLICATION_CODE = "AP";

	@MockBean(reset = MockReset.BEFORE) 
	FetchTokenData fetchTokenData;

	@BeforeEach
	public void setTokenData() {
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
	}
	
	@BeforeAll
	public void setDatabase() {
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
		saveDocument();
		saveDocumentOther();
		globalConfigService.saveUserFileConfig(getUserDocConfigRequest(CLIENT));
	}

	@Test
	void getdocumentForClient() throws Exception {

		String json = getJsonStringUsingObjectMapper(getDocumentsSearchParam(CLIENT, "123456", "1", "documentName"));

		String uri = URI + "/all";
		@SuppressWarnings("unchecked")
		PagedResponse<DocumentResponse> pagedResponse = getPagedResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}

	@Test
	void getDocumentsforInvalidOrgType() throws Exception {

		String json = getJsonStringUsingObjectMapper(
				getDocumentsSearchParam(INVALID_USER_TYPE, "123456", null, "documentType"));

		String uri = URI + "/all";
		@SuppressWarnings("unchecked")
		PagedResponse<DocumentResponse> pagedResponse = getPagedResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}

	@Test
	void getDocumentsforOther() throws Exception {

		String json = getJsonStringUsingObjectMapper(getDocumentsSearchParam(CLIENT, OTHER, null, null));

		String uri = URI + "/all";
		@SuppressWarnings("unchecked")
		PagedResponse<DocumentResponse> pagedResponse = getPagedResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}
	
	@Test
	void getdocumentForClient_1() throws Exception {

		String json = getJsonStringUsingObjectMapper(DocumentsSearchParam.builder().accountNumber("abc123").build());

		String uri = URI + "/all";
		@SuppressWarnings("unchecked")
		PagedResponse<DocumentResponse> pagedResponse = getPagedResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}

	@Test
	void getFolderList() throws Exception {

		String uri = URI + "/folders";
		String json = getJsonStringUsingObjectMapper(
				getDocumentForldersSearchParam("123456", "1", LocalDate.now(), "folderName"));

		@SuppressWarnings("unchecked")
		PagedResponse<DocumentResponse> pagedResponse = getPagedResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}
	
	@Test
	void getFolderList_2() throws Exception {

		String uri = URI + "/folders";
		String json = getJsonStringUsingObjectMapper(
				getDocumentForldersSearchParam(null, null, LocalDate.now(), "modifiedDate"));

		@SuppressWarnings("unchecked")
		PagedResponse<DocumentResponse> pagedResponse = getPagedResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}
	
	@Test
	void getFolderList_3() throws Exception {
		PagedResponse<DocumentResponse> pagedResponse = searchOnFolder("123456", "fileSize");
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}
	

	@Test
	void getFolderList_4() throws Exception {
		PagedResponse<DocumentResponse> pagedResponse = searchOnFolder(null, "shareDate");
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}

	@Test
	void getFolderList_5() throws Exception {

		PagedResponse<DocumentResponse> pagedResponse = searchOnFolder("TestAccountNo", "receiveDate");
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}

	@Test
	void getFolderList_6() throws Exception {

		String uri = URI + "/folders";

		@SuppressWarnings("unchecked")
		PagedResponse<DocumentResponse> pagedResponse = getPagedResponseForPOST(uri);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}
	
	@Test
	void getFolderList_7() throws Exception {

		PagedResponse<DocumentResponse> pagedResponse = searchOnFolder("TestAccountNo", "shareBy");
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}
	
	@Test
	void getFolderList_8() throws Exception {

		PagedResponse<DocumentResponse> pagedResponse = searchOnFolder("TestAccountNo", "sharedWith");
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}

	@Test
	void getDocumentsForProducts() throws Exception {

		String uri = URI + "/type";
		@SuppressWarnings("unchecked")
		CommonResponse<List<DocumentTypeResponse>> pagedResponse = getBaseResponseForGET(uri);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}
	
	@Test
	void deleteDocument() throws Exception {
		String uri = URI + "/1";
		@SuppressWarnings("unchecked")
		CommonResponse<DocumentTypeResponse> commonResponse = getBaseResponseForPatch(uri);
		assertEquals(CommonResponse.OperationStatus.SUCCESS, commonResponse.getStatus());
	}

	@Test
	void testDeleteFolder() throws Exception {
		String uri = URI + "/folder/123456";
		@SuppressWarnings("unchecked")
		CommonResponse<String> commonResponse = getBaseResponseForPatch(uri);
		assertEquals(CommonResponse.OperationStatus.SUCCESS, commonResponse.getStatus());
	}
	
	private void saveDocument() {
		Document document = new Document();

		FileUploadConfigRequest fileUploadConfigRequest = new FileUploadConfigRequest();
		fileUploadConfigRequest.setClientAccountNo("123456");
		fileUploadConfigRequest.setDocumentGenerationDate(LocalDateTime.now());
		fileUploadConfigRequest.setDocType(APPLICATION_CODE);

		DocType docType = docTypeRepository.findByShortCode("AP").orElseThrow();

		document.saveDocument(document, fileUploadConfigRequest, false, null, docType.getName(),  getTokenData(), getTokenData());
		documentRepository.save(document);
	}

	private List<UserDocConfigRequest> getUserDocConfigRequest(String orgType) {

		List<UserDocConfigRequest> userDocConfigRequests = new ArrayList<>();
		userDocConfigRequests.add(getUserDocConfigRequest("field1", "CAN", orgType));
		userDocConfigRequests.add(getUserDocConfigRequest("field2", "OAN", orgType));
		if (!orgType.equals(CLIENT))
			userDocConfigRequests.add(getUserDocConfigRequest("field6", "CIDSC", orgType));

		userDocConfigRequests.add(getUserDocConfigRequest("SEPARATOR", "_", orgType));
		return userDocConfigRequests;
	}

	private DocumentsSearchParam getDocumentsSearchParam(String orgTypeCode, String accountNumber, String search, String sortParam) {
		return DocumentsSearchParam.builder().accountNumber(accountNumber)
				.documentType("Application").documentName("abc.txt").generationDateFrom(LocalDate.now())
				.generationDateTo(LocalDate.now()).uploadDateFrom(LocalDate.now()).uploadDateTo(LocalDate.now())
				.textSearch(search).sortParam(sortParam).build();
	}
	
	private DocumentForldersSearchParam getDocumentForldersSearchParam(String folderName, String search,
			LocalDate localDate, String sortParam) {
		return DocumentForldersSearchParam.builder().folderName(folderName).textSearch(search)
				.modifiedDateFrom(localDate).modifiedDateTo(localDate).sortParam(sortParam).build();
	}

	private void saveDocumentOther() {
		Document document = new Document();
		FileUploadConfigRequest fileUploadConfigRequest = new FileUploadConfigRequest();
		fileUploadConfigRequest.setClientAccountNo("123456");
		fileUploadConfigRequest.setOriginalAccountNo("456789");

		document.saveDocument(document, fileUploadConfigRequest, true, null,
				"abc.txt", getTokenData(), getTokenData());
		documentRepository.save(document);
	}
	
	@SuppressWarnings("unchecked")
	private PagedResponse<DocumentResponse> searchOnFolder(String accountNumber, String searchParam) throws Exception{
		String uri = URI + "/folders";
		String json = getJsonStringUsingObjectMapper(getDocumentForldersSearchParam("123456", null, null, searchParam));

		return getPagedResponseForPOST(uri, json);
	}

}