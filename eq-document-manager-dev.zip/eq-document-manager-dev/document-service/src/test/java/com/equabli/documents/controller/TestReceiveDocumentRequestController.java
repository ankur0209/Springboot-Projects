package com.equabli.documents.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.feignclients.CommonConfigService;
import com.equabli.common.request.EmailRequest;
import com.equabli.common.request.RequestNewDocumentRequest;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.response.UserDetailResponse;
import com.equabli.common.response.UserDetails;
import com.equabli.common.response.UserMailResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.documents.TestAppConfig;
import com.equabli.documents.feignclient.SentMail;
import com.equabli.documents.feignclient.UserService;
import com.equabli.documents.request.DownloadDocumentRequest;
import com.equabli.documents.request.UserDocConfigRequest;
import com.equabli.documents.response.ReceiveDocumentResponse;
import com.equabli.documents.searchparams.ReceiveRequestDocumentSearchParam;
import com.equabli.documents.service.GlobalConfigService;
import com.equabli.documents.service.impl.SentReceiveDocumentServiceImpl;
@TestInstance(Lifecycle.PER_CLASS)
class TestReceiveDocumentRequestController extends TestAppConfig {

	public static final String URI = "http://localhost:8081/user/document/receiveDocumentRequest";
	// private static final String DOCUMENT_ID = "doumentId";
	
	@Autowired
	GlobalConfigService globalConfigService;
	
	@Autowired
	private SentReceiveDocumentServiceImpl sendReceiveDocumentService;
	
	@Autowired
	private MessageSupplier messageSupplier;
	
	@MockBean 
	private UserService userService;
	
	@MockBean
	private SentMail sentMail;

	@MockBean(reset = MockReset.BEFORE) 
	FetchTokenData fetchTokenData;
	
	@MockBean
	CommonConfigService configService;

	@BeforeEach
	public void setTokenData() {
		Mockito.when(userService.emailExists(any(), any()))
				.thenReturn(convertJsonToString(getListUserDetailResponse()));
		Mockito.when(sentMail.sendEmails(any(), anyList())).thenReturn("Mail Sent");
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
		Mockito.when(configService.getToken(any(), any(), any())).thenReturn(getFcmToken());
		Mockito.when(sentMail.sendNotification(any(), any())).thenReturn("send Successfully");
	}
	
	@Test
	void getReceiveDocumentRequest() throws Exception {

		globalConfigService.saveUserFileConfig(getUserDocConfigRequest("CL"));
		sendReceiveDocumentService.saveRequestNewDocument(getRequestNewDocumentRequest("TH"));
		String json = getJsonStringUsingObjectMapper(getReceiveRequestDocumentSearchParam("1",null));

		String uri = URI + "/all";
		@SuppressWarnings("unchecked")
		PagedResponse<ReceiveDocumentResponse> pagedResponse = getPagedResponseForPOST(uri, json);

		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}

	@Test
	void getReceiveDocumentRequest_1() throws Exception {
		String uri = URI + "/all";
		@SuppressWarnings("unchecked")
		PagedResponse<ReceiveDocumentResponse> pagedResponse = getPagedResponseForPOST(uri);

		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}

	@Test
	void getReceiveDocumentRequest_2() throws Exception {
		globalConfigService.saveUserFileConfig(getUserDocConfigRequest("CL"));
		sendReceiveDocumentService.saveRequestNewDocument(getRequestNewDocumentRequest("TH"));
		String json = getJsonStringUsingObjectMapper(getReceiveRequestDocumentSearchParam(null,"requestedDocument"));

		String uri = URI + "/all";
		@SuppressWarnings("unchecked")
		PagedResponse<ReceiveDocumentResponse> pagedResponse = getPagedResponseForPOST(uri, json);

		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}

	@Test
	void saveReceiveDocumentRequest() throws Exception {

		String uri = URI;
		String json = convertJsonToString(getDownloadDocRequest(true));

		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}

	@Test
	void saveReceiveDocumentRequest_1() throws Exception {

		String uri = URI;
		String json = convertJsonToString(getInvalidDownloadDocRequest(true));

		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}

	@Test
	void deleteReceiveDocumentRequest() throws Exception {
		String uri = URI + "/1";

		@SuppressWarnings("unchecked")
		CommonResponse<String> pagedResponse = getBaseResponseForPatch(uri);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}
	
	@Test
	void deleteReceiveDocumentRequestInValid() throws Exception {
		String uri = URI + "/0";

		@SuppressWarnings("unchecked")
		CommonResponse<String> pagedResponse = getBaseResponseForPatch(uri);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}
	
//	@Test
//	void sendRequestDocuementSummary() throws Exception {
//
//		globalConfigService.saveUserFileConfig(getUserDocConfigRequest("CL"));
//		sendReceiveDocumentService.saveRequestNewDocument(getRequestNewDocumentRequest("TH"));
//		
//		String uri = URI + "/summary";
//		@SuppressWarnings("unchecked")
//		CommonResponse<SentReceiveSummaryResponse> commonResponse = getBaseResponseForGET(uri);
//		assertEquals(
//				messageSupplier.get(DocumentMessageConstants.RequireDocConfig.DOCUMENT_RECEIVE_SUMMARY_FETCH_SUCCESS),
//				commonResponse.getMessage());
//	}

	private DownloadDocumentRequest getDownloadDocRequest(boolean stat) {
		List<Long> documentIdList = new ArrayList<>();
		if (stat) {
			documentIdList.add(1l);
			// documentIdList.add(2l);
		}
		DownloadDocumentRequest documentRequest = new DownloadDocumentRequest();
		documentRequest.setDocumentId(documentIdList);

		return documentRequest;
	}

	private DownloadDocumentRequest getInvalidDownloadDocRequest(boolean stat) {
		List<Long> documentIdList = new ArrayList<>();
		if (stat) {
			documentIdList.add(0l);
			// documentIdList.add(2l);
		}
		DownloadDocumentRequest documentRequest = new DownloadDocumentRequest();
		documentRequest.setDocumentId(documentIdList);

		return documentRequest;
	}

	private ReceiveRequestDocumentSearchParam getReceiveRequestDocumentSearchParam(String search,String sortParam) {
		return ReceiveRequestDocumentSearchParam.builder().clientAccountNumber("123456").documentName("abc.txt")
				.documentType("TH").dueDateFrom(LocalDate.now()).dueDateTo(LocalDate.now()).equabliAccountNumber(7891230L)
				.originalAccountNumber("456789").fullfillmentDateFrom(LocalDate.now()).fullfillmentDateTo(LocalDate.now()).
				textSearch(search).sortParam(sortParam).requestedDateFrom(LocalDate.now()).requestedDateTo(LocalDate.now()).
				requestedBy("Test User").requestStatus("Open")
				.build();
	}
	
	private RequestNewDocumentRequest getRequestNewDocumentRequest(String docTypeCode) {
		
 		
		RequestNewDocumentRequest requestNewDocumentRequest = new RequestNewDocumentRequest();
		requestNewDocumentRequest.setSendRequests(getUserDetailsRequest());
		requestNewDocumentRequest.setOriginalAccountNumber("456789");
		requestNewDocumentRequest.setClientAccountNumber("123456");
		requestNewDocumentRequest.setEquabliAccountNumber(7890L);
		requestNewDocumentRequest.setDocTypeCode(docTypeCode);

		return requestNewDocumentRequest;
	}
	
	private List<UserDocConfigRequest> getUserDocConfigRequest(String orgType) {

		List<UserDocConfigRequest> userDocConfigRequests = new ArrayList<>();
		userDocConfigRequests.add(getUserDocConfigRequest("field1", "CAN", orgType));
		userDocConfigRequests.add(getUserDocConfigRequest("field2", "OAN", orgType));
		userDocConfigRequests.add(getUserDocConfigRequest("SEPARATOR", "-", orgType));
		return userDocConfigRequests;
	}
	
	private List<String> getUserDetailsRequest(){
		return Arrays.asList("ssingh2@q3tech.com", "abehal@equabli.com");
	}
	
	private UserMailResponse getListUserDetailResponse() {
		UserDetailResponse userDetailResponse = new UserDetailResponse();
		userDetailResponse.setIsExists(true);
		userDetailResponse.setMailId("ssingh2@q3tech.com");
		
		UserDetails userDetails = new UserDetails();
		userDetails.setFirstName("Sachin");
		userDetails.setPrincipleId(21L);
		userDetails.setOrgType("CL");
		userDetails.setOrgCode("MRLT");
		userDetailResponse.setUserDetails(userDetails);
		
		UserDetailResponse userDetailResponse2 = new UserDetailResponse();
		userDetailResponse2.setIsExists(true);
		userDetailResponse2.setMailId("abehal@equabli.com");
		UserDetails userDetails2 = new UserDetails();
		userDetails2.setFirstName("Aakash");
		userDetails2.setPrincipleId(9L);
		userDetails2.setOrgType("PT");
		userDetails2.setOrgCode("TRAKA");
		userDetailResponse2.setUserDetails(userDetails2);
		
		UserMailResponse userMailResponse = new UserMailResponse();
		userMailResponse.setError(null);
		userMailResponse.setValidation(true);
		userMailResponse.setMessage("success");
		userMailResponse.setResponse(Arrays.asList(userDetailResponse, userDetailResponse2));
		
		return userMailResponse;
	}
	
	private List<EmailRequest> getEmailRequest(String email) {
		return Arrays.asList(EmailRequest.builder().recipients(Arrays.asList(email)).subject("Testing mail")
				.parameters(null).templateName("sample.html").build());
	}
}
