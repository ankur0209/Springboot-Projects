package com.equabli.documents.controller;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.enums.FileNameConfigEnum;
import com.equabli.common.response.CommonResponse;
import com.equabli.documents.TestAppConfig;
import com.equabli.documents.request.UserDocConfigRequest;
import com.equabli.documents.response.DefaultDocMgrConfigResponse;
import com.equabli.documents.response.UserDocConfigResponse;


@TestMethodOrder(OrderAnnotation.class)
@TestInstance(Lifecycle.PER_CLASS)
class TestGlobalConfigController extends TestAppConfig {

	public static final String URI = "http://localhost:8081/user/file";
	private static final String CLIENT = "CL", PARTNER = "PT", INVALID_USER_TYPE = "Abc", ORG_TYPE = "orgType", fieldName = "fieldName";

	@MockBean(reset = MockReset.BEFORE) 
	FetchTokenData fetchTokenData;

	@BeforeEach
	public void setTokenData() {
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
	}
	
	@Test
	@Order(1)
	void userFileConfig() throws Exception {
		String json = convertJsonToString(getUserDocConfigRequest(CLIENT));
		String uri = URI + "/configuration";

		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	@Test
	void userFileConfig_1() throws Exception {
		String json = convertJsonToString(getUserDocConfigRequest(PARTNER));
		String uri = URI + "/configuration";

		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}

	@Test
	@Order(2)
	void getUserFileConfig() throws Exception {

		String uri = URI + "/configuration";
		MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>(2);
		multiValueMap.add(fieldName, FileNameConfigEnum.FIELD.toString());

		@SuppressWarnings("unchecked")
		CommonResponse<List<UserDocConfigResponse>> response = getBaseResponseForGET(uri, multiValueMap);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, response.getStatus());
	}

	@Test
	void userFileConfigInvalidData() throws Exception {
		
		String json = convertJsonToString(getUserDocConfigRequestInvalidData(CLIENT));
		String uri = URI + "/configuration";

		@SuppressWarnings("unchecked")
		CommonResponse baseresponse = getBaseResponseForPOST(uri, json);
		Assert.assertEquals(1, baseresponse.getErrors().size());
	}

//	@Test
//	void userFileConfigInvalidData_2() throws Exception {
//		String json = convertJsonToString(getUserDocConfigRequestInvalidData_2(CLIENT));
//		String uri = URI + "/configuration";
//
//		@SuppressWarnings("unchecked")
//		CommonResponse baseresponse = getBaseResponseForPOST(uri, json);
//		Assert.assertEquals(1, baseresponse.getErrors().size());
//	}

	@Test
	void getUserFileConfigForInvalidOrgType() throws Exception {

		String uri = URI + "/configuration";
		MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>(2);
		multiValueMap.add(fieldName, FileNameConfigEnum.FIELD.toString());

		@SuppressWarnings("unchecked")
		CommonResponse<List<UserDocConfigResponse>> errorMessage = getBaseResponseForGET(uri, multiValueMap);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, errorMessage.getStatus());
	}

	@Test
	void getFileNamesConfigForClient() throws Exception {

		MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>(2);
		multiValueMap.add(fieldName, FileNameConfigEnum.FIELD.toString());
		multiValueMap.add(ORG_TYPE, CLIENT);

		@SuppressWarnings("unchecked")
		CommonResponse<DefaultDocMgrConfigResponse> errorMessage = getBaseResponseForGET(URI, multiValueMap);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, errorMessage.getStatus());
	}

	private List<UserDocConfigRequest> getUserDocConfigRequest(String orgType) {

		List<UserDocConfigRequest> userDocConfigRequests = new ArrayList<>();
		userDocConfigRequests.add(getUserDocConfigRequest("field1", "CAN", orgType));
		userDocConfigRequests.add(getUserDocConfigRequest("field2", "OAN", orgType));
		return userDocConfigRequests;
	}

	private List<UserDocConfigRequest> getUserDocConfigRequestInvalidData(String orgType) {

		List<UserDocConfigRequest> userDocConfigRequests = new ArrayList<>();
		userDocConfigRequests.add(getUserDocConfigRequest("Test", "CAN", orgType));
		return userDocConfigRequests;
	}

	private List<UserDocConfigRequest> getUserDocConfigRequestInvalidData_2(String orgType) {

		List<UserDocConfigRequest> userDocConfigRequests = new ArrayList<>();
		userDocConfigRequests.add(getUserDocConfigRequest("field7", "DN", orgType));
		return userDocConfigRequests;
	}
}
