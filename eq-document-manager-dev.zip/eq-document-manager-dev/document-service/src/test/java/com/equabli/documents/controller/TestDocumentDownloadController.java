package com.equabli.documents.controller;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.MockReset;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.entity.Document;
import com.equabli.common.entity.DownloadHistory;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.repository.DownloadHistoryRepository;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.DownloadHistoryResponse;
import com.equabli.common.response.PageRequestData;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.utils.Util;
import com.equabli.documents.TestAppConfig;
import com.equabli.documents.request.DownloadDocumentRequest;
import com.equabli.documents.searchparams.DownloadHistorySearchParam;

@TestInstance(Lifecycle.PER_CLASS)
class TestDocumentDownloadController extends TestAppConfig {

	public static final String URI = "http://localhost:8081/user/document/download";
	private static final String DOWNLOAD_AT = "downloadAt";

	@MockBean
	DownloadHistoryRepository downloadHistoryRepository;
	
	@MockBean
	DocumentRepository documentRepository;
	
	@MockBean(reset = MockReset.BEFORE) 
	FetchTokenData fetchTokenData;

	@BeforeEach
	public void setTokenData() {
		Mockito.when(fetchTokenData.getTokenData()).thenReturn(getTokenData());
	}
	
	@Test
	void getDocumentDownload() throws Exception {

		String uri = URI;
		String json = convertJsonToString(getDownloadDocRequest(true));

		when(documentRepository.findById(1L)).thenReturn(Optional.of(new Document()));
		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}

	@Test
	void getDocumentDownload_1() throws Exception {

		String uri = URI;
		String json = convertJsonToString(getDownloadDocRequest(false));

		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}
	
	@Test
	void getDocumentDownload_2() throws Exception {

		String uri = URI;
		String json = convertJsonToString(getInvalidDownloadDocRequest(true));

		@SuppressWarnings("unchecked")
		CommonResponse<String> baseresponse = getBaseResponseForPOST(uri, json);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
	}

	@Test
	void deleteDownloadHistory() throws Exception {
		String uri = URI + "/1";
		
		when(downloadHistoryRepository.findById(1L)).thenReturn(Optional.of(new DownloadHistory()));

		@SuppressWarnings("unchecked")
		CommonResponse<String> pagedResponse = getBaseResponseForPatch(uri);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}

	@Test
	void deleteDownloadHistory_1() throws Exception {
		String uri = URI + "/0";
		
		@SuppressWarnings("unchecked")
		CommonResponse<String> pagedResponse = getBaseResponseForPatch(uri);
		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, pagedResponse.getStatus());
	}

//	@Test
//	void getDocumentInvalidData() throws Exception {
//
//		String uri = URI;
//		MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>(1);
//		multiValueMap.add(DOCUMENT_ID, "0");
//
//		@SuppressWarnings("unchecked")
//		CommonResponse<String> baseresponse = getBaseResponseForPatch(uri, multiValueMap);
//		Assert.assertEquals(1, baseresponse.getErrors().size());
//		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, baseresponse.getStatus());
//	}
	
	@Test
	void getAllRequiredDocument() throws Exception {

		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, getDownloadDocument("").getStatus());
	}

	@Test
	void getAllRequiredDocument_1() throws Exception {

		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, getDownloadDocument("documentName").getStatus());
	}

	@Test
	void getAllRequiredDocument_2() throws Exception {

		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, getDownloadDocument("size").getStatus());
	}

	@Test
	void getAllRequiredDocument_3() throws Exception {

		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, getDownloadDocument("downloadDate").getStatus());
	}

	@Test
	void getAllRequiredDocument_4() throws Exception {

		Assert.assertEquals(CommonResponse.OperationStatus.SUCCESS, getDownloadDocument("status").getStatus());
	}

	private DownloadDocumentRequest getDownloadDocRequest(boolean stat) {
		List<Long> documentIdList = new ArrayList<>();
		if (stat) {
			documentIdList.add(1l);
			//documentIdList.add(2l);
		}
		DownloadDocumentRequest documentRequest = new DownloadDocumentRequest();
		documentRequest.setDocumentId(documentIdList);

		return documentRequest;
	}
	
	private DownloadDocumentRequest getInvalidDownloadDocRequest(boolean stat) {
		List<Long> documentIdList = new ArrayList<>();
		if (stat) {
			documentIdList.add(0l);
			//documentIdList.add(2l);
		}
		DownloadDocumentRequest documentRequest = new DownloadDocumentRequest();
		documentRequest.setDocumentId(documentIdList);

		return documentRequest;
	}
	
	private DownloadHistorySearchParam getDownloadSearchParam(String sortParam) {
		return DownloadHistorySearchParam.builder().sortParam(sortParam).build();
	}
	
	@SuppressWarnings("unchecked")
	private PagedResponse<DownloadHistoryResponse> getDownloadDocument(String sortParam) throws Exception {
		String uri = URI + "/all";
		
		DownloadHistorySearchParam  searchParam = getDownloadSearchParam(sortParam);
		
		String sortParams = searchParam == null || searchParam.getSortParam() == null ? DOWNLOAD_AT
				: searchParam.getSortParam();
		PageRequestData pageRequestData = searchParam != null
				? Util.getPageRequestData(searchParam.getPageSize(), searchParam.getPageNumber(),
						searchParam.getSortOrder(), sortParam)
				: Util.getPageRequestData(null, null, null, DOWNLOAD_AT);

		Sort sort = Util.getSortingOrder(pageRequestData.getSortOrder(), getDownloadSortParam(sortParams));
		Pageable pageable = PageRequest.of(pageRequestData.getPageNumber(), pageRequestData.getPageSize(), sort);

		Page<DownloadHistory> pagedTasks = new PageImpl<>(Arrays.asList(getDownloadHistory(), getDownloadHistory()));
		when(downloadHistoryRepository.findByUserIdAndIsDeleteFalse(getTokenData().getPrincipleId(), pageable))
				.thenReturn(pagedTasks);
		
		String json = convertJsonToString(getDownloadSearchParam(sortParam));

		return getPagedResponseForPOST(uri,json);
	}
	
	private DownloadHistory getDownloadHistory() {
		DownloadHistory download = new DownloadHistory();
		download.saveDocumentDownloadHistory(download, new Document(), getTokenData());
		return download;
	}
	
	private String getDownloadSortParam(String sortParams) {
        String sortParamsVal = null;
        switch (sortParams) {
        case "documentName" -> sortParamsVal = "document.receiveFileName";
        case "size" -> sortParamsVal = "docSize";
        case "downloadDate" -> sortParamsVal = DOWNLOAD_AT;
        case "status" -> sortParamsVal = "downloadStatus";
        default -> sortParamsVal = DOWNLOAD_AT;
        }
        return sortParamsVal;
    }
}
