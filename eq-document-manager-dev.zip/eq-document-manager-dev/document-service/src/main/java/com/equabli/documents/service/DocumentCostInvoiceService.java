package com.equabli.documents.service;

import java.io.ByteArrayInputStream;

import com.equabli.common.response.CommonResponse;
import com.equabli.documents.response.DocumentCostInvoiceResponse;

public interface DocumentCostInvoiceService {

	CommonResponse<DocumentCostInvoiceResponse> getDocumentCostInvoiceDetails(String tenure);

	ByteArrayInputStream downloadDocumentCostInvoice(String tenure);

}
