package com.equabli.documents.response;

import com.equabli.common.entity.Lookup;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(description = "Fetch all subscription")
public class SubscriptionResponse {

	@Schema(description = "Subscription code", example = "BT")
	String subscriptionCode;
	
	@Schema(description = "subscription value", example = "15 GB")
	String subscriptionValue;
	
	@Schema(description = "subscription description", example = "Basic Tier")
	String description;

	public SubscriptionResponse(Lookup lookup) {
		this.subscriptionCode = lookup.getKeycode();
		this.subscriptionValue = lookup.getKeyvalue();
		this.description = lookup.getDescription();
	}
}
