package com.equabli.documents.searchparams;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Search Parameter for Document Coverage")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentCoverageSearchParam {

	@Schema(description = "Duration of data", example = "month")
	private String duration;
	
	@Schema(description = "Short Code of product", example = "CC")
	private String product;
	
	@Schema(description = "Client Account number", example = "123456")
	private String portfolio;
	
	@Schema(description = "User Id", example = "21")
	private Long userId;
}
