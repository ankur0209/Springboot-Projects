package com.equabli.documents.searchparams;

import javax.validation.constraints.NotBlank;

import com.equabli.common.response.PageRequestData;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Search for Account having a not specific document")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountNOTDocumentSearchParam extends PageRequestData {

	@NotBlank(message = "Document Type Code is required")
	private String docTypeCode;
	
	private String tenure;
	private String portfolio;
	private String productCode;
	private Long userId;
	
}
