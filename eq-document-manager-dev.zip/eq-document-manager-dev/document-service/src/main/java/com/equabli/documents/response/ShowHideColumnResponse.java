package com.equabli.documents.response;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(description = "Fetch all table and columns")
@Builder
public class ShowHideColumnResponse {
	
	String tableName;
	List<String> columnNames;
}
