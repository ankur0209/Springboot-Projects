package com.equabli.documents.searchparams;

import java.time.LocalDate;

import com.equabli.common.constants.MessageConstants;
import com.equabli.common.response.PageRequestData;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Search Parameter for Sent Request Document")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SentRequestDocumentSearchParam extends PageRequestData {

	private String documentType;
	private String documentName;
	private String originalAccountNumber;
	private Long equabliAccountNumber;
	private String clientAccountNumber;
	private String textSearch;
	
	@Schema(description = "Request date from "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate requestedDateFrom;
	
	@Schema(description = "Request date to "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate requestedDateTo;
	
	@Schema(description = "Due date from "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate dueDateFrom;
	
	@Schema(description = "Due date to "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate dueDateTo;

	@Schema(description = "Fullfillment date from "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate fullfillmentDateFrom;

	@Schema(description = "Fullfillment date to "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate fullfillmentDateTo;
	
	@Schema(description = "Name of user")
	private String requestedFrom;
	
	@Schema(description = "Status of Document ", example = "Open")
	private String requestStatus;
}
