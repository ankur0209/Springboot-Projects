package com.equabli.documents.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocMgrConfigValResponse {

	@Schema(description = "Short code of document manager config value", example = "CAN")
	private String shortCode;
	
	private String description;
	
	@Schema(description = "Values of field", example = "Client Account Number")
	private String fieldValue;
	
}
