package com.equabli.documents.service.impl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.Lookup;
import com.equabli.common.entity.Usage;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.repository.LookupRepository;
import com.equabli.common.repository.UsageRepository;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.documents.response.SubscriptionResponse;
import com.equabli.documents.service.SubscriptionService;

@Service
public class SubscriptionServiceImpl implements SubscriptionService {

	@Autowired
	FetchTokenData fetchTokenData;

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	LookupRepository lookupRepository;

	@Autowired
	UsageRepository usageRepository;

	@Override
	public CommonResponse<List<SubscriptionResponse>> getAllSubscription() {

		List<SubscriptionResponse> lookupResponse = getLookupByLookupGroupKeyValue(
				MessageConstants.Subscription.SUBSCRIPTION_TYPE);
		return CommonResponse.success(messageSupplier.get(MessageConstants.Subscription.SUBSCRIPTION_FETCH_SUCCESS),
				lookupResponse);
	}

	@Override
	public CommonResponse<SubscriptionResponse> getSubscription() {

		TokenData tokenData = fetchTokenData.getTokenData();
		Usage usage = getUsage(tokenData);
		SubscriptionResponse lookupResponse = new SubscriptionResponse(getLookup(usage.getLookupUid()));

		return CommonResponse.success(messageSupplier.get(MessageConstants.Subscription.SUBSCRIPTION_FETCH_SUCCESS),
				lookupResponse);
	}

	@Override
	public CommonResponse<String> saveSubscription(String subscriptionCode) {

		TokenData tokenData = fetchTokenData.getTokenData();

		Lookup lookup = getLookupBySubscriptionCode(subscriptionCode);
		Usage usage = usageRepository.findByOrgCode(tokenData.getUserOrgCode()).orElse(new Usage());
		usage.saveUsage(usage, lookup.getUid(), tokenData);
		usageRepository.save(usage);

		return CommonResponse.success(messageSupplier.get(MessageConstants.Subscription.SUBSCRIPTION_UPDATE_SUCCESS,
				tokenData.getFirstName()));
	}

	@Override
	public Usage getUsage(TokenData tokenData) {

		Usage usage = usageRepository.findByOrgCode(tokenData.getUserOrgCode()).orElse(new Usage());
		if (usage.getLookupUid() == null) {
			usage.saveUsage(usage,
					getLookupBySubscriptionCode(MessageConstants.Subscription.SUBSCRIPTION_KEY_CODE).getUid(),
					tokenData);
			usage = usageRepository.save(usage);
		}

		return usage;
	}

	@Override
	public List<SubscriptionResponse> getLookupByLookupGroupKeyValue(String keyvalue) {
		return lookupRepository.findByLookupGroup_keyvalue(keyvalue).stream().map(SubscriptionResponse::new).toList();
	}

	@Override
	public Lookup getLookupBySubscriptionCode(String subscriptionCode) {
		return lookupRepository
				.findByLookupGroup_keyvalueAndKeycode(MessageConstants.Subscription.SUBSCRIPTION_TYPE, subscriptionCode)
				.orElseThrow(() -> new InvalidArgumentException(
						messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, subscriptionCode)));
	}

	@Override
	public Lookup getLookup(UUID lookupUid) {
		return lookupRepository.findByUid(lookupUid).orElseThrow(
				() -> new InvalidArgumentException(messageSupplier.get(MessageConstants.NOT_VALID_ID, lookupUid)));
	}
}
