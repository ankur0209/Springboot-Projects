package com.equabli.documents.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.configs.AWSOperations;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.DocType;
import com.equabli.common.entity.QDocument;
import com.equabli.common.entity.RequireDoc;
import com.equabli.common.entity.Usage;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.queryhelpers.LikeHelper;
import com.equabli.common.repository.DocTypeRepository;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.repository.RequireDocRepository;
import com.equabli.common.repository.ShareByRepository;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PageRequestData;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.response.RequireDocResponse;
import com.equabli.common.response.ShareByWithResponse;
import com.equabli.common.utils.DateUtils;
import com.equabli.common.utils.DurationDateUtils;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.documents.constants.ColumnConstants;
import com.equabli.documents.constants.DocumentMessageConstants;
import com.equabli.documents.response.AccountDocumentResponse;
import com.equabli.documents.response.DocumentCoverageResponse;
import com.equabli.documents.response.UsageResponse;
import com.equabli.documents.searchparams.AccountDocumentSearchParam;
import com.equabli.documents.searchparams.AccountNOTDocumentSearchParam;
import com.equabli.documents.searchparams.DocumentCoverageSearchParam;
import com.equabli.documents.service.DocumentSummaryService;
import com.equabli.documents.service.ShowHideColumnService;
import com.equabli.documents.service.SubscriptionService;
import com.querydsl.core.BooleanBuilder;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DocumentSummaryServiceImpl implements DocumentSummaryService {

	private static final QDocument qDocument = QDocument.document;

	@Autowired
	FetchTokenData fetchTokenData;

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	DocumentRepository documentRepository;

	@Autowired
	RequireDocRepository requireDocRepository;

	@Autowired
	private ShowHideColumnService showHideColumnService;

	@Autowired
	private DocTypeRepository docTypeRepository;

	@Autowired
	private ShareByRepository shareByRepository;

	@Autowired
	private SubscriptionService subscriptionService;
	
	@Autowired(required = false)
	AWSOperations awsOperations;
	
	@Value("${awsS3.bucket.name}")
	private String awsBucketName;
	
	@Override
	public CommonResponse<List<DocumentCoverageResponse>> getDocumentCoverage(
			DocumentCoverageSearchParam documentCoverageSearchParam) {

		TokenData tokenData = fetchTokenData.getTokenData();
		List<DocumentCoverageResponse> docCoverageResponses = new ArrayList<>();

		if (documentCoverageSearchParam == null)
			documentCoverageSearchParam = new DocumentCoverageSearchParam();

		DurationDateUtils duration = new DurationDateUtils(documentCoverageSearchParam.getDuration(),
				LocalDateTime.now());

		List<String> docTypeCodes = requireDocRepository.findByOrgCodeAndAndIsDeleteFalse(tokenData.getUserOrgCode())
				.stream().map(RequireDoc::getDocTypeCode).distinct().toList();
		log.info("docTypeCodes {}", docTypeCodes);

		Map<String, DocType> documentType = docTypeRepository.findByShortCodeIn(docTypeCodes).stream()
				.collect(Collectors.toMap(DocType::getShortCode, docType -> docType));

		for (String docTypeCode : docTypeCodes) {
			DocumentCoverageResponse documentCoverageResponse = new DocumentCoverageResponse();

			List<RequireDoc> requireDocs = requireDocRepository.findByOrgCodeAndDocTypeCodeAndIsDeleteFalse(
					tokenData.getUserOrgCode(), docTypeCode, documentCoverageSearchParam.getProduct());
			List<String> requireProductCodes = requireDocs.stream().map(RequireDoc::getProductCode).distinct().toList();

			log.info("requireProductCodes {}", requireProductCodes);
			
			int comletedDocumentSummary = documentRepository
					.getCompletedDocumentSummary(tokenData.getUserOrgCode(), requireProductCodes, docTypeCode,
							duration.getFirstDay(), duration.getLastDay(), documentCoverageSearchParam.getUserId(),
							documentCoverageSearchParam.getPortfolio(), documentCoverageSearchParam.getProduct())
					.size();

			int totalDocumentSummary = documentRepository
					.getTotalDocumentSummary(tokenData.getUserOrgCode(), documentCoverageSearchParam.getProduct(),
							duration.getFirstDay(), duration.getLastDay(), documentCoverageSearchParam.getUserId(),
							documentCoverageSearchParam.getPortfolio(), requireProductCodes)
					.size();

			log.info("DocCode ->{}, comletedDocumentSummary->{}, totalDocumentSummary -> {}", docTypeCode,
					comletedDocumentSummary, totalDocumentSummary);

			documentCoverageResponse.setValues(comletedDocumentSummary,
					(totalDocumentSummary - comletedDocumentSummary), totalDocumentSummary);
			documentCoverageResponse.setDocTypeCode(docTypeCode);
			documentCoverageResponse.setDocumentType(documentType.get(docTypeCode).getName());
			docCoverageResponses.add(documentCoverageResponse);

		}

		return CommonResponse.success(
				messageSupplier.get(DocumentMessageConstants.Summary.COVERAGE_SUMMARY_FETCH_SUCCESS),
				docCoverageResponses);
	}

	@Override
	public CommonResponse<List<String>> getClientAccountNumber() {
		TokenData tokenData = fetchTokenData.getTokenData();
		List<String> clientAccountNumber = documentRepository.getClientAccountNumber(tokenData.getPrincipleId());
		return CommonResponse.success(
				messageSupplier.get(DocumentMessageConstants.Summary.CLIENT_ACCOUNT_FETCH_SUCCESS),
				clientAccountNumber);
	}

	@Override
	public PagedResponse<AccountDocumentResponse> getAccountListForSpecificDocument(
			@NonNull AccountDocumentSearchParam documentsSearchParam) {

		TokenData tokenData = fetchTokenData.getTokenData();

		getDocType(documentsSearchParam.getDocTypeCode());
		DurationDateUtils tenture = new DurationDateUtils(documentsSearchParam.getTenure(), LocalDateTime.now());

		List<String> accounts = getAccountNumberForSpecificDocument(documentsSearchParam.getDocTypeCode(), tokenData,
				documentsSearchParam, tenture);

		log.info("DocTypeCode -> {}, tenture startDate->{} endDate ->{}, Account Have Document ->{}",
				documentsSearchParam.getDocTypeCode(), tenture.getFirstDay(), tenture.getLastDay(), accounts);
		documentsSearchParam.setAccounts(accounts.isEmpty() ? null : accounts);
		
		
		List<Long> documentIds =  documentRepository.getDocumentids(tokenData.getUserOrgCode(), documentsSearchParam.getDocTypeCode(),
				documentsSearchParam.getTextSearch(), tenture.getFirstDay(), tenture.getLastDay(),
				documentsSearchParam.getUserId(), documentsSearchParam.getClientAccountNumber(),
				documentsSearchParam.getProductCode(), documentsSearchParam.getAccounts());
		log.info("Fetch document Ids {}", documentIds);

		PageRequestData pageRequestData = Util.getPageRequestData(documentsSearchParam.getPageSize(),
				documentsSearchParam.getPageNumber(), documentsSearchParam.getSortOrder(),
				documentsSearchParam.getSortParam() != null ? documentsSearchParam.getSortParam()
						: ColumnConstants.COLUMN_UPDATED_AT);

		Sort sort = Util.getSortingOrder(pageRequestData.getSortOrder(),
				getAccountSortParam(pageRequestData.getSortParam()));
		Pageable pageable = PageRequest.of(pageRequestData.getPageNumber(), pageRequestData.getPageSize(), sort);
		Page<AccountDocumentResponse> documents = null;
		if (StringUtils.hasText(documentsSearchParam.getTextSearch())) {
			documents = documentRepository
					.getDocumentList(tokenData.getUserOrgCode(), documentsSearchParam.getDocTypeCode(),
							documentsSearchParam.getTextSearch(), tenture.getFirstDay(), tenture.getLastDay(),
							documentsSearchParam.getUserId(), documentsSearchParam.getClientAccountNumber(),
							documentsSearchParam.getProductCode(), documentsSearchParam.getAccounts(), documentIds, pageable)
					.map(AccountDocumentResponse::new);
		} else {
			documents = documentRepository
					.findAll(getPredicateForDocuments(documentsSearchParam, tokenData, tenture, documentIds), pageable)
					.map(AccountDocumentResponse::new);
		}

		documents.forEach(document -> document.setSharedBy(getShareByDetail(document.getId())));

		if (ColumnConstants.COLUMN_SHARED_BY.equals(documentsSearchParam.getSortParam())) {
			documents = sortDocumentList(documents, pageable, documentsSearchParam.getSortOrder());
		}

		List<String> columns = showHideColumnService.getColumns(ColumnConstants.TABLE_ACCOUNTS, tokenData);

		return documents.isEmpty() ? PagedResponse.empty()
				: PagedResponse.of(documents.getContent(), columns, documents.getNumber(), documents.getSize(),
						(int) documents.getTotalElements(), documents.getTotalPages());
	}

	/**
	 * Fetch the those client account number that have specific document
	 * 
	 * @param docTypeCode
	 * @param tokenData
	 * @param documentsSearchParam
	 * @param tenture
	 * @return
	 */
	private List<String> getAccountNumberForSpecificDocument(String docTypeCode, TokenData tokenData,
			AccountDocumentSearchParam documentsSearchParam, DurationDateUtils tenture) {

		List<String> requireDocs = requireDocRepository
				.getByOrgTypeCodeAndDocTypeCodeAndIsDeleteFalse(tokenData.getUserOrgCode(), docTypeCode,
						documentsSearchParam.getProductCode())
				.stream().map(RequireDocResponse::getProductCode).toList();
		log.info("requireDocs {}", requireDocs);
		
		if(requireDocs.isEmpty())
			return Collections.emptyList();

		List<String> accounts = documentRepository
				.getCompletedDocumentSummary(tokenData.getUserOrgCode(), requireDocs, docTypeCode,
						tenture.getFirstDay(), tenture.getLastDay(), documentsSearchParam.getUserId(),
						documentsSearchParam.getPortfolio(), documentsSearchParam.getProductCode());

		log.info("Document Has Accounts {}", accounts);
		return accounts;
	}

	private BooleanBuilder getPredicateForDocuments(@NonNull AccountDocumentSearchParam documentsSearchParam,
			TokenData tokenData, DurationDateUtils tenture, List<Long> documentIds) {
		BooleanBuilder booleanBuilder = new BooleanBuilder();
		booleanBuilder.and(qDocument.orgCode.eq(tokenData.getUserOrgCode()));
		booleanBuilder.and(qDocument.isDelete.isFalse());
		booleanBuilder.and(qDocument.isOthers.isFalse());
		booleanBuilder.and(qDocument.docTypeCode.eq(documentsSearchParam.getDocTypeCode()));
		booleanBuilder.and(qDocument.updatedAt.goe(tenture.getFirstDay()));
		booleanBuilder.and(qDocument.updatedAt.loe(tenture.getLastDay()));

		if (!documentIds.isEmpty())
			booleanBuilder.and(qDocument.id.in(documentIds));
		
		if (documentsSearchParam.getAccounts() != null)
			booleanBuilder.and(qDocument.clientAccountNo.in(documentsSearchParam.getAccounts()));

		if (StringUtils.hasText(documentsSearchParam.getPortfolio()))
			booleanBuilder.and(qDocument.clientAccountNo.eq(documentsSearchParam.getPortfolio()));

		if (StringUtils.hasText(documentsSearchParam.getProductCode()))
			booleanBuilder.and(qDocument.productCode.eq(documentsSearchParam.getProductCode()));

		if (documentsSearchParam.getUserId() != null)
			booleanBuilder.and(qDocument.userId.eq(documentsSearchParam.getUserId()));

		if (StringUtils.hasText(documentsSearchParam.getDocumentName()))
			booleanBuilder.and(qDocument.generatedFileName
					.likeIgnoreCase(LikeHelper.anyPosition(documentsSearchParam.getDocumentName())));

		if (StringUtils.hasText(documentsSearchParam.getClientAccountNumber()))
			booleanBuilder.and(qDocument.clientAccountNo.eq(documentsSearchParam.getClientAccountNumber()));

		if (documentsSearchParam.getEquabliAccountNumber() != null)
			booleanBuilder.and(qDocument.equabliAccountNo.eq(documentsSearchParam.getEquabliAccountNumber()));

		if (StringUtils.hasText(documentsSearchParam.getOriginalAccountNumber()))
			booleanBuilder.and(qDocument.originalAccountNo.eq(documentsSearchParam.getOriginalAccountNumber()));

		if (documentsSearchParam.getGenerationDateFrom() != null
				&& documentsSearchParam.getGenerationDateTo() != null) {
			booleanBuilder.and(qDocument.documentGenerationDate
					.goe(DateUtils.atStartOfDay(documentsSearchParam.getGenerationDateFrom())));
			booleanBuilder.and(qDocument.documentGenerationDate
					.loe(DateUtils.atEndOfDay(documentsSearchParam.getGenerationDateTo())));
		}

		if (documentsSearchParam.getUploadDateFrom() != null && documentsSearchParam.getUploadDateTo() != null) {
			booleanBuilder
					.and(qDocument.createdAt.goe(DateUtils.atStartOfDay(documentsSearchParam.getUploadDateFrom())));
			booleanBuilder.and(qDocument.createdAt.loe(DateUtils.atEndOfDay(documentsSearchParam.getUploadDateTo())));
		}

		return booleanBuilder;
	}

	public String getAccountSortParam(String sortParams) {
		String sortParamsVal = null;
		switch (sortParams) {
		case ColumnConstants.COLUMN_DOCUMENT_NAME -> sortParamsVal = "generatedFileName";
		case ColumnConstants.COLUMN_ORIGINAL_ACCOUNT_NUMBER -> sortParamsVal = "originalAccountNo";
		case ColumnConstants.COLUMN_EQUABLI_ACCOUNT_NUMBER -> sortParamsVal = "eqaubliAccountNo";
		case ColumnConstants.COLUMN_CLIENT_ACCOUNT_NUMBER -> sortParamsVal = "clientAccountNo";
		case ColumnConstants.COLUMN_GENERATED_DATE -> sortParamsVal = "documentGenerationDate";
		case ColumnConstants.COLUMN_UPLOAD_DATE -> sortParamsVal = ColumnConstants.COLUMN_UPDATED_AT;
		case ColumnConstants.COLUMN_FILE_SIZE -> sortParamsVal = "fileSize";
		default -> sortParamsVal = ColumnConstants.COLUMN_UPDATED_AT;
		}
		return sortParamsVal;
	}

	private DocType getDocType(String docTypeCode) {
		return docTypeRepository.findByShortCode(docTypeCode).orElseThrow(() -> new InvalidArgumentException(
				messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, " " + docTypeCode)));
	}

	@Override
	public PagedResponse<String> getAccountListForNotSpecificDocument(
			AccountNOTDocumentSearchParam accountNOTDocumentSearchParam) {

		TokenData tokenData = fetchTokenData.getTokenData();
		getDocType(accountNOTDocumentSearchParam.getDocTypeCode());

		List<String> accounts = getAllAccountNumberForSpecificDocument(accountNOTDocumentSearchParam.getDocTypeCode(),
				tokenData, accountNOTDocumentSearchParam);

		log.info("DocTypeCode ->{}, All Accounts ->{}", accountNOTDocumentSearchParam.getDocTypeCode(),
				accounts);

		DurationDateUtils tenture = new DurationDateUtils(accountNOTDocumentSearchParam.getTenure(),
				LocalDateTime.now());
		AccountDocumentSearchParam accountDocumentSearchParam = AccountDocumentSearchParam.builder()
				.productCode(accountNOTDocumentSearchParam.getProductCode())
				.userId(accountNOTDocumentSearchParam.getUserId())
				.portfolio(accountNOTDocumentSearchParam.getPortfolio()).build();
		List<String> accountsHasDocument = getAccountNumberForSpecificDocument(
				accountNOTDocumentSearchParam.getDocTypeCode(), tokenData, accountDocumentSearchParam, tenture);

		List<String> finalAccountList = new ArrayList<>();
		finalAccountList.addAll(accounts);
		finalAccountList.addAll(accountsHasDocument);
		finalAccountList.removeAll(accountsHasDocument);

		log.info("Accounts --> {} ", accountsHasDocument);
		log.info("finalAccountList --> {} ", finalAccountList);

		PageRequestData pageRequestData = Util.getPageRequestData(accountNOTDocumentSearchParam.getPageSize(),
				accountNOTDocumentSearchParam.getPageNumber());
		
		int skip = pageRequestData.getPageNumber() * pageRequestData.getPageSize();
		int totalElements = finalAccountList.size();

		if (ColumnConstants.COLUMN_CLIENT_ACCOUNT_NUMBER.equals(accountNOTDocumentSearchParam.getSortParam())
				&& "desc".equalsIgnoreCase(accountNOTDocumentSearchParam.getSortOrder()))
			finalAccountList = finalAccountList.stream().sorted(Comparator.comparing(String::toString).reversed())
					.skip(skip).limit(pageRequestData.getPageSize()).toList();
		else
			finalAccountList = finalAccountList.stream().sorted(Comparator.comparing(String::toString)).skip(skip)
					.limit(pageRequestData.getPageSize()).toList();
		
		List<String> columns = showHideColumnService.getColumns(ColumnConstants.TABLE_ACCOUNTS, tokenData);

		return finalAccountList.isEmpty() ? PagedResponse.empty()
				: PagedResponse.of(finalAccountList, columns, (skip + 1), pageRequestData.getPageSize(), totalElements);
	}

//	/**
//	 * Fetch the those client account number that have specific NOT document
//	 * 
//	 * @param docTypeCode
//	 * @param tokenData
//	 * @param documentsSearchParam
//	 * @param tenture
//	 * @return
//	 */
//	private List<DocumentSummaryResponse> getAccountNumberForSpecificNOTDocument(String docTypeCode,
//			TokenData tokenData, AccountNOTDocumentSearchParam accountNOTDocumentSearchParam) {
//
//		List<DocumentSummaryResponse> responseList = new ArrayList<>();
//		DurationDateUtils tenture = new DurationDateUtils(accountNOTDocumentSearchParam.getTenure(),
//				LocalDateTime.now());
//
//		List<RequireDocResponse> requireDocs = requireDocRepository.getByOrgTypeCodeAndDocTypeCodeAndIsDeleteFalse(
//				tokenData.getOrgType(), docTypeCode, accountNOTDocumentSearchParam.getProductCode());
//		for (RequireDocResponse requireDoc : requireDocs) {
//			List<DocumentSummaryResponse> documentSummaryResponses = documentRepository
//					.getInCompletedAccountDocumentSummary(tokenData.getOrgType(), requireDoc.getProductCode(),
//							docTypeCode, tenture.getFirstDay(), tenture.getLastDay(),
//							accountNOTDocumentSearchParam.getUserId(), accountNOTDocumentSearchParam.getPortfolio());
//			log.info("productCode -> {}, docTypeCode -> {}, tenture startDate-> {} endDate ->{}, Accounts NOT -> {} ",
//					requireDoc.getProductCode(), requireDoc.getDocTypeCode(), tenture.getFirstDay(),
//					tenture.getLastDay(),
//					documentSummaryResponses.stream().map(DocumentSummaryResponse::getClientAccountNumber).toList());
//			responseList.addAll(documentSummaryResponses);
//
//		}
//		return responseList;
//	}
	
	/**
	 * Fetch the all Account list
	 * 
	 * @param docTypeCode
	 * @param tokenData
	 * @param accountNOTDocumentSearchParam
	 * @return
	 */
	private List<String> getAllAccountNumberForSpecificDocument(String docTypeCode, TokenData tokenData,
			AccountNOTDocumentSearchParam accountNOTDocumentSearchParam) {

		DurationDateUtils tenture = new DurationDateUtils(accountNOTDocumentSearchParam.getTenure(),
				LocalDateTime.now());

		List<String> requireDocs = requireDocRepository
				.getByOrgTypeCodeAndDocTypeCodeAndIsDeleteFalse(tokenData.getUserOrgCode(), docTypeCode,
						accountNOTDocumentSearchParam.getProductCode())
				.stream().map(RequireDocResponse::getProductCode).toList();
		log.info("requireDocs {}", requireDocs);

		if (requireDocs.isEmpty())
			return Collections.emptyList();

		List<String> accounts = documentRepository.getTotalDocumentSummary(tokenData.getUserOrgCode(),
				accountNOTDocumentSearchParam.getProductCode(), tenture.getFirstDay(), tenture.getLastDay(),
				accountNOTDocumentSearchParam.getUserId(), accountNOTDocumentSearchParam.getPortfolio(), requireDocs);

		log.info("Document All Accounts {}", accounts);
		return accounts;

	}

	@Override
	public CommonResponse<UsageResponse> getUserUsage() {

		TokenData tokenData = fetchTokenData.getTokenData();
		Usage usage = subscriptionService.getUsage(tokenData);

		UsageResponse usageResponse = new UsageResponse(usage,
				subscriptionService.getLookup(usage.getLookupUid()).getKeyvalue());
		
		return CommonResponse.success(
				messageSupplier.get(DocumentMessageConstants.Summary.COVERAGE_USAGE_FETCH_SUCCESS), usageResponse);
	}

	private List<ShareByWithResponse> getShareByDetail(Long id) {
		List<ShareByWithResponse> shareByWithResponses = shareByRepository.findByDocumentIdAndIsUnsharedFalse(id)
				.stream().map(ShareByWithResponse::new).toList();
		shareByWithResponses.forEach(s -> s.setProfilePicture(getUserProfilePicturePreSignUrl(s.getUserId())));
		return shareByWithResponses;
	}

	private Page<AccountDocumentResponse> sortDocumentList(Page<AccountDocumentResponse> pages, Pageable pageable,
			String order) {
		List<AccountDocumentResponse> compareList = new ArrayList<>(pages.getContent());
		Comparator<AccountDocumentResponse> compare = (AccountDocumentResponse f1,
				AccountDocumentResponse f2) -> f1.getSharedBy().size() - f2.getSharedBy().size();

		if (ColumnConstants.ORDER_DESC.equalsIgnoreCase(order))
			Collections.sort(compareList, compare.reversed());
		else
			Collections.sort(compareList, compare);

		return new PageImpl<>(compareList, pageable, compareList.size());
	}
	
	private String getUserProfilePicturePreSignUrl(Long userId) {
		String profilePath = awsOperations.getUserProfilePictureKey(awsBucketName,
				Util.profilePicturePath(String.valueOf(userId)));
		log.info("userId ->{}, User Profile Picture Path ->{}", userId, profilePath);
		return profilePath != null
				? awsOperations.genaratePreSignUrl(awsBucketName, profilePath, Util.PROFILE_PRE_SIGN_URL_EXPIRE_TIME)
				: null;
	}
}
