package com.equabli.documents.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.DocMgrConfig;
import com.equabli.common.entity.DocMgrConfigVal;
import com.equabli.common.entity.UserDocConfig;
import com.equabli.common.enums.FileNameConfigEnum;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.repository.DocMgrConfigRepository;
import com.equabli.common.repository.DocMgrConfigValRepository;
import com.equabli.common.repository.UserDocConfigRepository;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.documents.constants.DocumentMessageConstants;
import com.equabli.documents.request.UserDocConfigRequest;
import com.equabli.documents.response.DefaultDocMgrConfigResponse;
import com.equabli.documents.response.DocMgrConfigResponse;
import com.equabli.documents.response.DocMgrConfigValResponse;
import com.equabli.documents.response.UserDocConfigResponse;
import com.equabli.documents.service.GlobalConfigService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GlobalConfigServiceImpl implements GlobalConfigService {

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	private DocMgrConfigRepository docMgrConfigRepository;

	@Autowired
	private DocMgrConfigValRepository docMgrConfigValRepository;

	@Autowired
	private UserDocConfigRepository userDocConfigRepository;

	@Autowired
	private FetchTokenData fetchTokenData;

	@Override
	@Transactional
	public CommonResponse<String> saveUserFileConfig(List<UserDocConfigRequest> userDocConfigRequests) {
		List<String> userDocConfigSaved = new ArrayList<>();

		TokenData tokenData = fetchTokenData.getTokenData();

		for (UserDocConfigRequest userDocConfigRequest : userDocConfigRequests) {

			DocMgrConfig docMgrConfig = getDocMgrConfig(userDocConfigRequest.getConfigShortCode(),
					tokenData.getOrgType());
			DocMgrConfigVal docMgrConfigVal = getDocMgrConfigVal(userDocConfigRequest.getConfigValShortCode(),
					docMgrConfig);

			UserDocConfig userDocConfig = userDocConfigRepository
					.findByOrgCodeAndDocMgrConfig(tokenData.getUserOrgCode(), docMgrConfig).orElse(new UserDocConfig());

			userDocConfig.saveUserDocConfig(userDocConfig, docMgrConfig, docMgrConfigVal, tokenData);
			userDocConfig = userDocConfigRepository.save(userDocConfig);
			userDocConfigSaved.add(userDocConfig.getDocMgrConfig().getShortCode());
		}

		List<String> fieldList = userDocConfigRequests.stream().filter(
				l -> StringUtils.startsWithIgnoreCase(l.getConfigShortCode(), FileNameConfigEnum.FIELD.getShortCode()))
				.map(UserDocConfigRequest::getConfigShortCode).toList();

		List<UserDocConfig> userDocConfig = userDocConfigRepository
				.findByOrgCodeAndDocMgrConfigSelectedCodeStartsWithAndDocMgrConfigSelectedCodeNotIn(
						tokenData.getUserOrgCode(), FileNameConfigEnum.FIELD.getShortCode(), fieldList);
		userDocConfig.forEach(ud -> ud.deleteUserDocConfig(ud, fetchTokenData.getTokenData()));

		userDocConfigRepository.saveAll(userDocConfig);

		return CommonResponse.success(messageSupplier.get(DocumentMessageConstants.GlobalConfigs.CREATE_SUCCESS,
				userDocConfigSaved.toString()), userDocConfigSaved.toString());
	}

	@Override
	public CommonResponse<List<UserDocConfigResponse>> getUserFileConfig(FileNameConfigEnum fileNameConfig) {
		log.info("We have fetched This Token Data " + fetchTokenData.getTokenData());

		TokenData tokenData = fetchTokenData.getTokenData();

		List<UserDocConfig> userDocConfigs = userDocConfigRepository
				.findByOrgCodeAndDocMgrConfig_ShortCodeStartsWithAndIsDeleteFalseOrderByDocMgrConfig_ShortCode(
						tokenData.getUserOrgCode(), fileNameConfig.getShortCode());

		List<UserDocConfigResponse> userDocConfigResponses = userDocConfigs.stream().map(UserDocConfigResponse::new)
				.toList();
		return CommonResponse.success(messageSupplier.get(DocumentMessageConstants.GlobalConfigs.FETCH_SUCCESS),
				userDocConfigResponses);
	}

	@Override
	public CommonResponse<DefaultDocMgrConfigResponse> getDefaultDocMgrConfiguration(
			FileNameConfigEnum fileNameConfig) {

		TokenData tokenData = fetchTokenData.getTokenData();

		DefaultDocMgrConfigResponse userDocConfigResponse = new DefaultDocMgrConfigResponse();
		userDocConfigResponse.setOrgTypeCode(tokenData.getOrgType());

		List<DocMgrConfig> docMgrConfigs = docMgrConfigRepository
				.findByOrgTypeCodeAndShortCodeStartsWithOrderByShortCode(tokenData.getOrgType(),
						fileNameConfig.getShortCode());

		List<DocMgrConfigResponse> docMgrConfigResponses = new ArrayList<>();
		for (DocMgrConfig docMgrConfig : docMgrConfigs) {

			DocMgrConfigResponse docMgrConfigResponse = new DocMgrConfigResponse();
			BeanUtils.copyProperties(docMgrConfig, docMgrConfigResponse);

			List<DocMgrConfigVal> docMgrConfigVals = docMgrConfigValRepository
					.findBydocMgrConfig_id(docMgrConfig.getId());

			List<DocMgrConfigValResponse> docMgrConfigValResponses = new ArrayList<>();
			for (DocMgrConfigVal docMgrConfigVal : docMgrConfigVals) {
				DocMgrConfigValResponse docMgrConfigValResponse = new DocMgrConfigValResponse();
				BeanUtils.copyProperties(docMgrConfigVal, docMgrConfigValResponse);
				docMgrConfigValResponses.add(docMgrConfigValResponse);
			}
			docMgrConfigResponse.setConfigVals(docMgrConfigValResponses);
			docMgrConfigResponses.add(docMgrConfigResponse);

		}

		userDocConfigResponse.setDocMgrConfigs(docMgrConfigResponses);
		return CommonResponse.success(messageSupplier.get(DocumentMessageConstants.GlobalConfigs.FETCH_SUCCESS),
				userDocConfigResponse);
	}

	private DocMgrConfig getDocMgrConfig(String docMgrConfigShortCode, String orgTypeCode) {
		return docMgrConfigRepository.findByShortCodeAndOrgTypeCode(docMgrConfigShortCode, orgTypeCode).orElseThrow(
				() -> new InvalidArgumentException(messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE,
						MessageConstants.DOC_MGR_CONFIG + " " + docMgrConfigShortCode, null)));
	}

	private DocMgrConfigVal getDocMgrConfigVal(String docMgrConfigValshortCode, DocMgrConfig docMgrConfig) {

		Optional<DocMgrConfigVal> docMgrConfigValOpt = docMgrConfigValRepository
				.findByShortCodeAndDocMgrConfig_Id(docMgrConfigValshortCode, docMgrConfig.getId());
		if (docMgrConfigValOpt.isPresent())
			return docMgrConfigValOpt.get();
		else {
			DocMgrConfigVal docMgrConfigVal = new DocMgrConfigVal();
			docMgrConfigVal.saveDocMgrConfigVal(docMgrConfigVal, docMgrConfig, docMgrConfigValshortCode,
					docMgrConfigValshortCode);
			return docMgrConfigValRepository.save(docMgrConfigVal);
		}
	}

}
