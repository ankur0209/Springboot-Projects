package com.equabli.documents.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.documents.request.DownloadDocumentRequest;
import com.equabli.documents.response.ReceiveDocumentResponse;
import com.equabli.documents.response.SentReceiveSummaryResponse;
import com.equabli.documents.searchparams.ReceiveRequestDocumentSearchParam;
import com.equabli.documents.service.ReceivedDocumentRequestService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user/document/receiveDocumentRequest")
@Tag(name = "Receive Document Request API", description = "Receive Document Request API for document manager")
@Slf4j
public class ReceivedDocumentRequestController {

	@Autowired
	private ReceivedDocumentRequestService documentRequestService;

	@Operation(summary = "Fetch list of requested document", description = "Fetch list of requested document for specific account nunmber")
	@PostMapping("/all")
	public PagedResponse<ReceiveDocumentResponse> getReceivedDocumentRequestList(
			@RequestBody(required = false) ReceiveRequestDocumentSearchParam receiveRequestDocumentSearchParam) {
		log.info("Fetching list of Requested document {} ", receiveRequestDocumentSearchParam);
		return documentRequestService.getReceivedDocumentRequestList(receiveRequestDocumentSearchParam);
	}

	@Operation(summary = "Delete requested document", description = "Delete requested document")
	@PatchMapping("/{id}")
	public CommonResponse<String> deleteDocumentsForProducts(@PathVariable(name = "id") Long documentRequestId) {
		log.info("delete requested document {} ", documentRequestId);
		return documentRequestService.deleteRequestedDocument(documentRequestId);
	}

	@Operation(summary = "Download list of receive document", description = "Download list of receive document")
	@PostMapping
	public CommonResponse<String> downloadReceiveDocumentHistory(
			@Valid @RequestBody DownloadDocumentRequest documentRequest) {
		log.info("Download list of receive document {}", documentRequest);
		return documentRequestService.saveDownloadReceiveDocumentHistory(documentRequest);
	}
	
	@Operation(summary = "Fetch Receive request summary ", description = "Fetch Receive request summary")
	@GetMapping("/summary")
	public CommonResponse<SentReceiveSummaryResponse> getSentRequestSummary() {
		log.info("Receive request document summary");
		return documentRequestService.getReceiveRequestSummary();
	}

}