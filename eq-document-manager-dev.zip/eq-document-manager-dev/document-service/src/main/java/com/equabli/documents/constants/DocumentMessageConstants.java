package com.equabli.documents.constants;

public final class DocumentMessageConstants {

	public static final String OTHER = "Other";
	public static final String EVICT_CACHE_CONST = "ProductResponse";

	private DocumentMessageConstants() {
	}

	public final class GlobalConfigs {

		private GlobalConfigs() {
		}

		public static final String CREATE_SUCCESS = "global.config.create.success";
		public static final String FETCH_SUCCESS = "global.config.fetch.success";
	}

	public final class DocumentConfig {
		private DocumentConfig() {
		}

		public static final String COST_CREATE_SUCCESS = "cost.config.create.success";
		public static final String COST_FETCH_SUCCESS = "cost.config.fetch.success";
		public static final String DOCUMENT_FETCH_SUCCESS = "document.fetch.success";
		public static final String COST_DELETE_SUCCESS = "cost.config.delete.success";
		public static final String DOCUMENT_DELETE_SUCCESS = "document.delete.success";
	}

	public final class RequireDocConfig {
		private RequireDocConfig() {
		}

		public static final String REQUIRED_DOC_CREATE_SUCCESS = "require.doc.config.create.success";
		public static final String REQUIRED_DOC_FETCH_SUCCESS = "require.doc.config.fetch.success";
		public static final String REQUIRED_DOC_DELETE_SUCCESS = "require.doc.config.delete.success";
		public static final String DOCUMENT_SENT_SUMMARY_FETCH_SUCCESS = "document.sent.summary.fetch.success";
		public static final String DOCUMENT_RECEIVE_SUMMARY_FETCH_SUCCESS = "document.receive.summary.fetch.success";
	}

	public final class DocumentDownloadConfig {
		private DocumentDownloadConfig() {
		}

		public static final String DOWNLOAD_CREATE_SUCCESS = "download.config.create.success";
		public static final String DOWNLOAD_FETCH_SUCCESS = "download.config.fetch.success";
		public static final String DOWNLOAD_DELETE_SUCCESS = "download.config.delete.success";
	}

	public final class SentDocumentConstants {
		private SentDocumentConstants() {
		}

		public static final String SENT_CREATE_SUCCESS = "sent.create.success";
		public static final String DOCUMENT_REQUEST_DELETE_SUCCESS = "document.request.delete.success";
	}

	public final class Summary {
		private Summary() {
		}
		public static final String COVERAGE_SUMMARY_FETCH_SUCCESS = "coverage.summary.fetch.success";
		public static final String CLIENT_ACCOUNT_FETCH_SUCCESS = "client.account.fetch.success";
		public static final String COVERAGE_USAGE_FETCH_SUCCESS = "usage.summary.fetch.success";
	}
	
	public final class ShareDocumentConstants {
		private ShareDocumentConstants() {
		}
		
		public static final String SHARE_DOCUMENT_CREATE_SUCCESS = "share.document.create.success";
		public static final String SHARE_DOCUMENT_FETCH_SUCCESS = "share.document.fetch.success";
	}
	
	public final class DocumentCostInvoiceConstants {
		private DocumentCostInvoiceConstants() {
		}
		
		public static final String DOCUMENT_COST_INVOICE_CREATE_SUCCESS = "document.cost.invoice.create.success";
		public static final String DOCUMENT_COST_INVOICE_FETCH_SUCCESS = "document.cost.invoice.fetch.success";
	}
	
	public final class DocumentTypeIdentification{
		private DocumentTypeIdentification() {
		}
		
		public static final String DOCUMENT_TYPE_IDENTIFICATION_SAVED_SUCCESS = "document.type.identification.saved.success";
		public static final String DOCUMENT_TYPE_IDENTIFICATION_DELETE_SUCCESS = "document.type.identification.delete.success";
		
	}
}
