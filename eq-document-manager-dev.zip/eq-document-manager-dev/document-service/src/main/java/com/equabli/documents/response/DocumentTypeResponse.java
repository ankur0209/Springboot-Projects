package com.equabli.documents.response;

import com.equabli.common.entity.DocType;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;

@Getter
public class DocumentTypeResponse {

	@Schema(description = "Type of document", example = "Application")
	private String documentType;

	@Schema(description = "Short code of document", example = "AP")
	private String shortCode;

	@Schema(description = "document description")
	private String description;

	public DocumentTypeResponse(DocType docType) {
		this.documentType = docType.getName();
		this.shortCode = docType.getShortCode();
		this.description = docType.getDescription();
	}
}
