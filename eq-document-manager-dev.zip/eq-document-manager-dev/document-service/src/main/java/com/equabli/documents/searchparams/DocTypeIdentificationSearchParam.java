package com.equabli.documents.searchparams;

import com.equabli.common.response.PageRequestData;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Search for Document Type Identification")
public class DocTypeIdentificationSearchParam extends PageRequestData {

	private String documentType;
}
