package com.equabli.documents.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.equabli.common.response.CommonResponse;
import com.equabli.documents.response.DocumentCostInvoiceResponse;
import com.equabli.documents.service.DocumentCostInvoiceService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user/document/cost/invoice")
@Tag(name = "Document Cost Invoice API", description = "Document Cost Invoice API for document manager")
@Slf4j
public class DocumentCostInvoiceController {

	@Autowired
	private DocumentCostInvoiceService documentCostInvoiceService;
	
	@Operation(summary = "Get Document cost Invoice details", description = "Get Document cost Invoice details")
	@GetMapping
	public CommonResponse<DocumentCostInvoiceResponse> getDocumentCostInvoiceDetails(
			@RequestParam("tenure") String tenure) {
		log.info("Get cost invoice for client and partner");
		return documentCostInvoiceService.getDocumentCostInvoiceDetails(tenure);
	}

	@Operation(summary = "Get Document cost Invoice details", description = "Get Document cost Invoice details")
	@GetMapping("/download")
	public ResponseEntity<Resource> downloadDocumentCostInvoice(@RequestParam("tenure") String tenure) {
		log.info("Download cost invoice for client, partner and Equabli");
		String fileName = "invoice_"+tenure+".pdf";
		InputStreamResource file = new InputStreamResource(
				documentCostInvoiceService.downloadDocumentCostInvoice(tenure));
		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename= " + fileName)
				.contentType(MediaType.parseMediaType("application/vnd.ms-pdf")).body(file);
	}

}
