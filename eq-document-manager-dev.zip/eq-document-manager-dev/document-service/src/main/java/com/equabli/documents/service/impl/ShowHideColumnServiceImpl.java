package com.equabli.documents.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.entity.ShowHideColumn;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.repository.ShowHideColumnRepository;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.documents.constants.ColumnConstants;
import com.equabli.documents.request.ShowHideColumnRequest;
import com.equabli.documents.response.ShowHideColumnResponse;
import com.equabli.documents.service.ShowHideColumnService;

@Service
public class ShowHideColumnServiceImpl implements ShowHideColumnService {

	@Autowired
	ShowHideColumnRepository showHideColumnRepository;

	@Autowired
	FetchTokenData fetchTokenData;

	@Autowired
	MessageSupplier messageSupplier;

	@Override
	public CommonResponse<String> saveColumnsRequest(ShowHideColumnRequest showHideColumnRequest) {
		TokenData tokenData = fetchTokenData.getTokenData();

		getColumns(showHideColumnRequest.getTableName());

		ShowHideColumn showHideColumn = showHideColumnRepository
				.findByUserIdAndTableName(tokenData.getPrincipleId(), showHideColumnRequest.getTableName())
				.orElse(new ShowHideColumn());

		showHideColumn.saveShowHideColumn(showHideColumn, showHideColumnRequest.getTableName(),
				StringUtils.join(showHideColumnRequest.getColumnNames(), ColumnConstants.COLUMNS_SEPERATORY),
				tokenData);
		showHideColumn = showHideColumnRepository.save(showHideColumn);

		return CommonResponse.success(
				messageSupplier.get(ColumnConstants.COLUMN_CREATE_SUCCESS, showHideColumn.getTableName()),
				showHideColumn.getTableName());
	}

	@Override
	public List<String> getColumns(String tableName, TokenData tokenData) {

		Optional<ShowHideColumn> showHideColumnOpt = showHideColumnRepository
				.findByUserIdAndTableName(tokenData.getPrincipleId(), tableName);
		if (showHideColumnOpt.isEmpty()) {

			ShowHideColumn showHideColumn = new ShowHideColumn();
			showHideColumn.saveShowHideColumn(showHideColumn, tableName,
					StringUtils.join(getColumns(tableName), ColumnConstants.COLUMNS_SEPERATORY), tokenData);
			showHideColumn = showHideColumnRepository.save(showHideColumn);

			return Stream.of(StringUtils.split(showHideColumn.getColumns(), ColumnConstants.COLUMNS_SEPERATORY))
					.toList();
		} else
			return Stream
					.of(StringUtils.split(showHideColumnOpt.get().getColumns(), ColumnConstants.COLUMNS_SEPERATORY))
					.toList();
	}

	@Override
	public CommonResponse<List<ShowHideColumnResponse>> getTableAllColumns() {

		List<ShowHideColumnResponse> tables = new ArrayList<>();
		for (String tableName : ColumnConstants.getTables())
			tables.add(ShowHideColumnResponse.builder().tableName(tableName).columnNames(getColumns(tableName)).build());
		
		return CommonResponse.success(messageSupplier.get(ColumnConstants.COLUMN_FETCH_SUCCESS), tables);
	}

	private List<String> getColumns(String tableName) {
		List<String> columns;

		switch (tableName) {
		case ColumnConstants.TABLE_SENT_REQUEST_DOCUMENT -> columns = getColumnsForSentDocumentRequest();
		case ColumnConstants.TABLE_RECEIVE_REQUEST_DOCUMENT -> columns = getColumnsForReceiveDocumentRequest();
		case ColumnConstants.TABLE_DOCUMENT -> columns = getColumnsForDocument();
		case ColumnConstants.TABLE_DOCUMENT_FOLDER -> columns = getColumnsForDocumentFolder();
		case ColumnConstants.TABLE_ACCOUNTS -> columns = getColumnsForAccount();
		default -> throw new InvalidArgumentException(
				messageSupplier.get(ColumnConstants.NOT_VALID_TABLE_NAME, tableName + " "));
		}

		return columns;
	}

	private static List<String> getColumnsForSentDocumentRequest() {
		return Arrays.asList(ColumnConstants.COLUMN_REQUESTED_DOCUMENT, ColumnConstants.COLUMN_ORIGINAL_ACCOUNT_NUMBER,
				ColumnConstants.COLUMN_EQUABLI_ACCOUNT_NUMBER, ColumnConstants.COLUMN_CLIENT_ACCOUNT_NUMBER,
				ColumnConstants.COLUMN_REQUESTED_DATE, ColumnConstants.COLUMN_DUE_DATE,
				ColumnConstants.COLUMN_FULFILLMENT_DATE, ColumnConstants.COLUMN_FILE_NAME,
				ColumnConstants.COLUMN_REQUESTED_FROM);
	}

	private static List<String> getColumnsForReceiveDocumentRequest() {
		return Arrays.asList(ColumnConstants.COLUMN_REQUESTED_DOCUMENT, ColumnConstants.COLUMN_ORIGINAL_ACCOUNT_NUMBER,
				ColumnConstants.COLUMN_EQUABLI_ACCOUNT_NUMBER, ColumnConstants.COLUMN_CLIENT_ACCOUNT_NUMBER,
				ColumnConstants.COLUMN_REQUESTED_DATE, ColumnConstants.COLUMN_DUE_DATE,
				ColumnConstants.COLUMN_FULFILLMENT_DATE, ColumnConstants.COLUMN_DOCUMENT_NAME,
				ColumnConstants.COLUMN_REQUESTED_BY);
	}

	private static List<String> getColumnsForDocument() {
		return Arrays.asList(ColumnConstants.COLUMN_NAME, ColumnConstants.COLUMN_DOCUMENT_TYPE,
				ColumnConstants.COLUMN_ORIGINAL_ACCOUNT_NUMBER, ColumnConstants.COLUMN_EQUABLI_ACCOUNT_NUMBER,
				ColumnConstants.COLUMN_CLIENT_ACCOUNT_NUMBER, ColumnConstants.COLUMN_GENERATED_DATE,
				ColumnConstants.COLUMN_UPLOAD_DATE, ColumnConstants.COLUMN_SHARE_DATE,
				ColumnConstants.COLUMN_RECEIVE_DATE, ColumnConstants.COLUMN_FILE_SIZE, ColumnConstants.COLUMN_SHARED_BY,
				ColumnConstants.COLUMN_SHARED_WITH);
	}

	private static List<String> getColumnsForDocumentFolder() {
		return Arrays.asList(ColumnConstants.COLUMN_NAME, ColumnConstants.COLUMN_FILE_SIZE,
				ColumnConstants.COLUMN_MODIFIED_DATE, ColumnConstants.COLUMN_SHARE_DATE,
				ColumnConstants.COLUMN_RECEIVED_DATE, ColumnConstants.COLUMN_SHARED_BY,
				ColumnConstants.COLUMN_SHARED_WITH);
	}
	
	private static List<String> getColumnsForAccount() {
		return Arrays.asList(ColumnConstants.COLUMN_ORIGINAL_ACCOUNT_NUMBER, ColumnConstants.COLUMN_EQUABLI_ACCOUNT_NUMBER,
				ColumnConstants.COLUMN_CLIENT_ACCOUNT_NUMBER, ColumnConstants.COLUMN_DOCUMENT_NAME,
				ColumnConstants.COLUMN_GENERATED_DATE, ColumnConstants.COLUMN_UPLOAD_DATE,
				ColumnConstants.COLUMN_FILE_SIZE, ColumnConstants.COLUMN_SHARED_BY);
	}

}
