package com.equabli.documents.response;

import java.time.LocalDateTime;

import com.equabli.common.entity.Document;
import com.equabli.common.entity.SendReceiveDocument;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;

@Getter
@Schema(description = "Page response for Sent Document request")
public class SentDocumentResponse {

	private Long id;

	@Schema(description = "Original Account number", example = "456789")
	private String originalAccountNumber;

	@Schema(description = "Client Account number", example = "123456")
	private String clientAccountNumber;

	@Schema(description = "Equabli Account number", example = "789123")
	private Long equabliAccountNumber;

	@Schema(description = "Request date in MM/dd/yyyy", example = "11/25/2023")
	@JsonFormat(pattern = "MM/dd/yyyy")
	private LocalDateTime requestDate;

	@Schema(description = "Due date in MM/dd/yyyy", example = "11/25/2023")
	@JsonFormat(pattern = "MM/dd/yyyy")
	private LocalDateTime dueDate;

	@Schema(description = "After uploaded document MM/dd/yyyy", example = "11/25/2023")
	@JsonFormat(pattern = "MM/dd/yyyy")
	private LocalDateTime fulfillmentDate;

	@Schema(description = "Name of Document", example = "TH-123232-234242.pdf")
	private String documentName;

	@Schema(description = "Name of request user", example = "Abc")
	private String requestedFrom;

	@Schema(description = "Request status", example = "Open")
	private String requestStatus;

	@Schema(description = "Type of document", example = "Transation History")
	private String documentType;

	@Schema(description = "For set document name based on file name configuration")
	@JsonIgnore
	private Document fullFilledDocument;

	private String filePath;
	private Long documentId;
	private Long fileSize;

	public SentDocumentResponse(SendReceiveDocument sendReceiveDocument) {
		this.id = sendReceiveDocument.getId();
		this.originalAccountNumber = sendReceiveDocument.getOriginalAccountNo();
		this.clientAccountNumber = sendReceiveDocument.getClientAccountNo();
		this.equabliAccountNumber = sendReceiveDocument.getEquabliAccNo();
		this.requestDate = sendReceiveDocument.getRequestedAt();
		this.requestedFrom = sendReceiveDocument.getRequestedTo();
		this.documentName = sendReceiveDocument.getFullfilledDocumentId() == null ? null
				: sendReceiveDocument.getFullfilledDocumentId().getGeneratedFileName();
		this.requestStatus = sendReceiveDocument.getRequestStatus();
		this.documentType = sendReceiveDocument.getDocumentType();
		this.fullFilledDocument = sendReceiveDocument.getFullfilledDocumentId();
		this.fulfillmentDate = sendReceiveDocument.getFullfilledOn();
		this.filePath = sendReceiveDocument.getFullfilledDocumentId() == null ? null
				: sendReceiveDocument.getFullfilledDocumentId().getGeneratedFilePath();
		this.dueDate = sendReceiveDocument.getDueOnAt();
		this.documentId = sendReceiveDocument.getFullfilledDocumentId() == null ? 0l
				: sendReceiveDocument.getFullfilledDocumentId().getId();
		this.fileSize = sendReceiveDocument.getFullfilledDocumentId() == null ? 0l
				: sendReceiveDocument.getFullfilledDocumentId().getFileSize();
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	
	public void setDueDate(LocalDateTime dueDate) {
		this.dueDate =dueDate;
	}
}