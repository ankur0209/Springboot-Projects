package com.equabli.documents.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RequireDocumentRequest {

	@Schema(description = "Short code of document", example = "AP")
	private String documentCode;
	
	@Schema(description = "Document Name", example = "Application")
	private String documentName;
	
}
