package com.equabli.documents.constants;

public class ColumnConstants {

	private ColumnConstants() {
	}

	public static final String NOT_VALID_TABLE_NAME = "not.valid.table.name";
	public static final char COLUMNS_SEPERATORY = ',';
	public static final String COLUMN_CREATE_SUCCESS = "column.create.success";
	public static final String COLUMN_FETCH_SUCCESS = "column.fetch.success";
	public static final String TABLE_SENT_REQUEST_DOCUMENT = "sentDocumentRequest";
	public static final String TABLE_RECEIVE_REQUEST_DOCUMENT = "receiveDocumentRequest";
	public static final String TABLE_DOCUMENT = "document";
	public static final String TABLE_DOCUMENT_FOLDER = "documentFolder";
	public static final String TABLE_ACCOUNTS = "accounts";
	
	private static final String[] TABLES_NAMES = { TABLE_DOCUMENT_FOLDER, TABLE_DOCUMENT,
			TABLE_SENT_REQUEST_DOCUMENT, TABLE_RECEIVE_REQUEST_DOCUMENT, TABLE_ACCOUNTS };

	public static String[] getTables() {
		return TABLES_NAMES.clone();
	}
	
	public static final String COLUMN_REQUESTED_DOCUMENT = "requestedDocument";
	public static final String COLUMN_ORIGINAL_ACCOUNT_NUMBER = "originalAccountNumber";
	public static final String COLUMN_EQUABLI_ACCOUNT_NUMBER = "equabliAccountNumber";
	public static final String COLUMN_CLIENT_ACCOUNT_NUMBER = "clientAccountNumber";
	public static final String COLUMN_REQUESTED_DATE = "requestedDate";
	public static final String COLUMN_DUE_DATE = "dueDate";
	public static final String COLUMN_FULFILLMENT_DATE = "fulfillmentDate";
	public static final String COLUMN_FILE_NAME = "fileName";
	public static final String COLUMN_REQUESTED_FROM = "requestedFrom";
	public static final String COLUMN_REQUESTED_BY = "requestedBy";
	public static final String COLUMN_DOCUMENT_NAME = "documentName";
	
	public static final String COLUMN_NAME = "name";
	public static final String COLUMN_SIZE = "size";
	public static final String COLUMN_MODIFIED_DATE = "modifiedDate";
	public static final String COLUMN_SHARED_DATE = "sharedDate";
	public static final String COLUMN_RECEIVED_DATE = "receivedDate";
	public static final String COLUMN_SHARED_BY = "sharedBy";
	public static final String COLUMN_SHARED_WITH = "sharedWith";	
	
	public static final String COLUMN_DOCUMENT_TYPE = "documentType";
	public static final String COLUMN_GENERATED_DATE = "generatedDate";
	public static final String COLUMN_UPLOAD_DATE = "uploadDate";
	public static final String COLUMN_SHARE_DATE = "shareDate";
	public static final String COLUMN_RECEIVE_DATE = "receiveDate";
	public static final String COLUMN_FILE_SIZE = "fileSize";

	public static final String COLUMN_UPDATED_AT = "updatedAt";
	public static final String COLUMN_CREATED_AT = "createdAt";
	public static final String ORDER_DESC = "desc";
	public static final String ORDER_ASC = "asc";
	
}
