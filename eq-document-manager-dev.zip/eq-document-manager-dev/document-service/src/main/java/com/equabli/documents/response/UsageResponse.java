package com.equabli.documents.response;

import java.text.CharacterIterator;
import java.text.DecimalFormat;
import java.text.StringCharacterIterator;

import com.equabli.common.entity.Usage;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UsageResponse {

	private static long kilo = 1024;
	private static final DecimalFormat df = new DecimalFormat("0.00");

	@Schema(description = "Used data ", example = "9")
	private String used;

	@Schema(description = "Percentage of used data", example = "60")
	private String percentage;

	@Schema(description = "Show Based on subscription plan ", example = "15")
	private String total;

	@Schema(description = "Total of uploaded document")
	private Long totalDocument;

	public UsageResponse(Usage usage, String subscriptionPlan) {
		this.used = usage.getUsed() == null ? "0 MB" : humanReadableByteCountSI(usage.getUsed());
		this.totalDocument = usage.getTotalDocument();
		this.total = subscriptionPlan;

		if (usage.getUsed() == null)
			this.percentage = "0";
		else
			this.percentage = df.format((getSize(usage.getUsed()) * 100) / Integer.parseInt(subscriptionPlan.split(" ")[0]));
	}

	public static double getSize(long size) {
		double kb = (double) size / kilo;
		double mb = kb / kilo;
		return mb / kilo;
	}

	public static String humanReadableByteCountSI(long bytes) {
		if (-1000 < bytes && bytes < 1000) {
			return bytes + " B";
		}
		CharacterIterator ci = new StringCharacterIterator("kMGTPE");
		while (bytes <= -999_950 || bytes >= 999_950) {
			bytes /= 1000;
			ci.next();
		}
		return String.format("%.1f %cB", bytes / 1000.0, ci.current());
	}
}
