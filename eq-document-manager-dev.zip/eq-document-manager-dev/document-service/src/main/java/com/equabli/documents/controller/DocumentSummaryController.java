package com.equabli.documents.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.documents.response.AccountDocumentResponse;
import com.equabli.documents.response.DocumentCoverageResponse;
import com.equabli.documents.response.UsageResponse;
import com.equabli.documents.searchparams.AccountDocumentSearchParam;
import com.equabli.documents.searchparams.AccountNOTDocumentSearchParam;
import com.equabli.documents.searchparams.DocumentCoverageSearchParam;
import com.equabli.documents.service.DocumentSummaryService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user/document/summary")
@Tag(name = "Document Summary API", description = "Document Summary API for document manager")
@Slf4j
public class DocumentSummaryController {

	@Autowired
	DocumentSummaryService documentSummaryService;

	@Operation(summary = "Fetch document coverage", description = "Fetch document coverage")
	@PostMapping("/coverage")
	public CommonResponse<List<DocumentCoverageResponse>> getDocumentCoverage(
			@RequestBody(required = false) DocumentCoverageSearchParam documentCoverageSearchParam) {
		log.info("Fetching document summary coverage  documentCoverageSearchParam {} ", documentCoverageSearchParam);
		return documentSummaryService.getDocumentCoverage(documentCoverageSearchParam);
	}

	@Operation(summary = "Fetch document client number", description = "Fetch document client number")
	@GetMapping("/clientAccount")
	public CommonResponse<List<String>> getDocumentClientAccountNumber() {
		log.info("Fetching document summary client Account number ");
		return documentSummaryService.getClientAccountNumber();
	}
	
	@Operation(summary = "Fetch list of Account having a specific document", description = "Fetch list of Account having a specific document")
	@PostMapping("/accounts")
	public PagedResponse<AccountDocumentResponse> getAccountListForDocument(
			@Valid @RequestBody AccountDocumentSearchParam accountDocumentSearchParam) {
		log.info("Fetching list of account having a specific document for accountDocumentSearchParam {} ", accountDocumentSearchParam);
		return documentSummaryService.getAccountListForSpecificDocument(accountDocumentSearchParam);
	}
	
	@Operation(summary = "Fetch list of Account having a not specific document", description = "Fetch list of Account having a not specific document")
	@PostMapping("/accounts/not")
	public PagedResponse<String> getAccountListForDocument(
			@Valid @RequestBody AccountNOTDocumentSearchParam accountNOTDocumentSearchParam) {
		log.info("Fetching list of account having a not specific document for accountNOTDocumentSearchParam {} ", accountNOTDocumentSearchParam);
		return documentSummaryService.getAccountListForNotSpecificDocument(accountNOTDocumentSearchParam);
	}
	
	@Operation(summary = "Fetch user usage detail ", description = "Fetch user usage detail ")
	@GetMapping("/usage")
	public CommonResponse<UsageResponse> getUsage() {
		log.info("Fetching the user Usage deatail ");
		return documentSummaryService.getUserUsage();
	}
}
