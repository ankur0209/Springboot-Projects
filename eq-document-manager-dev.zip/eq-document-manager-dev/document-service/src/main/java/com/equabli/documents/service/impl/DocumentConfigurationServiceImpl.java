package com.equabli.documents.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.configs.AWSOperations;
import com.equabli.common.constants.Constants;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.DocCost;
import com.equabli.common.entity.DocType;
import com.equabli.common.entity.Document;
import com.equabli.common.entity.QDocument;
import com.equabli.common.entity.QSendReceiveDocument;
import com.equabli.common.entity.QShareBy;
import com.equabli.common.entity.QShareWith;
import com.equabli.common.entity.RequireDoc;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.feignclients.CommonConfigService;
import com.equabli.common.queryhelpers.LikeHelper;
import com.equabli.common.repository.DocCostRepository;
import com.equabli.common.repository.DocTypeRepository;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.repository.RequireDocRepository;
import com.equabli.common.repository.SentReceiveDocumentRepository;
import com.equabli.common.repository.ShareByRepository;
import com.equabli.common.repository.ShareWithRepository;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.FolderResponse;
import com.equabli.common.response.PageRequestData;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.response.ProductResponse;
import com.equabli.common.response.ProductValidateResponse;
import com.equabli.common.response.ShareByWithResponse;
import com.equabli.common.searchparam.DocumentForldersSearchParam;
import com.equabli.common.utils.DateUtils;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.documents.constants.ColumnConstants;
import com.equabli.documents.constants.DocumentMessageConstants;
import com.equabli.documents.request.DocumentCostRequest;
import com.equabli.documents.request.RequireDocumentRequest;
import com.equabli.documents.request.RequiredDocConfigRequest;
import com.equabli.documents.response.DocumentCostConfigResponse;
import com.equabli.documents.response.DocumentCostResponse;
import com.equabli.documents.response.DocumentResponse;
import com.equabli.documents.response.DocumentTypeResponse;
import com.equabli.documents.response.RequiredDocConfigResponse;
import com.equabli.documents.searchparams.DocumentsSearchParam;
import com.equabli.documents.service.DocumentConfigurationService;
import com.equabli.documents.service.ShowHideColumnService;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.JPAExpressions;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DocumentConfigurationServiceImpl implements DocumentConfigurationService {

	private static final QDocument qDocument = QDocument.document;
	private static final QShareBy qShareBy = QShareBy.shareBy;
	private static final QShareWith qShareWith = QShareWith.shareWith;
	private static final QSendReceiveDocument qSendReceiveDocument = QSendReceiveDocument.sendReceiveDocument;
	
	
	@Value("${awsS3.bucket.name}")
	private String awsBucketName;
	
	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	private DocumentRepository documentRepository;

	@Autowired
	private RequireDocRepository requireDocRepository;

	@Autowired
	private DocCostRepository docCostRepository;

	@Autowired
	private DocTypeRepository docTypeRepository;

	@Autowired
	FetchTokenData fetchTokenData;
	
	@Autowired(required = false)
	AWSOperations awsOperations;
	
	@Autowired
	ShowHideColumnService showHideColumnService;
	
	@Autowired
	ShareByRepository shareByRepository;
	
	@Autowired
	ShareWithRepository shareWithRepository;
	
	@Autowired
	SentReceiveDocumentRepository sentReceiveDocumentRepository;
	
	@Autowired
	CommonConfigService configService;
	@Autowired
	private HttpServletRequest request;

	private static final String PROD_CODE = "productCode";
	private static final String PROD_NAME = "productName";
	private static final String FOLDER_NAME = "clientAccountNo";
	private static final String WEB_ORIGIN_CONST = "WEB";

	@Override
	public PagedResponse<DocumentResponse> getDocumentListForAccountNumber(
			@NonNull DocumentsSearchParam documentsSearchParam) {

		TokenData tokenData = fetchTokenData.getTokenData();

		PageRequestData pageRequestData = Util.getPageRequestData(documentsSearchParam.getPageSize(),
				documentsSearchParam.getPageNumber(),
				documentsSearchParam.getSortOrder(),
				documentsSearchParam.getSortParam()!= null ? documentsSearchParam.getSortParam() : ColumnConstants.COLUMN_UPDATED_AT);

		Sort sort = Util.getSortingOrder(pageRequestData.getSortOrder(), getDocumentSortParam(pageRequestData.getSortParam()));
		Pageable pageable = PageRequest.of(pageRequestData.getPageNumber(), pageRequestData.getPageSize(),sort);

		Page<DocumentResponse> fileNames = null;

		fileNames = documentRepository.findAll(getPredicateForDocuments(documentsSearchParam, tokenData), pageable)
				.map(DocumentResponse::new);
		
		fileNames.forEach(document -> {
			document.setPreSignUrl(getPresingUrl(document.getObjectKey(), document.getFileSize()));
			document.setReceiveDate(getReceivedDateById(document.getId()));
			document.setSharedBy(getShareByDetail(document.getId()));
			document.setShareDate(getShareDocumentDate(document.getId()));
			document.setSharedWith(getShareWithDetail(document.getId()));
		});
		
		if (sortDocument(documentsSearchParam.getSortParam())) {
			fileNames = sortDocumentList(fileNames, pageable, documentsSearchParam.getSortParam(),
					documentsSearchParam.getSortOrder());
		}
		
		List<String> columns = showHideColumnService.getColumns(ColumnConstants.TABLE_DOCUMENT, tokenData);

		return fileNames.isEmpty() ? PagedResponse.empty()
				: PagedResponse.of(fileNames.getContent(), columns, fileNames.getNumber(), fileNames.getSize(),
						(int) fileNames.getTotalElements(), fileNames.getTotalPages());
	}

	private BooleanBuilder getPredicateForDocuments(@NonNull DocumentsSearchParam documentsSearchParam,
			TokenData tokenData) {
		BooleanBuilder booleanBuilder = new BooleanBuilder();
		booleanBuilder.and(qDocument.isDelete.isFalse());
		
		
		/**
		 * When account number is "Other" than we fetch those file detail have not
		 * proper file name configuration
		 */
		if (DocumentMessageConstants.OTHER.equals(documentsSearchParam.getAccountNumber())) {
			booleanBuilder.and(qDocument.orgCode.eq(tokenData.getUserOrgCode()));
			booleanBuilder.and(qDocument.isOthers.isTrue());
		} else {
			booleanBuilder.and(qDocument.isOthers.isFalse());
			booleanBuilder.and(addOrgCodeValidation(tokenData));

			BooleanBuilder booleanBuilderOr = new BooleanBuilder();
			booleanBuilderOr.or(qDocument.originalAccountNo.eq(documentsSearchParam.getAccountNumber()));
			booleanBuilderOr.or(qDocument.clientAccountNo.eq(documentsSearchParam.getAccountNumber()));
			if (Util.isDigit(documentsSearchParam.getAccountNumber()))
				booleanBuilderOr
						.or(qDocument.equabliAccountNo.eq(Long.parseLong(documentsSearchParam.getAccountNumber())));
			
			
			BooleanBuilder booleanBuildersent = new BooleanBuilder();
			booleanBuildersent.or(qDocument.id
					.in(JPAExpressions.select(qSendReceiveDocument.fullfilledDocumentId.id).from(qSendReceiveDocument)
							.join(qDocument).on(qDocument.id.eq(qSendReceiveDocument.fullfilledDocumentId.id))
							.where(qSendReceiveDocument.sentRequestOrgCode.eq(tokenData.getUserOrgCode()))));
			
			booleanBuildersent.or(qDocument.clientAccountNo.eq(documentsSearchParam.getAccountNumber()));
			
			booleanBuilder.and(booleanBuildersent);
			log.info("QUERY booleanBuildersent -> {}", booleanBuildersent.toString());
			
			BooleanBuilder booleanBuildershare = new BooleanBuilder();
			booleanBuildershare.or(qDocument.id.in(JPAExpressions.select(qShareBy.documentId).from(qShareBy).join(qShareWith)
					.on(qShareWith.shareById.id.eq(qShareBy.id).and(qShareWith.isUnshared.isFalse())
							.and(qShareWith.shareWithUserOrgCode.eq(tokenData.getUserOrgCode())))));
			booleanBuildershare.or(qDocument.clientAccountNo.eq(documentsSearchParam.getAccountNumber()));
			
			booleanBuilder.and(booleanBuildershare);
			log.info("QUERY booleanBuildershare -> {}", booleanBuildershare.toString());
			
			booleanBuilder.and(booleanBuilderOr);
		}
		
		if(StringUtils.hasText(documentsSearchParam.getTextSearch())) {
			BooleanBuilder booleanBuilderOr = new BooleanBuilder();
			booleanBuilderOr.or(qDocument.generatedFileName
					.likeIgnoreCase(LikeHelper.anyPosition(documentsSearchParam.getTextSearch())));
			booleanBuilderOr.or(qDocument.documentName.likeIgnoreCase(LikeHelper.anyPosition(documentsSearchParam.getTextSearch())));
			booleanBuilderOr.or(qDocument.originalAccountNo.likeIgnoreCase(LikeHelper.anyPosition(documentsSearchParam.getTextSearch())));
			booleanBuilderOr.or(qDocument.clientAccountNo.likeIgnoreCase(LikeHelper.anyPosition(documentsSearchParam.getTextSearch())));
			booleanBuilderOr.or(qDocument.equabliAccountNo.stringValue()
					.likeIgnoreCase(LikeHelper.anyPosition(documentsSearchParam.getTextSearch())));
			booleanBuilderOr.or(qDocument.id.in(JPAExpressions.select(qShareBy.documentId).from(qShareBy)
					.where(qShareBy.documentId.eq(qDocument.id).and(qShareBy.orgCode.eq(tokenData.getUserOrgCode()))
							.and(qShareBy.isUnshared.isFalse()).and(qShareBy.sharedBy
									.likeIgnoreCase(LikeHelper.anyPosition(documentsSearchParam.getTextSearch()))))));
			booleanBuilderOr.or(qDocument.id
					.in(JPAExpressions.select(qShareBy.documentId).from(qShareBy).join(qShareWith)
							.on(qShareWith.shareById.id.eq(qShareBy.id).and(qShareWith.isUnshared.isFalse())
									.and(qShareWith.shareWithName.likeIgnoreCase(
											LikeHelper.anyPosition(documentsSearchParam.getTextSearch()))))
							.where(qShareBy.orgCode.eq(tokenData.getUserOrgCode()))));
			
			booleanBuilder.and(booleanBuilderOr);
		}else {

			if (StringUtils.hasText(documentsSearchParam.getDocumentType()))
				booleanBuilder.and(qDocument.docTypeCode.eq(documentsSearchParam.getDocumentType()));

			if (StringUtils.hasText(documentsSearchParam.getDocumentName()))
				booleanBuilder.and(qDocument.generatedFileName
						.likeIgnoreCase(LikeHelper.anyPosition(documentsSearchParam.getDocumentName())));

			if (documentsSearchParam.getGenerationDateFrom() != null
					&& documentsSearchParam.getGenerationDateTo() != null) {
				booleanBuilder.and(qDocument.documentGenerationDate
						.goe(DateUtils.atStartOfDay(documentsSearchParam.getGenerationDateFrom())));
				booleanBuilder.and(qDocument.documentGenerationDate
						.loe(DateUtils.atEndOfDay(documentsSearchParam.getGenerationDateTo())));
			}

			if (documentsSearchParam.getUploadDateFrom() != null && documentsSearchParam.getUploadDateTo() != null) {
				booleanBuilder.and(qDocument.createdAt.goe(DateUtils.atStartOfDay(documentsSearchParam.getUploadDateFrom())));
				booleanBuilder.and(qDocument.createdAt.loe(DateUtils.atEndOfDay(documentsSearchParam.getUploadDateTo())));
			}
			
			if (documentsSearchParam.getShareDateFrom() != null
					&& documentsSearchParam.getShareDateTo() != null) {
				BooleanExpression exp = qDocument.id.in(JPAExpressions.select(qShareBy.documentId).from(qShareBy)
						.where(qShareBy.documentId.eq(qDocument.id).and(qShareBy.orgCode.eq(tokenData.getUserOrgCode()))
								.and(qShareBy.isUnshared.isFalse()).and(qShareBy.sharedAt
										.goe(DateUtils.atStartOfDay(documentsSearchParam.getShareDateFrom())))));
				booleanBuilder.and(exp);
				BooleanExpression exp1 = qDocument.id.in(JPAExpressions.select(qShareBy.documentId).from(qShareBy)
						.where(qShareBy.documentId.eq(qDocument.id).and(qShareBy.orgCode.eq(tokenData.getUserOrgCode()))
								.and(qShareBy.isUnshared.isFalse()).and(qShareBy.sharedAt
										.loe(DateUtils.atEndOfDay(documentsSearchParam.getShareDateTo())))));
				booleanBuilder.and(exp1);
			}

			if (documentsSearchParam.getReceiveDateFrom() != null
					&& documentsSearchParam.getReceiveDateTo() != null) {
				booleanBuilder.and(qDocument.createdAt
						.goe(DateUtils.atStartOfDay(documentsSearchParam.getReceiveDateFrom())));
				booleanBuilder.and(qDocument.createdAt
						.loe(DateUtils.atEndOfDay(documentsSearchParam.getReceiveDateTo())));
			}
			
			if (StringUtils.hasText(documentsSearchParam.getShareBy())) {
				BooleanExpression exp = qDocument.id.in(JPAExpressions.select(qShareBy.documentId).from(qShareBy)
						.where(qShareBy.documentId.eq(qDocument.id).and(qShareBy.orgCode.eq(tokenData.getUserOrgCode()))
								.and(qShareBy.isUnshared.isFalse()).and(qShareBy.sharedBy
										.likeIgnoreCase(LikeHelper.anyPosition(documentsSearchParam.getShareBy())))));
				booleanBuilder.and(exp);
			}

			if (StringUtils.hasText(documentsSearchParam.getShareWith())) {
				BooleanExpression exp = qDocument.id
						.in(JPAExpressions.select(qShareBy.documentId).from(qShareBy).join(qShareWith)
								.on(qShareWith.shareById.id.eq(qShareBy.id).and(qShareWith.isUnshared.isFalse())
										.and(qShareWith.shareWithName.likeIgnoreCase(
												LikeHelper.anyPosition(documentsSearchParam.getShareWith()))))
								.where(qShareBy.orgCode.eq(tokenData.getUserOrgCode())));
				booleanBuilder.and(exp);
			}
		}
		
		log.info("QUERY booleanBuilder -> {}", booleanBuilder);
		
		return booleanBuilder;
	}
	
	private BooleanBuilder addOrgCodeValidation(TokenData tokenData) {
		BooleanBuilder booleanBuilderOrgCode = new BooleanBuilder();
		booleanBuilderOrgCode.or(qDocument.orgCode.eq(tokenData.getUserOrgCode()));
		
		booleanBuilderOrgCode.or(qDocument.orgCode.in(JPAExpressions.select(qShareBy.orgCode).from(qShareBy)
				.join(qShareWith).on(qShareWith.shareById.id.eq(qShareBy.id).and(qShareWith.isUnshared.isFalse())
						.and(qShareWith.shareWithUserOrgCode.eq(tokenData.getUserOrgCode())))));
		
		booleanBuilderOrgCode.or(qDocument.orgCode.in(JPAExpressions.select(qShareWith.shareWithUserOrgCode).from(qShareBy)
				.join(qShareWith).on(qShareWith.shareById.id.eq(qShareBy.id).and(qShareWith.isUnshared.isFalse())
						.and(qShareWith.shareWithUserOrgCode.eq(tokenData.getUserOrgCode())))));
		log.info("QUERY booleanBuilderOrgCode -> {}", booleanBuilderOrgCode);
		return booleanBuilderOrgCode;
	}

	@Override
	public PagedResponse<FolderResponse> getFolderList(DocumentForldersSearchParam documentForldersSearchParam) {

		TokenData tokenData = fetchTokenData.getTokenData();
		List<FolderResponse> finalList = new ArrayList<>();

		if (documentForldersSearchParam == null) {
			documentForldersSearchParam = new DocumentForldersSearchParam();
		}
		
		String sortParam = documentForldersSearchParam.getSortParam() == null ? FOLDER_NAME
				: documentForldersSearchParam.getSortParam();
		
		List<FolderResponse> groupByClientAccountNo = documentRepository.groupByClientAccountNoList(tokenData.getUserOrgCode(),
				documentForldersSearchParam, documentForldersSearchParam.getTextSearch(),
				documentForldersSearchParam.getReceiveDateFrom() == null ? null
						: DateUtils.atStartOfDay(documentForldersSearchParam.getReceiveDateFrom()),
				documentForldersSearchParam.getReceiveDateTo() == null ? null
						: DateUtils.atEndOfDay(documentForldersSearchParam.getReceiveDateTo()),
				documentForldersSearchParam.getShareDateFrom() == null ? null
						: DateUtils.atStartOfDay(documentForldersSearchParam.getShareDateFrom()),
				documentForldersSearchParam.getShareDateTo() == null ? null
						: DateUtils.atEndOfDay(documentForldersSearchParam.getShareDateTo()));
			
		groupByClientAccountNo.forEach(l -> {
			l.setDocuments(
					documentRepository.getByClientAcountNoAndOrgCode(l.getFolderName(), tokenData.getUserOrgCode()));
			l.setShareBy(getShareByClientAcountNo(l.getFolderName()));
			l.setSharedWith(getShareWithClientAcountNo(l.getFolderName()));
			l.setShareDate(getShareAtDate(l.getFolderName()));
			l.setReceiveDate(getReceivedDateByAccountNo(l.getFolderName()));
		});

		finalList.addAll(groupByClientAccountNo);
		
		FolderResponse otherDocuments = documentRepository.getOtherDocuments(tokenData.getUserOrgCode());
		otherDocuments.setDocuments(documentRepository.getDocumentsByOther(tokenData.getUserOrgCode()));
		if (otherDocuments.getModifiedDate() != null
				&& (DocumentMessageConstants.OTHER.equalsIgnoreCase(documentForldersSearchParam.getTextSearch())
						|| documentForldersSearchParam.allNull()))
			finalList.add(otherDocuments);

		PageRequestData pageRequestData = documentForldersSearchParam != null
				? Util.getPageRequestData(documentForldersSearchParam.getPageSize(),
						documentForldersSearchParam.getPageNumber(), documentForldersSearchParam.getSortOrder(),
						sortParam)
				: Util.getPageRequestData(null, null, null, FOLDER_NAME);

		finalList = finalList.stream().filter(getPredicate(documentForldersSearchParam)).toList();
		finalList = getFolderSortParma(finalList,sortParam,pageRequestData.getSortOrder());
		
		int totalElements = finalList.size();
		int skip = pageRequestData.getPageNumber() * pageRequestData.getPageSize();

		finalList = finalList.stream().skip(skip).limit(pageRequestData.getPageSize()).toList();

		List<String> columns = showHideColumnService.getColumns(ColumnConstants.TABLE_DOCUMENT_FOLDER, tokenData);

		return finalList.isEmpty() ? PagedResponse.empty()
				: PagedResponse.of(finalList, columns, (skip + 1), pageRequestData.getPageSize(), totalElements);

	}
	
	private Predicate<FolderResponse> getPredicate(DocumentForldersSearchParam documentForldersSearchParam) {

		if (documentForldersSearchParam.getFolderName() != null
				&& documentForldersSearchParam.getModifiedDateFrom() != null
				&& documentForldersSearchParam.getModifiedDateTo() != null)
			return getFolderNamePredicate(documentForldersSearchParam)
					.and(getDatePredicate(documentForldersSearchParam));
		else if (documentForldersSearchParam.getModifiedDateFrom() != null
				&& documentForldersSearchParam.getModifiedDateTo() != null)
			return getDatePredicate(documentForldersSearchParam);
		else if (documentForldersSearchParam.getFolderName() != null)
			return getFolderNamePredicate(documentForldersSearchParam);
		else
			return e -> true;
	}
	
	private Predicate<FolderResponse> getFolderNamePredicate(DocumentForldersSearchParam documentForldersSearchParam) {
		return e -> e.getFolderName().equals(documentForldersSearchParam.getFolderName());
	}

	private Predicate<FolderResponse> getDatePredicate(DocumentForldersSearchParam documentForldersSearchParam) {
		return e -> e.getModifiedDate()
				.isAfter(DateUtils.atStartOfDay(documentForldersSearchParam.getModifiedDateFrom()))
				&& e.getModifiedDate().isBefore(DateUtils.atEndOfDay(documentForldersSearchParam.getModifiedDateTo()));
	}

	@Override
	public PagedResponse<DocumentTypeResponse> getDocumentsForProducts(Integer pageSize, Integer pageNumber) {

		PageRequestData pageRequestData = Util.getPageRequestData(pageSize, pageNumber,null,null);
		Pageable pageable = PageRequest.of(pageRequestData.getPageNumber(), pageRequestData.getPageSize());
		Page<DocumentTypeResponse> productDocumentResponses = docTypeRepository.findAll(pageable)
				.map(DocumentTypeResponse::new);

		return productDocumentResponses.isEmpty() ? PagedResponse.empty()
				: PagedResponse.of(productDocumentResponses.getContent(), productDocumentResponses.getNumber(),
						productDocumentResponses.getSize(), (int) productDocumentResponses.getTotalElements(),
						productDocumentResponses.getTotalPages());
	}

	@Override
	@Transactional
	public CommonResponse<String> saveDocumentCost(DocumentCostRequest documentCostRequest) {

		TokenData tokenData = fetchTokenData.getTokenData();
		DocType docType = getDocType(documentCostRequest.getDocTypeCode());
		DocCost docCost = docCostRepository.findByOrgCodeAndDocTypeCodeAndIsDeleteFalse(tokenData.getUserOrgCode(),
				documentCostRequest.getDocTypeCode()).orElse(new DocCost());
		docCost.saveDocCost(docCost, documentCostRequest.getCost(), docType, tokenData);
		docCost = docCostRepository.save(docCost);

		return CommonResponse.success(messageSupplier.get(DocumentMessageConstants.DocumentConfig.COST_CREATE_SUCCESS,
				docCost.getDocType().getShortCode()), docCost.getDocType().getShortCode());
	}

	@Override
	public PagedResponse<DocumentCostConfigResponse> getDocumentCostConfigPage(Integer pageSize, Integer pageNumber) {

		TokenData tokenData = fetchTokenData.getTokenData();

		PageRequestData pageRequestData = Util.getPageRequestData(pageSize, pageNumber, null,null);
		int startRecord = (pageRequestData.getPageNumber() * pageRequestData.getPageSize()) + 1;
		Pageable pageable = PageRequest.of(pageRequestData.getPageNumber(), pageRequestData.getPageSize());

		Page<DocumentCostConfigResponse> docTypePage = docCostRepository
				.findByOrgCodeAndCostNotNullAndIsDeleteFalse(tokenData.getUserOrgCode(), pageable)
				.map(DocumentCostConfigResponse::new);

		return docTypePage.isEmpty() ? PagedResponse.empty()
				: PagedResponse.of(docTypePage.getContent(), startRecord, pageRequestData.getPageSize(),
						(int) docTypePage.getTotalElements());
	}

	@Override
	@Cacheable(value = DocumentMessageConstants.EVICT_CACHE_CONST)
	public CommonResponse<List<ProductResponse>> getProducts() {
		log.info("Check for DB from document service..");
		List<ProductResponse> productResponses = new ArrayList<>();
		String authorization = request.getHeader(Constants.AUTHORIZATION);
		String validMessage = configService.getProductList(authorization, WEB_ORIGIN_CONST);
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		try {
			ProductValidateResponse productValidateResponse = mapper.readValue(validMessage, ProductValidateResponse.class);
			productResponses = productValidateResponse.getResponse();
		}catch (Exception e) {
			log.error("ERROR WHILE CONVERT VALUES - > {}", e.getMessage(), e);
		}
		return CommonResponse.success(
				messageSupplier.get(DocumentMessageConstants.RequireDocConfig.REQUIRED_DOC_FETCH_SUCCESS),
				productResponses);
	}

	@Override
	@Transactional
	public CommonResponse<String> saveRequiredDocument(RequiredDocConfigRequest requiredDocConfigRequest) {

		List<RequireDoc> requireDocs = new ArrayList<>();
		TokenData tokenData = fetchTokenData.getTokenData();

		for (String docTypeCode : requiredDocConfigRequest.getDocTypeCode()) {
			RequireDoc requireDoc = requireDocRepository
					.findByOrgCodeAndProductCodeAndDocTypeCode(tokenData.getUserOrgCode(),
							requiredDocConfigRequest.getProductCode(), docTypeCode)
					.orElse(new RequireDoc());
			requireDoc.saveRequireDoc(requireDoc, requiredDocConfigRequest.getProductCode(), docTypeCode, tokenData);
			requireDocs.add(requireDoc);
		}
		requireDocRepository.saveAll(requireDocs);

		List<RequireDoc> requireDocDelete = requireDocRepository.findByOrgCodeAndProductCodeAndDocTypeCodeNotIn(
				tokenData.getUserOrgCode(), requiredDocConfigRequest.getProductCode(),
				requiredDocConfigRequest.getDocTypeCode());
		requireDocDelete.forEach(l -> l.deleteRequireDoc(l, tokenData));

		requireDocRepository.saveAll(requireDocDelete);

		return CommonResponse
				.success(messageSupplier.get(DocumentMessageConstants.RequireDocConfig.REQUIRED_DOC_CREATE_SUCCESS));
	}

	@Override
	public CommonResponse<DocumentCostResponse> getDocumentCostConfig(String docTypeCode) {
		TokenData tokenData = fetchTokenData.getTokenData();
		DocType docType = getDocType(docTypeCode);
		DocCost docCost = getDocCost(docTypeCode, tokenData.getUserOrgCode());
		DocumentCostResponse documentCostResponse = new DocumentCostResponse(docCost.getDocTypeCode(),
				docCost.getCost(), docType.getName());

		return CommonResponse.success(
				messageSupplier.get(DocumentMessageConstants.DocumentConfig.COST_FETCH_SUCCESS, docTypeCode),
				documentCostResponse);
	}

	@Override
	@Transactional
	public CommonResponse<String> deleteDocumentCostConfig(String docTypeCode) {
		TokenData tokenData = fetchTokenData.getTokenData();
		getDocType(docTypeCode);

		DocCost docCost = getDocCost(docTypeCode, tokenData.getUserOrgCode());
		docCost.deleteDocCost(docCost, fetchTokenData.getTokenData());
		docCost = docCostRepository.save(docCost);

		return CommonResponse.success(messageSupplier.get(DocumentMessageConstants.DocumentConfig.COST_DELETE_SUCCESS,
				docCost.getDocType().getShortCode()), docCost.getDocType().getShortCode());
	}

	/**
	 * Fetch DocType by product code and document code
	 * 
	 * @param productCode
	 * @param documentCode
	 * @return
	 */
	private DocType getDocType(String docTypeCode) {
		return docTypeRepository.findByShortCode(docTypeCode).orElseThrow(() -> new InvalidArgumentException(
				messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, " " + docTypeCode, null)));
	}

	private DocCost getDocCost(String docTypeCode, String ownerOrgTypeCode) {
		return docCostRepository.findByOrgCodeAndDocTypeCodeAndIsDeleteFalse(ownerOrgTypeCode, docTypeCode)
				.orElseThrow(() -> new InvalidArgumentException(
						messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, " " + docTypeCode, null)));
	}

	@Override
	@Transactional
	public CommonResponse<String> deleteRequiredDocument(String productCode) {

		TokenData tokenData = fetchTokenData.getTokenData();

		List<RequireDoc> listRequireDocs = requireDocRepository
				.findByOrgCodeAndProductCodeAndIsDeleteFalse(tokenData.getUserOrgCode(), productCode);
		for (RequireDoc requireDoc : listRequireDocs) {
			requireDoc.deleteRequireDoc(requireDoc, tokenData);
			requireDocRepository.save(requireDoc);
		}
		return CommonResponse
				.success(messageSupplier.get(DocumentMessageConstants.RequireDocConfig.REQUIRED_DOC_DELETE_SUCCESS));
	}

	@Override
	public CommonResponse<RequiredDocConfigResponse> getRequirementDocument(String productCode) {

//		List<Map<String, String>> prodMap = Util.getProductMap(productCode);
		ProductResponse productResponse = getAllProductDetails().stream()
				.filter(pr -> pr.getShortName().equals(productCode)).findFirst().get();
		TokenData tokenData = fetchTokenData.getTokenData();

		List<RequireDoc> listOfDoc = requireDocRepository
				.findByOrgCodeAndProductCodeAndIsDeleteFalse(tokenData.getUserOrgCode(), productCode);
		List<RequireDocumentRequest> listOfDocument = getListOfRequireDoc(listOfDoc);
		RequiredDocConfigResponse docConfigResponse = new RequiredDocConfigResponse(productResponse.getShortName(),
				productResponse.getFullName(), listOfDocument);
		return CommonResponse.success(
				messageSupplier.get(DocumentMessageConstants.RequireDocConfig.REQUIRED_DOC_FETCH_SUCCESS),
				docConfigResponse);
	}

	@Override
	public CommonResponse<List<RequiredDocConfigResponse>> getAllRequirementDocument() {

		TokenData tokenData = fetchTokenData.getTokenData();

		List<RequiredDocConfigResponse> listOfDocumentResponse = new ArrayList<>();
		List<ProductResponse> productResponse = getAllProductDetails();
		//List<Map<String, String>> prodctList = Util.getProductMap("");
		for (ProductResponse productMap : productResponse) {
			List<RequireDoc> listOfDoc = requireDocRepository
					.findByOrgCodeAndProductCodeAndIsDeleteFalse(tokenData.getUserOrgCode(), productMap.getShortName());
			if (!listOfDoc.isEmpty()) {
				List<RequireDocumentRequest> requireDocList = getListOfRequireDoc(listOfDoc);
				RequiredDocConfigResponse docConfigResponse = new RequiredDocConfigResponse(productMap.getShortName(),
						productMap.getFullName(), requireDocList);
				listOfDocumentResponse.add(docConfigResponse);
			}
		}
		return CommonResponse.success(
				messageSupplier.get(DocumentMessageConstants.RequireDocConfig.REQUIRED_DOC_FETCH_SUCCESS),
				listOfDocumentResponse);
	}

	private List<RequireDocumentRequest> getListOfRequireDoc(List<RequireDoc> listOfDoc) {
		List<RequireDocumentRequest> listOfDocument = new ArrayList<>();
		RequireDocumentRequest documentRequest;
		for (RequireDoc requireDoc : listOfDoc) {
			documentRequest = new RequireDocumentRequest();
			DocType docType = docTypeRepository.findByShortCode(requireDoc.getDocTypeCode()).orElse(new DocType());
			documentRequest.setDocumentCode(docType.getShortCode());
			documentRequest.setDocumentName(docType.getName());
			listOfDocument.add(documentRequest);
		}
		return listOfDocument;
	}
	
	private String getPresingUrl(String objectKey, Long fileSize) {
		return awsOperations == null ? null
				: awsOperations.genaratePreSignUrl(awsBucketName, objectKey, Util.getExprireTimeByFileSize(fileSize));
	}

	@Override
	public CommonResponse<String> deleteDocument(Long id) {
		Document document = documentRepository.findById(id)
				.orElseThrow(() -> new InvalidArgumentException(messageSupplier.get(MessageConstants.NOT_VALID, id)));
		document.deleteDocument(document, fetchTokenData.getTokenData());
		documentRepository.save(document);

		return CommonResponse.success(messageSupplier
				.get(DocumentMessageConstants.DocumentConfig.DOCUMENT_DELETE_SUCCESS, String.valueOf(id)),
				String.valueOf(id));
	}
	
	private String getDocumentSortParam(String sortParams) {
		String sortParamsVal = null;
		switch (sortParams) {
		case ColumnConstants.COLUMN_NAME -> sortParamsVal = "generatedFileName";
		case ColumnConstants.COLUMN_DOCUMENT_TYPE -> sortParamsVal = "docTypeCode";
		case ColumnConstants.COLUMN_ORIGINAL_ACCOUNT_NUMBER -> sortParamsVal = "originalAccountNo";
		case ColumnConstants.COLUMN_EQUABLI_ACCOUNT_NUMBER -> sortParamsVal = "equabliAccountNo";
		case ColumnConstants.COLUMN_CLIENT_ACCOUNT_NUMBER -> sortParamsVal = "clientAccountNo";
		case ColumnConstants.COLUMN_GENERATED_DATE -> sortParamsVal = "documentGenerationDate";
		case ColumnConstants.COLUMN_UPLOAD_DATE -> sortParamsVal = ColumnConstants.COLUMN_CREATED_AT;
		case ColumnConstants.COLUMN_FILE_SIZE -> sortParamsVal = "fileSize";
		default -> sortParamsVal = ColumnConstants.COLUMN_UPDATED_AT;
		}
		return sortParamsVal;
	}
	
	private List<FolderResponse> getFolderSortParma(List<FolderResponse> finalList, String param, String order) {
		List<FolderResponse> compareList = new ArrayList<>(finalList);
		Comparator<FolderResponse> compare = null;
		switch (param) {
		case ColumnConstants.COLUMN_NAME ->
			compare = (FolderResponse f1, FolderResponse f2) -> f1.getFolderName().compareTo(f2.getFolderName());
		case ColumnConstants.COLUMN_FILE_SIZE ->
			compare = (FolderResponse f1, FolderResponse f2) -> f1.getFileSize().compareTo(f2.getFileSize());
		case ColumnConstants.COLUMN_MODIFIED_DATE ->
			compare = (FolderResponse f1, FolderResponse f2) -> f1.getModifiedDate().compareTo(f2.getModifiedDate());
		case ColumnConstants.COLUMN_SHARE_DATE -> compare = (FolderResponse f1, FolderResponse f2) -> {
			if (f2.getShareDate() == null)
				return -1;
			else if (f1.getShareDate() == null)
				return 0;
			else
				return f1.getShareDate().compareTo(f2.getShareDate());
		};
		case ColumnConstants.COLUMN_RECEIVED_DATE -> compare = (FolderResponse f1, FolderResponse f2) -> {
			if (f2.getReceiveDate() == null)
				return -1;
			else if (f1.getReceiveDate() == null)
				return 0;
			else
				return f1.getReceiveDate().compareTo(f2.getReceiveDate());
		};
		case ColumnConstants.COLUMN_SHARED_BY ->
			compare = (FolderResponse f1, FolderResponse f2) -> f1.getShareBy().size() - f2.getShareBy().size();
		case ColumnConstants.COLUMN_SHARED_WITH ->
			compare = (FolderResponse f1, FolderResponse f2) -> f1.getSharedWith().size() - f2.getSharedWith().size();
		default -> compare = (FolderResponse f1, FolderResponse f2) -> f1.getFolderName().compareTo(f2.getFolderName());
		}
		if (ColumnConstants.ORDER_DESC.equalsIgnoreCase(order))
			Collections.sort(compareList, compare.reversed());
		else
			Collections.sort(compareList, compare);
		return compareList;
	}

	private List<ShareByWithResponse> getShareByDetail(Long id) {
		List<ShareByWithResponse> shareByWithResponses = shareByRepository.findByDocumentIdAndIsUnsharedFalse(id)
				.stream().map(ShareByWithResponse::new).toList();
		shareByWithResponses.forEach(s -> s.setProfilePicture(getUserProfilePicturePreSignUrl(s.getUserId())));
		return shareByWithResponses;
	}
	
	private LocalDateTime getShareDocumentDate(Long id) {
		return shareByRepository.getByDocumentIdAndIsUnsharedFalse(id) == null ? null
				: shareByRepository.getByDocumentIdAndIsUnsharedFalse(id);
	}
	
	@Override
	public CommonResponse<String> deleteFolder(String clientAccountNo) {
		
		List<Document> listOfDocument = documentRepository.findByClientAccountNoAndIsDeleteFalse(clientAccountNo);
		if(!listOfDocument.isEmpty()) {
			for(Document document : listOfDocument) {
				document.deleteDocument(document, fetchTokenData.getTokenData());
				documentRepository.save(document);
			}
		}
		return CommonResponse.success(messageSupplier
				.get(DocumentMessageConstants.DocumentConfig.DOCUMENT_DELETE_SUCCESS,clientAccountNo),clientAccountNo);
	}

	private List<ShareByWithResponse> getShareWithDetail(Long id) {
		List<ShareByWithResponse> shareByWithResponses = shareWithRepository.getByShareWithDocumentId(id).stream()
				.map(ShareByWithResponse::new).toList();
		shareByWithResponses.forEach(s -> s.setProfilePicture(getUserProfilePicturePreSignUrl(s.getUserId())));
		return shareByWithResponses;
	}

	private List<ShareByWithResponse> getShareByClientAcountNo(String clientAccountNo) {
		List<ShareByWithResponse> shareByWithResponses = shareByRepository.getByClientAcountNo(clientAccountNo);
		shareByWithResponses.forEach(s -> s.setProfilePicture(getUserProfilePicturePreSignUrl(s.getUserId())));
		return shareByWithResponses;
	}

	private List<ShareByWithResponse> getShareWithClientAcountNo(String clientAccountNo) {
		List<ShareByWithResponse> shareByWithResponses = shareWithRepository.getByClientAcountNo(clientAccountNo);
		shareByWithResponses.forEach(s -> s.setProfilePicture(getUserProfilePicturePreSignUrl(s.getUserId())));
		return shareByWithResponses;
	}
	
	private String getShareAtDate(String clientAccountNo) {
		return shareByRepository.getShareAtByClientAcountNo(clientAccountNo) == null ? null :
				DateUtils.convertLocalDateTimeToString(shareByRepository.getShareAtByClientAcountNo(clientAccountNo));
	}
	
	private LocalDateTime getReceivedDateById(Long id) {
		LocalDateTime receiveDate = sentReceiveDocumentRepository.getReceiveDateById(id);
		return receiveDate == null ? null : receiveDate;
	}
	
	private String getReceivedDateByAccountNo(String clientAccountNo) {
		LocalDateTime receiveDate = sentReceiveDocumentRepository.getReceiveDateByClientAccountNo(clientAccountNo);
		return receiveDate == null ? null :
			DateUtils.convertLocalDateTimeToString(receiveDate);
	}
	
	private boolean sortDocument(String param) {
		List<String> columns = Arrays.asList(ColumnConstants.COLUMN_SHARED_BY, ColumnConstants.COLUMN_SHARED_WITH,
				ColumnConstants.COLUMN_SHARED_DATE, ColumnConstants.COLUMN_RECEIVE_DATE);
		return columns.contains(param);
	}
	
	private Page<DocumentResponse> sortDocumentList(Page<DocumentResponse> pages, Pageable pageable, String param,
			String order) {
		List<DocumentResponse> compareList = new ArrayList<>(pages.getContent());
		Comparator<DocumentResponse> compare = null;

		switch (param) {
		case ColumnConstants.COLUMN_SHARED_BY ->
			compare = (DocumentResponse f1, DocumentResponse f2) -> f1.getSharedBy().size() - f2.getSharedBy().size();
		case ColumnConstants.COLUMN_SHARED_WITH -> compare = (DocumentResponse f1,
				DocumentResponse f2) -> f1.getSharedWith().size() - f2.getSharedWith().size();
		case ColumnConstants.COLUMN_SHARE_DATE -> compare = (DocumentResponse f1, DocumentResponse f2) -> {
			if (f2.getShareDate() == null)
				return -1;
			else if (f1.getShareDate() == null)
				return 0;
			else
				return f1.getShareDate().compareTo(f2.getShareDate());
		};
		case ColumnConstants.COLUMN_RECEIVE_DATE -> compare = (DocumentResponse f1, DocumentResponse f2) -> {
			if (f2.getReceiveDate() == null)
				return -1;
			else if (f1.getReceiveDate() == null)
				return 0;
			else
				return f1.getReceiveDate().compareTo(f2.getReceiveDate());
		};
		default -> log.info("Not valid Columns");
		}

		if (compare == null)
			return pages;

		if (ColumnConstants.ORDER_DESC.equalsIgnoreCase(order))
			Collections.sort(compareList, compare.reversed());
		else
			Collections.sort(compareList, compare);

		return new PageImpl<>(compareList, pageable, compareList.size());
	}
	
	private String getUserProfilePicturePreSignUrl(Long userId) {
		String profilePath = awsOperations.getUserProfilePictureKey(awsBucketName,
				Util.profilePicturePath(String.valueOf(userId)));
		log.info("userId ->{}, User Profile Picture Path ->{}", userId, profilePath);
		return profilePath != null
				? awsOperations.genaratePreSignUrl(awsBucketName, profilePath, Util.PROFILE_PRE_SIGN_URL_EXPIRE_TIME)
				: null;
	}
	
	private List<ProductResponse> getAllProductDetails() {
		List<ProductResponse> productResponses = new ArrayList<>();
		String authorization = request.getHeader(Constants.AUTHORIZATION);
		String validMessage = configService.getProductList(authorization, WEB_ORIGIN_CONST);
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		try {
			ProductValidateResponse productValidateResponse = mapper.readValue(validMessage, ProductValidateResponse.class);
			productResponses = productValidateResponse.getResponse();
		}catch (Exception e) {
			log.error("ERROR WHILE CONVERT VALUES - > {}", e.getMessage(), e);
		}
		return productResponses;
	}
}