package com.equabli.documents.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.response.CommonResponse;
import com.equabli.documents.response.SubscriptionResponse;
import com.equabli.documents.service.SubscriptionService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user/subscription")
@Tag(name = "Subscripton Configuration API", description = "Subscripton Configuration API for document manager")
@Slf4j
public class SubscriptionController {

	@Autowired
	private SubscriptionService subscriptionService;

	@Autowired
	private FetchTokenData fetchTokenData;

	@Operation(summary = "Save subscription", description = "Save subscription")
	@PutMapping("/{subscriptionCode}")
	public CommonResponse<String> saveSubscription(@PathVariable("subscriptionCode") String subscriptionCode) {
		log.info("Update the subscription subscriptionCode -> {}, LoggerUser ->{}", subscriptionCode,
				fetchTokenData.getTokenData());
		return subscriptionService.saveSubscription(subscriptionCode);
	}

	@Operation(summary = "Fetch the saved subscription detail", description = "Fetch the saved subscription detail")
	@GetMapping
	public CommonResponse<SubscriptionResponse> getSubscription() {
		log.info("Get the subscription LoggerUser ->{}", fetchTokenData.getTokenData());
		return subscriptionService.getSubscription();
	}

	@Operation(summary = "Fetch All subscriptions detail", description = "Fetch All subscriptions detail")
	@GetMapping("/all")
	public CommonResponse<List<SubscriptionResponse>> getAllSubscription() {
		log.info("Fetch the All subscriptions");
		return subscriptionService.getAllSubscription();
	}

}
