package com.equabli.documents.searchparams;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;

import com.equabli.common.constants.MessageConstants;
import com.equabli.common.response.PageRequestData;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Search for Documents")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentsSearchParam extends PageRequestData {

	@NotBlank(message = "accountNumber")
	private String accountNumber;
	
	private String documentType;
	private String documentName;
	private String textSearch;

	@Schema(description = "Generation Date From "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate generationDateFrom;
	@Schema(description = "Generation Date To "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate generationDateTo;

	@Schema(description = "Upload Date From "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate uploadDateFrom;
	@Schema(description = "Upload Date To "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate uploadDateTo;

	@Schema(description = "Share date From "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate shareDateFrom;
	@Schema(description = "Share date To "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate shareDateTo;

	@Schema(description = "Receive date From "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate receiveDateFrom;
	
	@Schema(description = "Receive date To "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate receiveDateTo;

	@Schema(description = "Name of User")
	private String shareBy;

	@Schema(description = "Name of User")
	private String shareWith;
}
