package com.equabli.documents.service;

import java.util.List;

import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.documents.response.AccountDocumentResponse;
import com.equabli.documents.response.DocumentCoverageResponse;
import com.equabli.documents.response.UsageResponse;
import com.equabli.documents.searchparams.AccountDocumentSearchParam;
import com.equabli.documents.searchparams.AccountNOTDocumentSearchParam;
import com.equabli.documents.searchparams.DocumentCoverageSearchParam;

public interface DocumentSummaryService {

	CommonResponse<List<DocumentCoverageResponse>> getDocumentCoverage(
			DocumentCoverageSearchParam documentCoverageSearchParam);

	CommonResponse<List<String>> getClientAccountNumber();

	PagedResponse<AccountDocumentResponse> getAccountListForSpecificDocument(
			AccountDocumentSearchParam documentsSearchParam);

	PagedResponse<String> getAccountListForNotSpecificDocument(
			AccountNOTDocumentSearchParam accountNOTDocumentSearchParam);

	CommonResponse<UsageResponse> getUserUsage();

}
