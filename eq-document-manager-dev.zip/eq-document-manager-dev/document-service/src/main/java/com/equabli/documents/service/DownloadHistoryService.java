package com.equabli.documents.service;

import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.DownloadHistoryResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.documents.request.DownloadDocumentRequest;
import com.equabli.documents.searchparams.DownloadHistorySearchParam;

public interface DownloadHistoryService {

	CommonResponse<String> saveDownloadDocumentHistory(DownloadDocumentRequest documentRequest);

	CommonResponse<String> deleteDownloadDocumentHistory(Long downloadHistoryCode);

	PagedResponse<DownloadHistoryResponse> getDownloadHistoryPage(DownloadHistorySearchParam downloadHistorySearchParam);
}
