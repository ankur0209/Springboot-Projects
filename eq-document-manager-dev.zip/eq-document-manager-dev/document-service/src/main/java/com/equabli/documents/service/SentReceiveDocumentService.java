package com.equabli.documents.service;

import java.util.List;

import com.equabli.common.request.RequestNewDocumentRequest;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.documents.response.DocumentSummaryResponse;
import com.equabli.documents.response.SentDocumentResponse;
import com.equabli.documents.searchparams.SentReceiveSummarySearchParam;
import com.equabli.documents.searchparams.SentRequestDocumentSearchParam;

public interface SentReceiveDocumentService {

	CommonResponse<String> saveRequestNewDocument(RequestNewDocumentRequest requestNewDocumentRequest);

	PagedResponse<SentDocumentResponse> getSentDocumentRequest(SentRequestDocumentSearchParam sentRequestDocumentSearchParam);

	CommonResponse<String> deleteDocumentRequest(Long documentRequestId);

	CommonResponse<List<DocumentSummaryResponse>> getSentRequestSummary(SentReceiveSummarySearchParam sentReceiveSummarySearchParam);

}