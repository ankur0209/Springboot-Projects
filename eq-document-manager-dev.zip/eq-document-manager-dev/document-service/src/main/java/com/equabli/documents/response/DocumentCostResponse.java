package com.equabli.documents.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;

@Getter
@Schema(description = "Fetch document cost configuration for edit configuration")
public class DocumentCostResponse {

	@Schema(description = "Short code of document type", example = "AP")
	private String docTypeCode;

	@Schema(description = "Type of document", example = "Application")
	private String documentType;
	
	@Schema(description = "Cost of document", example = "10")
	private Float cost;

	public DocumentCostResponse(String shortCode, Float docCost, String documentType) {
		this.documentType = documentType;
		this.docTypeCode = shortCode;
		this.cost = docCost;
	}
}
