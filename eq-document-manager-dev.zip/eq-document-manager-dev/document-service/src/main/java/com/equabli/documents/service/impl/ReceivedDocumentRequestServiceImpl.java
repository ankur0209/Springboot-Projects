package com.equabli.documents.service.impl;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.Document;
import com.equabli.common.entity.DownloadHistory;
import com.equabli.common.entity.QSendReceiveDocument;
import com.equabli.common.entity.SendReceiveDocument;
import com.equabli.common.enums.DocumentRequestStatusEnum;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.queryhelpers.LikeHelper;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.repository.DownloadHistoryRepository;
import com.equabli.common.repository.SentReceiveDocumentRepository;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PageRequestData;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.utils.DateUtils;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.documents.constants.ColumnConstants;
import com.equabli.documents.constants.DocumentMessageConstants;
import com.equabli.documents.request.DownloadDocumentRequest;
import com.equabli.documents.response.ReceiveDocumentResponse;
import com.equabli.documents.response.SentReceiveSummaryResponse;
import com.equabli.documents.searchparams.ReceiveRequestDocumentSearchParam;
import com.equabli.documents.service.ReceivedDocumentRequestService;
import com.equabli.documents.service.ShowHideColumnService;
import com.querydsl.core.BooleanBuilder;

@Service
public class ReceivedDocumentRequestServiceImpl implements ReceivedDocumentRequestService {

	private static final QSendReceiveDocument qSendReceiveDocument = QSendReceiveDocument.sendReceiveDocument;

	@Value("${document.over-due.in-days}")
	private Integer documentOverDue;
	
	@Autowired
	private SentReceiveDocumentRepository sentReceiveDocumentRepository;

	@Autowired
	private MessageSupplier messageSupplier;

	@Autowired
	private DocumentRepository documentRepository;

	@Autowired
	private DownloadHistoryRepository downloadHistoryRepository;
	
	@Autowired
	private FetchTokenData fetchTokenData;
	
	@Autowired
	private ShowHideColumnService showHideColumnService;

	private static final String REQUEST_AT = "requestedAt";
	
	@Override
	public PagedResponse<ReceiveDocumentResponse> getReceivedDocumentRequestList(
			ReceiveRequestDocumentSearchParam receiveRequestDocumentSearchParam) {

		TokenData tokenData = fetchTokenData.getTokenData();
		
		String sortParam = receiveRequestDocumentSearchParam == null
				|| receiveRequestDocumentSearchParam.getSortParam() == null ? REQUEST_AT
						: receiveRequestDocumentSearchParam.getSortParam();
		PageRequestData pageRequestData = receiveRequestDocumentSearchParam != null
				? Util.getPageRequestData(receiveRequestDocumentSearchParam.getPageSize(),
						receiveRequestDocumentSearchParam.getPageNumber(),
						receiveRequestDocumentSearchParam.getSortOrder(), sortParam)
				: Util.getPageRequestData(null, null, null, REQUEST_AT);

		int startRecord = (pageRequestData.getPageNumber() * pageRequestData.getPageSize()) + 1;
		Sort sort = Util.getSortingOrder(pageRequestData.getSortOrder(), getReceiveRequestSortParam(sortParam));
		Pageable pageable = PageRequest.of(pageRequestData.getPageNumber(), pageRequestData.getPageSize(), sort);

		Page<ReceiveDocumentResponse> sentDocumentResponsePage = sentReceiveDocumentRepository
				.findAll(getPredicate(tokenData.getPrincipleId(), receiveRequestDocumentSearchParam), pageable)
				.map(ReceiveDocumentResponse::new);

		List<String> columns = showHideColumnService.getColumns(ColumnConstants.TABLE_RECEIVE_REQUEST_DOCUMENT, tokenData);

		return sentDocumentResponsePage.isEmpty() ? PagedResponse.empty()
				: PagedResponse.of(sentDocumentResponsePage.getContent(), columns, startRecord, pageRequestData.getPageSize(),
						(int) sentDocumentResponsePage.getTotalElements());
	}

	@Override
	@Transactional
	public CommonResponse<String> deleteRequestedDocument(Long documentRequestId) {
		
		SendReceiveDocument sendReceiveDocument = sentReceiveDocumentRepository.findById(documentRequestId)
				.orElseThrow(() -> new InvalidArgumentException(
						messageSupplier.get(MessageConstants.NOT_VALID_ID, " " + documentRequestId)));

		sendReceiveDocument.deleteSendReceiveDocument(sendReceiveDocument, fetchTokenData.getTokenData());
		sendReceiveDocument = sentReceiveDocumentRepository.save(sendReceiveDocument);

		return CommonResponse.success(
				messageSupplier.get(DocumentMessageConstants.SentDocumentConstants.DOCUMENT_REQUEST_DELETE_SUCCESS,
						sendReceiveDocument.getId().toString()),
				sendReceiveDocument.getId().toString());
	}

	@Override
	@Transactional
	public CommonResponse<String> saveDownloadReceiveDocumentHistory(DownloadDocumentRequest documentRequest) {
		
		TokenData tokenData = fetchTokenData.getTokenData();
		for (Long docId : documentRequest.getDocumentId()) {

			Document document = documentRepository.findById(docId).orElseThrow(
					() -> new InvalidArgumentException(messageSupplier.get(MessageConstants.NOT_VALID, docId)));

			DownloadHistory downloadHistory = new DownloadHistory();
			downloadHistory.saveDocumentDownloadHistory(downloadHistory, document, tokenData);
			downloadHistoryRepository.save(downloadHistory);
		}
		return CommonResponse
				.success(messageSupplier.get(DocumentMessageConstants.DocumentDownloadConfig.DOWNLOAD_CREATE_SUCCESS));
	}

	private BooleanBuilder getPredicate(Long receiveRequestUserId, ReceiveRequestDocumentSearchParam receiveRequestDocumentSearchParam) {

		BooleanBuilder booleanBuilder = new BooleanBuilder();

		booleanBuilder.and(qSendReceiveDocument.isDelete.isFalse());
		booleanBuilder.and(qSendReceiveDocument.receiveRequestUserId.eq(receiveRequestUserId));

		if (Objects.nonNull(receiveRequestDocumentSearchParam)) {
			if (StringUtils.hasText(receiveRequestDocumentSearchParam.getTextSearch())) {
				BooleanBuilder booleanBuilderOr = new BooleanBuilder();
				booleanBuilderOr.or(qSendReceiveDocument.documentName
						.likeIgnoreCase(LikeHelper.anyPosition(receiveRequestDocumentSearchParam.getTextSearch())));
				booleanBuilderOr.or(qSendReceiveDocument.documentType
						.likeIgnoreCase(LikeHelper.anyPosition(receiveRequestDocumentSearchParam.getTextSearch())));
				booleanBuilderOr.or(qSendReceiveDocument.originalAccountNo
						.likeIgnoreCase(LikeHelper.anyPosition(receiveRequestDocumentSearchParam.getTextSearch())));
				booleanBuilderOr.or(qSendReceiveDocument.clientAccountNo
						.likeIgnoreCase(LikeHelper.anyPosition(receiveRequestDocumentSearchParam.getTextSearch())));
				booleanBuilderOr.or(qSendReceiveDocument.equabliAccNo.stringValue()
						.likeIgnoreCase(LikeHelper.anyPosition(receiveRequestDocumentSearchParam.getTextSearch())));
				booleanBuilderOr.or(qSendReceiveDocument.requestedBy
						.likeIgnoreCase(LikeHelper.anyPosition(receiveRequestDocumentSearchParam.getTextSearch())));
				booleanBuilderOr.or(qSendReceiveDocument.requestStatus
						.likeIgnoreCase(LikeHelper.anyPosition(receiveRequestDocumentSearchParam.getTextSearch())));
				booleanBuilder.and(booleanBuilderOr);
			}else {
				if (StringUtils.hasText(receiveRequestDocumentSearchParam.getDocumentType()))
					booleanBuilder
							.and(qSendReceiveDocument.docTypeCode.eq(receiveRequestDocumentSearchParam.getDocumentType()));

				if (StringUtils.hasText(receiveRequestDocumentSearchParam.getDocumentName())) {
					String value = LikeHelper.anyPosition(receiveRequestDocumentSearchParam.getDocumentName());
					booleanBuilder.and(qSendReceiveDocument.documentName.likeIgnoreCase(value));
				}

				if (StringUtils.hasText(receiveRequestDocumentSearchParam.getOriginalAccountNumber()))
					booleanBuilder.and(qSendReceiveDocument.originalAccountNo
							.eq(receiveRequestDocumentSearchParam.getOriginalAccountNumber()));
				
				if (receiveRequestDocumentSearchParam.getEquabliAccountNumber() != null)
					booleanBuilder.and(qSendReceiveDocument.equabliAccNo
							.eq(receiveRequestDocumentSearchParam.getEquabliAccountNumber()));
				
				if (StringUtils.hasText(receiveRequestDocumentSearchParam.getClientAccountNumber()))
					booleanBuilder.and(qSendReceiveDocument.clientAccountNo
							.eq(receiveRequestDocumentSearchParam.getClientAccountNumber()));

				if (receiveRequestDocumentSearchParam.getRequestedDateFrom() != null && 
						receiveRequestDocumentSearchParam.getRequestedDateTo() != null) {
					booleanBuilder.and(qSendReceiveDocument.requestedAt
							.goe(DateUtils.atStartOfDay(receiveRequestDocumentSearchParam.getRequestedDateFrom())));
					booleanBuilder.and(qSendReceiveDocument.requestedAt
							.loe(DateUtils.atEndOfDay(receiveRequestDocumentSearchParam.getRequestedDateTo())));
				}
				
				if (receiveRequestDocumentSearchParam.getDueDateFrom() != null && 
						receiveRequestDocumentSearchParam.getDueDateTo() != null) {
					booleanBuilder.and(qSendReceiveDocument.dueOnAt
							.goe(DateUtils.atStartOfDay(receiveRequestDocumentSearchParam.getDueDateFrom())));
					booleanBuilder.and(qSendReceiveDocument.dueOnAt
							.loe(DateUtils.atEndOfDay(receiveRequestDocumentSearchParam.getDueDateTo())));
				}
				
				if (receiveRequestDocumentSearchParam.getFullfillmentDateFrom() != null && 
						receiveRequestDocumentSearchParam.getFullfillmentDateTo() != null) {
					booleanBuilder.and(qSendReceiveDocument.fullfilledOn
							.goe(DateUtils.atStartOfDay(receiveRequestDocumentSearchParam.getFullfillmentDateFrom())));
					booleanBuilder.and(qSendReceiveDocument.fullfilledOn
							.loe(DateUtils.atEndOfDay(receiveRequestDocumentSearchParam.getFullfillmentDateTo())));
				}
				
				if (StringUtils.hasText(receiveRequestDocumentSearchParam.getRequestedBy()))
					booleanBuilder.and(qSendReceiveDocument.requestedBy
							.equalsIgnoreCase(receiveRequestDocumentSearchParam.getRequestedBy()));
				
				if (StringUtils.hasText(receiveRequestDocumentSearchParam.getRequestStatus()))
					booleanBuilder.and(qSendReceiveDocument.requestStatus
							.equalsIgnoreCase(receiveRequestDocumentSearchParam.getRequestStatus()));
			}
		}
		return booleanBuilder;
	}
	
	@Override
	public CommonResponse<SentReceiveSummaryResponse> getReceiveRequestSummary() {

		TokenData tokenData = fetchTokenData.getTokenData();
		LocalDateTime localDateTime = LocalDateTime.now().minusDays(documentOverDue).with(LocalTime.MIN);

		Integer overDue = sentReceiveDocumentRepository
				.countByReceiveRequestOrgCodeAndRequestStatusAndRequestedAtLessThanAndIsDeleteFalse(
						tokenData.getUserOrgCode(), DocumentRequestStatusEnum.OPEN.getRequestStatus(), localDateTime);

		Integer open = sentReceiveDocumentRepository.countByReceiveRequestOrgCodeAndRequestStatusAndIsDeleteFalse(
				tokenData.getUserOrgCode(), DocumentRequestStatusEnum.OPEN.getRequestStatus());
		open = open - overDue;

		Integer fullFilled = sentReceiveDocumentRepository.countByReceiveRequestOrgCodeAndRequestStatusAndIsDeleteFalse(
				tokenData.getUserOrgCode(), DocumentRequestStatusEnum.FULFILLED.getRequestStatus());

		Integer total = open + fullFilled + overDue;
		SentReceiveSummaryResponse sentReceiveSummary = SentReceiveSummaryResponse.builder().open(open).overDue(overDue)
				.fullfilled(fullFilled).total(total).build();

		return CommonResponse.success(
				messageSupplier.get(DocumentMessageConstants.RequireDocConfig.DOCUMENT_RECEIVE_SUMMARY_FETCH_SUCCESS),
				sentReceiveSummary);
	}
	
	private String getReceiveRequestSortParam(String sortParams) {
		String sortParamsVal = null;
		switch (sortParams) {
		case ColumnConstants.COLUMN_REQUESTED_DOCUMENT -> sortParamsVal = "documentType";
		case ColumnConstants.COLUMN_ORIGINAL_ACCOUNT_NUMBER -> sortParamsVal = "originalAccountNo";
		case ColumnConstants.COLUMN_EQUABLI_ACCOUNT_NUMBER -> sortParamsVal = "equabliAccNo";
		case ColumnConstants.COLUMN_CLIENT_ACCOUNT_NUMBER -> sortParamsVal = "clientAccountNo";
		case ColumnConstants.COLUMN_REQUESTED_DATE -> sortParamsVal = REQUEST_AT;
		case ColumnConstants.COLUMN_DUE_DATE -> sortParamsVal = "dueOnAt";
		case ColumnConstants.COLUMN_FULFILLMENT_DATE -> sortParamsVal = "fullfilledOn";
		case ColumnConstants.COLUMN_DOCUMENT_NAME -> sortParamsVal = "documentName";
		case ColumnConstants.COLUMN_REQUESTED_BY -> sortParamsVal = "requestedBy";
		default -> sortParamsVal = REQUEST_AT;
		}
		return sortParamsVal;
	}
}