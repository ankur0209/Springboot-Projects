package com.equabli.documents.constants;

public final class InvoiceDataConstants {

	public static final String ORG_NAME = "organization"; 
	public static final String ORG_CODE = "organizationCode"; 
	public static final String ORG_TYPE = "organizationType"; 
	public static final String INVOICE_START_DATE = "startDate"; 
	public static final String INVOICE_END_DATE = "endDate"; 
	public static final String CLIENT_INVOICE_DATA = "invoiceData"; 
	public static final String TOTAL_AMOUNT_PAY = "totalAmountPay"; 
	
	public static final String PARTNER_INVOICE_DATA = "invoice";
	public static final String PT_INVOICE_START_DATE = "ptStartDate"; 
	public static final String PT_INVOICE_END_DATE = "ptEndDate"; 
	public static final String PARTNER_NAME = "partnerName"; 
	public static final String PARTNER_ID = "partnerId";
	public static final String PARTNER_TOTAL_COST = "totalCost";
}
