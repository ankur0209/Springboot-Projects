package com.equabli.documents.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.equabli.common.enums.FileNameConfigEnum;
import com.equabli.common.response.CommonResponse;
import com.equabli.documents.request.UserDocConfigRequest;
import com.equabli.documents.response.DefaultDocMgrConfigResponse;
import com.equabli.documents.response.UserDocConfigResponse;
import com.equabli.documents.service.GlobalConfigService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user/file")
@Tag(name = "User File Name Configuration API", description = "User file Configuration API for document manager")
@Slf4j
public class GlobalConfigController {

	@Autowired
	private GlobalConfigService globalConfigService;

	@Operation(summary = "Save user file name Configuration", description = "To create user file name config for document manager")
	@PostMapping("/configuration")
	public CommonResponse<String> userFileConfig(@Valid @RequestBody List<UserDocConfigRequest> userDocConfigRequest)
			throws Exception {
		log.info("Creating User file Config for user document configuration  {} ", userDocConfigRequest);
		return globalConfigService.saveUserFileConfig(userDocConfigRequest);
	}

	@Operation(summary = "Fetch User file name configuration", description = "Fetch user file name config for document manager")
	@GetMapping("/configuration")
	public CommonResponse<List<UserDocConfigResponse>> getUserFileConfig(
			@RequestParam(name = "fieldName", required = true) FileNameConfigEnum fileNameConfig) {
		log.info("Getting User file Config for user fileNameConfig {} ", fileNameConfig);
		return globalConfigService.getUserFileConfig(fileNameConfig);
	}

	@Operation(summary = "Fetch default values of file name configuration", description = "Fetch the defualt values of file name configuration lie field, retention policy, "
			+ " seperator and document policy.")
	@GetMapping
	public CommonResponse<DefaultDocMgrConfigResponse> getFileConcatVal(
			@RequestParam(name = "fieldName", required = true) FileNameConfigEnum fileNameConfig) {
		log.info("Fetching FileConcatVal for fileNameConfig ", fileNameConfig);
		return globalConfigService.getDefaultDocMgrConfiguration(fileNameConfig);

	}
}
