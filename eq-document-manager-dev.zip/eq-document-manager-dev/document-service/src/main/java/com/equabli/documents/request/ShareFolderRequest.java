package com.equabli.documents.request;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.equabli.common.request.ShareUserDetailRequest;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Schema(description = "Share Document Request")
public class ShareFolderRequest {

	@Schema(description = "Document id", example = "1")
	@NotNull(message = "Client Account No must not be null")
	private String clientAccountNo;
	
	@Schema(description = "Share folder details with whom documnt share", example = "[\"email\":\"abc@gmail.com\",\"isRegisterUser\":\"true\"]")
	@NotNull(message = "Share folder details must not be null")
	private List<ShareUserDetailRequest> shareDetail;
}
