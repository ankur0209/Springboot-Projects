package com.equabli.documents.service;

import java.util.List;
import java.util.UUID;

import com.equabli.common.auth.TokenData;
import com.equabli.common.entity.Lookup;
import com.equabli.common.entity.Usage;
import com.equabli.common.response.CommonResponse;
import com.equabli.documents.response.SubscriptionResponse;

public interface SubscriptionService {

	CommonResponse<List<SubscriptionResponse>> getAllSubscription();

	CommonResponse<String> saveSubscription(String subscriptionCode);

	CommonResponse<SubscriptionResponse> getSubscription();

	Usage getUsage(TokenData tokenData);

	List<SubscriptionResponse> getLookupByLookupGroupKeyValue(String keyvalue);

	Lookup getLookupBySubscriptionCode(String subscriptionCode);

	Lookup getLookup(UUID lookupUid);
}