package com.equabli.documents.service.impl;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.DocType;
import com.equabli.common.entity.QSendReceiveDocument;
import com.equabli.common.entity.SendReceiveDocument;
import com.equabli.common.enums.DocumentRequestStatusEnum;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.queryhelpers.LikeHelper;
import com.equabli.common.repository.DocTypeRepository;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.repository.SentReceiveDocumentRepository;
import com.equabli.common.request.RequestNewDocumentRequest;
import com.equabli.common.request.UserEmailRequest;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PageRequestData;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.response.UserDetailResponse;
import com.equabli.common.response.UserMailResponse;
import com.equabli.common.utils.DateUtils;
import com.equabli.common.utils.DurationDateUtils;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.documents.constants.ColumnConstants;
import com.equabli.documents.constants.DocumentMessageConstants;
import com.equabli.documents.feignclient.UserService;
import com.equabli.documents.response.DocumentSummaryResponse;
import com.equabli.documents.response.SentDocumentResponse;
import com.equabli.documents.response.SentReceiveSummaryResponse;
import com.equabli.documents.searchparams.SentReceiveSummarySearchParam;
import com.equabli.documents.searchparams.SentRequestDocumentSearchParam;
import com.equabli.documents.service.SentReceiveDocumentService;
import com.equabli.documents.service.ShowHideColumnService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.querydsl.core.BooleanBuilder;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SentReceiveDocumentServiceImpl implements SentReceiveDocumentService {

	private static final QSendReceiveDocument qSendReceiveDocument = QSendReceiveDocument.sendReceiveDocument;
	private static final String DOCUMENT_REQUEST_TITLE = "send request for document upload";
	
	@Value("${document.over-due.in-days}")
	private Integer documentOverDue;
	
	@Autowired
	private MessageSupplier messageSupplier;

	@Autowired
	private SentReceiveDocumentRepository sentReceiveDocumentRepository;

	@Autowired
	private DocumentRepository documentRepository;

	@Autowired
	private DocTypeRepository docTypeRepository;

	@Autowired
	private FetchTokenData fetchTokenData;

	@Autowired
	private ShowHideColumnService showHideColumnService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private AsyncServiceImpl asyncService;
	
	@Autowired
	private HttpServletRequest request;
	
	private static final String REQUEST_AT = "requestedAt";

	@Override
	@Transactional
	public CommonResponse<String> saveRequestNewDocument(RequestNewDocumentRequest requestNewDocumentRequest) {

		TokenData tokenData = fetchTokenData.getTokenData();

		DocType docType = getDocType(requestNewDocumentRequest.getDocTypeCode());
		requestNewDocumentRequest.setDocumentType(docType.getName());

		List<Long> sendReceiveDocumentIds = new ArrayList<>();
//		If document already uploaded do nothing
		Long documentCount = documentRepository.findDocumentByAccountNumber(tokenData.getOrgType(),
				requestNewDocumentRequest.getOriginalAccountNumber(),
				requestNewDocumentRequest.getClientAccountNumber(), requestNewDocumentRequest.getEquabliAccountNumber(),
				requestNewDocumentRequest.getDocTypeCode());

		if (documentCount > 0) {
			log.info("documentCount already uploaded for {}", requestNewDocumentRequest);
		} else {
			List<UserDetailResponse> userDetailResponses = this.getUserDetail(
					requestNewDocumentRequest.getSendRequests(), requestNewDocumentRequest.getClientAccountNumber(),
					docType, tokenData);
			for (UserDetailResponse userDetailResponse : userDetailResponses) {

				log.info("Sent Document Request userEmail -> {}", userDetailResponse);

//				If document request already generate than update data else create new		
				SendReceiveDocument sendReceiveDocument = sentReceiveDocumentRepository
						.getBySendReceiveDocument(requestNewDocumentRequest.getOriginalAccountNumber(),
								requestNewDocumentRequest.getClientAccountNumber(), docType.getShortCode(),
								userDetailResponse.getUserDetails().getPrincipleId())
						.orElse(new SendReceiveDocument());

				sendReceiveDocument.saveSendReceiveDocument(sendReceiveDocument, requestNewDocumentRequest,
						DocumentRequestStatusEnum.OPEN, tokenData, tokenData, userDetailResponse.getUserDetails(),documentOverDue);
				sendReceiveDocument = sentReceiveDocumentRepository.save(sendReceiveDocument);
				sendReceiveDocumentIds.add(sendReceiveDocument.getId());
				sendNotification(tokenData, sendReceiveDocument, request.getHeader(Constants.AUTHORIZATION),
						DOCUMENT_REQUEST_TITLE);
			}
		}

		return CommonResponse
				.success(messageSupplier.get(DocumentMessageConstants.SentDocumentConstants.SENT_CREATE_SUCCESS,
						sendReceiveDocumentIds.toString()), sendReceiveDocumentIds.toString());
	}

	public List<UserDetailResponse> getUserDetail(List<String> emails, String clientAccountNumber, DocType docType,
			TokenData tokenData) {
		String authorization = request.getHeader(Constants.AUTHORIZATION);
		String response = userService.emailExists(authorization, UserEmailRequest.builder().datas(emails).build());
		log.info("response -> {}", response);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		try {
			UserMailResponse userMailResponse = mapper.readValue(response, UserMailResponse.class);
			List<UserDetailResponse> userDeatil = userMailResponse.getResponse().stream()
					.filter(UserDetailResponse::getIsExists).toList();
			asyncService.sentEmailToUsers(authorization, userMailResponse, docType, clientAccountNumber, tokenData);
			return userDeatil;

		} catch (JsonProcessingException e) {
			log.error("ERROR WHILE CONVERT VALUES - > {}", e.getMessage(), e);
		}

		return Collections.emptyList();
	}

	

	@Override
	public PagedResponse<SentDocumentResponse> getSentDocumentRequest(
			SentRequestDocumentSearchParam sentRequestDocumentSearchParam) {

		TokenData tokenData = fetchTokenData.getTokenData();

		String sortParam = sentRequestDocumentSearchParam == null
				|| sentRequestDocumentSearchParam.getSortParam() == null ? REQUEST_AT
						: sentRequestDocumentSearchParam.getSortParam();

		PageRequestData pageRequestData = sentRequestDocumentSearchParam != null
				? Util.getPageRequestData(sentRequestDocumentSearchParam.getPageSize(),
						sentRequestDocumentSearchParam.getPageNumber(), sentRequestDocumentSearchParam.getSortOrder(),
						sortParam)
				: Util.getPageRequestData(null, null, null, REQUEST_AT);

		int startRecord = (pageRequestData.getPageNumber() * pageRequestData.getPageSize()) + 1;
		Sort sort = Util.getSortingOrder(pageRequestData.getSortOrder(), getSentRequestSortParam(sortParam));
		Pageable pageable = PageRequest.of(pageRequestData.getPageNumber(), pageRequestData.getPageSize(), sort);

		Page<SentDocumentResponse> sentDocumentResponsePage = null;
		if (sentRequestDocumentSearchParam != null
				&& StringUtils.hasText(sentRequestDocumentSearchParam.getTextSearch())) {
			sentDocumentResponsePage = sentReceiveDocumentRepository
					.getSendReceiveDocumentList(tokenData.getPrincipleId(),
							sentRequestDocumentSearchParam.getTextSearch(), pageable)
					.map(SentDocumentResponse::new);
		} else {
			sentDocumentResponsePage = sentReceiveDocumentRepository
					.findAll(getPredicate(tokenData.getPrincipleId(), sentRequestDocumentSearchParam), pageable)
					.map(SentDocumentResponse::new);
		}

		List<String> columns = showHideColumnService.getColumns(ColumnConstants.TABLE_SENT_REQUEST_DOCUMENT, tokenData);

		return sentDocumentResponsePage.isEmpty() ? PagedResponse.empty()
				: PagedResponse.of(sentDocumentResponsePage.getContent(), columns, startRecord,
						pageRequestData.getPageSize(), (int) sentDocumentResponsePage.getTotalElements());
	}

	private BooleanBuilder getPredicate(@NotNull Long sentRequestUserId,
			SentRequestDocumentSearchParam sentRequestDocumentSearchParam) {

		BooleanBuilder booleanBuilder = new BooleanBuilder();

		booleanBuilder.and(qSendReceiveDocument.isDelete.isFalse());
		booleanBuilder.and(qSendReceiveDocument.sentRequestUserId.eq(sentRequestUserId));

		if (Objects.nonNull(sentRequestDocumentSearchParam)) {
			if (StringUtils.hasText(sentRequestDocumentSearchParam.getDocumentType()))
				booleanBuilder
						.and(qSendReceiveDocument.docTypeCode.eq(sentRequestDocumentSearchParam.getDocumentType()));

			if (StringUtils.hasText(sentRequestDocumentSearchParam.getDocumentName())) {
				String value = LikeHelper.anyPosition(sentRequestDocumentSearchParam.getDocumentName());
				booleanBuilder.and(qSendReceiveDocument.documentName.likeIgnoreCase(value));
			}

			if (StringUtils.hasText(sentRequestDocumentSearchParam.getOriginalAccountNumber()))
				booleanBuilder.and(qSendReceiveDocument.originalAccountNo
						.eq(sentRequestDocumentSearchParam.getOriginalAccountNumber()));

			if (sentRequestDocumentSearchParam.getEquabliAccountNumber() != null)
				booleanBuilder.and(
						qSendReceiveDocument.equabliAccNo.eq(sentRequestDocumentSearchParam.getEquabliAccountNumber()));

			if (StringUtils.hasText(sentRequestDocumentSearchParam.getClientAccountNumber()))
				booleanBuilder.and(qSendReceiveDocument.clientAccountNo
						.eq(sentRequestDocumentSearchParam.getClientAccountNumber()));

			if (sentRequestDocumentSearchParam.getRequestedDateFrom() != null
					&& sentRequestDocumentSearchParam.getRequestedDateTo() != null) {
				booleanBuilder.and(qSendReceiveDocument.requestedAt
						.goe(DateUtils.atStartOfDay(sentRequestDocumentSearchParam.getRequestedDateFrom())));
				booleanBuilder.and(qSendReceiveDocument.requestedAt
						.loe(DateUtils.atEndOfDay(sentRequestDocumentSearchParam.getRequestedDateTo())));
			}

			if (sentRequestDocumentSearchParam.getDueDateFrom() != null
					&& sentRequestDocumentSearchParam.getDueDateTo() != null) {
				booleanBuilder.and(qSendReceiveDocument.dueOnAt
						.goe(DateUtils.atStartOfDay(sentRequestDocumentSearchParam.getDueDateFrom())));
				booleanBuilder.and(qSendReceiveDocument.dueOnAt
						.loe(DateUtils.atEndOfDay(sentRequestDocumentSearchParam.getDueDateTo())));
			}

			if (sentRequestDocumentSearchParam.getFullfillmentDateFrom() != null
					&& sentRequestDocumentSearchParam.getFullfillmentDateTo() != null) {
				booleanBuilder.and(qSendReceiveDocument.fullfilledOn
						.goe(DateUtils.atStartOfDay(sentRequestDocumentSearchParam.getFullfillmentDateFrom())));
				booleanBuilder.and(qSendReceiveDocument.fullfilledOn
					.loe(DateUtils.atEndOfDay(sentRequestDocumentSearchParam.getFullfillmentDateTo())));
			}

			if (StringUtils.hasText(sentRequestDocumentSearchParam.getRequestedFrom()))
				booleanBuilder.and(qSendReceiveDocument.requestedTo
						.equalsIgnoreCase(sentRequestDocumentSearchParam.getRequestedFrom()));

			if (StringUtils.hasText(sentRequestDocumentSearchParam.getRequestStatus()))
				booleanBuilder.and(qSendReceiveDocument.requestStatus
						.equalsIgnoreCase(sentRequestDocumentSearchParam.getRequestStatus()));
		}
		return booleanBuilder;
	}

	@Override
	@Transactional
	public CommonResponse<String> deleteDocumentRequest(Long documentRequestId) {

		TokenData tokenData = fetchTokenData.getTokenData();

		SendReceiveDocument sendReceiveDocument = sentReceiveDocumentRepository.findById(documentRequestId)
				.orElseThrow(() -> new InvalidArgumentException(
						messageSupplier.get(MessageConstants.NOT_VALID_ID, " " + documentRequestId)));

		sendReceiveDocument.deleteSendReceiveDocument(sendReceiveDocument, tokenData);
		sendReceiveDocument = sentReceiveDocumentRepository.save(sendReceiveDocument);

		return CommonResponse.success(
				messageSupplier.get(DocumentMessageConstants.SentDocumentConstants.DOCUMENT_REQUEST_DELETE_SUCCESS,
						sendReceiveDocument.getId().toString()),
				sendReceiveDocument.getId().toString());
	}

	private DocType getDocType(String docTypeCode) {
		return docTypeRepository.findByShortCode(docTypeCode).orElseThrow(() -> new InvalidArgumentException(
				messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, " " + docTypeCode, null)));
	}

	@Override
	public CommonResponse<List<DocumentSummaryResponse>> getSentRequestSummary(
			SentReceiveSummarySearchParam sentReceiveSummarySearchParam) {
		List<DocumentSummaryResponse> documentSummaryList = new ArrayList<>();
		
		TokenData tokenData = fetchTokenData.getTokenData();
		if (sentReceiveSummarySearchParam == null)
			sentReceiveSummarySearchParam = new SentReceiveSummarySearchParam();

		if (!StringUtils.hasText(sentReceiveSummarySearchParam.getProduct()))
			sentReceiveSummarySearchParam.setProduct(null);

		DurationDateUtils duration = new DurationDateUtils(sentReceiveSummarySearchParam.getDuration(),
				LocalDateTime.now());

		LocalDateTime localDateTime = LocalDateTime.now().minusDays(documentOverDue).with(LocalTime.MIN);
		SentReceiveSummaryResponse sentDocumentSummary = getSentDocumentSummary(tokenData,
				sentReceiveSummarySearchParam, duration, localDateTime);
		SentReceiveSummaryResponse receiveDocumentSummary = getReceiveDocumentSummary(tokenData,
				sentReceiveSummarySearchParam, duration, localDateTime);
		
		documentSummaryList.add(DocumentSummaryResponse.builder().name("sentDocumentSummary")
				.summary(sentDocumentSummary).build());
		documentSummaryList.add(DocumentSummaryResponse.builder().name("receiveDocumentSummary")
				.summary(receiveDocumentSummary).build());

		return CommonResponse.success(
				messageSupplier.get(DocumentMessageConstants.RequireDocConfig.DOCUMENT_SENT_SUMMARY_FETCH_SUCCESS),
				documentSummaryList);
	}

	private SentReceiveSummaryResponse getSentDocumentSummary(TokenData tokenData, SentReceiveSummarySearchParam sentReceiveSummarySearchParam, DurationDateUtils duration, LocalDateTime localDateTime) {
		Integer overDue = sentReceiveDocumentRepository.countBySentRequestOrgCodeAndIsDeleteFalse(
				tokenData.getUserOrgCode(), DocumentRequestStatusEnum.OPEN.getRequestStatus(), duration.getFirstDay(),
				duration.getLastDay(), sentReceiveSummarySearchParam.getUserId(),
				sentReceiveSummarySearchParam.getPortfolio(),localDateTime, sentReceiveSummarySearchParam.getProduct());
		
		Integer open = sentReceiveDocumentRepository.countBySentRequestOrgCodeAndIsDeleteFalse(
				tokenData.getUserOrgCode(), DocumentRequestStatusEnum.OPEN.getRequestStatus(), duration.getFirstDay(),
				duration.getLastDay(), sentReceiveSummarySearchParam.getUserId(),
				sentReceiveSummarySearchParam.getPortfolio(),sentReceiveSummarySearchParam.getProduct());
		open = open - overDue;
		Integer fullFilled = sentReceiveDocumentRepository.countBySentRequestOrgCodeAndIsDeleteFalse(
				tokenData.getUserOrgCode(), DocumentRequestStatusEnum.FULFILLED.getRequestStatus(), duration.getFirstDay(),
				duration.getLastDay(), sentReceiveSummarySearchParam.getUserId(),
				sentReceiveSummarySearchParam.getPortfolio(),sentReceiveSummarySearchParam.getProduct());
		Integer total = open + fullFilled + overDue;
		return SentReceiveSummaryResponse.builder().open(open).overDue(overDue)
				.fullfilled(fullFilled).total(total).build();
	}
	
	private SentReceiveSummaryResponse getReceiveDocumentSummary(TokenData tokenData,
			SentReceiveSummarySearchParam sentReceiveSummarySearchParam, DurationDateUtils duration,
			LocalDateTime localDateTime) {
		Integer overDue = sentReceiveDocumentRepository.countByReceiveRequestOrgCodeAndIsDeleteFalse(
				tokenData.getUserOrgCode(), DocumentRequestStatusEnum.OPEN.getRequestStatus(), duration.getFirstDay(),
				duration.getLastDay(), sentReceiveSummarySearchParam.getUserId(),
				sentReceiveSummarySearchParam.getPortfolio(),localDateTime, sentReceiveSummarySearchParam.getProduct());
		
		Integer open = sentReceiveDocumentRepository.countByReceiveRequestOrgCodeAndIsDeleteFalse(
				tokenData.getUserOrgCode(), DocumentRequestStatusEnum.OPEN.getRequestStatus(), duration.getFirstDay(),
				duration.getLastDay(), sentReceiveSummarySearchParam.getUserId(),
				sentReceiveSummarySearchParam.getPortfolio(),sentReceiveSummarySearchParam.getProduct());
		open = open - overDue;
		Integer fullFilled = sentReceiveDocumentRepository.countByReceiveRequestOrgCodeAndIsDeleteFalse(
				tokenData.getUserOrgCode(), DocumentRequestStatusEnum.FULFILLED.getRequestStatus(), duration.getFirstDay(),
				duration.getLastDay(), sentReceiveSummarySearchParam.getUserId(),
				sentReceiveSummarySearchParam.getPortfolio(),sentReceiveSummarySearchParam.getProduct());
		Integer total = open + fullFilled + overDue;
		return SentReceiveSummaryResponse.builder().open(open).overDue(overDue)
				.fullfilled(fullFilled).total(total).build();
	}

	private String getSentRequestSortParam(String sortParams) {
		String sortParamsVal = null;
		switch (sortParams) {
		case ColumnConstants.COLUMN_REQUESTED_DOCUMENT -> sortParamsVal = "documentType";
		case ColumnConstants.COLUMN_ORIGINAL_ACCOUNT_NUMBER -> sortParamsVal = "originalAccountNo";
		case ColumnConstants.COLUMN_EQUABLI_ACCOUNT_NUMBER -> sortParamsVal = "equabliAccNo";
		case ColumnConstants.COLUMN_CLIENT_ACCOUNT_NUMBER -> sortParamsVal = "clientAccountNo";
		case ColumnConstants.COLUMN_REQUESTED_DATE -> sortParamsVal = REQUEST_AT;
		case ColumnConstants.COLUMN_DUE_DATE -> sortParamsVal = "dueOnAt";
		case ColumnConstants.COLUMN_FULFILLMENT_DATE -> sortParamsVal = "fullfilledOn";
		case ColumnConstants.COLUMN_FILE_NAME -> sortParamsVal = "documentName";
		case ColumnConstants.COLUMN_REQUESTED_FROM -> sortParamsVal = "requestedTo";
		default -> sortParamsVal = REQUEST_AT;
		}
		return sortParamsVal;
	}

	private void sendNotification(TokenData tokenData, SendReceiveDocument sendReceiveDocument,
			String authorization, String title) {
		asyncService.sentNotificationToUsers(tokenData, sendReceiveDocument,authorization,title);
	}
}