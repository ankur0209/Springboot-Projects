package com.equabli.documents.response;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class DocumentSummaryResponse {

	private String name;
	private SentReceiveSummaryResponse summary;
}
