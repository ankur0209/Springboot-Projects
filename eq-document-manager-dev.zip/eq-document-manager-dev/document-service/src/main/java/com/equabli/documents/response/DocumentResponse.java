package com.equabli.documents.response;

import java.time.LocalDateTime;
import java.util.List;

import com.equabli.common.entity.Document;
import com.equabli.common.response.ShareByWithResponse;
import com.equabli.common.utils.DateUtils;
import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Schema(description = "Document response for fetch list of document for specific folder/Account Number")
@Getter
@Setter
@NoArgsConstructor
public class DocumentResponse {

	@Schema(description = "Id of document", example = "1")
	private Long id;

	@Schema(description = "Name of document", example = "Application")
	private String documentName;

	@Schema(description = "Type of document", example = "Application")
	private String documentType;

	@Schema(description = "Original account number ", example = "456789")
	private String originalAccountNo;

	@Schema(description = "Equabli account number ", example = "789123")
	private Long equabliAccountNo;

	@Schema(description = "Client account number ", example = "123456")
	private String clientAccountNo;

	@JsonFormat(pattern = "MM/dd/yyyy")
	@Schema(description = "Document generation date formate MM/dd/yyy", example = "11/25/2022")
	private LocalDateTime generateDate;

	private String uploadDate;
	
	@Schema(description = "Share Date MM/dd/yyyy", example = "11/25/2023")
	@JsonFormat(pattern = "MM/dd/yyyy")
	private LocalDateTime shareDate;
	private Long fileSize;
	private List<ShareByWithResponse> sharedBy;
	private List<ShareByWithResponse> sharedWith;

	@Schema(description = "Name of uploaded file ", example = "Test.pdf")
	private String fileName;

	@Schema(description = "Path of file where it is uploaded")
	private String objectKey;
	private String orgTypeCode;
	private String filePath;

	@Schema(description = "Product code", example = "CC")
	private String productCode;
	
	@Schema(description = "PreSignUrl for download and view Uploded document", example = "CC")
	private String preSignUrl;
	
	@Schema(description = "Receive Date MM/dd/yyyy", example = "11/25/2023")
	@JsonFormat(pattern = "MM/dd/yyyy")
	private LocalDateTime receiveDate;

	public DocumentResponse(Document document) {
		this.id = document.getId();
		this.documentName = document.getGeneratedFileName();
		this.originalAccountNo = document.getOriginalAccountNo();
		this.documentType = document.getDocumentName();
		this.equabliAccountNo = document.getEquabliAccountNo();
		this.clientAccountNo = document.getClientAccountNo();
		this.generateDate = document.getDocumentGenerationDate();
		this.orgTypeCode = document.getOrgCode();
		this.fileName = document.getGeneratedFileName();
		this.objectKey = document.getObjKey();
		this.fileSize = document.getFileSize();
		this.filePath = document.getGeneratedFilePath();
		this.productCode = document.getProductCode();
		this.uploadDate = document.getCreatedAt() == null ? null
				: DateUtils.convertLocalDateTimeToString(document.getCreatedAt());
	}
}
