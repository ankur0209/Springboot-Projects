package com.equabli.documents.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.documents.request.DocTypeIdentificationRequest;
import com.equabli.documents.response.DocTypeIdentificationResponse;
import com.equabli.documents.searchparams.DocTypeIdentificationSearchParam;
import com.equabli.documents.service.DocTypeIdentificationService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user/document/identification")
@Tag(name = "Document Type Identification API", description = "Document Type Identification API")
@Slf4j
public class DocTypeIdentificationController {

	@Autowired
	private DocTypeIdentificationService docTypeIdentificationService;

	@Operation(summary = "Add/Update Document Type Identification", description = "Add/Update Document Type Identification")
	@PostMapping
	public CommonResponse<String> saveDocumentTypeIdentification(@Valid @RequestBody DocTypeIdentificationRequest docTypeIdentificationRequest) {
		log.info("Save document type Identification docTypeIdentificationRequest {}", docTypeIdentificationRequest);
		return docTypeIdentificationService.saveDocTypeIdentification(docTypeIdentificationRequest);
	}

	@Operation(summary = "Delete Document Type Identification ", description = "Delete Document Type Identification")
	@PatchMapping("/{docTypeCode}")
	public CommonResponse<String> deleteDocumentTypeIdentification(@PathVariable(name = "docTypeCode") String docTypeCode) {
		log.info("Delete Document type Identification DocumentTypeCode {} ", docTypeCode);
		return docTypeIdentificationService.deleteDocumentTypeIdentification(docTypeCode);
	}

	@Operation(summary = "Fetch all Document Type Identification", description = "Fetch all Document Type Identification")
	@PostMapping("/all")
	public PagedResponse<DocTypeIdentificationResponse> getDocumentTypeIdentification(
			@RequestBody(required = false) DocTypeIdentificationSearchParam docTypeIdentificationSearchParam) {
		log.info("Fetch all Document Type Identification {}", docTypeIdentificationSearchParam);
		return docTypeIdentificationService.getDocumentTypeIdentification(docTypeIdentificationSearchParam);
	}

}
