package com.equabli.documents.request;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RequiredDocConfigRequest {

	@Schema(description = "Short code of product", example = "CC")
	@NotBlank(message = "productCode should not be blank")
	private String productCode;
	
	@NotNull(message = "docTypeCode should not be blank")
	@Schema(description = "List of Document type code",example = "[\"AP\"]")
	private List<String> docTypeCode;
}
