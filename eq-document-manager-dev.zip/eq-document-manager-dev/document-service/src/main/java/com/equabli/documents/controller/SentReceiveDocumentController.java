package com.equabli.documents.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.equabli.common.request.RequestNewDocumentRequest;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.documents.response.DocumentSummaryResponse;
import com.equabli.documents.response.SentDocumentResponse;
import com.equabli.documents.searchparams.SentReceiveSummarySearchParam;
import com.equabli.documents.searchparams.SentRequestDocumentSearchParam;
import com.equabli.documents.service.SentReceiveDocumentService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user/document/request")
@Tag(name = "Request Document Configuration API", description = "Request Document Configuration API for document manager")
@Slf4j
public class SentReceiveDocumentController {

	@Autowired
	private SentReceiveDocumentService sendReceiveDocumentService;

	@Operation(summary = "Save request new document", description = "Save request new document ")
	@PostMapping
	public CommonResponse<String> saveNewDocumentRequest(
			@Valid @RequestBody RequestNewDocumentRequest requestNewDocumentRequest) throws Exception {
		log.info("Creating request new document {} ", requestNewDocumentRequest);
		return sendReceiveDocumentService.saveRequestNewDocument(requestNewDocumentRequest);
	}

	@Operation(summary = "Fetch sent requested document and Search", description = "Fetch sent requested document and Search")
	@PostMapping("/all")
	public PagedResponse<SentDocumentResponse> getRequestedDocument(
			@RequestBody(required = false) SentRequestDocumentSearchParam sentRequestDocumentSearchParam) {
		log.info("Fetching list of sent document request sentRequestDocumentSearchParam {}",
				sentRequestDocumentSearchParam);
		return sendReceiveDocumentService.getSentDocumentRequest(sentRequestDocumentSearchParam);
	}

	@Operation(summary = "Delete document request", description = "Delete document request")
	@PatchMapping("/{id}")
	public CommonResponse<String> deleteDocumentsForProducts(@PathVariable(name = "id") Long documentRequestId) {
		log.info("delete document request {} ", documentRequestId);
		return sendReceiveDocumentService.deleteDocumentRequest(documentRequestId);
	}
	
	@Operation(summary = "Fetch sent request summary ", description = "Fetch sent request summary")
	@PostMapping("/summary")
	public CommonResponse<List<DocumentSummaryResponse>> getSentRequestSummary(
			@RequestBody(required = false) SentReceiveSummarySearchParam sentReceiveSummarySearchParam) {
		log.info("sent request document summary {} ", sentReceiveSummarySearchParam);
		return sendReceiveDocumentService.getSentRequestSummary(sentReceiveSummarySearchParam);
	}

}
