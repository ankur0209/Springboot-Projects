package com.equabli.documents.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.documents.request.DocumentCostRequest;
import com.equabli.documents.response.DocumentCostConfigResponse;
import com.equabli.documents.response.DocumentCostResponse;
import com.equabli.documents.service.DocumentConfigurationService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user/document/cost")
@Tag(name = "Document Cost API", description = "Document Cost API for document manager")
@Slf4j
public class DocumentCostController {

	@Autowired
	private DocumentConfigurationService configurationService;

	@Operation(summary = "Save document cost", description = "Save document cost")
	@PostMapping
	public CommonResponse<String> saveCost(@Valid @RequestBody DocumentCostRequest documentCostRequest) {
		log.info("Creating document cost {} ", documentCostRequest);
		return configurationService.saveDocumentCost(documentCostRequest);
	}

	@Operation(summary = "Edit saved document cost configuration ", description = "Edit saved document cost configuration")
	@GetMapping
	public CommonResponse<DocumentCostResponse> getDocumentsCost(
			@RequestParam(name = "docTypeCode") String docTypeCode) {
		log.info("Fetch document cost for docTypeCode {} ", docTypeCode);
		return configurationService.getDocumentCostConfig(docTypeCode);
	}

	@Operation(summary = "Fetch saved document cost configuration", description = "Fetch saved document cost configuration ")
	@GetMapping("/all")
	public PagedResponse<DocumentCostConfigResponse> getCosts(
			@RequestParam(name = "pageSize", required = false) Integer pageSize,
			@RequestParam(name = "pageNumber", required = false) Integer pageNumber) {
		log.info("Fetching list of document cost configuration");
		return configurationService.getDocumentCostConfigPage(pageSize, pageNumber);
	}

	@Operation(summary = "Delete saved document cost configuration ", description = "Delete saved document cost configuration")
	@PatchMapping("/{docTypeCode}")
	public CommonResponse<String> deleteDocumentsForProducts(@PathVariable(name = "docTypeCode") String docTypeCode) {
		log.info("delete document cost for documentCode {} ", docTypeCode);
		return configurationService.deleteDocumentCostConfig(docTypeCode);
	}

}
