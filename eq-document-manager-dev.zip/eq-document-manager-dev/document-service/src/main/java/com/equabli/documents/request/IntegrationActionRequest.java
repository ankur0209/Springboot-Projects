package com.equabli.documents.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Integration action request")
public class IntegrationActionRequest {

	@Schema(description = "Type of action", example = "RECALL")
	private String action;

	@Schema(description = "Client Account Number", example = "1232134")
	private String clientAccountNumber;

	@Schema(description = "Action to party code", example = "123")
	private String actionToPartyCode;
}
