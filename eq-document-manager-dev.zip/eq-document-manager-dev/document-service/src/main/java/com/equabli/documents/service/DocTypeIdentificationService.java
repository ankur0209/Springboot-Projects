package com.equabli.documents.service;

import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.documents.request.DocTypeIdentificationRequest;
import com.equabli.documents.response.DocTypeIdentificationResponse;
import com.equabli.documents.searchparams.DocTypeIdentificationSearchParam;

public interface DocTypeIdentificationService {

	/**
	 * Add/Update the DocTypeDetail 
	 * @param docTypeIdentificationRequest
	 * @return
	 */
	CommonResponse<String> saveDocTypeIdentification(DocTypeIdentificationRequest docTypeIdentificationRequest);

	CommonResponse<String> deleteDocumentTypeIdentification(String docTypeCode);

	PagedResponse<DocTypeIdentificationResponse> getDocumentTypeIdentification(DocTypeIdentificationSearchParam docTypeIdentificationSearchParam);

}
