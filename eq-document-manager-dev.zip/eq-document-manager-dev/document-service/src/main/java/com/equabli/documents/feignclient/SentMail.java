package com.equabli.documents.feignclient;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.equabli.common.configs.FeignClientConfig;
import com.equabli.common.constants.Constants;
import com.equabli.common.request.EmailRequest;
import com.equabli.common.request.NotificationRequest;

@FeignClient(name = "notification-service", path = "/notification-service/api/v1/notification", configuration = FeignClientConfig.class)
//@FeignClient(name = "notification-service", url = "http://localhost:8084/notification-service/api/v1/notification", configuration = FeignClientConfig.class)
public interface SentMail {

	@PostMapping(value = "/email", consumes = { MediaType.APPLICATION_JSON_VALUE })
	String sendEmail(@RequestHeader(Constants.AUTHORIZATION) String bearerToken,
			@RequestBody EmailRequest emailRequest);

	@PostMapping(value = "/emails", consumes = { MediaType.APPLICATION_JSON_VALUE })
	String sendEmails(@RequestHeader(Constants.AUTHORIZATION) String bearerToken,
			@RequestBody List<EmailRequest> emailRequest);
	
	@PostMapping(value = "/web", consumes = { MediaType.APPLICATION_JSON_VALUE })
	String sendNotification(@RequestHeader(Constants.AUTHORIZATION) String bearerToken,
			@RequestBody NotificationRequest notificationRequests);
}
