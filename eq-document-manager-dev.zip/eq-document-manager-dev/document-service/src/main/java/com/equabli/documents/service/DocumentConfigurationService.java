package com.equabli.documents.service;

import java.util.List;

import org.springframework.lang.NonNull;

import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.FolderResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.response.ProductResponse;
import com.equabli.common.searchparam.DocumentForldersSearchParam;
import com.equabli.documents.request.DocumentCostRequest;
import com.equabli.documents.request.RequiredDocConfigRequest;
import com.equabli.documents.response.DocumentCostConfigResponse;
import com.equabli.documents.response.DocumentCostResponse;
import com.equabli.documents.response.DocumentResponse;
import com.equabli.documents.response.DocumentTypeResponse;
import com.equabli.documents.response.RequiredDocConfigResponse;
import com.equabli.documents.searchparams.DocumentsSearchParam;

public interface DocumentConfigurationService {

	PagedResponse<DocumentResponse> getDocumentListForAccountNumber(@NonNull DocumentsSearchParam documentsSearchParam);

	PagedResponse<FolderResponse> getFolderList(DocumentForldersSearchParam documentForldersSearchParam);

	PagedResponse<DocumentTypeResponse> getDocumentsForProducts(Integer pageSize, Integer pageNumber);

	CommonResponse<String> saveDocumentCost(DocumentCostRequest documentCostRequest);

	CommonResponse<List<ProductResponse>> getProducts();

	CommonResponse<String> saveRequiredDocument(RequiredDocConfigRequest requireDocumentRequest);

	PagedResponse<DocumentCostConfigResponse> getDocumentCostConfigPage(Integer pageSize, Integer pageNumber);

	CommonResponse<DocumentCostResponse> getDocumentCostConfig(String documentCode);

	CommonResponse<String> deleteDocumentCostConfig(String documentCode);

	CommonResponse<String> deleteRequiredDocument(String productCode);

	CommonResponse<RequiredDocConfigResponse> getRequirementDocument(String productCode);

	CommonResponse<List<RequiredDocConfigResponse>> getAllRequirementDocument();

	CommonResponse<String> deleteDocument(Long id);

	CommonResponse<String> deleteFolder(String clientAccountNo);

}