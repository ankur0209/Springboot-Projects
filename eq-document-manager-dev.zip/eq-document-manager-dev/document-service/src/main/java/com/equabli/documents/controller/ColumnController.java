package com.equabli.documents.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.equabli.common.response.CommonResponse;
import com.equabli.documents.request.ShowHideColumnRequest;
import com.equabli.documents.response.ShowHideColumnResponse;
import com.equabli.documents.service.ShowHideColumnService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user/document/column")
@Tag(name = "Column Configuration API", description = "Column Configuration API for document manager")
@Slf4j
public class ColumnController {

	@Autowired
	private ShowHideColumnService showHideColumnService;

	@Operation(summary = "Save table columns", description = "Save table columns")
	@PostMapping
	public CommonResponse<String> saveTableColumns(
			@Valid @RequestBody ShowHideColumnRequest documentsSearchParam) {
		log.info("Save show hide column {}", documentsSearchParam);
		return showHideColumnService.saveColumnsRequest(documentsSearchParam);
	}
	
	@Operation(summary = "Fetch table all columns", description = "Save table all columns")
	@GetMapping("/all")
	public CommonResponse<List<ShowHideColumnResponse>> getTableColumns() {
		log.info("Fetch table all column");
		return showHideColumnService.getTableAllColumns();
	}

}
