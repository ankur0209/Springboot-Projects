package com.equabli.documents.response;

import com.equabli.common.entity.UserDocConfig;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDocConfigResponse {

	@Schema(description = "Organization Type Code", example = "CT")
	private String orgTypeCode;
	
	@Schema(description = "Value of document manager config", example = "field1")
	private String configSelectedCode;

	@Schema(description = "document manager config value", example = "CAN")
	private String configValSelectedCode;
	
	public UserDocConfigResponse(UserDocConfig userDocConfig) {
		this.orgTypeCode = userDocConfig.getOrgCode();
		this.configSelectedCode = userDocConfig.getDocMgrConfigSelectedCode();
		this.configValSelectedCode = userDocConfig.getDocMgrConfigValSelectedCode();
	}
}
