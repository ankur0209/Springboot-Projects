package com.equabli.documents.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDocConfigRequest {

	@Schema(description = "Short code of document manager config", example = "field1")
	private String configShortCode;
	
	@Schema(description = "Short code of document manager config val", example = "OAN")
	private String configValShortCode;
	
}
