package com.equabli.documents.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.equabli.common.constants.MessageConstants;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.request.AccountNumberValidateRequest;
import com.equabli.common.response.AccountValidateDetail;
import com.equabli.common.response.AccountValidateResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.documents.feignclient.UserService;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AccountNumberValidateService {

	@Autowired
	private UserService userService;
	
	@Autowired
	private MessageSupplier messageSupplier;
	
	public Boolean validateForClientAccountNumber(String accountNumber) {
		String validateMessage = userService.clientAccountNumberExits(AccountNumberValidateRequest.builder().accountNumber(accountNumber).build());
		log.info("Client Account Number Response -> {}", validateMessage);
		boolean isExists = checkForValidateAccountNo(validateMessage);
		if (!isExists)
			throw new InvalidArgumentException(
					messageSupplier.get(MessageConstants.NOT_VALID_ACCOUNT_NUMBER, " " + accountNumber));
		return isExists;
	}

	public Boolean validateForOriginalAccountNumber(String accountNumber) {
		String validateMessage = userService.originalAccountNumberExits(AccountNumberValidateRequest.builder().accountNumber(accountNumber).build());
		log.info("Original Account Number Response -> {}", validateMessage);
		boolean isExists = checkForValidateAccountNo(validateMessage);
		if (!isExists)
			throw new InvalidArgumentException(
					messageSupplier.get(MessageConstants.NOT_VALID_ACCOUNT_NUMBER, " " + accountNumber));
		return isExists;
	}

	public Boolean validateForEquabliAccountNumber(String accountNumber) {
		String validateMessage = userService.eqaubliAccountNumberExits(AccountNumberValidateRequest.builder().accountNumber(accountNumber).build());
		log.info("Equabli Account Number Response -> {}", validateMessage);
		boolean isExists = checkForValidateAccountNo(validateMessage);
		if (!isExists)
			throw new InvalidArgumentException(
					messageSupplier.get(MessageConstants.NOT_VALID_ACCOUNT_NUMBER, " " + accountNumber));
		return isExists;
	}
	
	private boolean checkForValidateAccountNo(String validateMessage) {
		boolean validateStatus = false;
		if(!StringUtils.hasText(validateMessage))
			return validateStatus;
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		
		try {
			AccountValidateResponse accountValidateResponse = mapper.readValue(validateMessage, AccountValidateResponse.class);
			List<AccountValidateDetail> accountValidateDetails = accountValidateResponse.getResponse().stream()
					.filter(AccountValidateDetail::getIsExists).toList();
			validateStatus = accountValidateDetails.get(0).getIsExists();
		}catch (Exception e) {
			log.error("ERROR WHILE CONVERT VALUES - > {}", e.getMessage(), e);
		}
		return validateStatus;
	}
}
