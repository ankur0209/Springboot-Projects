package com.equabli.documents.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocMgrConfigResponse {

	@Schema(description = "Short code of document manager config", example = "field1")
	private String shortCode;
	
	@Schema(description = "Description about short code")
	private String description;
	
	@Schema(description = "Default value of specified field", example = "Client Account Number")
	private String defaultValue;
	
	private List<DocMgrConfigValResponse> configVals;
}
