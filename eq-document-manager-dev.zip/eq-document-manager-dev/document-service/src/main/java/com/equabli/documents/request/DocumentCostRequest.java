package com.equabli.documents.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(description = "Add document cost configuration")
public class DocumentCostRequest {

	@Schema(description = "Short code of document Type", example = "AP")
	private String docTypeCode;

	@Schema(description = "Cost of document", example = "10")
	private Float cost;
}
