package com.equabli.documents.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.equabli.common.response.CommonResponse;
import com.equabli.documents.request.ShareDocumentRequest;
import com.equabli.documents.request.ShareFolderRequest;
import com.equabli.documents.service.ShareDocumentService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user/document/share")
@Tag(name = "Share Document API", description = "Share Document API for document manager")
@Slf4j
public class ShareDocumentController {

	@Autowired
	private ShareDocumentService shareDocumentService;
	
	@Operation(summary = "Share document", description = "share document")
	@PostMapping("/file")
	public CommonResponse<String> shareDocument(@Valid @RequestBody ShareDocumentRequest shareDocumentRequest) {
		log.info("list of share document {}", shareDocumentRequest);
		return shareDocumentService.shareDocument(shareDocumentRequest);
	}
	
	@Operation(summary = "UnShare document", description = "share document")
	@PatchMapping("/file/{email}")
	public CommonResponse<String> unShareDocument(@PathVariable(name = "email") String email) {
		log.info("unshare document by email {}", email);
		return shareDocumentService.unShareDocument(email);
	}
	
	@Operation(summary = "Share folder of document", description = "share folder of document")
	@PostMapping("/folder")
	public CommonResponse<String> shareFolder(@Valid @RequestBody ShareFolderRequest folderRequest) {
		log.info("share folder {}", folderRequest);
		return shareDocumentService.shareFolder(folderRequest);
	}
	
}
