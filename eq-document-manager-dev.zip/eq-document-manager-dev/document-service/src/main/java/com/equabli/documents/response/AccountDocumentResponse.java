package com.equabli.documents.response;

import java.time.LocalDateTime;
import java.util.List;

import com.equabli.common.entity.Document;
import com.equabli.common.response.ShareByWithResponse;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Schema(description = "Fetch list of Account for specific Document")
@Getter
@Setter
@NoArgsConstructor
public class AccountDocumentResponse {
	
	private Long id;
	
	@Schema(description = "Original account number ", example = "456789")
	private String originalAccountNumber;

	@Schema(description = "Equabli account number ", example = "789123")
	private Long equabliAccountNumber;

	@Schema(description = "Client account number ", example = "123456")
	private String clientAccountNumber;

	@JsonFormat(pattern = "MM/dd/yyyy")
	@Schema(description = "Document generation date formate MM/dd/yyy", example = "11/25/2022")
	private LocalDateTime generateDate;

	@JsonFormat(pattern = "MM/dd/yyyy")
	@Schema(description = "Document uploaddate formate MM/dd/yyy", example = "11/25/2022")
	private LocalDateTime uploadDate;
	
	private Long fileSize;
	private List<ShareByWithResponse> sharedBy;

	@Schema(description = "Name of uploaded file ", example = "Test.pdf")
	private String fileName;
	
	private String filePath;
	
	@JsonIgnore
	private String documentName;
	@JsonIgnore
	private String documentType;
	@JsonIgnore
	private String productCode;
	
	public AccountDocumentResponse(Document document) {
		this.id = document.getId();
		this.originalAccountNumber = document.getOriginalAccountNo();
		this.equabliAccountNumber = document.getEquabliAccountNo();
		this.clientAccountNumber = document.getClientAccountNo();
		this.generateDate = document.getDocumentGenerationDate();
		this.uploadDate = document.getCreatedAt();
		this.fileName = document.getGeneratedFileName();
		this.fileSize = document.getFileSize();
		this.productCode = document.getProductCode();
		this.documentName = document.getGeneratedFileName();
		this.documentType = document.getDocTypeCode();
		this.filePath = document.getObjKey();
	}
}
