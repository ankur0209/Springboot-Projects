package com.equabli.documents.response;

import java.util.Collections;
import java.util.List;

import com.equabli.common.entity.DocTypeIdentification;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(description = "Add/Update Document Type Identification Response")
public class DocTypeIdentificationResponse {

	@Schema(description = "Document Type", example = "Application")
	private String documentType;

	@Schema(description = "Short code of document Type", example = "AP")
	private String docTypeCode;

	@Schema(description = "List of document type fileds")
	private List<String> docTypeFields;

	public DocTypeIdentificationResponse(DocTypeIdentification docTypeIdentification) {
		this.documentType = docTypeIdentification.getDocType().getName();
		this.docTypeCode = docTypeIdentification.getDocType().getShortCode();
		this.docTypeFields = docTypeIdentification.getDocTypeFields() != null
				? docTypeIdentification.getDocTypeFields().getDocFields()
				: Collections.emptyList();
	}
}
