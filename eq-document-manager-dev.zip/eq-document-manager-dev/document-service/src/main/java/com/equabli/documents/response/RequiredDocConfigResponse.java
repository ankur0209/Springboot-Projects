package com.equabli.documents.response;

import java.util.List;

import com.equabli.documents.request.RequireDocumentRequest;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;

@Getter
public class RequiredDocConfigResponse {

	@Schema(description = "Short code of prodcut", example = "CC")
	private String productCode;
	
	@Schema(description = "Name of prodcut", example = "Credit Card")
	private String productName;
	
	private List<RequireDocumentRequest> documents;
	
	public RequiredDocConfigResponse(String prodCode, String prodName, List<RequireDocumentRequest> request) {
		this.productCode = prodCode;
		this.productName = prodName;
		this.documents = request;
	}
}
