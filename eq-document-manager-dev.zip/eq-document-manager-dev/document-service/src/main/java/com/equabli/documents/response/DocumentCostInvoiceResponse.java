package com.equabli.documents.response;

import java.util.List;

import com.equabli.common.response.DocumentCostInvoiceConfig;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Schema(description = "Fetch document cost of partner to pay or client to receive")
@Getter
@Setter
@Builder
public class DocumentCostInvoiceResponse {

	List<DocumentCostInvoiceConfig> listOfPartner;
	String costCollectByClient;
}
