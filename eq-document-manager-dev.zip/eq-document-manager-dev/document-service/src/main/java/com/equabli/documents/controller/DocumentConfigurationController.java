package com.equabli.documents.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.FolderResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.searchparam.DocumentForldersSearchParam;
import com.equabli.documents.response.DocumentResponse;
import com.equabli.documents.response.DocumentTypeResponse;
import com.equabli.documents.searchparams.DocumentsSearchParam;
import com.equabli.documents.service.DocumentConfigurationService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user/document")
@Tag(name = "Document Configuration API", description = "Document Configuration API for document manager")
@Slf4j
public class DocumentConfigurationController {

	@Autowired
	private DocumentConfigurationService configurationService;

	@Operation(summary = "Fetch list of document", description = "Fetch list of document for specific account nunmber")
	@PostMapping("/all")
	public PagedResponse<DocumentResponse> getDocumentListForAccountNumber(
			@Valid @RequestBody DocumentsSearchParam documentsSearchParam) {
		log.info("Fetching list of document for documentsSearchParam {} ", documentsSearchParam);
		return configurationService.getDocumentListForAccountNumber(documentsSearchParam);
	}

	@Operation(summary = "Fetch list of folder", description = "Fetch list of forlder for User Type ")
	@PostMapping("/folders")
	public PagedResponse<FolderResponse> getFolders(
			@RequestBody(required = false) DocumentForldersSearchParam documentForldersSearchParam) {
		log.info("Fetching list of folder for documentForldersSearchParam {} ", documentForldersSearchParam);
		return configurationService.getFolderList(documentForldersSearchParam);
	}

	@Operation(summary = "Fetch documents type", description = "Fetch the document types ")
	@GetMapping("/type")
	public PagedResponse<DocumentTypeResponse> getDocumentType(
			@RequestParam(name = "pageSize", required = false) Integer pageSize,
			@RequestParam(name = "pageNumber", required = false) Integer pageNumber) {
		log.info("Get document type ");
		return configurationService.getDocumentsForProducts(pageSize, pageNumber);
	}
	
	@Operation(summary = "Delete uploaded documents", description = "delete uploaded document")
	@PatchMapping("/{id}")
	public CommonResponse<String> deleteDocument(@PathVariable(name = "id") Long id){
		log.info("Delete uploaded document as per id {} ", id);
		return configurationService.deleteDocument(id);
	}
	
	@Operation(summary = "Delete folder of documents", description = "delete folder of document")
	@PatchMapping("/folder/{clientAccountNo}")
	public CommonResponse<String> deleteFolder(@PathVariable(name = "clientAccountNo") String clientAccountNo){
		log.info("Delete folder of document as per account no {} ", clientAccountNo);
		return configurationService.deleteFolder(clientAccountNo);
	}
}
