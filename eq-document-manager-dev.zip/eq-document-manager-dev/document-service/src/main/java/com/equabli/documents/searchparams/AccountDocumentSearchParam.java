package com.equabli.documents.searchparams;

import java.time.LocalDate;
import java.util.List;

import javax.validation.constraints.NotBlank;

import com.equabli.common.constants.MessageConstants;
import com.equabli.common.response.PageRequestData;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Search for Account having a specific document")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountDocumentSearchParam extends PageRequestData {

	@NotBlank(message = "Document Type Code is required")
	private String docTypeCode;
	
	private String tenure;
	private String portfolio;
	private String productCode;
	private Long userId;
	
	private String documentName;
	private String originalAccountNumber;
	private Long equabliAccountNumber;
	private String clientAccountNumber;
	private String textSearch;
	
	@Schema(description = "Generation Date From "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate generationDateFrom;
	@Schema(description = "Generation Date To "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate generationDateTo;

	@Schema(description = "Upload Date From "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate uploadDateFrom;
	@Schema(description = "Upload Date To "
			+ MessageConstants.DATE_FORMATE, example = MessageConstants.DATE_FORMATE_EX, pattern = MessageConstants.DATE_FORMATE, type = "string")
	@JsonFormat(pattern = MessageConstants.DATE_FORMATE)
	private LocalDate uploadDateTo;
	
	@JsonIgnore
	private List<String> accounts;

}
