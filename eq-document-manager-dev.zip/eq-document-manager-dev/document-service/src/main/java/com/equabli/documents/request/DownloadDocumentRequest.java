package com.equabli.documents.request;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(description = "Add Download Document history configuration")
public class DownloadDocumentRequest {

	@Schema(description = "Document id List", example = "[\"1\"]")
	private List<Long> documentId;
}
