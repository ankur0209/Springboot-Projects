package com.equabli.documents.response;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class SentReceiveSummaryResponse {

	private Integer fullfilled;
	private Integer open;
	private Integer overDue;
	private Integer total;
}
