package com.equabli.documents.request;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(description = "Add/Update Document Type Detail")
public class DocTypeIdentificationRequest {

	@Schema(description = "Short code of document Type", example = "BS", required = true)
	@NotBlank(message = "Document Type Code is required")
	private String docTypeCode;

	@Schema(description = "List of document type fileds", example = "[\"Buyer Name\",\"Seller Name\"]", required = true)
	@NotNull(message = "Document Type Fields is required")
	private List<String> docTypeFields;
}
