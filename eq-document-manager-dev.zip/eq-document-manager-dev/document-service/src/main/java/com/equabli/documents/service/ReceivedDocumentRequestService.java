package com.equabli.documents.service;

import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.documents.request.DownloadDocumentRequest;
import com.equabli.documents.response.ReceiveDocumentResponse;
import com.equabli.documents.response.SentReceiveSummaryResponse;
import com.equabli.documents.searchparams.ReceiveRequestDocumentSearchParam;

public interface ReceivedDocumentRequestService {

	PagedResponse<ReceiveDocumentResponse> getReceivedDocumentRequestList(ReceiveRequestDocumentSearchParam receiveRequestDocumentSearchParam);

	CommonResponse<String> deleteRequestedDocument(Long documentRequestId);

	CommonResponse<String> saveDownloadReceiveDocumentHistory(DownloadDocumentRequest documentRequest);

	CommonResponse<SentReceiveSummaryResponse> getReceiveRequestSummary();

}
