package com.equabli.documents.service;

import java.util.List;

import com.equabli.common.auth.TokenData;
import com.equabli.common.response.CommonResponse;
import com.equabli.documents.request.ShowHideColumnRequest;
import com.equabli.documents.response.ShowHideColumnResponse;

public interface ShowHideColumnService {

	CommonResponse<String> saveColumnsRequest(ShowHideColumnRequest showHideColumnRequest);

	List<String> getColumns(String tableName, TokenData tokenData);

	CommonResponse<List<ShowHideColumnResponse>> getTableAllColumns();
}