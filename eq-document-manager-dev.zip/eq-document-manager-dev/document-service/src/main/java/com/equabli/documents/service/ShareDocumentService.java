package com.equabli.documents.service;

import com.equabli.common.response.CommonResponse;
import com.equabli.documents.request.ShareDocumentRequest;
import com.equabli.documents.request.ShareFolderRequest;

public interface ShareDocumentService {

	CommonResponse<String> shareDocument(ShareDocumentRequest shareDocumentRequest);

	CommonResponse<String> unShareDocument(String email);

	CommonResponse<String> shareFolder(ShareFolderRequest folderRequest);

}
