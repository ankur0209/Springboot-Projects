package com.equabli.documents.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.DownloadHistoryResponse;
import com.equabli.common.response.PagedResponse;
import com.equabli.documents.request.DownloadDocumentRequest;
import com.equabli.documents.searchparams.DownloadHistorySearchParam;
import com.equabli.documents.service.DownloadHistoryService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user/document/download")
@Tag(name = "Download Document API", description = "Download Document API for document manager")
@Slf4j
public class DownloadHistoryController {

	@Autowired
	private DownloadHistoryService documentDownloadHistoryService;

	@Operation(summary = "Save list of document history", description = "Save list of document history")
	@PostMapping
	public CommonResponse<String> saveDownloadDocumentHistory(
			@Valid @RequestBody DownloadDocumentRequest documentRequest) {
		log.info("Save list of document {}", documentRequest);
		return documentDownloadHistoryService.saveDownloadDocumentHistory(documentRequest);
	}

	@Operation(summary = "Delete document history ", description = "Delete document history")
	@PatchMapping("/{id}")
	public CommonResponse<String> deleteDownloadDocumentHistory(
			@PathVariable(name = "id") Long id){
		log.info("delete document download history for id {} ", id);
		return documentDownloadHistoryService.deleteDownloadDocumentHistory(id);
	}

	@Operation(summary = "Fetch saved download document history configuration", description = "Fetch saved download document history configuration")
	@PostMapping("/all")
	public PagedResponse<DownloadHistoryResponse> getDownloadHistoryPage(
			@RequestBody DownloadHistorySearchParam downloadHistorySearchParam) {
		log.info("Fetching list of document history configuration for productCode {} ");
		return documentDownloadHistoryService.getDownloadHistoryPage(downloadHistorySearchParam);
	}

}
