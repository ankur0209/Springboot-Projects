package com.equabli.documents.service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.equabli.common.utils.Util;
import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class PdfGenaratorUtil {
	
	@Autowired
	TemplateEngine templateEngine;

	public ByteArrayInputStream generatePdf(String name, Map<String, Object> dataMap, String templatePath) {
		String fileName = Util.generatetempFile(name);
		File pdfFile = exportToPdfBox(dataMap, templatePath, fileName);
		byte[] arr = null;
		try {
			arr = Files.readAllBytes(Paths.get(pdfFile.getPath()));
		} catch (IOException e) {
			log.error("Error while download sample file for send request document -> {}", e.getMessage());
		}
		return new ByteArrayInputStream(arr);
	}
	
	public File exportToPdfBox(Map<String, Object> variables, String templatePath, String fileName) {
		try (OutputStream os = new FileOutputStream(fileName);) {
			// There are more options on the builder than shown below.
			PdfRendererBuilder builder = new PdfRendererBuilder();
			builder.withHtmlContent(getHtmlString(variables, templatePath), null);
			builder.useFont(new File("templates/font.css"), "Poppins");
			builder.toStream(os);
			builder.run();
		} catch (Exception e) {
			log.error("Exception while generating pdf : {}", e);
		}
		return new File(fileName);
	}

	private String getHtmlString(Map<String, Object> variables, String templatePath) {
		Context context = new Context();
		context.setVariables(variables);

		return templateEngine.process("templates/" + templatePath, context);
	}

}
