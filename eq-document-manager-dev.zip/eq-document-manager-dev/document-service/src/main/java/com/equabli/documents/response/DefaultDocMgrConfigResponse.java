package com.equabli.documents.response;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DefaultDocMgrConfigResponse {

	private List<DocMgrConfigResponse> docMgrConfigs;
	
	@Schema(description = "Organization type code", example = "CL")
	private String orgTypeCode;
}
