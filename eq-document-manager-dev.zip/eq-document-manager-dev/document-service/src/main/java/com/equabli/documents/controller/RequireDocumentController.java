package com.equabli.documents.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.ProductResponse;
import com.equabli.documents.request.RequiredDocConfigRequest;
import com.equabli.documents.response.RequiredDocConfigResponse;
import com.equabli.documents.service.DocumentConfigurationService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user/document/require")
@Tag(name = "Require Document API", description = "Require Document API for document manager")
@Slf4j
public class RequireDocumentController {

	@Autowired
	private DocumentConfigurationService configurationService;

	@Operation(summary = "Get list of product", description = "Get list of product")
	@GetMapping("/product/type")
	public CommonResponse<List<ProductResponse>> getDocumentsForProducts() throws Exception {
		log.info("Get list of product {} ");
		return configurationService.getProducts();
	}

	@Operation(summary = "Fetch All Required Document", description = "Fetch All Required Document")
	@GetMapping("/all")
	public CommonResponse<List<RequiredDocConfigResponse>> getAllRequirementDocument() throws Exception {
		log.info("Fetch All Required Document");
		return configurationService.getAllRequirementDocument();
	}

	@Operation(summary = "Get Required Document as per product code", description = "Get Required Document as per product code")
	@GetMapping
	public CommonResponse<RequiredDocConfigResponse> getRequirementDocument(
			@RequestParam(name = "productCode") String productCode) throws Exception {
		log.info("Get Required Document as per product code {} ", productCode);
		return configurationService.getRequirementDocument(productCode);
	}

	@Operation(summary = "Save Required Document Configuration", description = "Save Required Document Configuration")
	@PostMapping
	public CommonResponse<String> saveRequirementDocument(
			@Valid @RequestBody RequiredDocConfigRequest requiredDocConfigRequest) throws Exception {
		log.info("Save required document as per product code {} ", requiredDocConfigRequest);
		return configurationService.saveRequiredDocument(requiredDocConfigRequest);
	}

	@Operation(summary = "Delete Required Document Configuration", description = "Delete Required Document Configuration")
	@PatchMapping("/{productCode}")
	public CommonResponse<String> deleteRequiredDocument(@PathVariable(name = "productCode") String productCode) {
		log.info("Delete required document as per product code {} ", productCode);
		return configurationService.deleteRequiredDocument(productCode);
	}
}
