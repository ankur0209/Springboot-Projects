package com.equabli.documents.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.equabli.common.response.CommonResponse;
import com.equabli.documents.request.IntegrationActionRequest;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/integration/")
@Tag(name = "Document Integration API", description = "Document Integration API")
@Slf4j
public class IntegrationController {

	@Operation(summary = "Integration action", description = "Integration action")
	@PostMapping("action")
	public CommonResponse<String> saveTableColumns(
			@RequestBody IntegrationActionRequest integrationActionRequest) {
		log.info("Integration action request {}", integrationActionRequest);
		return CommonResponse.success("success");
	}
	
}
