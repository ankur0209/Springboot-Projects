package com.equabli.documents.request;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.equabli.common.request.ShareUserDetailRequest;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Schema(description = "Share Document Request")
public class ShareDocumentRequest {

	@Schema(description = "Document id", example = "1")
	@NotNull(message = "DocumentId must not be null")
	private Long documentId;

	@Schema(description = "Share document details with whom documnt share", example = "[\"email\":\"abc@gmail.com\",\"isRegisterUser\":\"true\"]")
	@NotNull(message = "Share document details must not be null")
	private List<ShareUserDetailRequest> shareDetail;
	
}
