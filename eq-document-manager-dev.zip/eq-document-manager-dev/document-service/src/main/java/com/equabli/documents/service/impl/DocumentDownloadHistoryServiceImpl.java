package com.equabli.documents.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.Document;
import com.equabli.common.entity.DownloadHistory;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.repository.DownloadHistoryRepository;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.DownloadHistoryResponse;
import com.equabli.common.response.PageRequestData;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.documents.constants.DocumentMessageConstants;
import com.equabli.documents.request.DownloadDocumentRequest;
import com.equabli.documents.searchparams.DownloadHistorySearchParam;
import com.equabli.documents.service.DownloadHistoryService;

@Service
public class DocumentDownloadHistoryServiceImpl implements DownloadHistoryService {

	@Autowired
	private MessageSupplier messageSupplier;

	@Autowired
	private DocumentRepository documentRepository;

	@Autowired
	private DownloadHistoryRepository downloadHistoryRepository;

	@Autowired
	FetchTokenData fetchTokenData;

	private static final String DOWNLOAD_AT = "downloadAt";
	
	@Override
	@Transactional
	public CommonResponse<String> saveDownloadDocumentHistory(DownloadDocumentRequest documentRequest) {

		TokenData tokenData = fetchTokenData.getTokenData();
		for (Long docId : documentRequest.getDocumentId()) {

			Document document = documentRepository.findById(docId).orElseThrow(
					() -> new InvalidArgumentException(messageSupplier.get(MessageConstants.NOT_VALID, docId)));

			DownloadHistory downloadHistory = new DownloadHistory();
			downloadHistory.saveDocumentDownloadHistory(downloadHistory, document, tokenData);
			downloadHistoryRepository.save(downloadHistory);
		}
		return CommonResponse
				.success(messageSupplier.get(DocumentMessageConstants.DocumentDownloadConfig.DOWNLOAD_CREATE_SUCCESS));
	}

	@Override
	@Transactional
	public CommonResponse<String> deleteDownloadDocumentHistory(Long downloadHistoryCode) {

		DownloadHistory downloadHistory = downloadHistoryRepository.findById(downloadHistoryCode)
				.orElseThrow(() -> new InvalidArgumentException(
						messageSupplier.get(MessageConstants.NOT_VALID, downloadHistoryCode)));
		downloadHistory.deleteDownloadHistory(downloadHistory);
		downloadHistoryRepository.save(downloadHistory);
		return CommonResponse
				.success(messageSupplier.get(DocumentMessageConstants.DocumentDownloadConfig.DOWNLOAD_DELETE_SUCCESS,
						String.valueOf(downloadHistoryCode)));
	}

	@Override
	public PagedResponse<DownloadHistoryResponse> getDownloadHistoryPage(DownloadHistorySearchParam downloadHistorySearchParam) {

		TokenData tokenData = fetchTokenData.getTokenData();
		
		String sortParam = downloadHistorySearchParam == null
				|| downloadHistorySearchParam.getSortParam() == null ? DOWNLOAD_AT
						: downloadHistorySearchParam.getSortParam();
		PageRequestData pageRequestData = downloadHistorySearchParam != null
				? Util.getPageRequestData(downloadHistorySearchParam.getPageSize(),
						downloadHistorySearchParam.getPageNumber(), downloadHistorySearchParam.getSortOrder(),sortParam)
				: Util.getPageRequestData(null, null, null, DOWNLOAD_AT);

		int startRecord = (pageRequestData.getPageNumber() * pageRequestData.getPageSize()) + 1;
		Sort sort = Util.getSortingOrder(pageRequestData.getSortOrder(), getDownloadSortParam(sortParam));
		Pageable pageable = PageRequest.of(pageRequestData.getPageNumber(), pageRequestData.getPageSize(),sort);

		Page<DownloadHistoryResponse> downloadHistoryPage = downloadHistoryRepository
				.findByUserIdAndIsDeleteFalse(tokenData.getPrincipleId(), pageable)
				.map(DownloadHistoryResponse::new);

		return downloadHistoryPage.isEmpty() ? PagedResponse.empty()
				: PagedResponse.of(downloadHistoryPage.getContent(), startRecord, pageRequestData.getPageSize(),
						(int) downloadHistoryPage.getTotalElements());
	}
	
	private String getDownloadSortParam(String sortParams) {
		String sortParamsVal = null;
		switch (sortParams) {
		case "documentName" -> sortParamsVal = "document.receiveFileName";
		case "size" -> sortParamsVal = "docSize";
		case "downloadDate" -> sortParamsVal = DOWNLOAD_AT;
		case "status" -> sortParamsVal = "downloadStatus";
		default -> sortParamsVal = DOWNLOAD_AT;
		}
		return sortParamsVal;
	}
}
