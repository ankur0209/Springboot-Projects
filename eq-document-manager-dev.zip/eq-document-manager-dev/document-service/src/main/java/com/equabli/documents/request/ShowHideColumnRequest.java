package com.equabli.documents.request;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(description = "Show Hide columns ")
public class ShowHideColumnRequest {
	
	@NotBlank
	String tableName;
	
	@NotNull(message =  "Column Names required")
	List<String> columnNames;
}
