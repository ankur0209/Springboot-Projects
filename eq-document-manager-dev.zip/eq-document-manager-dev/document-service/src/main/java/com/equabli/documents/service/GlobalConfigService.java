package com.equabli.documents.service;

import java.util.List;

import com.equabli.common.enums.FileNameConfigEnum;
import com.equabli.common.response.CommonResponse;
import com.equabli.documents.request.UserDocConfigRequest;
import com.equabli.documents.response.DefaultDocMgrConfigResponse;
import com.equabli.documents.response.UserDocConfigResponse;

public interface GlobalConfigService {

	/**
	 * Save user file configuration
	 * 
	 * @param fileNameConfigDTO @
	 */
	public CommonResponse<String> saveUserFileConfig(List<UserDocConfigRequest> userDocConfigRequest);

	/**
	 * Get user file configuration
	 * 
	 * @param userUuid
	 * @param UserType
	 * @return @
	 */
	public CommonResponse<List<UserDocConfigResponse>> getUserFileConfig(FileNameConfigEnum fileNameConfig);

	/**
	 * 
	 * @param orgType
	 * @return
	 */
	public CommonResponse<DefaultDocMgrConfigResponse> getDefaultDocMgrConfiguration(FileNameConfigEnum fileNameConfig);

}
