package com.equabli.documents.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.DocType;
import com.equabli.common.entity.Document;
import com.equabli.common.entity.ShareBy;
import com.equabli.common.entity.ShareWith;
import com.equabli.common.enums.DocumentShareTypeEnum;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.repository.DocTypeRepository;
import com.equabli.common.repository.DocumentRepository;
import com.equabli.common.repository.ShareByRepository;
import com.equabli.common.repository.ShareWithRepository;
import com.equabli.common.request.ShareUserDetailRequest;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.documents.constants.DocumentMessageConstants;
import com.equabli.documents.request.ShareDocumentRequest;
import com.equabli.documents.request.ShareFolderRequest;
import com.equabli.documents.service.ShareDocumentService;

@Service
public class ShareDocumentServiceImpl implements ShareDocumentService {

	@Autowired
	DocumentRepository documentRepository;

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	FetchTokenData fetchTokenData;

	@Autowired
	ShareByRepository shareByRepository;
	
	@Autowired
	ShareWithRepository shareWithRepository;

	@Autowired private AsyncServiceImpl asyncServiceImpl;
	@Autowired private DocTypeRepository docTypeRepository;
	@Autowired private HttpServletRequest request;
	
	@Override
	public CommonResponse<String> shareDocument(ShareDocumentRequest shareDocumentRequest) {

		TokenData tokenData = fetchTokenData.getTokenData();
		String authorization = request.getHeader(Constants.AUTHORIZATION);
		Document document = documentRepository.findById(shareDocumentRequest.getDocumentId())
				.orElseThrow(() -> new InvalidArgumentException(messageSupplier.get(MessageConstants.NOT_VALID, 
						shareDocumentRequest.getDocumentId())));
		String id = handleShareDocument(document, tokenData,
				shareDocumentRequest.getShareDetail(),DocumentShareTypeEnum.FILE,authorization);
		shareDocumentNotification(tokenData, authorization, shareDocumentRequest.getShareDetail(),
				DocumentShareTypeEnum.FILE,document.getClientAccountNo(),
				document.getDocTypeCode());
		return CommonResponse.success(
				messageSupplier.get(DocumentMessageConstants.ShareDocumentConstants.SHARE_DOCUMENT_CREATE_SUCCESS, id),
				id);
	}

	@Override
	public CommonResponse<String> unShareDocument(String email) {
		handleUnSharedDocument(email);
		return CommonResponse.success(messageSupplier
				.get(DocumentMessageConstants.ShareDocumentConstants.SHARE_DOCUMENT_CREATE_SUCCESS, email),email);
	}

	@Override
	public CommonResponse<String> shareFolder(ShareFolderRequest folderRequest) {
		TokenData tokenData = fetchTokenData.getTokenData();
		String authorization = request.getHeader(Constants.AUTHORIZATION);
		List<Document> listOfDocument = documentRepository
				.findByClientAccountNoAndIsDeleteFalse(folderRequest.getClientAccountNo());
		for (Document document : listOfDocument) {
			handleShareDocument(document, tokenData, folderRequest.getShareDetail(),DocumentShareTypeEnum.FOLDER,
					authorization);
		}
		shareDocumentNotification(tokenData, authorization, folderRequest.getShareDetail(),
				DocumentShareTypeEnum.FOLDER,folderRequest.getClientAccountNo(),
				"");
		return CommonResponse.success(
				messageSupplier.get(DocumentMessageConstants.ShareDocumentConstants.SHARE_DOCUMENT_CREATE_SUCCESS));
	}
	
	private String handleShareDocument(Document document, TokenData tokenData, List<ShareUserDetailRequest> shareDetail,
			DocumentShareTypeEnum type, String authorization) {
		ShareBy shareBy = shareByRepository.findByUserIdAndDocumentId(tokenData.getPrincipleId(),document.getId()).orElse(new ShareBy());
		shareBy.saveShareBy(shareBy, document, tokenData, tokenData, type);
		shareBy = shareByRepository.save(shareBy);

		for (ShareUserDetailRequest userDetailRequest : shareDetail) {
			ShareWith shareWith = shareWithRepository
					.findByShareById_IdAndSharedWithEmailId(shareBy.getId(), userDetailRequest.getEmail())
					.orElse(new ShareWith());
			shareWith.saveShareWith(shareWith, shareBy, tokenData, type, userDetailRequest);
			shareWithRepository.save(shareWith);
		}
		
		DocType docType = docTypeRepository.findByShortCode(document.getDocTypeCode())
				.orElseThrow(() -> new InvalidArgumentException(
						messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, document.getDocTypeCode())));
		asyncServiceImpl.shareDocumentEmailToUser(tokenData, docType,
				document.getClientAccountNo(), shareDetail, authorization);
		return String.valueOf(shareBy.getId());
	}
	
	private void shareDocumentNotification(TokenData tokenData, String authorization,
			List<ShareUserDetailRequest> shareDetail, DocumentShareTypeEnum type,String accountNo, String docTYpe) {
		String shareWith = shareDetail.stream().map(m -> m.getName()).collect(Collectors.joining(","));
		asyncServiceImpl.shareDocumentNotification(tokenData, authorization, shareWith,
				shareDetail,type,accountNo,docTYpe);
	}

	private void handleUnSharedDocument(String email) {
		List<ShareWith> shareWithList = shareWithRepository.findBySharedWithEmailId(email);
		if (!shareWithList.isEmpty()) {
			for (ShareWith shareWith : shareWithList) {
				shareWith.saveUnShareWith(shareWith);
				shareWithRepository.save(shareWith);
			}
		}
	}
}
