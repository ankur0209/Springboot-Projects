package com.equabli.documents.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.equabli.common.configs.FeignClientConfig;
import com.equabli.common.constants.Constants;
import com.equabli.common.request.AccountNumberValidateRequest;
import com.equabli.common.request.UserEmailRequest;

@FeignClient(name = "user-service", path = "/user-service/api", configuration = FeignClientConfig.class)
//@FeignClient(name = "user-service", url = "http://k8s-equablid-equablii-3d7f80b23b-1277713601.us-east-1.elb.amazonaws.com/user-service/api", configuration = FeignClientConfig.class)
public interface UserService {

	@PostMapping(value = "/v1/users/email/exists", consumes = { MediaType.APPLICATION_JSON_VALUE })
	String emailExists(@RequestHeader(Constants.AUTHORIZATION) String bearerToken,
			@RequestBody UserEmailRequest userEmailRequest);

	@PostMapping(value = "/v1/user/clientAccount/exists", consumes = { MediaType.APPLICATION_JSON_VALUE })
	String clientAccountNumberExits(@RequestBody AccountNumberValidateRequest accountNumberValidateRequest);

	@PostMapping(value = "/v1/user/originalAccount/exists", consumes = { MediaType.APPLICATION_JSON_VALUE })
	String originalAccountNumberExits(@RequestBody AccountNumberValidateRequest accountNumberValidateRequest);

	@PostMapping(value = "/v1/user/eqaubliAccount/exists", consumes = { MediaType.APPLICATION_JSON_VALUE })
	String eqaubliAccountNumberExits(@RequestBody AccountNumberValidateRequest accountNumberValidateRequest);
}
