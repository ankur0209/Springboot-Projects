package com.equabli.documents.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.DocType;
import com.equabli.common.entity.DocTypeIdentification;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.repository.DocTypeIdentificationRepository;
import com.equabli.common.repository.DocTypeRepository;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.PageRequestData;
import com.equabli.common.response.PagedResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.documents.constants.DocumentMessageConstants;
import com.equabli.documents.request.DocTypeIdentificationRequest;
import com.equabli.documents.response.DocTypeIdentificationResponse;
import com.equabli.documents.searchparams.DocTypeIdentificationSearchParam;
import com.equabli.documents.service.DocTypeIdentificationService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DocTypeIdentificationServiceImpl implements DocTypeIdentificationService {

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	DocTypeIdentificationRepository docTypeIdentificationRepository;

	@Autowired
	DocTypeRepository docTypeRepository;

	@Autowired
	FetchTokenData fetchTokenData;

	@Override
	public CommonResponse<String> saveDocTypeIdentification(DocTypeIdentificationRequest docTypeIdentificationRequest) {

		TokenData tokenData = fetchTokenData.getTokenData();
		DocType docType = getDocType(docTypeIdentificationRequest.getDocTypeCode());
		log.info("docType {}", docType);

		DocTypeIdentification docTypeIdentification = docTypeIdentificationRepository
				.findByDocType_ShortCode(docType.getShortCode()).orElse(new DocTypeIdentification());
		docTypeIdentification.setIdentificationJson(docTypeIdentificationRequest.getDocTypeFields());
		docTypeIdentification.saveDocTypeIdentification(docTypeIdentification, docType, tokenData);
		docTypeIdentificationRepository.save(docTypeIdentification);
		log.info("docTypeIdentification {}", docTypeIdentification);

		return CommonResponse.success(messageSupplier
				.get(DocumentMessageConstants.DocumentTypeIdentification.DOCUMENT_TYPE_IDENTIFICATION_SAVED_SUCCESS));
	}

	private DocType getDocType(String docTypeCode) {
		return docTypeRepository.findByShortCode(docTypeCode).orElseThrow(() -> new InvalidArgumentException(
				messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, " " + docTypeCode)));
	}

	@Override
	public CommonResponse<String> deleteDocumentTypeIdentification(String docTypeCode) {

		TokenData tokenData = fetchTokenData.getTokenData();
		log.info("tokenData {}", tokenData);

		DocTypeIdentification docTypeIdentification = docTypeIdentificationRepository
				.findByDocType_ShortCode(docTypeCode).orElseThrow(() -> new InvalidArgumentException(
						messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, docTypeCode)));

		docTypeIdentification.deleteDocTypeIdentification(docTypeIdentification, tokenData);
		docTypeIdentificationRepository.save(docTypeIdentification);
		log.info("docTypeIdentification {}", docTypeIdentification);

		return CommonResponse.success(messageSupplier
				.get(DocumentMessageConstants.DocumentTypeIdentification.DOCUMENT_TYPE_IDENTIFICATION_DELETE_SUCCESS));
	}

	@Override
	public PagedResponse<DocTypeIdentificationResponse> getDocumentTypeIdentification(
			DocTypeIdentificationSearchParam docTypeIdentificationSearchParam) {

		String sortParam = "id";

		if (docTypeIdentificationSearchParam == null)
			docTypeIdentificationSearchParam = new DocTypeIdentificationSearchParam();

		PageRequestData pageRequestData = Util.getPageRequestData(docTypeIdentificationSearchParam.getPageSize(),
				docTypeIdentificationSearchParam.getPageNumber(), docTypeIdentificationSearchParam.getSortOrder(),
				sortParam);

		log.info("pageRequestData {}", pageRequestData);

		Sort sort = Util.getSortingOrder(pageRequestData.getSortOrder(), sortParam);
		Pageable pageable = PageRequest.of(pageRequestData.getPageNumber(), pageRequestData.getPageSize(), sort);

		Page<DocTypeIdentificationResponse> docTypeIdentificationPage = docTypeIdentificationRepository
				.getDocumentTypeIdentification(docTypeIdentificationSearchParam.getDocumentType(), pageable)
				.map(DocTypeIdentificationResponse::new);

		int startRecord = Math.min((int) docTypeIdentificationPage.getTotalElements(),
				pageable.getPageNumber() * pageable.getPageSize()) + 1;

		log.info("docTypeIdentificationPage {}", docTypeIdentificationPage);

		return docTypeIdentificationPage.isEmpty() ? PagedResponse.empty()
				: PagedResponse.of(docTypeIdentificationPage.getContent(), startRecord, pageRequestData.getPageSize(),
						(int) docTypeIdentificationPage.getTotalElements());
	}
}
