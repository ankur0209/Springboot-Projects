package com.equabli.documents.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Schema(description = "Fetch document coverage")
@Setter
public class DocumentCoverageResponse {

	@Schema(description = "Short code of document type", example = "AP")
	private String docTypeCode;

	@Schema(description = "Type of document", example = "Application")
	private String documentType;

	@Schema(description = "Completed document count", example = "10")
	private Integer complete;
	
	@Schema(description = "InComplete document count", example = "5")
	private Integer inComplete;
	
	@Schema(description = "Total of document count", example = "15")
	private Integer total;
	
	@Schema(description = "Percentage of document completed", example = "67")
	private Integer percentage;
	
	public void setValues(Integer complete, Integer inComplete, Integer total) {
		if(this.complete != null)	
			this.complete = this.complete + complete;
		else
			this.complete = complete;
		
		if(this.inComplete != null)	
			this.inComplete = this.inComplete + inComplete;
		else
			this.inComplete = inComplete;
		
		if(this.total !=null)
			this.total = this.total + total;
		else
			this.total = total;
		
		if(this.total != null && this.total > 0)
			this.percentage = (this.complete * 100) / this.total;
	}
	
	
}
