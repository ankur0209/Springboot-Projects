package com.equabli.documents.service.impl;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.FetchTokenData;
import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.Constants;
import com.equabli.common.repository.DocumentCostInvoiceRepository;
import com.equabli.common.request.DocumentCostInvoicerData;
import com.equabli.common.response.CommonResponse;
import com.equabli.common.response.DocumentCostInvoiceConfig;
import com.equabli.common.utils.DateUtils;
import com.equabli.common.utils.DurationDateUtils;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.common.utils.Util;
import com.equabli.documents.constants.DocumentMessageConstants;
import com.equabli.documents.constants.InvoiceDataConstants;
import com.equabli.documents.response.DocumentCostInvoiceResponse;
import com.equabli.documents.service.DocumentCostInvoiceService;
import com.equabli.documents.service.PdfGenaratorUtil;

@Service
public class DocumentCostInvoiceServiceImpl implements DocumentCostInvoiceService {

	@Value("${docCost.invoiceOfClient.pdf-template.name}")
	private String clientInvoiceTemplate;

	@Value("${docCost.invoiceOfPartner.pdf-template.name}")
	private String partnerInvoiceTemplate;

	@Value("${docCost.invoiceOfEquabli.pdf-template.name}")
	private String equabliInvoiceTemplate;

	@Autowired
	FetchTokenData fetchTokenData;

	@Autowired
	DocumentCostInvoiceRepository documentCostInvoiceRepository;

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	PdfGenaratorUtil pdfGenaratorUtil;

	@Override
	public CommonResponse<DocumentCostInvoiceResponse> getDocumentCostInvoiceDetails(String tenure) {

		TokenData tokenData = fetchTokenData.getTokenData();
		List<DocumentCostInvoiceConfig> groupByDocumentCosts = null;
		DurationDateUtils duration = new DurationDateUtils(tenure, LocalDateTime.now());
		if (tokenData.getOrgType().equals(Constants.CLIENT_CODE)) {
			groupByDocumentCosts = documentCostInvoiceRepository.groupByDocumentCostForClient(tokenData.getOrgType(),
					tokenData.getUserOrgCode(), duration.getFirstDay(), duration.getLastDay());
		} else if (tokenData.getOrgType().equals(Constants.PARTNER_CODE)) {
			groupByDocumentCosts = documentCostInvoiceRepository.groupByDocumentCostForPartner(tokenData.getOrgType(),
					tokenData.getUserOrgCode(), duration.getFirstDay(), duration.getLastDay());
		}else {
			groupByDocumentCosts = documentCostInvoiceRepository.groupByDocumentCostForClient(tokenData.getOrgType(),
					tokenData.getUserOrgCode(), duration.getFirstDay(), duration.getLastDay());
		}

		String totalAmountPay = groupByDocumentCosts.stream().map(x -> new BigDecimal(x.getAmountPay()))
				.reduce(BigDecimal.ZERO, BigDecimal::add).toString();

		DocumentCostInvoiceResponse documentCostInvoiceResponse = DocumentCostInvoiceResponse.builder()
				.listOfPartner(groupByDocumentCosts).costCollectByClient(totalAmountPay).build();

		return CommonResponse.success(
				messageSupplier
						.get(DocumentMessageConstants.DocumentCostInvoiceConstants.DOCUMENT_COST_INVOICE_FETCH_SUCCESS),
				documentCostInvoiceResponse);
	}

	@Override
	public ByteArrayInputStream downloadDocumentCostInvoice(String tenure) {
		TokenData tokenData = fetchTokenData.getTokenData();
		DurationDateUtils duration = new DurationDateUtils(tenure, LocalDateTime.now());
		
		if (tokenData.getOrgType().equals(Constants.CLIENT_CODE)) 
			return clientDocCostInvoiceDetails(tokenData,duration);
		else if (tokenData.getOrgType().equals(Constants.PARTNER_CODE)) 
			return partnerDocCostInvoiceDetails(tokenData,duration);
		else // For equabli user
			return equabliDocCostInvoiceDetails(tokenData,duration);
	}

	/**
	 * Collect Data of partner and client for PDF generation.
	 * Collect total cost of client need to be get.
	 * Generation of data map for invoice generation by key.
	 * Generate PDF
	 * @param tokenData
	 * @param duration
	 * @return
	 */
	private ByteArrayInputStream clientDocCostInvoiceDetails(TokenData tokenData, DurationDateUtils duration) {
		Map<String, Object> invoiceDataByKey;
		List<Map<String, Object>> costDetailsOfClient = getClientCostDetailsList(tokenData, duration.getFirstDay(),
				duration.getLastDay());
		String totalCost = getTotalCostOfClient(costDetailsOfClient);
		invoiceDataByKey = invoiceDataforPdfGeneration(tokenData, costDetailsOfClient, totalCost, duration.getFirstDay(),
				duration.getLastDay());
		return pdfGenaratorUtil.generatePdf("InvoiceOfClientDocCost.pdf", invoiceDataByKey, clientInvoiceTemplate);
	}
	
	/**
	 * Collect Data of partner for PDF generation.
	 * Collect total cost of client need to be get.
	 * Generation of data map for invoice generation by key.
	 * Generate PDF
	 * @param tokenData
	 * @param duration
	 * @return
	 */
	private ByteArrayInputStream partnerDocCostInvoiceDetails(TokenData tokenData, DurationDateUtils duration) {
		Map<String, Object> invoiceDataByKey;
		List<DocumentCostInvoicerData> costDetailsOfPartner = getPartnerCostDetailsList(tokenData, duration.getFirstDay(),
				duration.getLastDay());
		String totalCost = getTotalCostOfPartner(costDetailsOfPartner);
		invoiceDataByKey = partnerDataforPdfGeneration(tokenData, costDetailsOfPartner, totalCost, duration.getFirstDay(),
				duration.getLastDay());
		return pdfGenaratorUtil.generatePdf("InvoiceOfPartnerDocCost.pdf", invoiceDataByKey, partnerInvoiceTemplate);
	}

	/**
	 * Collect Data of partner for PDF generation.
	 * Collect total cost of Equabli need to be get.
	 * Generation of data map for invoice generation by key.
	 * Generate PDF
	 * @param tokenData
	 * @param duration
	 * @return
	 */
	private ByteArrayInputStream equabliDocCostInvoiceDetails(TokenData tokenData, DurationDateUtils duration) {
		Map<String, Object> invoiceDataByKey;
		List<Map<String, Object>> costDetailsOfEquabli = getEquabliCostDetailsList(tokenData, duration.getFirstDay(),
				duration.getLastDay());
		String totalCost = getTotalCostOfClient(costDetailsOfEquabli);
		invoiceDataByKey = invoiceDataforPdfGeneration(tokenData, costDetailsOfEquabli, totalCost, duration.getFirstDay(),
				duration.getLastDay());
		return pdfGenaratorUtil.generatePdf("InvoiceOfEquabliDocCost.pdf", invoiceDataByKey, equabliInvoiceTemplate);
	}
	
	private List<Map<String, Object>> getClientCostDetailsList(TokenData tokenData, LocalDateTime startDay,
			LocalDateTime endDay) {
		List<Map<String, Object>> clientInvoiceCosts = new ArrayList<>();

		List<String> listOfPartnerOrgCode = documentCostInvoiceRepository
				.getPartnerOrgCodeForClient(tokenData.getOrgType(), tokenData.getUserOrgCode());
		for (String partnerOrgCode : listOfPartnerOrgCode) {
			List<DocumentCostInvoicerData> partnerDetailsForDocCostInvoice = documentCostInvoiceRepository
					.documentCostInvoiceDataForClient(partnerOrgCode, startDay, endDay);
			if (partnerDetailsForDocCostInvoice.isEmpty())
				continue;
			String totalCost = getTotalCostOfPartner(partnerDetailsForDocCostInvoice);
			Map<String, Object> invoiceDetailByKey = partnerDataforPdfGeneration(tokenData,
					partnerDetailsForDocCostInvoice, totalCost, startDay, endDay);
			clientInvoiceCosts.add(invoiceDetailByKey);
		}
		return clientInvoiceCosts;
	}

	private List<DocumentCostInvoicerData> getPartnerCostDetailsList(TokenData tokenData, LocalDateTime startDay,
			LocalDateTime endDay) {
		List<DocumentCostInvoicerData> partnerDocCostInvoiceDatas = new ArrayList<>();

		List<DocumentCostInvoicerData> documentCostInvoiceDataForClientList = documentCostInvoiceRepository
				.documentCostInvoiceDataForClient(tokenData.getUserOrgCode(), startDay, endDay);
		partnerDocCostInvoiceDatas.addAll(documentCostInvoiceDataForClientList);
		return partnerDocCostInvoiceDatas;
	}

	private List<Map<String, Object>> getEquabliCostDetailsList(TokenData tokenData, LocalDateTime startDay,
			LocalDateTime endDay) {
		List<Map<String, Object>> equabliInvoiceCosts = new ArrayList<>();

		List<String> listOfPartnerOrgCode = documentCostInvoiceRepository
				.getPartnerOrgCodeForEquabli(tokenData.getOrgType(), tokenData.getUserOrgCode());
		for (String partnerOrgCode : listOfPartnerOrgCode) {
			List<DocumentCostInvoicerData> partnerDetailsForDocCostInvoice = documentCostInvoiceRepository
					.documentCostInvoiceDataForClient(partnerOrgCode, startDay, endDay);
			if (partnerDetailsForDocCostInvoice.isEmpty())
				continue;
			String totalCost = getTotalCostOfPartner(partnerDetailsForDocCostInvoice);
			Map<String, Object> invoiceDetailByKey = partnerDataforPdfGeneration(tokenData, partnerDetailsForDocCostInvoice,
					totalCost, startDay, endDay);
			equabliInvoiceCosts.add(invoiceDetailByKey);
		}
		return equabliInvoiceCosts;
	}

	private Map<String, Object> invoiceDataforPdfGeneration(TokenData tokenData, List<Map<String, Object>> lists,
			String totalCost, LocalDateTime startDay, LocalDateTime endDay) {
		Map<String, Object> dataMap = new LinkedHashMap<>();
		dataMap.put(InvoiceDataConstants.ORG_NAME, tokenData.getUserOrgName());
		dataMap.put(InvoiceDataConstants.ORG_CODE, tokenData.getUserOrgCode());
		dataMap.put(InvoiceDataConstants.ORG_TYPE, tokenData.getOrgType());
		dataMap.put(InvoiceDataConstants.INVOICE_START_DATE, DateUtils.dateFormateForinvoice(startDay));
		dataMap.put(InvoiceDataConstants.INVOICE_END_DATE, DateUtils.dateFormateForinvoice(endDay));
		dataMap.put(InvoiceDataConstants.CLIENT_INVOICE_DATA, lists);
		dataMap.put(InvoiceDataConstants.TOTAL_AMOUNT_PAY, totalCost);
		return dataMap;
	}

	private Map<String, Object> partnerDataforPdfGeneration(TokenData tokenData,
			List<DocumentCostInvoicerData> docCostInvoiceDatas, String totalCost,LocalDateTime startDay, LocalDateTime endDay) {
		docCostInvoiceDatas.forEach(l -> {
			l.setFullfillDate(DateUtils.convertDateTOMMMMDDYYYY(l.getFullfillmentDate()));
			l.setFileSize(Util.getSize(l.getSize()));
		});
		
		Map<String, Object> dataMap = new LinkedHashMap<>();
		dataMap.put(InvoiceDataConstants.ORG_NAME, tokenData.getUserOrgName());
		dataMap.put(InvoiceDataConstants.ORG_CODE, tokenData.getUserOrgCode());
		dataMap.put(InvoiceDataConstants.ORG_TYPE, tokenData.getOrgType());
		dataMap.put(InvoiceDataConstants.PT_INVOICE_START_DATE, DateUtils.dateFormateForinvoice(startDay));
		dataMap.put(InvoiceDataConstants.PT_INVOICE_END_DATE, DateUtils.dateFormateForinvoice(endDay));
		dataMap.put(InvoiceDataConstants.PARTNER_NAME, docCostInvoiceDatas.get(0).getPartnerName());
		dataMap.put(InvoiceDataConstants.PARTNER_ID, docCostInvoiceDatas.get(0).getPartnerId());
		dataMap.put(InvoiceDataConstants.PARTNER_TOTAL_COST, totalCost);
		dataMap.put(InvoiceDataConstants.PARTNER_INVOICE_DATA, docCostInvoiceDatas);
		return dataMap;
	}

	private String getTotalCostOfPartner(List<DocumentCostInvoicerData> docCostInvoiceDatas) {
		docCostInvoiceDatas.forEach(data -> {
			data.setPartnerCost(
					new BigDecimal(Float.toString(data.getCost())).setScale(2, RoundingMode.HALF_UP).toString());
		});
		return docCostInvoiceDatas.stream().map(x -> new BigDecimal(Float.toString(x.getCost())))
				.reduce(BigDecimal.ZERO, BigDecimal::add).setScale(2, RoundingMode.HALF_UP).toString();
	}

	private String getTotalCostOfClient(List<Map<String, Object>> list) {
		return list.stream().map(x -> new BigDecimal(x.get("totalCost").toString()))
				.reduce(BigDecimal.ZERO, BigDecimal::add).setScale(2, RoundingMode.HALF_UP).toString();
	}
}
