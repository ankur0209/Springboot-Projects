package com.equabli.documents.service.impl;

import static com.equabli.common.constants.NotificationConstant.BODY;
import static com.equabli.common.constants.NotificationConstant.DOCUMENT_TYPE;
import static com.equabli.common.constants.NotificationConstant.REQUEST_NOTIFICATIO_BODY_MESSAGE;
import static com.equabli.common.constants.NotificationConstant.SHARE_FILE_NOTIFICATIO_BODY_MESSAGE;
import static com.equabli.common.constants.NotificationConstant.SHARE_FOLDER_NOTIFICATIO_BODY_MESSAGE;
import static com.equabli.common.constants.NotificationConstant.TYPE;
import static com.equabli.common.constants.NotificationConstant.DOCUMENT_REQUEST;
import static com.equabli.common.constants.NotificationConstant.SHARE_DOCUMENT;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.equabli.common.auth.TokenData;
import com.equabli.common.constants.MessageConstants;
import com.equabli.common.entity.DocType;
import com.equabli.common.entity.SendReceiveDocument;
import com.equabli.common.enums.DocumentShareTypeEnum;
import com.equabli.common.exception.InvalidArgumentException;
import com.equabli.common.feignclients.CommonConfigService;
import com.equabli.common.repository.DocTypeRepository;
import com.equabli.common.request.EmailRequest;
import com.equabli.common.request.NotificationRequest;
import com.equabli.common.request.ShareUserDetailRequest;
import com.equabli.common.response.UserDetailResponse;
import com.equabli.common.response.UserDetails;
import com.equabli.common.response.UserMailResponse;
import com.equabli.common.utils.MessageSupplier;
import com.equabli.documents.feignclient.SentMail;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AsyncServiceImpl {

	@Value("${user.not.exists.mail-template.name}")
	private String userNotExistTemplate;

	@Value("${user.exists.mail-template.name}")
	private String userExistTemplate;

	@Value("${share.document.mail-template.name}")
	private String shareDocumentTemplate;

	@Autowired
	SentMail sentMail;

	@Autowired
	MessageSupplier messageSupplier;

	@Autowired
	CommonConfigService configService;

	@Autowired
	DocTypeRepository docTypeRepository;

	private static final String SUBJECT = "Document Requested for Client Account Number : ";
	private static final String SHARE_DOC_SUB = "Share Document for Client Account Number : ";
	private static final String ACCOUNT = "account";
	private static final String FILE = "FILE";
	private static final String SHARE_DOCUMENT_TITLE = "share document";

	@Async
	public void sentEmailToUsers(String authorization, UserMailResponse userMailResponse, DocType docType,
			String clientAccountNumber, TokenData tokenData) {

		List<EmailRequest> emailRequests = new ArrayList<>();

		for (UserDetailResponse userDetailResponse : userMailResponse.getResponse()) {
			if (BooleanUtils.isTrue(userDetailResponse.getIsExists())) {

				UserDetails userDetail = userDetailResponse.getUserDetails();
				log.info("EXISTS USER DETAIL -> {}", userDetail);

				HashMap<String, Object> parameters = setMailData(tokenData, docType, clientAccountNumber);

				emailRequests.add(EmailRequest.builder().recipients(Arrays.asList(userDetail.getEmailAddress()))
						.subject(SUBJECT + clientAccountNumber).parameters(parameters).templateName(userExistTemplate)
						.build());
			} else {
				log.info("NOT EXISTS USER DETAIL -> {}", userDetailResponse);

				HashMap<String, Object> parameters = setMailData(tokenData, docType, clientAccountNumber);

				emailRequests.add(EmailRequest.builder().recipients(Arrays.asList(userDetailResponse.getMailId()))
						.subject(SUBJECT + clientAccountNumber).parameters(parameters)
						.templateName(userNotExistTemplate).build());
			}
		}

		String mailResponse = sentMail.sendEmails(authorization, emailRequests);
		log.info("mailResponse -> {}", mailResponse);
	}

	private HashMap<String, Object> setMailData(TokenData tokenData, DocType docType, String clientAccountNumber) {
		HashMap<String, Object> parameters = new HashMap<>();
		parameters.put("name", tokenData.getFirstName());
		parameters.put("docTypeCode", docType.getShortCode());
		parameters.put("documentType", docType.getName());
		parameters.put("clientAccountNumber", clientAccountNumber);
		parameters.put("userOrgName", tokenData.getUserOrgName());
		return parameters;
	}

	public void shareDocumentEmailToUser(TokenData tokenData, DocType docType, String clientAccountNumber,
			List<ShareUserDetailRequest> shareDetail, String authorization) {
		List<EmailRequest> emailRequests = new ArrayList<>();
		for (ShareUserDetailRequest userDetailRequest : shareDetail) {
			HashMap<String, Object> parameters = setMailData(tokenData, docType, clientAccountNumber);
			emailRequests.add(EmailRequest.builder().recipients(Arrays.asList(userDetailRequest.getEmail()))
					.subject(SHARE_DOC_SUB + clientAccountNumber).parameters(parameters)
					.templateName(shareDocumentTemplate).build());
		}

		String mailResponse = sentMail.sendEmails(authorization, emailRequests);
		log.info("mailResponse -> {}", mailResponse);
	}

	/********
	 * Start Notification part
	 * 
	 * @param userId
	 ********/

	/**
	 * Send notification for upload document request
	 * 
	 * @param tokenData
	 * @param sendReceiveDocument
	 * @param authorization
	 * @param title
	 * @param token
	 */
	public void sentNotificationToUsers(TokenData tokenData, SendReceiveDocument sendReceiveDocument,
			String authorization, String title) {
		String message = messageSupplier.get(REQUEST_NOTIFICATIO_BODY_MESSAGE, tokenData.getFirstName(),
				tokenData.getUserOrgCode(), sendReceiveDocument.getDocumentType(),
				sendReceiveDocument.getClientAccountNo());
		Map<String, Object> notificationData = new LinkedHashMap<>();
		notificationData.put("from", sendReceiveDocument.getRequestedBy());
		notificationData.put("to", sendReceiveDocument.getRequestedTo());
		saveNotificationData(sendReceiveDocument.getClientAccountNo(), DOCUMENT_REQUEST, message, notificationData,
				sendReceiveDocument.getDocTypeCode());
		sendNotification(sendReceiveDocument.getReceiveRequestUserId(), sendReceiveDocument.getReceiveRequestOrgCode(),
				sendReceiveDocument.getReceiveRequestOrgTypeCode(), notificationData, message, authorization, title);
	}

	/**
	 * Send notification for share document.
	 * 
	 * @param tokenData
	 * @param shareBy
	 * @param authorization
	 * @param title
	 * @param shareWith
	 * @param shareDetail
	 * @param type
	 */
	public void shareDocumentNotification(TokenData tokenData, String authorization, String shareWith,
			List<ShareUserDetailRequest> shareDetail, DocumentShareTypeEnum type, String accountNo,
			String docTypeCode) {

		for (ShareUserDetailRequest shareUserRequest : shareDetail) {
			Map<String, Object> notificationData = new LinkedHashMap<>();
			notificationData.put("from", tokenData.getFirstName());
			notificationData.put("to", shareWith);
			String message = null;
			if (FILE.equals(type.name()))
				message = messageSupplier.get(SHARE_FILE_NOTIFICATIO_BODY_MESSAGE, tokenData.getFirstName(),
						tokenData.getUserOrgCode(), type, getDocType(docTypeCode).getName(), accountNo);
			else
				message = messageSupplier.get(SHARE_FOLDER_NOTIFICATIO_BODY_MESSAGE, tokenData.getFirstName(),
						tokenData.getUserOrgCode(), type, accountNo);

			saveNotificationData(accountNo, SHARE_DOCUMENT, message, notificationData, docTypeCode);
			sendNotification(shareUserRequest.getPrincipleId(), shareUserRequest.getUserOrgCode(),
					shareUserRequest.getOrgType(), notificationData, message, authorization,SHARE_DOCUMENT_TITLE);
		}
	}

	private void sendNotification(Long userId,String orgCode,String orgType, Map<String, Object> notificationData,
			String message, String authorization, String title) {
		NotificationRequest notificationRequests = NotificationRequest.builder()
				.userId(userId).orgCode(orgCode)
				.orgTypeCode(orgType).title(title).message(message)
				.dataMap(notificationData).build();
		String response = sentMail.sendNotification(authorization, notificationRequests);
		log.info("", response);
	}
	
	private Map<String, Object> saveNotificationData(String clientAccountNo, String type, String bodyMessage,
			Map<String, Object> parameters, String docTypeCode) {
		parameters.put(TYPE, type);
		parameters.put(ACCOUNT, clientAccountNo);
		parameters.put(BODY, bodyMessage);
		parameters.put(DOCUMENT_TYPE, StringUtils.isEmpty(docTypeCode) ? "" : getDocType(docTypeCode).getName());
		return parameters;
	}
	

	private DocType getDocType(String docTypeCode) {
		return docTypeRepository.findByShortCode(docTypeCode).orElseThrow(() -> new InvalidArgumentException(
				messageSupplier.get(MessageConstants.NOT_VALID_SHORT_CODE, docTypeCode)));
	}
}
