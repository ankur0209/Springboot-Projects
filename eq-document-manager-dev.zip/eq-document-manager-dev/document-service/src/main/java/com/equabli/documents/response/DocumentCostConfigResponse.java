package com.equabli.documents.response;

import com.equabli.common.entity.DocCost;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;

@Getter
@Schema(description = "Fetch saved docuemnt cost configuration for partner or thir party organization type")
public class DocumentCostConfigResponse {

	@Schema(description = "Type of document", example = "Application")
	private String documentType;
	
	@Schema(description = "Short code of document type", example = "AP")
	private String docTypeCode;
	
	@Schema(description = "Name of client", example = "client name")
	private String clientName;
	
	@Schema(description = "Cost of document", example = "10")
	private Float cost;
	
	public DocumentCostConfigResponse(DocCost docCost) {
		this.docTypeCode = docCost.getDocTypeCode();
		this.documentType = docCost.getDocType().getName();
		this.clientName = docCost.getOrgName();
		this.cost = docCost.getCost();
	}
}
