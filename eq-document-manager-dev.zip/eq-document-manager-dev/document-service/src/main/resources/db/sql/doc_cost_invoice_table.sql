CREATE TABLE IF NOT EXISTS data.document_cost_invoice
(
    document_cost_invoice_uid uuid NOT NULL,
    client_org_type_code character varying(2) COLLATE pg_catalog."default",
    client_org_code character varying(10) COLLATE pg_catalog."default",
    partner_org_type_code character varying(2) COLLATE pg_catalog."default",
    partner_org_code character varying(10) COLLATE pg_catalog."default",
    action_by_user_id bigint,
    action_by_org_type_code character varying(2),
    action_by_org_code character varying(10),
    doc_type_code character varying(10) COLLATE pg_catalog."default",
    doc_cost real,
    dtm_utc_create timestamp with time zone,
    dtm_utc_update timestamp with time zone,
    dtm_utc_delete timestamp with time zone,
    created_by character varying(50) COLLATE pg_catalog."default",
    updated_by character varying(50) COLLATE pg_catalog."default",
    deleted_by character varying(50) COLLATE pg_catalog."default",
    record_source_code character varying(10) COLLATE pg_catalog."default",
    record_status_code character varying(10) COLLATE pg_catalog."default",
    ip_address character varying(255) COLLATE pg_catalog."default",
    mac_address character varying(255) COLLATE pg_catalog."default",
    app_code character varying(10) COLLATE pg_catalog."default",
    is_delete boolean,
	doc_size bigint,
    send_receive_document_id bigint,
    CONSTRAINT document_cost_invoice_pkey PRIMARY KEY (document_cost_invoice_uid),
    CONSTRAINT fkey_send_receive_document_id_document_cost_invoice FOREIGN KEY (send_receive_document_id)
        REFERENCES data.send_receive_document (send_receive_document_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);