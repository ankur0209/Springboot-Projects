ALTER TABLE data.document  
ADD COLUMN client_org_code VARCHAR(10);