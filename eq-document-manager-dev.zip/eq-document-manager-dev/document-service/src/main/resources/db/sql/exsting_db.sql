CREATE TABLE conf.record_status (
    record_status_id smallint NOT NULL,
    short_name character varying(15),
    description character varying(200),
    dtm_utc_create timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    created_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    dtm_utc_update timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    updated_by character varying(50) DEFAULT CURRENT_USER NOT NULL
);

insert into conf.record_status (record_status_id,	short_name,	description)
values (1,'RAW','Record as Arrived from Client'),
(1,'RAW','Record as Arrived from Client'),
(2,'Cleaning','Record is in staging and cleaning is in progress'),
(3,'Suspected','Record is in suspected stage'),
(4,'Orphaned','References are missing for this Record'),
(5,'Enabled','Can be used for new record'),
(6,'Disabled','Can not be used for new records, however will be used to show the status of the record'),
(7,'Deleted','Can not be used for new records, and will filter out the associated records from all views,reports etc..'),
(8,'Started','Can be used for new record'),
(9,'InProgress','Can be used for new record'),
(10,'Completed','Can be used for new record');

CREATE TABLE conf.record_source (
    record_source_id smallint NOT NULL,
    short_name character varying(15),
    description character varying(200),
    dtm_utc_create timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    created_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    dtm_utc_update timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    updated_by character varying(50) DEFAULT CURRENT_USER NOT NULL
);


CREATE TABLE conf.client (
    client_id integer NOT NULL,
    short_name character varying(5),
    full_name character varying(50),
    client_type character varying(50),
    poc_name character varying(50),
    address1 character varying(100),
    address2 character varying(100),
    city character varying(50),
    zip character varying(10),
    phone1 character varying(15),
    phone2 character varying(15),
    email_address character varying(50),
    record_status_id smallint DEFAULT 5 NOT NULL,
    dtm_utc_create timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    created_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    dtm_utc_update timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    updated_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    record_source_id smallint DEFAULT 3,
    app_id smallint DEFAULT 1,
    ip_address character varying(255),
    mac_address character varying(255),
    state_code character varying(2),
    website character varying(25),
    quicksight_id integer,
    is_masterserviced boolean DEFAULT false
);



CREATE TABLE conf.partner (
    partner_id integer NOT NULL,
    short_name character varying(5),
    full_name character varying(50) NOT NULL,
    address1 character varying(100),
    address2 character varying(100),
    city character varying(50),
    zip character varying(10),
    email_address character varying(50),
    phone1 character varying(15),
    phone2 character varying(15),
    poc_name character varying(50),
    amt_min_coll_limit numeric(13,2),
    amt_max_coll_limit numeric(13,2),
    servicetype_id smallint,
    record_status_id smallint DEFAULT 5,
    dtm_utc_create timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    created_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    dtm_utc_update timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    updated_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    record_source_id smallint DEFAULT 3,
    app_id smallint DEFAULT 1,
    ip_address character varying(255),
    mac_address character varying(255),
    state_code character varying(2),
    website character varying(25),
    quicksight_id integer,
    name_pronunciation character varying(100),
    email_pronunciation character varying(100),
    phone_pronunciation character varying(50),
    address_pronunciation character varying(500),
    is_eqassociate boolean DEFAULT true
);



CREATE TABLE conf.map_clientpartner (
    map_clientpartner_id integer NOT NULL,
    client_id integer NOT NULL,
    partner_id integer NOT NULL,
    partner_type character varying(2) NOT NULL,
    external_system_id integer,
    record_status_id smallint DEFAULT 5,
    dtm_utc_create timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    created_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    dtm_utc_update timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    updated_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    record_source_id smallint DEFAULT 3,
    app_id smallint DEFAULT 1,
    ip_address character varying(255),
    mac_address character varying(255)
);


CREATE TABLE conf.app_role (
    app_role_id smallint NOT NULL,
    short_name character varying(5) NOT NULL,
    full_name character varying(50) NOT NULL,
    description character varying(200),
    record_status_id smallint,
    dtm_utc_create timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    created_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    dtm_utc_update timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    updated_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    record_source_id smallint,
    app_id smallint,
    ip_address character varying(255),
    mac_address character varying(255)
);

insert into conf.app_role(app_role_id, short_name,full_name,description)
values (2,'EXECT','Executive','Read-Write LoginCan raise request for create,change any recrod, can view less sensitive information'),
(3,'CNSLT','Consultant','Limited access over the application'),
(4,'APRVR','Approver','Read Only Login, , can view all information, Approve Requests '),
(5,'AUDTR','Auditor','Read Only Login, mostly historical data'),
(6,'MANGR','Manager','Read Login, Can change his personal information, can view all information'),
(7,'GUEST','Guest','Read-Only Login, Can change his personal information, can not view sensitive information'),
(9,'AWIGT','All Widget Reader','Can view all widget');



CREATE TABLE auth.principle (
    principle_id bigint NOT NULL,
    uid uuid DEFAULT gen_random_uuid(),
    login_key character varying(50) NOT NULL,
    login_secret character varying(128),
    first_name character varying(50) NOT NULL,
    middle_name character varying(50) DEFAULT ''::character varying,
    last_name character varying(50) DEFAULT ''::character varying,
    email_address character varying(50) NOT NULL,
    is_email_consent boolean DEFAULT false,
    dtm_email_consent timestamp without time zone,
    phone character varying(15) DEFAULT ''::character varying,
    is_phone_consent boolean DEFAULT false,
    dtm_phone_consent timestamp without time zone,
    address1 character varying(100) NOT NULL,
    address2 character varying(100) DEFAULT ''::character varying,
    city character varying(50) DEFAULT ''::character varying,
    state character varying(2) DEFAULT ''::character varying,
    country character varying(30) DEFAULT ''::character varying,
    zip character varying(10) DEFAULT ''::character varying,
    orgtype character varying(2) DEFAULT 'EQ'::character varying NOT NULL,
    client_id integer,
    partner_id integer,
    authtype character varying(2) DEFAULT 'RO'::character varying NOT NULL,
    dtm_password_set timestamp without time zone,
    count_login_attempt integer DEFAULT 0,
    dtm_successful_login timestamp without time zone,
    dtm_password_reset timestamp without time zone,
    count_failed_attempt integer DEFAULT 0,
    dtm_failed_attempt timestamp without time zone,
    dtm_lock timestamp without time zone,
    dtm_lock_reset timestamp without time zone,
    record_status_id smallint DEFAULT 1,
    dtm_utc_create timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    created_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    dtm_utc_update timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    updated_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    record_source_id smallint DEFAULT 3,
    app_id smallint DEFAULT 1,
    ip_address character varying(255),
    mac_address character varying(255),
    accesskey character varying(128),
    app_role_id integer DEFAULT 7);	
	
	
	CREATE TABLE auth.secret_answer (
    secret_answer_id bigint NOT NULL,
    principle_id bigint NOT NULL,
    question character varying(2) NOT NULL,
    answer character varying(256) NOT NULL,
    record_status_id smallint DEFAULT 5 NOT NULL,
    dtm_utc_create timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    created_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    dtm_utc_update timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    updated_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    record_source_id smallint DEFAULT 3,
    app_id smallint DEFAULT 1,
    ip_address character varying(255),
    mac_address character varying(255)
);


CREATE TABLE conf.product (
    product_id bigint NOT NULL,
    short_name character varying(5),
    full_name character varying(50),
    description character varying(200) NOT NULL,
    debtcategory_id smallint,
    record_status_id smallint DEFAULT 5,
    dtm_utc_create timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    created_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    dtm_utc_update timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    updated_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    record_source_id smallint DEFAULT 3,
    app_id smallint DEFAULT 1,
    ip_address character varying(255),
    mac_address character varying(255),
    scrubtype smallint DEFAULT 0,
    
    dtm_utc_delete timestamp with time zone,
    deleted_by character varying(50),
    is_active boolean,
    is_delete boolean
);


insert into  conf.product(product_id,short_name,full_name,description,debtcategory_id,created_by,scrubtype)
values
('10','DD','Direct Deposit Account','Direct Deposit Account','2','postgres',0),
('11','RL','Revolving Line of Credit ','Revolving Line of Credit ','4','postgres',0),
('12','MG','Mortgage','Mortgage','2','postgres',0),
('13','LO','Lease to Own','Lease to Own','2','postgres',0),
('14','RO','Rent to Own','Rent to Own','2','postgres',0),
('15','BP','Buy Now Pay Later','Buy Now Pay Later','2','postgres',0),
('16','MT','Money Transfer Account','Money Transfer Account','2','postgres',0),
('1','CC','Credit Card','credit card','4','postgres',0),
('2','UD','Utility Debt','utility bill','2','postgres',0),
('3','CL','Consumer Loan','Consumer Loan ','2','postgres',0),
('4','TL','Telecom','Telecom','2','postgres',0),
('5','ML','Medical','Medical','2','postgres',0),
('6','HC','Healthcare','Healthcare','2','postgres',0),
('7','MD','Municipal Debt','Municipal Debt','2','postgres',0),
('8','AL','Auto Loan','Auto Loan','2','postgres',0),
('9','DC','Debit Card','Debit Card','2','postgres',0),
('17','SL','Student Loan','Student Loan','2','postgres',0),
('18','DP','Donate Now Pay Later','Donate Now Pay Later','2','postgres',0),
('19','HE','HELOC','HELOC','2','postgres',0);


