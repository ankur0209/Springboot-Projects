ALTER TABLE data.share_with ADD COLUMN share_with_org_type_code character varying(2);
ALTER TABLE data.share_with ADD COLUMN share_with_user_org_code character varying(50);