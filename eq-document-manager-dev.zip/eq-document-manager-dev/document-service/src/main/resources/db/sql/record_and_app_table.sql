CREATE TABLE conf.record_status (
    record_status_id smallint NOT NULL,
	short_code  character varying(10),
    short_name character varying(15),
    description character varying(200),
    dtm_utc_create timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    created_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    dtm_utc_update timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    updated_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    CONSTRAINT record_status_pkey PRIMARY KEY (record_status_id)
);
INSERT INTO conf.record_status(
	record_status_id, short_code, short_name, description)
	VALUES (1, 'RS_RAW', 'RAW', 'Record as Arrived from Client'),
	(2, 'RS_CLEAN', 'Cleaning', 'Record is in staging and cleaning is in progress'),
	(3, 'RS_SUSPECT', 'Suspected', 'Record is in suspected stage'),
	(4, 'RS_ORPHAN', 'Orphaned', 'References are missing for this Record'),
	(5, 'RS_ENABLE', 'Enabled', 'Can be used for new record'),
	(6, 'RS_DISABLE', 'Disabled', 'Can not be used for new records\, however will be used to show the status of the record'),
	(7, 'RS_START', 'Started', 'Can be used for new record'),
	(8, 'RS_INPROG', 'InProgress', 'Can be used for new record'),
	(9, 'RS_COMPLT', 'Completed', 'Can be used for new record'),
	(10, 'RS_INCLUDE', 'Include', 'Can be used for new record'),
	(11, 'RS_EXCLUDE', 'Exclude', 'Can be used for new record'),
	(12, 'RS_REQUEST', 'Requested', 'Account Servicing Request'),
	(13, 'RS_APPROVE', 'Approved', 'Account Servicing Request'),
	(14, 'RS_REJECT', 'Rejected', 'Account Servicing Request'),
	(15, 'RS_CANCEL', 'Cancelled', 'Account Servicing Request'),
	(16, 'RS_SUCCESS', 'Successful', 'Can be used when batch is successfully executed'),
	(17, 'RS_FAIL', 'Failed', 'Can be used when batch is Failed or not executed'),
	(18, 'RS_MAILST', 'Mail Sent', 'Can be used when email is sent'),
	(19, 'RS_MAILNST', 'Mail Not sent', 'Can be used when email is not sent'),
	(20, 'RS_PARTIAL', 'Partial Success', 'Successful Partially\, Can be used for background automated process');
	
CREATE TABLE conf.record_source (
    record_source_id smallint NOT NULL,
	short_code character varying(10),
    short_name character varying(15),
    description character varying(200),
    dtm_utc_create timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    created_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    dtm_utc_update timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    updated_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    CONSTRAINT record_source_pkey PRIMARY KEY (record_source_id)
);
INSERT INTO conf.record_source(
	record_source_id, short_code, short_name, description)
	VALUES (1, 'ECP-DM', 'Document Mgr', 'Data prepared by Equabli Document manager');
	
CREATE TABLE conf.app (
    app_id smallint NOT NULL,
    short_code character varying(10),
	short_name character varying(15),
    description character varying(200),
    dtm_utc_create timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    created_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    dtm_utc_update timestamp without time zone DEFAULT timezone('utc'::text, CURRENT_TIMESTAMP) NOT NULL,
    updated_by character varying(50) DEFAULT CURRENT_USER NOT NULL,
    CONSTRAINT app_pkey PRIMARY KEY (app_id)
);
INSERT INTO conf.app(app_id, short_code, short_name, description)
	VALUES (1, 'ECP-WEB', 'ECP-WEB', 'Equabli Web Application'),
	(2, 'ECP-BAT', 'ECP-BAT', 'Equabli Automated Batch Process');	
	