CREATE TABLE conf.lookup_group
(
    lookup_group_uid uuid NOT NULL DEFAULT gen_random_uuid(),
    keyvalue character varying(50),
    description character varying(200),
    is_business_function boolean,

    dtm_utc_create timestamp with time zone,
    dtm_utc_update timestamp with time zone,
    dtm_utc_delete timestamp with time zone,
    created_by character varying(50),
    updated_by character varying(50),
    deleted_by character varying(50),
    record_source_code character varying(10),
    record_status_code character varying(10),
    ip_address  character varying(255),
    mac_address character varying(255),
    app_code character varying(10),
    is_delete boolean,

    CONSTRAINT pk_conf_lookup_group_uid PRIMARY KEY (lookup_group_uid)
);

CREATE TABLE conf.lookup
(
    lookup_uid uuid NOT NULL DEFAULT gen_random_uuid(),
    lookup_group_uid uuid NOT NULL,
    group_sequence smallint,
    keycode character varying(2),
    keyvalue character varying(50),
    description character varying(200),
    scrubtype smallint DEFAULT 0,

   	dtm_utc_create timestamp with time zone,
    dtm_utc_update timestamp with time zone,
    dtm_utc_delete timestamp with time zone,
    created_by character varying(50),
    updated_by character varying(50),
    deleted_by character varying(50),
    record_source_code character varying(10),
    record_status_code character varying(10),
    ip_address  character varying(255),
    mac_address character varying(255),
    app_code character varying(10),
    is_delete boolean,

    CONSTRAINT pk_conf_lookup_uid PRIMARY KEY (lookup_uid),
    CONSTRAINT fk_conf_lookup_lookup_group_uid FOREIGN KEY (lookup_group_uid)
        REFERENCES conf.lookup_group (lookup_group_uid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

-- Add lookup_uid in usage table
ALTER TABLE data.usage ADD COLUMN lookup_uid uuid;
ALTER TABLE data.usage ADD CONSTRAINT fk_conf_lookup_lookup_uid FOREIGN KEY (lookup_uid)
        REFERENCES conf.lookup (lookup_uid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION;

-- Insert subcription values into lookup_group
INSERT INTO conf.lookup_group(
	keyvalue, description, dtm_utc_create, dtm_utc_update, created_by, updated_by, is_delete)
	VALUES ('subscription_type', 'subscription_type', NOW(), NOW(), current_user, current_user, false);

-- Insert subcription values into lookup
INSERT INTO conf.lookup(
	lookup_group_uid, 
	group_sequence, keycode, keyvalue, description, dtm_utc_create, dtm_utc_update, created_by, updated_by, is_delete)
	VALUES ( (select lg.lookup_group_uid FROM conf.lookup_group AS lg WHERE lg.keyvalue = 'subscription_type'), 
				1, 'BT', '15 GB', 'Basic Tier', NOW(), NOW(), current_user, current_user, false),
			((select lg.lookup_group_uid FROM conf.lookup_group AS lg WHERE lg.keyvalue = 'subscription_type'), 
				2, 'ST', '50 GB', 'Standard Tier', NOW(), NOW(), current_user, current_user, false),
			((select lg.lookup_group_uid FROM conf.lookup_group AS lg WHERE lg.keyvalue = 'subscription_type'), 
				3, 'PT', '100 GB', 'Premium Tier', NOW(), NOW(), current_user, current_user, false);
			
-- Remove subscription_id from usage table
ALTER TABLE data.usage DROP COLUMN subscription_id;
			