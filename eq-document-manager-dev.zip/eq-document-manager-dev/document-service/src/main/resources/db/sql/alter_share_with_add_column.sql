ALTER TABLE data.share_with  
ADD COLUMN share_with_name VARCHAR(255);